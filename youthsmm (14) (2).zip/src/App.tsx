import React, { useState, useEffect } from 'react';
import { LoginPage } from './components/LoginPage';
import { UserDashboard } from './components/UserDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { User } from './types';
import { RefreshCw } from 'lucide-react';
import { AnimatedLogo } from './components/AnimatedLogo';
import { broadcastAdminChange } from './lib/api';

export default function App() {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('youthsmm_token'));
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [view, setView] = useState<'user' | 'admin'>('user');

  // Verify and fetch user profile (supports quiet background refreshes)
  const fetchUserProfile = async (authToken: string, showLoadingIndicator = false) => {
    try {
      if (showLoadingIndicator) {
        setLoading(true);
      }
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        const isAdmin =
          data.user?.role === 'admin' ||
          (data.user?.email || '').includes('bhattg805');

        // If admin, default view can be admin or user
        if (isAdmin && !localStorage.getItem('youthsmm_last_view')) {
          setView('admin');
        }
      } else {
        // Token expired or invalid
        localStorage.removeItem('youthsmm_token');
        setToken(null);
        setUser(null);
      }
    } catch (err) {
      console.warn('Failed to verify session (offline or network error):', err);
    } finally {
      if (showLoadingIndicator) {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    if (token) {
      fetchUserProfile(token, true);
    } else {
      setLoading(false);
    }
  }, [token]);

  const handleLoginSuccess = (newToken: string, loggedUser: User) => {
    setToken(newToken);
    setUser(loggedUser);
    const isAdmin =
      loggedUser.role === 'admin' ||
      (loggedUser.email || '').includes('bhattg805');
    setView(isAdmin ? 'admin' : 'user');
  };

  const handleLogout = () => {
    localStorage.removeItem('youthsmm_token');
    localStorage.removeItem('youthsmm_last_view');
    setToken(null);
    setUser(null);
    fetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F8F4EA] text-stone-900 flex flex-col items-center justify-center space-y-4">
        <AnimatedLogo size="lg" showText={true} theme="light" />
        <div className="flex items-center space-x-2 text-xs text-stone-500 font-mono">
          <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#DC2626]" />
          <span>Connecting to YouthSMM...</span>
        </div>
      </div>
    );
  }

  // Not logged in -> Show Login Page
  if (!token || !user) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  // Logged in as Admin & viewing Admin Panel
  if (view === 'admin' && (user.role === 'admin' || (user.email || '').includes('bhattg805'))) {
    return (
      <AdminDashboard
        user={user}
        token={token}
        onLogout={handleLogout}
        onSwitchToUser={() => {
          broadcastAdminChange();
          localStorage.setItem('youthsmm_last_view', 'user');
          fetchUserProfile(token);
          setView('user');
        }}
      />
    );
  }

  // Logged in as User (or Admin viewing User Panel)
  return (
    <UserDashboard
      user={user}
      token={token}
      onLogout={handleLogout}
      onSwitchToAdmin={() => {
        localStorage.setItem('youthsmm_last_view', 'admin');
        fetchUserProfile(token);
        setView('admin');
      }}
      onRefreshUser={() => fetchUserProfile(token)}
    />
  );
}
