import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Gift,
  Sparkles,
  Zap,
  Flame,
  Tag,
  Wallet,
  X,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  MessageCircle,
} from 'lucide-react';
import { DashboardBanner } from '../types';

interface UserPromoBannerProps {
  publicSettings: any;
  onNavigateTab: (tab: any) => void;
  isDarkMode?: boolean;
}

const THEME_STYLES: Record<string, { gradient: string; border: string; badge: string; shadow: string }> = {
  red: {
    gradient: 'from-[#DC2626] via-[#B91C1C] to-[#881337]',
    border: 'border-red-400/40',
    badge: 'text-red-100 bg-black/25 border-white/20',
    shadow: 'shadow-red-950/25',
  },
  purple: {
    gradient: 'from-purple-900 via-indigo-800 to-purple-700',
    border: 'border-purple-400/30',
    badge: 'text-purple-200 bg-purple-500/20 border-purple-400/30',
    shadow: 'shadow-purple-950/30',
  },
  emerald: {
    gradient: 'from-emerald-950 via-teal-900 to-emerald-800',
    border: 'border-emerald-400/30',
    badge: 'text-emerald-200 bg-emerald-500/20 border-emerald-400/30',
    shadow: 'shadow-emerald-950/30',
  },
  rose: {
    gradient: 'from-rose-950 via-red-900 to-rose-800',
    border: 'border-rose-400/30',
    badge: 'text-rose-200 bg-rose-500/20 border-rose-400/30',
    shadow: 'shadow-rose-950/30',
  },
  amber: {
    gradient: 'from-amber-950 via-orange-900 to-rose-900',
    border: 'border-amber-400/30',
    badge: 'text-amber-200 bg-amber-500/20 border-amber-400/30',
    shadow: 'shadow-amber-950/30',
  },
  blue: {
    gradient: 'from-blue-950 via-indigo-900 to-cyan-900',
    border: 'border-cyan-400/30',
    badge: 'text-cyan-200 bg-cyan-500/20 border-cyan-400/30',
    shadow: 'shadow-blue-950/30',
  },
  cyan: {
    gradient: 'from-cyan-950 via-teal-900 to-blue-900',
    border: 'border-cyan-400/30',
    badge: 'text-cyan-200 bg-cyan-500/20 border-cyan-400/30',
    shadow: 'shadow-cyan-950/30',
  },
  dark: {
    gradient: 'from-slate-950 via-gray-900 to-slate-900',
    border: 'border-gray-700/50',
    badge: 'text-gray-300 bg-white/10 border-white/20',
    shadow: 'shadow-black/40',
  },
};

const renderBannerIcon = (iconName?: string) => {
  switch (iconName) {
    case 'sparkles':
      return <Sparkles className="w-6 h-6 text-amber-300" />;
    case 'zap':
      return <Zap className="w-6 h-6 text-yellow-300" />;
    case 'flame':
      return <Flame className="w-6 h-6 text-orange-400" />;
    case 'tag':
      return <Tag className="w-6 h-6 text-emerald-300" />;
    case 'wallet':
      return <Wallet className="w-6 h-6 text-blue-300" />;
    case 'gift':
    default:
      return <Gift className="w-6 h-6 text-yellow-300" />;
  }
};

export const UserPromoBanner: React.FC<UserPromoBannerProps> = ({
  publicSettings,
  onNavigateTab,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const lastSettingsKeyRef = useRef<string>('');

  // Parse all banners
  const activeBanners: DashboardBanner[] = useMemo(() => {
    if (publicSettings?.dashboardBanners) {
      try {
        const parsed =
          typeof publicSettings.dashboardBanners === 'string'
            ? JSON.parse(publicSettings.dashboardBanners)
            : publicSettings.dashboardBanners;
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.filter((b: DashboardBanner) => b.status === 'enabled');
        }
      } catch (_) {}
    }

    // Fallback: single banner fields from settings
    if (publicSettings?.bannerStatus !== 'disabled') {
      const title = publicSettings?.bannerTitle || 'Special Deposit Bonus!';
      const badge = publicSettings?.bannerBadge || 'PROMO BONUS';
      const subtitle = publicSettings?.bannerSubtitle || 'Get instant 5% bonus on UPI deposits above ₹500 today.';
      const btnText = publicSettings?.bannerBtnText || '+ Add funds';
      const btnLink = publicSettings?.bannerBtnLink || 'add_funds';

      return [
        {
          id: 'default-promo-banner',
          status: 'enabled',
          badge,
          title,
          subtitle,
          btnText,
          btnLink,
          theme: 'red',
          icon: 'wallet',
        },
      ];
    }

    return [];
  }, [
    publicSettings?.dashboardBanners,
    publicSettings?.bannerStatus,
    publicSettings?.bannerTitle,
    publicSettings?.bannerBadge,
    publicSettings?.bannerSubtitle,
    publicSettings?.bannerBtnText,
    publicSettings?.bannerBtnLink,
  ]);

  // Reset dismissal if banners data changes (e.g. admin edited the promo)
  const settingsKey = useMemo(() => {
    return JSON.stringify({
      banners: publicSettings?.dashboardBanners,
      title: publicSettings?.bannerTitle,
      badge: publicSettings?.bannerBadge,
      status: publicSettings?.bannerStatus,
    });
  }, [
    publicSettings?.dashboardBanners,
    publicSettings?.bannerTitle,
    publicSettings?.bannerBadge,
    publicSettings?.bannerStatus,
  ]);

  useEffect(() => {
    if (lastSettingsKeyRef.current && lastSettingsKeyRef.current !== settingsKey) {
      setIsDismissed(false); // Un-dismiss when updated
      setCurrentIndex(0);
    }
    lastSettingsKeyRef.current = settingsKey;
  }, [settingsKey]);

  // Auto rotate banners if more than 1
  useEffect(() => {
    if (activeBanners.length <= 1 || isHovered || isDismissed) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
    }, 5500);

    return () => clearInterval(timer);
  }, [activeBanners.length, isHovered, isDismissed]);

  // Ensure currentIndex stays in range
  useEffect(() => {
    if (currentIndex >= activeBanners.length && activeBanners.length > 0) {
      setCurrentIndex(0);
    }
  }, [activeBanners.length, currentIndex]);

  if (isDismissed || activeBanners.length === 0) {
    return null;
  }

  const currentBanner = activeBanners[currentIndex] || activeBanners[0];
  const theme = THEME_STYLES[currentBanner.theme || 'purple'] || THEME_STYLES.purple;

  const handleActionClick = () => {
    const link = (currentBanner.btnLink || 'add_funds').trim();

    // 1. External URL
    if (link.startsWith('http://') || link.startsWith('https://')) {
      window.open(link, '_blank', 'noopener,noreferrer');
      return;
    }

    // 2. WhatsApp or Phone number (e.g., 8795005604 or +91...)
    const cleanNumber = link.replace(/[\s\-+()]/g, '');
    if (/^\d{10,14}$/.test(cleanNumber)) {
      const formatted = cleanNumber.length === 10 ? `91${cleanNumber}` : cleanNumber;
      window.open(`https://wa.me/${formatted}`, '_blank', 'noopener,noreferrer');
      return;
    }

    // 3. Known Internal Tabs
    const knownTabs = [
      'new_order',
      'services',
      'orders',
      'add_funds',
      'tickets',
      'affiliate',
      'api',
      'child_panels',
      'blogs',
      'faq',
      'support_channels',
      'terms',
    ];

    if (knownTabs.includes(link)) {
      onNavigateTab(link);
      return;
    }

    // Default tab
    onNavigateTab('add_funds');
  };

  const isWhatsAppLink = () => {
    const link = (currentBanner.btnLink || '').trim().replace(/[\s\-+()]/g, '');
    return /^\d{10,14}$/.test(link);
  };

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`relative overflow-hidden rounded-3xl bg-gradient-to-r ${theme.gradient} border ${theme.border} p-4 sm:p-6 text-white shadow-lg ${theme.shadow} transition-all duration-300 animate-fadeIn`}
    >
      {/* Decorative ambient glowing orbs */}
      <div className="absolute -right-12 -top-12 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -left-12 -bottom-12 w-48 h-48 bg-black/20 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
        {/* Left: Icon and Text Details */}
        <div className="flex items-start sm:items-center space-x-3 sm:space-x-4 min-w-0 flex-1 pr-8 sm:pr-0">
          <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 border border-white/25 shadow-inner">
            {renderBannerIcon(currentBanner.icon || 'wallet')}
          </div>
          <div className="min-w-0 flex-1">
            {currentBanner.badge && (
              <span
                className={`inline-block text-[9px] sm:text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border mb-1 backdrop-blur-xs ${theme.badge}`}
              >
                {currentBanner.badge}
              </span>
            )}
            <h2 className="text-base sm:text-lg font-black text-white leading-tight drop-shadow-xs truncate">
              {currentBanner.title}
            </h2>
            {currentBanner.subtitle && (
              <p className="text-[11px] sm:text-xs text-white/90 font-medium mt-0.5 line-clamp-2 leading-relaxed">
                {currentBanner.subtitle}
              </p>
            )}
          </div>
        </div>

        {/* Right: Action Button & Controls */}
        <div className="flex items-center space-x-2 w-full sm:w-auto justify-between sm:justify-end shrink-0 pt-1 sm:pt-0">
          {/* Carousel Next / Prev (only if multiple banners) */}
          {activeBanners.length > 1 && (
            <div className="flex items-center space-x-1 mr-1 bg-black/20 backdrop-blur-xs rounded-full p-1 border border-white/10">
              <button
                type="button"
                onClick={() =>
                  setCurrentIndex((prev) => (prev - 1 + activeBanners.length) % activeBanners.length)
                }
                title="Previous Banner"
                className="w-6 h-6 rounded-full hover:bg-white/20 flex items-center justify-center text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <span className="text-[10px] font-mono font-bold px-1 text-white/90">
                {currentIndex + 1}/{activeBanners.length}
              </span>
              <button
                type="button"
                onClick={() => setCurrentIndex((prev) => (prev + 1) % activeBanners.length)}
                title="Next Banner"
                className="w-6 h-6 rounded-full hover:bg-white/20 flex items-center justify-center text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Action CTA Button */}
          {currentBanner.btnText && (
            <button
              type="button"
              onClick={handleActionClick}
              className="px-4 sm:px-5 py-2 sm:py-2.5 rounded-full bg-white text-stone-900 font-black text-xs hover:bg-stone-50 active:scale-95 transition-all shadow-md cursor-pointer flex items-center space-x-1.5 shrink-0"
            >
              {isWhatsAppLink() && <MessageCircle className="w-3.5 h-3.5 text-emerald-600 inline" />}
              <span>{currentBanner.btnText}</span>
              {currentBanner.btnLink && currentBanner.btnLink.startsWith('http') && (
                <ExternalLink className="w-3 h-3 text-stone-500" />
              )}
            </button>
          )}

          {/* Dismiss button */}
          <button
            type="button"
            onClick={() => setIsDismissed(true)}
            title="Dismiss promo banner"
            className="absolute sm:static top-3 right-3 sm:top-auto sm:right-auto w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-black/20 hover:bg-black/30 flex items-center justify-center text-white/90 hover:text-white transition-colors cursor-pointer border border-white/10"
          >
            <X className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>
        </div>
      </div>

      {/* Bottom indicator dots if multiple banners */}
      {activeBanners.length > 1 && (
        <div className="flex items-center justify-center space-x-1.5 mt-3 pt-2 border-t border-white/10">
          {activeBanners.map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setCurrentIndex(i)}
              className={`h-1.5 rounded-full transition-all cursor-pointer ${
                i === currentIndex ? 'w-6 bg-white' : 'w-2 bg-white/40 hover:bg-white/70'
              }`}
              title={`Go to banner ${i + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
};
