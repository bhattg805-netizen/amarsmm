import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  ListOrdered,
  Layers,
  Wallet,
  LogOut,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Clock,
  ExternalLink,
  Shield,
  Search,
  User as UserIcon,
  HelpCircle,
  Copy,
  Check,
  Send,
  Sliders,
  DollarSign,
  Share2,
  Key,
  Bell,
  Moon,
  Sun,
  Gift,
  Zap,
  TrendingUp,
  Award,
  ChevronDown,
  X,
  ChevronRight,
  Trophy,
  MessageSquare,
  Sparkles,
  LayoutGrid,
  Info,
  FileText,
  ShieldCheck,
  Menu,
  MoreHorizontal,
  Package,
  Plus,
  Globe,
  Ticket,
  FileCode,
  Users,
  BookOpen,
  Headphones,
} from 'lucide-react';
import { User, Service, Order, Category, Payment } from '../types';
import { fetchPublicSettings, subscribeToAdminChanges } from '../lib/api.ts';
import { AddFundsSection } from './AddFundsSection.tsx';
import { AiChatBot } from './AiChatBot.tsx';
import { CuteBoyAiAvatar } from './CuteBoyAiAvatar.tsx';
import { WhatsAppSupportButton } from './WhatsAppSupportButton.tsx';
import { AnimatedLogo } from './AnimatedLogo.tsx';
import { UserTicketsSection } from './UserTicketsSection.tsx';
import { UserChildPanelsSection } from './UserChildPanelsSection.tsx';
import { UserRefillsSection } from './UserRefillsSection.tsx';
import { UserApiDocsSection } from './UserApiDocsSection.tsx';
import { UserAffiliateSection } from './UserAffiliateSection.tsx';
import { UserBlogsSection } from './UserBlogsSection.tsx';
import { UserFaqSection } from './UserFaqSection.tsx';
import { UserSupportChannelsSection } from './UserSupportChannelsSection.tsx';
import { UserPromoBanner } from './UserPromoBanner.tsx';
import { ServiceCategoryIcon } from './ServiceCategoryIcon.tsx';
import { CategoryDropdown } from './CategoryDropdown.tsx';
import { ServiceDropdown } from './ServiceDropdown.tsx';
import {
  TelegramIcon,
  FacebookIcon,
  SpotifyIcon,
  TwitterXIcon,
  InstagramIcon,
  YouTubeIcon,
  TikTokIcon,
} from './BrandIcons.tsx';

interface UserDashboardProps {
  user: User;
  token: string;
  onLogout: () => void;
  onSwitchToAdmin: () => void;
  onRefreshUser: () => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  user,
  token,
  onLogout,
  onSwitchToAdmin,
  onRefreshUser,
}) => {
  const [activeTab, setActiveTab] = useState<
    | 'new_order'
    | 'mass_order'
    | 'orders'
    | 'services'
    | 'add_funds'
    | 'tickets'
    | 'api'
    | 'refills'
    | 'child_panels'
    | 'affiliate'
    | 'blogs'
    | 'faq'
    | 'support_channels'
    | 'terms'
  >('new_order');
  const [currentUser, setCurrentUser] = useState<User>(user);
  const [services, setServices] = useState<Service[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [publicSettings, setPublicSettings] = useState<any>(null);
  const [announcementsList, setAnnouncementsList] = useState<any[]>([]);

  // Child panels state
  const [userChildPanels, setUserChildPanels] = useState<any[]>([]);
  const [childPanelDomain, setChildPanelDomain] = useState('');
  const [childPanelCurrency, setChildPanelCurrency] = useState<'INR' | 'USD'>('INR');
  const [childPanelAdminUser, setChildPanelAdminUser] = useState('');
  const [childPanelAdminPass, setChildPanelAdminPass] = useState('');
  const [isOrderingChildPanel, setIsOrderingChildPanel] = useState(false);
  const [childPanelSuccess, setChildPanelSuccess] = useState<string | null>(null);
  const [childPanelError, setChildPanelError] = useState<string | null>(null);

  // Support tickets state
  const [userTickets, setUserTickets] = useState<any[]>([]);
  const [selectedUserTicket, setSelectedUserTicket] = useState<any | null>(null);
  const [userTicketMessages, setUserTicketMessages] = useState<any[]>([]);
  const [userTicketReplyText, setUserTicketReplyText] = useState('');
  const [loadingUserTicketMessages, setLoadingUserTicketMessages] = useState(false);
  const [sendingUserReply, setSendingUserReply] = useState(false);
  const [showCreateTicketModal, setShowCreateTicketModal] = useState(false);
  const [newTicketSubject, setNewTicketSubject] = useState('');
  const [newTicketMessage, setNewTicketMessage] = useState('');
  const [isCreatingTicket, setIsCreatingTicket] = useState(false);
  const [ticketActionMsg, setTicketActionMsg] = useState<string | null>(null);
  const [ticketActionError, setTicketActionError] = useState<string | null>(null);

  // New order form states
  const [selectedCategory, setSelectedCategory] = useState<number | 'all'>('all');
  const [selectedServiceId, setSelectedServiceId] = useState<number | ''>('');
  const [link, setLink] = useState('');
  const [quantity, setQuantity] = useState<number | ''>('');
  const [couponCode, setCouponCode] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState<string | null>(null);
  const [orderError, setOrderError] = useState<string | null>(null);

  // Mass order state
  const [massInput, setMassInput] = useState('');
  const [massResults, setMassResults] = useState<any[] | null>(null);

  // Filters, search & platforms
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all');
  const [orderFilter, setOrderFilter] = useState<string>('all');
  const [orderSearch, setOrderSearch] = useState<string>('');
  const [serviceSearch, setServiceSearch] = useState<string>('');
  const [isSyncing, setIsSyncing] = useState(false);

  // Top Promo & UI states
  const [showPromoBanner, setShowPromoBanner] = useState(true);
  const [showRewardsModal, setShowRewardsModal] = useState(false);
  const [currency, setCurrency] = useState<'INR' | 'USD' | 'EUR' | 'PKR'>('INR');
  const [showCurrencyDropdown, setShowCurrencyDropdown] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('youthsmm_theme') === 'dark';
  });
  const [isAiChatOpen, setIsAiChatOpen] = useState(false);
  const [activeStep, setActiveStep] = useState<number>(1);

  // User Profile Dropdown & Associated Modals
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showMobileNavDrawer, setShowMobileNavDrawer] = useState(false);
  const [showAccountSettingsModal, setShowAccountSettingsModal] = useState(false);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [accountSettingsSuccess, setAccountSettingsSuccess] = useState('');
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [copiedApiKey, setCopiedApiKey] = useState(false);
  const userMenuRef = React.useRef<HTMLDivElement>(null);
  const isFetchingRef = React.useRef(false);

  // Close user menu on outside click or touch
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent | TouchEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setShowUserMenu(false);
      }
    };
    if (showUserMenu) {
      document.addEventListener('mousedown', handleOutsideClick);
      document.addEventListener('touchstart', handleOutsideClick, { passive: true });
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('touchstart', handleOutsideClick);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [showUserMenu]);

  // Lock body scroll and handle Escape key for mobile nav drawer
  useEffect(() => {
    if (showMobileNavDrawer) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          setShowMobileNavDrawer(false);
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = originalOverflow;
        window.removeEventListener('keydown', handleKeyDown);
      };
    }
  }, [showMobileNavDrawer]);

  // Keep currentUser synced when user prop updates
  useEffect(() => {
    setCurrentUser(user);
  }, [user]);

  // Synchronize Dark Mode on document element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Toggle Dark Mode
  const toggleDarkMode = () => {
    const next = !isDarkMode;
    setIsDarkMode(next);
    localStorage.setItem('youthsmm_theme', next ? 'dark' : 'light');
    if (next) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  // Fetch panel data & public settings with real-time freshness
  const fetchData = async (forceFresh = false) => {
    if (isFetchingRef.current) return;
    isFetchingRef.current = true;
    try {
      const q = forceFresh ? `?_t=${Date.now()}` : '';
      const reqHeaders = {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        Pragma: 'no-cache',
      };
      const reqInit: RequestInit = {
        cache: 'no-store',
        headers: reqHeaders,
      };

      const [srvRes, catRes, ordRes, payRes, pubSettings, meRes, annRes, cpRes, tktRes] = await Promise.all([
        fetch(`/api/user/services${q}`, reqInit).catch(() => null),
        fetch(`/api/user/categories${q}`, reqInit).catch(() => null),
        fetch(`/api/user/orders${q}`, reqInit).catch(() => null),
        fetch(`/api/user/payments${q}`, reqInit).catch(() => null),
        fetchPublicSettings(forceFresh).catch(() => null),
        fetch(`/api/auth/me${q}`, reqInit).catch(() => null),
        fetch(`/api/user/announcements${q}`, reqInit).catch(() => null),
        fetch(`/api/user/child-panels${q}`, reqInit).catch(() => null),
        fetch(`/api/user/tickets${q}`, reqInit).catch(() => null),
      ]);

      if (srvRes && srvRes.ok) {
        try {
          const sData = await srvRes.json();
          if (Array.isArray(sData)) {
            setServices(sData);
            if (sData.length > 0) {
              setSelectedServiceId((prevId) => {
                if (!prevId || !sData.some((s: Service) => s.id === prevId)) {
                  return sData[0].id;
                }
                return prevId;
              });
            }
          }
        } catch (_) {}
      }
      if (catRes && catRes.ok) {
        try {
          const cData = await catRes.json();
          if (Array.isArray(cData)) {
            setCategories(cData);
            setSelectedCategory((prevCat) => {
              if (prevCat !== 'all' && !cData.some((c: Category) => c.id === prevCat)) {
                return 'all';
              }
              return prevCat;
            });
          }
        } catch (_) {}
      }
      if (ordRes && ordRes.ok) {
        try {
          const oData = await ordRes.json();
          if (Array.isArray(oData)) setOrders(oData);
        } catch (_) {}
      }
      if (payRes && payRes.ok) {
        try {
          const pData = await payRes.json();
          if (Array.isArray(pData)) setPayments(pData);
        } catch (_) {}
      }
      if (pubSettings) {
        setPublicSettings(pubSettings);
        if (pubSettings.websiteName) {
          document.title = `${pubSettings.websiteName} - Dashboard`;
        }
      }
      if (meRes && meRes.ok) {
        try {
          const meData = await meRes.json();
          if (meData?.user) {
            setCurrentUser(meData.user);
          }
        } catch (_) {}
      }
      if (annRes && annRes.ok) {
        try {
          const aData = await annRes.json();
          if (Array.isArray(aData)) setAnnouncementsList(aData);
        } catch (_) {}
      }
      if (cpRes && cpRes.ok) {
        try {
          const cpData = await cpRes.json();
          if (Array.isArray(cpData)) setUserChildPanels(cpData);
        } catch (_) {}
      }
      if (tktRes && tktRes.ok) {
        try {
          const tData = await tktRes.json();
          if (Array.isArray(tData)) setUserTickets(tData);
        } catch (_) {}
      }
    } catch (err) {
      console.warn('Data fetch notice:', err);
    } finally {
      isFetchingRef.current = false;
    }
  };

  // 1. Initial load
  useEffect(() => {
    fetchData(true);
  }, [token]);

  // 2. Refresh on tab switch
  useEffect(() => {
    fetchData(true);
  }, [activeTab]);

  // 3. Silent background polling every 15 seconds to capture updates smoothly without flooding
  useEffect(() => {
    const interval = setInterval(() => {
      fetchData(false);
    }, 15000);
    return () => clearInterval(interval);
  }, [token]);

  // 4. Multi-tab and broadcast listener for real-time synchronization with Admin Panel
  useEffect(() => {
    const handleSync = (updatedSettings?: any) => {
      if (updatedSettings && typeof updatedSettings === 'object') {
        setPublicSettings((prev: any) => ({ ...prev, ...updatedSettings }));
      } else {
        try {
          const stored = localStorage.getItem('youthsmm_public_settings');
          if (stored) {
            setPublicSettings((prev: any) => ({ ...prev, ...JSON.parse(stored) }));
          }
        } catch (_) {}
      }
      fetchData(true);
      onRefreshUser();
    };

    return subscribeToAdminChanges(handleSync);
  }, [onRefreshUser]);

  // Dynamic greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 4 && hour < 12) return 'Good morning,';
    if (hour >= 12 && hour < 17) return 'Good afternoon,';
    if (hour >= 17 && hour < 21) return 'Good evening,';
    return 'Good night,';
  };

  // Dynamic currency conversion based on Admin Panel exchange rates
  const formatPrice = (valInInr: number) => {
    const num = Number(valInInr) || 0;
    if (currency === 'USD') {
      const rate = parseFloat(publicSettings?.inrToUsdRate || '0.012') || 0.012;
      return `$ ${(num * rate).toFixed(2)}`;
    }
    if (currency === 'EUR') {
      const rate = parseFloat(publicSettings?.inrToEurRate || '0.011') || 0.011;
      return `€ ${(num * rate).toFixed(2)}`;
    }
    if (currency === 'PKR') {
      const rate = parseFloat(publicSettings?.inrToPkrRate || '3.32') || 3.32;
      return `Rs ${(num * rate).toFixed(2)}`;
    }
    return `₹ ${num.toFixed(2)}`;
  };

  // Order Child Panel Handler
  const handleOrderChildPanel = async (e: React.FormEvent) => {
    e.preventDefault();
    setChildPanelError(null);
    setChildPanelSuccess(null);
    if (!childPanelDomain.trim() || !childPanelAdminUser.trim() || !childPanelAdminPass.trim()) {
      setChildPanelError('Please enter domain, admin username, and admin password.');
      return;
    }
    const cleanDomain = childPanelDomain.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    const configPriceStr = publicSettings?.childPanelPrice || '₹ 1,500 / month';
    const parsedPrice = parseFloat(configPriceStr.replace(/[^0-9.]/g, '')) || 1500;

    if (userBalance < parsedPrice) {
      setChildPanelError(`Insufficient balance! Price is ${formatPrice(parsedPrice)}, but your balance is ${formatPrice(userBalance)}. Please add funds first.`);
      return;
    }

    setIsOrderingChildPanel(true);
    try {
      const res = await fetch('/api/user/child-panels', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          domain: cleanDomain,
          currency: childPanelCurrency,
          adminUsername: childPanelAdminUser.trim(),
          adminPassword: childPanelAdminPass.trim(),
          price: parsedPrice,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setChildPanelSuccess(`Child panel ordered successfully for ${cleanDomain}! It will be activated after nameservers point.`);
        setChildPanelDomain('');
        setChildPanelAdminUser('');
        setChildPanelAdminPass('');
        fetchData(true);
        onRefreshUser();
      } else {
        setChildPanelError(data.error || 'Failed to place child panel order.');
      }
    } catch (err: any) {
      setChildPanelError('Network error while ordering child panel.');
    } finally {
      setIsOrderingChildPanel(false);
    }
  };

  // Support Tickets Handlers
  const handleCreateUserTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    setTicketActionError(null);
    setTicketActionMsg(null);
    if (!newTicketSubject.trim() || !newTicketMessage.trim()) {
      setTicketActionError('Please provide both subject and message.');
      return;
    }
    setIsCreatingTicket(true);
    try {
      const res = await fetch('/api/tickets/new', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          subject: newTicketSubject.trim(),
          message: newTicketMessage.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setTicketActionMsg('Support ticket submitted successfully! A support agent will assist you soon.');
        setNewTicketSubject('');
        setNewTicketMessage('');
        setShowCreateTicketModal(false);
        fetchData(true);
      } else {
        setTicketActionError(data.error || 'Failed to submit ticket.');
      }
    } catch (err) {
      setTicketActionError('Network error submitting ticket.');
    } finally {
      setIsCreatingTicket(false);
    }
  };

  const handleSelectUserTicket = async (ticket: any) => {
    setSelectedUserTicket(ticket);
    setLoadingUserTicketMessages(true);
    try {
      const res = await fetch(`/api/tickets/${ticket.id}/messages`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setUserTicketMessages(data.messages || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingUserTicketMessages(false);
    }
  };

  const handleSendUserReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserTicket || !userTicketReplyText.trim()) return;
    setSendingUserReply(true);
    try {
      const res = await fetch(`/api/tickets/${selectedUserTicket.id}/reply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ message: userTicketReplyText.trim() }),
      });
      if (res.ok) {
        setUserTicketMessages((prev) => [
          ...prev,
          {
            id: Date.now(),
            message: userTicketReplyText.trim(),
            createdAt: new Date().toISOString(),
            senderName: currentUser.name || 'You',
            senderRole: 'user',
          },
        ]);
        setUserTicketReplyText('');
        fetchData(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSendingUserReply(false);
    }
  };

  // Total spent calculation
  const totalSpent = orders.reduce((sum, o) => {
    if (o.status !== 'cancelled' && o.status !== 'refunded') {
      return sum + Number(o.charge || 0);
    }
    return sum;
  }, 0);

  // Level & XP calculation
  const userBalance = Number(currentUser.balance ?? user.balance ?? 0);
  const xp = Math.min(120, Math.max(20, Math.floor((totalSpent % 200) / 200 * 120) || 66));
  const nextXp = Math.max(10, 120 - xp);
  const userLevel = totalSpent >= 5000 ? 'GOLD' : totalSpent >= 1000 ? 'SILVER' : 'BRONZE';

  const selectedService = services.find((s) => s.id === Number(selectedServiceId));
  const estimatedCharge =
    selectedService && typeof quantity === 'number' && quantity > 0
      ? ((quantity / 1000) * Number(selectedService.pricePerThousand)).toFixed(2)
      : '0.00';

  // Handle Order Submit
  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setOrderSuccess(null);
    setOrderError(null);

    if (!selectedServiceId) return setOrderError('Please select a service.');
    if (!link.trim()) return setOrderError('Please enter target link or username.');
    if (!quantity || Number(quantity) <= 0) return setOrderError('Please enter a valid quantity.');

    if (selectedService) {
      if (Number(quantity) < selectedService.minAmount) {
        return setOrderError(`Minimum quantity is ${selectedService.minAmount.toLocaleString()}`);
      }
      if (Number(quantity) > selectedService.maxAmount) {
        return setOrderError(`Maximum quantity is ${selectedService.maxAmount.toLocaleString()}`);
      }
    }

    if (userBalance < Number(estimatedCharge)) {
      return setOrderError(
        `Insufficient balance! Order costs ₹${estimatedCharge}, but your balance is ₹${userBalance.toFixed(2)}. Please add funds first.`
      );
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/orders/new', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          serviceId: Number(selectedServiceId),
          link: link.trim(),
          quantity: Number(quantity),
          couponCode: couponCode.trim() || undefined,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setOrderSuccess(data.message || `Order #${data.order?.id || 'OK'} placed successfully!`);
        setLink('');
        setQuantity('');
        setCouponCode('');
        onRefreshUser();
        fetchData();
      } else {
        setOrderError(data.error || 'Failed to place order.');
      }
    } catch (err: any) {
      setOrderError(err.message || 'Network error while placing order.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter categories and services based on selected platform & search
  const filteredCategories = categories.filter((c) => {
    if (selectedPlatform === 'all') return true;
    const catName = c.name.toLowerCase();
    const plat = selectedPlatform.toLowerCase();
    if (plat === 'twitter / 𝕏' || plat === 'twitter') {
      return catName.includes('twitter') || catName.includes('𝕏') || catName.includes('x ');
    }
    return catName.includes(plat);
  });

  const filteredServices = services.filter((s) => {
    const matchesCat = selectedCategory === 'all' || s.categoryId === selectedCategory;
    const matchesSearch =
      !serviceSearch ||
      s.name.toLowerCase().includes(serviceSearch.toLowerCase()) ||
      String(s.id).includes(serviceSearch);
    const matchesPlatform =
      selectedPlatform === 'all' ||
      s.name.toLowerCase().includes(selectedPlatform.toLowerCase());
    return matchesCat && matchesSearch && (selectedCategory !== 'all' || matchesPlatform);
  });

  const handleSyncOrders = async () => {
    setIsSyncing(true);
    try {
      await fetch('/api/user/orders/sync', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      await fetchData();
    } catch (err) {
      console.error('Order sync error:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  const filteredOrders = orders.filter((o) => {
    const matchesFilter =
      orderFilter === 'all' ||
      (orderFilter === 'processing' && (o.status === 'processing' || o.status === 'in_progress')) ||
      o.status.toLowerCase() === orderFilter.toLowerCase();

    const matchesSearch =
      !orderSearch ||
      String(o.id).includes(orderSearch) ||
      (o.serviceName || '').toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.link.toLowerCase().includes(orderSearch.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  const isAdmin =
    user.role === 'admin' ||
    (user.email || '').includes('bhattg805');

  // Display user name
  const displayName = user.name || user.username || user.email?.split('@')[0] || 'Echoes Club';

  // Platforms chip list matching screenshot with animated icons
  const platforms = [
    { id: 'instagram', name: 'Instagram', icon: <ServiceCategoryIcon name="Instagram" animated={true} size="sm" /> },
    { id: 'youtube', name: 'YouTube', icon: <ServiceCategoryIcon name="YouTube" animated={true} size="sm" /> },
    { id: 'telegram', name: 'Telegram', icon: <ServiceCategoryIcon name="Telegram" animated={true} size="sm" /> },
    { id: 'facebook', name: 'Facebook', icon: <ServiceCategoryIcon name="Facebook" animated={true} size="sm" /> },
    { id: 'twitter', name: 'Twitter / 𝕏', icon: <ServiceCategoryIcon name="Twitter" animated={true} size="sm" /> },
    { id: 'tiktok', name: 'TikTok', icon: <ServiceCategoryIcon name="TikTok" animated={true} size="sm" /> },
    { id: 'spotify', name: 'Spotify', icon: <ServiceCategoryIcon name="Spotify" animated={true} size="sm" /> },
  ];

  return (
    <div
      className={`min-h-screen transition-colors duration-200 font-sans ${
        isDarkMode ? 'dark bg-[#0B0F19] text-gray-100' : 'bg-[#F8F4EA] text-stone-900'
      }`}
    >
      {/* ===================== TOP HEADER ===================== */}
      <header
        className={`sticky top-0 z-40 transition-colors border-b ${
          isDarkMode
            ? 'bg-[#0F172A]/90 border-slate-800/80 backdrop-blur-md'
            : 'bg-[#FAF6EE]/95 border-[#EAE3D2] backdrop-blur-md'
        }`}
      >
        <div className="max-w-[1520px] mx-auto px-3 sm:px-6 h-15 sm:h-18 flex items-center justify-between">
          {/* Mobile Left: Hamburger + Page Title */}
          <div className="flex lg:hidden items-center space-x-2.5 min-w-0 pr-2">
            <button
              type="button"
              onClick={() => setShowMobileNavDrawer(true)}
              className={`w-9 h-9 rounded-full flex items-center justify-center border transition-all cursor-pointer shrink-0 active:scale-90 select-none ${
                isDarkMode
                  ? 'bg-slate-800 border-slate-700 text-gray-200 hover:text-white hover:bg-slate-700'
                  : 'bg-white border-[#EAE3D2] text-stone-700 hover:text-stone-900 hover:bg-stone-50 shadow-xs'
              }`}
              aria-label="Navigation Menu"
              aria-expanded={showMobileNavDrawer}
              title="Open Navigation Menu"
            >
              <Menu className="w-4.5 h-4.5 stroke-[2.2]" />
            </button>
            <span className="text-base font-black tracking-tight truncate text-stone-900 dark:text-white">
              {activeTab === 'new_order'
                ? 'New Order'
                : activeTab === 'mass_order'
                ? 'Mass Order'
                : activeTab === 'orders'
                ? 'Orders'
                : activeTab === 'services'
                ? 'Services'
                : activeTab === 'add_funds'
                ? 'Add Funds'
                : activeTab === 'tickets'
                ? 'Tickets'
                : activeTab === 'api'
                ? 'Api'
                : activeTab === 'refills'
                ? 'Refill History'
                : activeTab === 'child_panels'
                ? (publicSettings?.childPanelTitle || 'Child Panels')
                : activeTab === 'affiliate'
                ? 'Affiliates'
                : activeTab === 'blogs'
                ? 'Blogs & News'
                : activeTab === 'faq'
                ? 'FAQ'
                : activeTab === 'support_channels'
                ? 'Support Channels'
                : activeTab === 'terms'
                ? 'Terms & Policies'
                : 'Dashboard'}
            </span>
          </div>

          {/* Desktop Left: Animated Logo & Divider & Page Title */}
          <div className="hidden lg:flex items-center space-x-4 sm:space-x-6">
            <AnimatedLogo
              size="sm"
              showText={true}
              theme={isDarkMode ? 'dark' : 'light'}
              onClick={() => setActiveTab('new_order')}
            />

            <div className="flex items-center space-x-3 pl-2 border-l border-gray-300 dark:border-gray-700">
              <span className="text-base sm:text-lg font-extrabold tracking-tight">
                {activeTab === 'new_order'
                  ? 'New Order'
                  : activeTab === 'mass_order'
                  ? 'Mass Order'
                  : activeTab === 'orders'
                  ? 'Orders'
                  : activeTab === 'services'
                  ? 'Services'
                  : activeTab === 'add_funds'
                  ? 'Add Funds'
                  : activeTab === 'tickets'
                  ? 'Tickets'
                  : activeTab === 'api'
                  ? 'Api'
                  : activeTab === 'refills'
                  ? 'Refill History'
                  : activeTab === 'child_panels'
                  ? (publicSettings?.childPanelTitle || 'Child Panels')
                  : activeTab === 'affiliate'
                  ? 'Affiliates'
                  : activeTab === 'blogs'
                  ? 'Blogs & News'
                  : activeTab === 'faq'
                  ? 'FAQ'
                  : activeTab === 'support_channels'
                  ? 'Support Channels'
                  : activeTab === 'terms'
                  ? 'Terms & Policies'
                  : 'Dashboard'}
              </span>
            </div>
          </div>

          {/* Right Controls */}
          <div className="flex items-center space-x-1.5 sm:space-x-2.5 shrink-0">
            {/* Notification Bell */}
            <button
              type="button"
              onClick={() => alert('No unread notifications.')}
              className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
                isDarkMode
                  ? 'bg-slate-800 border-slate-700 text-gray-300 hover:text-white hover:border-slate-600'
                  : 'bg-white border-[#EAE3D2] text-stone-600 hover:text-stone-900 shadow-xs'
              }`}
              title="Notifications"
            >
              <Bell className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>

            {/* Currency Pill Selector */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowCurrencyDropdown(!showCurrencyDropdown)}
                className="px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-full bg-[#DC2626] hover:bg-red-700 text-white font-extrabold text-[11px] sm:text-xs flex items-center space-x-1 sm:space-x-1.5 shadow-sm transition-all cursor-pointer select-none"
              >
                <span>{currency}</span>
                <ChevronDown className="w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2.5]" />
              </button>

              {showCurrencyDropdown && (
                <div
                  className={`absolute right-0 mt-2 w-28 rounded-2xl shadow-xl border py-1.5 z-50 text-xs font-bold ${
                    isDarkMode
                      ? 'bg-slate-900 border-slate-700 text-gray-200'
                      : 'bg-[#FFFDF8] border-[#EAE3D2] text-stone-800'
                  }`}
                >
                  <button
                    onClick={() => {
                      setCurrency('INR');
                      setShowCurrencyDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-red-500/10 hover:text-red-600 flex items-center justify-between"
                  >
                    <span>INR (₹)</span>
                    {currency === 'INR' && <Check className="w-3.5 h-3.5 text-red-600" />}
                  </button>
                  <button
                    onClick={() => {
                      setCurrency('USD');
                      setShowCurrencyDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-red-500/10 hover:text-red-600 flex items-center justify-between"
                  >
                    <span>USD ($)</span>
                    {currency === 'USD' && <Check className="w-3.5 h-3.5 text-red-600" />}
                  </button>
                  <button
                    onClick={() => {
                      setCurrency('EUR');
                      setShowCurrencyDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-red-500/10 hover:text-red-600 flex items-center justify-between"
                  >
                    <span>EUR (€)</span>
                    {currency === 'EUR' && <Check className="w-3.5 h-3.5 text-red-600" />}
                  </button>
                  <button
                    onClick={() => {
                      setCurrency('PKR');
                      setShowCurrencyDropdown(false);
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-red-500/10 hover:text-red-600 flex items-center justify-between"
                  >
                    <span>PKR (Rs)</span>
                    {currency === 'PKR' && <Check className="w-3.5 h-3.5 text-red-600" />}
                  </button>
                </div>
              )}
            </div>

            {/* Dark Mode Moon Toggle */}
            <button
              type="button"
              onClick={toggleDarkMode}
              className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
                isDarkMode
                  ? 'bg-slate-800 border-slate-700 text-yellow-400'
                  : 'bg-white border-[#EAE3D2] text-stone-600 hover:text-stone-900 shadow-xs'
              }`}
              title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {isDarkMode ? <Sun className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Moon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
            </button>

            {/* User Profile / Menu Trigger */}
            <div className="relative" ref={userMenuRef}>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowUserMenu(!showUserMenu);
                }}
                className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
                  showUserMenu
                    ? 'ring-2 ring-red-500 bg-red-50 dark:bg-slate-800 border-red-400'
                    : isDarkMode
                    ? 'bg-slate-800 border-slate-700 text-gray-300 hover:text-white'
                    : 'bg-white border-[#EAE3D2] text-stone-700 hover:text-stone-900 shadow-xs'
                }`}
                title="Account"
                aria-expanded={showUserMenu}
              >
                <UserIcon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </button>

              {/* Profile Dropdown (Unified on Mobile & Laptop) */}
              {showUserMenu && (
                <div
                  className={`absolute right-0 top-full mt-2 w-[min(calc(100vw-1.5rem),21rem)] sm:w-84 max-h-[calc(100vh-5rem)] overflow-y-auto no-scrollbar rounded-3xl shadow-2xl border p-4 sm:p-5 z-50 select-none animate-in fade-in zoom-in-95 duration-150 transition-all ${
                    isDarkMode
                      ? 'bg-[#0F172A] border-slate-700 text-white shadow-black/80'
                      : 'bg-[#FFFDF8] border-[#EAE3D2] text-stone-900 shadow-2xl shadow-stone-900/10'
                  }`}
                  role="menu"
                  aria-label="User Profile Menu"
                >
                  {/* Top Header: SIGNED IN AS + Email + Badges */}
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#DC2626] to-[#EF4444] text-white flex items-center justify-center font-black text-sm shadow-md shrink-0 uppercase">
                      {user.email ? user.email.charAt(0) : 'U'}
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] font-black uppercase tracking-wider text-stone-500 dark:text-gray-400 block">
                        SIGNED IN AS
                      </span>
                      <span className="text-sm font-black text-stone-900 dark:text-white truncate block">
                        {user.email || user.name || 'Member'}
                      </span>
                      <div className="flex items-center space-x-2 pt-0.5">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-rose-100 dark:bg-rose-950/70 text-[#E11D48] dark:text-rose-300 border border-rose-200/80 dark:border-rose-900/60">
                          {isAdmin ? 'ADMINISTRATOR' : 'CLIENT'}
                        </span>
                        <span className="text-xs font-black font-mono text-emerald-600 dark:text-emerald-400 flex items-center space-x-1">
                          <span>₹</span>
                          <span>{Number(userBalance ?? 0).toFixed(2)}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Divider */}
                  <div className="border-t border-gray-200/80 dark:border-slate-800 my-3" />

                  {/* Section 1: Main User Actions */}
                  <div className="space-y-1">
                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        setShowAccountSettingsModal(true);
                      }}
                      className="w-full text-left py-2 px-2.5 rounded-2xl hover:bg-black/5 dark:hover:bg-slate-800/80 flex items-center justify-between text-xs sm:text-sm font-bold text-stone-800 dark:text-white transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center space-x-3 min-w-0">
                        <UserIcon className="w-4 h-4 text-sky-500 shrink-0 group-hover:scale-110 transition-transform stroke-[2.2]" />
                        <span>Account Settings</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-stone-400 dark:text-gray-400 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        setActiveTab('add_funds');
                      }}
                      className="w-full text-left py-2 px-2.5 rounded-2xl hover:bg-black/5 dark:hover:bg-slate-800/80 flex items-center justify-between text-xs sm:text-sm font-bold text-stone-800 dark:text-white transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center space-x-3 min-w-0">
                        <Wallet className="w-4 h-4 text-emerald-500 shrink-0 group-hover:scale-110 transition-transform stroke-[2.2]" />
                        <span>Add Funds History</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-stone-400 dark:text-gray-400 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        setShowRewardsModal(true);
                      }}
                      className="w-full text-left py-2 px-2.5 rounded-2xl hover:bg-black/5 dark:hover:bg-slate-800/80 flex items-center justify-between text-xs sm:text-sm font-bold text-stone-800 dark:text-white transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center space-x-3 min-w-0">
                        <Award className="w-4 h-4 text-amber-500 shrink-0 group-hover:scale-110 transition-transform stroke-[2.2]" />
                        <span>Rewards & Level Tier</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-stone-400 dark:text-gray-400 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                    </button>

                    {isAdmin && (
                      <button
                        type="button"
                        onClick={() => {
                          setShowUserMenu(false);
                          onSwitchToAdmin();
                        }}
                        className="w-full text-left py-2 px-2.5 rounded-2xl hover:bg-purple-500/10 dark:hover:bg-purple-950/40 flex items-center justify-between text-xs sm:text-sm font-bold transition-colors cursor-pointer group"
                      >
                        <div className="flex items-center space-x-3 min-w-0">
                          <LayoutGrid className="w-4 h-4 text-purple-600 dark:text-purple-400 shrink-0 group-hover:scale-110 transition-transform stroke-[2.2]" />
                          <span className="flex items-center space-x-1.5 font-black text-purple-600 dark:text-purple-300">
                            <span>👑</span>
                            <span>Open Admin Panel</span>
                          </span>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-purple-400 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    )}
                  </div>

                  {/* Divider */}
                  <div className="border-t border-gray-200/80 dark:border-slate-800 my-3" />

                  {/* Section 2: Informational & Policies */}
                  <div className="space-y-1">
                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        setShowAboutModal(true);
                      }}
                      className="w-full text-left py-2 px-2.5 rounded-2xl hover:bg-black/5 dark:hover:bg-slate-800/80 flex items-center justify-between text-xs sm:text-sm font-bold text-stone-800 dark:text-white transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center space-x-3 min-w-0">
                        <Info className="w-4 h-4 text-red-500 shrink-0 group-hover:scale-110 transition-transform stroke-[2.2]" />
                        <span>About Us & Platform</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-stone-400 dark:text-gray-400 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        setShowTermsModal(true);
                      }}
                      className="w-full text-left py-2 px-2.5 rounded-2xl hover:bg-black/5 dark:hover:bg-slate-800/80 flex items-center justify-between text-xs sm:text-sm font-bold text-stone-800 dark:text-white transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center space-x-3 min-w-0">
                        <FileText className="w-4 h-4 text-sky-500 shrink-0 group-hover:scale-110 transition-transform stroke-[2]" />
                        <span>Terms & Conditions</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-stone-400 dark:text-gray-400 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setShowUserMenu(false);
                        setShowPrivacyModal(true);
                      }}
                      className="w-full text-left py-2 px-2.5 rounded-2xl hover:bg-black/5 dark:hover:bg-slate-800/80 flex items-center justify-between text-xs sm:text-sm font-bold text-stone-800 dark:text-white transition-colors cursor-pointer group"
                    >
                      <div className="flex items-center space-x-3 min-w-0">
                        <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0 group-hover:scale-110 transition-transform stroke-[2]" />
                        <span>Privacy Policy</span>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-stone-400 dark:text-gray-400 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  </div>

                  {/* Divider */}
                  <div className="border-t border-gray-200/80 dark:border-slate-800 my-3" />

                  {/* Sign Out */}
                  <button
                    type="button"
                    onClick={() => {
                      setShowUserMenu(false);
                      onLogout();
                    }}
                    className="w-full text-left py-2 px-2.5 rounded-2xl hover:bg-red-50 dark:hover:bg-red-950/40 flex items-center space-x-3 text-xs sm:text-sm font-extrabold text-red-600 dark:text-red-400 transition-colors cursor-pointer group"
                  >
                    <LogOut className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 group-hover:translate-x-0.5 transition-transform stroke-[2.5]" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* ===================== MAIN WRAPPER ===================== */}
      <div className="max-w-[1520px] mx-auto px-3 sm:px-6 py-3.5 sm:py-8 pb-32 sm:pb-36 lg:pb-8 flex-1 w-full flex flex-col lg:flex-row gap-5 sm:gap-8 items-start">
        {/* ===================== LEFT SIDEBAR (DESKTOP) ===================== */}
        <aside className="hidden lg:block w-72 shrink-0 space-y-4 select-none">
          {/* BALANCE CARD (EXACT RED CARD MATCHING SCREENSHOT) */}
          <div className="relative overflow-hidden rounded-3xl bg-[#DC2626] p-6 text-white shadow-lg shadow-red-600/25">
            {/* Top Label */}
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-white/90 block">
              BALANCE
            </span>

            {/* Huge Amount */}
            <div className="mt-1 font-black text-3xl sm:text-4xl tracking-tight">
              {formatPrice(userBalance)}
            </div>

            {/* + Add funds Button */}
            <button
              onClick={() => setActiveTab('add_funds')}
              className="mt-4 px-4 py-2 rounded-full bg-white/20 hover:bg-white/30 text-white font-bold text-xs backdrop-blur-sm transition-all cursor-pointer shadow-xs inline-flex items-center space-x-1"
            >
              <span>{publicSettings?.sidebarAddFundsBtnText || '+ Add funds'}</span>
            </button>

            {/* Divider / Level Progress Section */}
            <div className="mt-6 pt-5 border-t border-white/20">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="flex items-center gap-1.5 text-white">
                  <span>🏅 {publicSettings?.sidebarLevelNum || 'Level 3'}</span>
                </span>
                <span className="bg-black/25 text-white text-[10px] px-2.5 py-0.5 rounded-full font-black uppercase tracking-wider">
                  {publicSettings?.sidebarLevelName || userLevel}
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-2 rounded-full bg-black/25 mt-2.5 overflow-hidden">
                <div
                  className="h-full bg-white rounded-full transition-all duration-500"
                  style={{ width: `${(xp / 120) * 100}%` }}
                />
              </div>

              {/* XP text */}
              <div className="mt-2 flex items-center justify-between text-[11px] font-mono font-semibold text-white/85">
                <span>{publicSettings?.sidebarXpText || `${xp} / 120 XP`}</span>
                <span>{publicSettings?.sidebarNextXp || `Next: ${nextXp} XP`}</span>
              </div>

              {/* Rewards Link */}
              <button
                type="button"
                onClick={() => setShowRewardsModal(true)}
                className="mt-3.5 inline-flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider text-white/95 hover:text-white hover:underline cursor-pointer"
              >
                <span>{publicSettings?.sidebarRewardsLinkText || '🏆 VIEW REWARDS & LEVELS'}</span>
              </button>
            </div>
          </div>

          {/* Switch to Admin Panel (if admin) */}
          {isAdmin && (
            <button
              onClick={onSwitchToAdmin}
              className="w-full py-3 px-4 rounded-2xl bg-[#6366F1] hover:bg-[#4F46E5] text-white font-extrabold text-xs flex items-center justify-center space-x-2 shadow-md shadow-indigo-500/25 transition-all cursor-pointer"
            >
              <Shield className="w-4 h-4" />
              <span>👑 Switch to Admin Panel</span>
            </button>
          )}

          {/* Navigation Items (Clean Vertical Stack Matching Screenshot) */}
          <nav className="space-y-1.5 pt-1">
            {/* 1. New Order */}
            <button
              onClick={() => setActiveTab('new_order')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'new_order'
                  ? 'bg-[#DC2626] text-white shadow-md shadow-red-500/25'
                  : isDarkMode
                  ? 'bg-slate-900/60 hover:bg-slate-800 text-gray-300 border border-slate-800/60'
                  : 'bg-[#FFFDF8] hover:bg-[#F3EDE0] text-stone-800 border border-[#EAE3D2]'
              }`}
            >
              <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-white/20">
                <Zap className="w-4 h-4 fill-current" />
              </div>
              <span className="text-sm">New Order</span>
            </button>

            {/* 2. Orders */}
            <button
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'orders'
                  ? 'bg-[#DC2626] text-white shadow-md shadow-red-500/25'
                  : isDarkMode
                  ? 'bg-slate-900/60 hover:bg-slate-800 text-gray-300 border border-slate-800/60'
                  : 'bg-[#FFFDF8] hover:bg-[#F3EDE0] text-stone-800 border border-[#EAE3D2]'
              }`}
            >
              <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-blue-600 text-white">
                <ListOrdered className="w-4 h-4" />
              </div>
              <span className="text-sm">Orders</span>
              {orders.length > 0 && (
                <span
                  className={`ml-auto px-2 py-0.5 rounded-full text-[10px] font-mono ${
                    activeTab === 'orders'
                      ? 'bg-white/20 text-white'
                      : isDarkMode
                      ? 'bg-slate-800 text-gray-400'
                      : 'bg-[#F2EBDC] text-stone-700'
                  }`}
                >
                  {orders.length}
                </span>
              )}
            </button>

            {/* 3. Services */}
            <button
              onClick={() => setActiveTab('services')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'services'
                  ? 'bg-[#DC2626] text-white shadow-md shadow-red-500/25'
                  : isDarkMode
                  ? 'bg-slate-900/60 hover:bg-slate-800 text-gray-300 border border-slate-800/60'
                  : 'bg-[#FFFDF8] hover:bg-[#F3EDE0] text-stone-800 border border-[#EAE3D2]'
              }`}
            >
              <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-cyan-500 text-white">
                <Layers className="w-4 h-4" />
              </div>
              <span className="text-sm">Services</span>
            </button>

            {/* 4. Add Funds */}
            <button
              onClick={() => setActiveTab('add_funds')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'add_funds'
                  ? 'bg-[#DC2626] text-white shadow-md shadow-red-500/25'
                  : isDarkMode
                  ? 'bg-slate-900/60 hover:bg-slate-800 text-gray-300 border border-slate-800/60'
                  : 'bg-[#FFFDF8] hover:bg-[#F3EDE0] text-stone-800 border border-[#EAE3D2]'
              }`}
            >
              <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-emerald-500 text-white">
                <Wallet className="w-4 h-4" />
              </div>
              <span className="text-sm">Add Funds</span>
            </button>

            {/* Divider */}
            <div className="pt-2 pb-1">
              <div className="border-t border-[#EAE3D2] dark:border-slate-800/80" />
            </div>

            {/* 6. Tickets */}
            <button
              onClick={() => setActiveTab('tickets')}
              className={`w-full flex items-center space-x-3.5 px-3.5 py-2.5 rounded-2xl text-[15px] font-bold transition-all cursor-pointer ${
                activeTab === 'tickets'
                  ? 'bg-[#EDE4D0] dark:bg-slate-800 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-700 dark:text-gray-300 hover:bg-[#F4EFE3] dark:hover:bg-white/5'
              }`}
            >
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-[#FF5376] text-white shrink-0 shadow-xs">
                <Ticket className="w-4 h-4" />
              </div>
              <span className="truncate">Tickets</span>
            </button>

            {/* 7. Api */}
            <button
              onClick={() => setActiveTab('api')}
              className={`w-full flex items-center space-x-3.5 px-3.5 py-2.5 rounded-2xl text-[15px] font-bold transition-all cursor-pointer ${
                activeTab === 'api'
                  ? 'bg-[#EDE4D0] dark:bg-slate-800 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-700 dark:text-gray-300 hover:bg-[#F4EFE3] dark:hover:bg-white/5'
              }`}
            >
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-[#FF1A1A] text-white shrink-0 shadow-xs">
                <FileCode className="w-4 h-4" />
              </div>
              <span className="truncate">Api</span>
            </button>

            {/* 8. Refill History */}
            <button
              onClick={() => setActiveTab('refills')}
              className={`w-full flex items-center space-x-3.5 px-3.5 py-2.5 rounded-2xl text-[15px] font-bold transition-all cursor-pointer ${
                activeTab === 'refills'
                  ? 'bg-[#EDE4D0] dark:bg-slate-800 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-700 dark:text-gray-300 hover:bg-[#F4EFE3] dark:hover:bg-white/5'
              }`}
            >
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-[#FF9900] text-white shrink-0 shadow-xs">
                <RefreshCw className="w-4 h-4" />
              </div>
              <span className="truncate">Refill History</span>
            </button>

            {/* 9. Child Panels */}
            <button
              onClick={() => setActiveTab('child_panels')}
              className={`w-full flex items-center space-x-3.5 px-3.5 py-2.5 rounded-2xl text-[15px] font-bold transition-all cursor-pointer ${
                activeTab === 'child_panels'
                  ? 'bg-[#EDE4D0] dark:bg-slate-800 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-700 dark:text-gray-300 hover:bg-[#F4EFE3] dark:hover:bg-white/5'
              }`}
            >
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-[#00B4B6] text-white shrink-0 shadow-xs">
                <Globe className="w-4 h-4" />
              </div>
              <span className="truncate">Child Panels</span>
            </button>

            {/* 10. Affiliates */}
            <button
              onClick={() => setActiveTab('affiliate')}
              className={`w-full flex items-center space-x-3.5 px-3.5 py-2.5 rounded-2xl text-[15px] font-bold transition-all cursor-pointer ${
                activeTab === 'affiliate'
                  ? 'bg-[#EDE4D0] dark:bg-slate-800 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-700 dark:text-gray-300 hover:bg-[#F4EFE3] dark:hover:bg-white/5'
              }`}
            >
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-[#8E44AD] text-white shrink-0 shadow-xs">
                <Users className="w-4 h-4" />
              </div>
              <span className="truncate">Affiliates</span>
            </button>

            {/* 11. Blogs & News */}
            <button
              onClick={() => setActiveTab('blogs')}
              className={`w-full flex items-center space-x-3.5 px-3.5 py-2.5 rounded-2xl text-[15px] font-bold transition-all cursor-pointer ${
                activeTab === 'blogs'
                  ? 'bg-[#EDE4D0] dark:bg-slate-800 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-700 dark:text-gray-300 hover:bg-[#F4EFE3] dark:hover:bg-white/5'
              }`}
            >
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-[#E91E63] text-white shrink-0 shadow-xs">
                <BookOpen className="w-4 h-4" />
              </div>
              <span className="truncate">Blogs & News</span>
            </button>

            {/* 12. FAQ */}
            <button
              onClick={() => setActiveTab('faq')}
              className={`w-full flex items-center space-x-3.5 px-3.5 py-2.5 rounded-2xl text-[15px] font-bold transition-all cursor-pointer ${
                activeTab === 'faq'
                  ? 'bg-[#EDE4D0] dark:bg-slate-800 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-700 dark:text-gray-300 hover:bg-[#F4EFE3] dark:hover:bg-white/5'
              }`}
            >
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-[#2196F3] text-white shrink-0 shadow-xs">
                <HelpCircle className="w-4 h-4" />
              </div>
              <span className="truncate">FAQ</span>
            </button>

            {/* 13. Support Channels */}
            <button
              onClick={() => setActiveTab('support_channels')}
              className={`w-full flex items-center space-x-3.5 px-3.5 py-2.5 rounded-2xl text-[15px] font-bold transition-all cursor-pointer ${
                activeTab === 'support_channels'
                  ? 'bg-[#EDE4D0] dark:bg-slate-800 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-700 dark:text-gray-300 hover:bg-[#F4EFE3] dark:hover:bg-white/5'
              }`}
            >
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-[#00897B] text-white shrink-0 shadow-xs">
                <Headphones className="w-4 h-4" />
              </div>
              <span className="truncate">Support Channels</span>
            </button>

            {/* 10. AI Chat Support */}
            <button
              onClick={() => setIsAiChatOpen(true)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                isAiChatOpen
                  ? 'bg-[#DC2626] text-white shadow-md shadow-red-500/25'
                  : isDarkMode
                  ? 'bg-slate-900/60 hover:bg-slate-800 text-gray-300 border border-slate-800/60'
                  : 'bg-[#FFFDF8] hover:bg-[#F3EDE0] text-stone-800 border border-[#EAE3D2]'
              }`}
            >
              <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-purple-600 text-white">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="text-sm">AI Chat Support</span>
            </button>
          </nav>

          {/* Footer branding */}
          <div className="pt-6 text-[11px] text-gray-400 font-semibold select-none">
            {publicSettings?.footerCopyright || '© YouthSMM | Main SMM Provider'}
          </div>
        </aside>

        {/* ===================== MAIN CONTENT ===================== */}
        <main className="flex-1 w-full min-w-0 space-y-4 sm:space-y-6">
          {/* ===================== TAB: NEW ORDER (DEFAULT) ===================== */}
          {activeTab === 'new_order' && (
            <>
              {/* 1. TOP PROMOTIONAL BANNER CAROUSEL (DYNAMICALLY MATCHING ADMIN SETTINGS) */}
              <UserPromoBanner
                publicSettings={publicSettings}
                onNavigateTab={(target) => {
                  if (target) setActiveTab(target as any);
                }}
                isDarkMode={isDarkMode}
              />

              {/* 2. WELCOME & 4 STAT BOXES CARD (MATCHING SCREENSHOT) */}
              <div
                className={`rounded-3xl p-4 sm:p-6 lg:p-8 border shadow-xs transition-colors ${
                  isDarkMode
                    ? 'bg-slate-900/90 border-slate-800'
                    : 'bg-white border-[#EAE3D2]'
                }`}
              >
                <div className="min-w-0">
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight truncate text-stone-900 dark:text-white">
                    <span>{getGreeting()} </span>
                    <span className="text-[#DC2626]">{displayName}</span>
                  </h1>
                  <p className="text-xs sm:text-sm text-stone-500 font-medium mt-1 line-clamp-2">
                    {publicSettings?.greetingNotice || 'Place a new order in a few taps — orders delivered on YouthSMM.'}
                  </p>
                </div>

                {/* 4 Stat Boxes in 2-column mobile grid, 4-column desktop */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4 mt-4 sm:mt-6">
                  {/* Stat 1: Balance */}
                  <div
                    className={`p-3.5 sm:p-4 rounded-2xl border transition-colors flex flex-col justify-between min-h-[105px] sm:min-h-[115px] ${
                      isDarkMode
                        ? 'bg-slate-800/50 border-slate-700/60'
                        : 'bg-[#FAF6EE] border-[#EAE3D2]'
                    }`}
                  >
                    <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
                      <Wallet className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </div>
                    <div className="mt-2 min-w-0">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-stone-500 block truncate">
                        BALANCE
                      </span>
                      <span className="text-sm sm:text-lg font-black tracking-tight block truncate mt-0.5 text-stone-900 dark:text-white">
                        {formatPrice(userBalance)}
                      </span>
                    </div>
                  </div>

                  {/* Stat 2: Total Orders */}
                  <div
                    className={`p-3.5 sm:p-4 rounded-2xl border transition-colors flex flex-col justify-between min-h-[105px] sm:min-h-[115px] ${
                      isDarkMode
                        ? 'bg-slate-800/50 border-slate-700/60'
                        : 'bg-[#FAF6EE] border-[#EAE3D2]'
                    }`}
                  >
                    <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-blue-500 text-white flex items-center justify-center shrink-0">
                      <ListOrdered className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </div>
                    <div className="mt-2 min-w-0">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-stone-500 block truncate">
                        TOTAL ORDERS
                      </span>
                      <span className="text-sm sm:text-lg font-black tracking-tight block truncate mt-0.5 text-stone-900 dark:text-white">
                        {orders.length}
                      </span>
                    </div>
                  </div>

                  {/* Stat 3: Total Spent */}
                  <div
                    className={`p-3.5 sm:p-4 rounded-2xl border transition-colors flex flex-col justify-between min-h-[105px] sm:min-h-[115px] ${
                      isDarkMode
                        ? 'bg-slate-800/50 border-slate-700/60'
                        : 'bg-[#FAF6EE] border-[#EAE3D2]'
                    }`}
                  >
                    <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-emerald-500 text-white flex items-center justify-center shrink-0">
                      <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </div>
                    <div className="mt-2 min-w-0">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-stone-500 block truncate">
                        TOTAL SPENT
                      </span>
                      <span className="text-sm sm:text-lg font-black tracking-tight block truncate mt-0.5 text-stone-900 dark:text-white">
                        {formatPrice(totalSpent)}
                      </span>
                    </div>
                  </div>

                  {/* Stat 4: Level */}
                  <div
                    className={`p-3.5 sm:p-4 rounded-2xl border transition-colors flex flex-col justify-between min-h-[105px] sm:min-h-[115px] ${
                      isDarkMode
                        ? 'bg-slate-800/50 border-slate-700/60'
                        : 'bg-[#FAF6EE] border-[#EAE3D2]'
                    }`}
                  >
                    <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0">
                      <Award className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </div>
                    <div className="mt-2 min-w-0">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-stone-500 block truncate">
                        LEVEL
                      </span>
                      <span className="text-xs sm:text-base font-black tracking-tight block truncate mt-0.5 text-stone-900 dark:text-white">
                        🥉 {publicSettings?.sidebarLevelName || userLevel}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* 3. ORDER FORM & RIGHT SUMMARY COLUMN (2-COLUMN GRID) */}
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 sm:gap-8 items-start">
                {/* LEFT / CENTER COLUMN: PLACE A NEW ORDER FORM */}
                <div
                  className={`xl:col-span-2 rounded-3xl p-4 sm:p-6 lg:p-8 border shadow-xs transition-colors space-y-5 sm:space-y-6 ${
                    isDarkMode
                      ? 'bg-slate-900/90 border-slate-800'
                      : 'bg-white border-[#EAE3D2]'
                  }`}
                >
                  {/* Form Card Header */}
                  <div className="flex items-center space-x-3">
                    <div className="w-9 h-9 rounded-full bg-[#DC2626] text-white flex items-center justify-center shrink-0">
                      <Zap className="w-5 h-5 fill-current" />
                    </div>
                    <h2 className="text-xl font-black tracking-tight">Place a new order</h2>
                  </div>

                  {/* Toggle: New Order vs Mass Order */}
                  <div className="flex items-center space-x-2">
                    <button
                      type="button"
                      onClick={() => setActiveTab('new_order')}
                      className="px-5 py-2.5 rounded-xl bg-[#DC2626] text-white font-black text-xs shadow-xs flex items-center space-x-1.5 cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5 fill-current" />
                      <span>New order</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('mass_order')}
                      className={`px-5 py-2.5 rounded-xl font-black text-xs border flex items-center space-x-1.5 transition-colors cursor-pointer ${
                        isDarkMode
                          ? 'bg-slate-800 text-gray-300 border-slate-700 hover:bg-slate-700'
                          : 'bg-[#F4EFE3] text-stone-700 border-[#DDD3BC] hover:bg-[#EAE3D0]'
                      }`}
                    >
                      <Sliders className="w-3.5 h-3.5" />
                      <span>Mass Order</span>
                    </button>
                  </div>

                  {/* Stepper badges: 1 Platform, 2 Category, 3 Service, 4 Details */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 select-none">
                    <div
                      className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center space-x-2 ${
                        isDarkMode
                          ? 'bg-slate-800/80 border-slate-700 text-white'
                          : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-900'
                      }`}
                    >
                      <span className="w-5 h-5 rounded-full bg-[#DC2626] text-white flex items-center justify-center text-[10px] font-black shrink-0">
                        1
                      </span>
                      <span>Platform</span>
                    </div>

                    <div
                      className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center space-x-2 ${
                        isDarkMode
                          ? 'bg-slate-800/50 border-slate-700 text-gray-300'
                          : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-800'
                      }`}
                    >
                      <span className="w-5 h-5 rounded-full bg-red-600/80 text-white flex items-center justify-center text-[10px] font-black shrink-0">
                        2
                      </span>
                      <span>Category</span>
                    </div>

                    <div
                      className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center space-x-2 ${
                        isDarkMode
                          ? 'bg-slate-800/50 border-slate-700 text-gray-300'
                          : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-800'
                      }`}
                    >
                      <span className="w-5 h-5 rounded-full bg-red-600/80 text-white flex items-center justify-center text-[10px] font-black shrink-0">
                        3
                      </span>
                      <span>Service</span>
                    </div>

                    <div
                      className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center space-x-2 ${
                        isDarkMode
                          ? 'bg-slate-800/50 border-slate-700 text-gray-300'
                          : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-800'
                      }`}
                    >
                      <span className="w-5 h-5 rounded-full bg-red-600/80 text-white flex items-center justify-center text-[10px] font-black shrink-0">
                        4
                      </span>
                      <span>Details</span>
                    </div>
                  </div>

                  {/* Platform Quick Filter Pills */}
                  <div className="flex flex-wrap gap-2 pt-2">
                    {platforms.map((p) => {
                      const isActive = selectedPlatform === p.id;
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            setSelectedPlatform(isActive ? 'all' : p.id);
                          }}
                          className={`px-3.5 py-2 rounded-xl text-xs font-bold border flex items-center space-x-2 transition-all cursor-pointer ${
                            isActive
                              ? 'bg-red-500/10 border-red-500 text-red-600'
                              : isDarkMode
                              ? 'bg-slate-800/60 border-slate-700 text-gray-300 hover:bg-slate-800 hover:text-white'
                              : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-800 hover:bg-[#EAE3D0]'
                          }`}
                        >
                          <span>{p.icon}</span>
                          <span>{p.name}</span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Feedback Messages */}
                  {orderSuccess && (
                    <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 p-4 rounded-2xl text-xs flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500 mt-0.5" />
                      <div>
                        <span className="font-bold block text-sm">{orderSuccess}</span>
                        <span className="block mt-0.5">
                          Order accepted by automated dispatch system and processing immediately.
                        </span>
                      </div>
                    </div>
                  )}

                  {orderError && (
                    <div className="bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400 p-4 rounded-2xl text-xs flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 shrink-0 text-red-500 mt-0.5" />
                      <div className="font-semibold">{orderError}</div>
                    </div>
                  )}

                  {/* Form fields */}
                  <form onSubmit={handlePlaceOrder} className="space-y-5">
                    {/* SEARCH CATEGORY / SERVICE */}
                    <div>
                      <label className="block text-[11px] font-black uppercase tracking-wider text-stone-500 mb-2">
                        SEARCH CATEGORY / SERVICE
                      </label>
                      <div className="relative">
                        <Search className="w-4 h-4 text-stone-400 absolute left-4 top-3.5 pointer-events-none" />
                        <input
                          type="text"
                          placeholder="Search any service or category by name, keyword, or ID..."
                          value={serviceSearch}
                          onChange={(e) => setServiceSearch(e.target.value)}
                          className={`w-full pl-11 pr-4 py-3 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-red-500/30 border transition-all ${
                            isDarkMode
                              ? 'bg-slate-800/80 border-slate-700 text-white placeholder-gray-500'
                              : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-900 placeholder-stone-400 focus:bg-[#FFFDF8]'
                          }`}
                        />
                      </div>
                    </div>

                    {/* STEP 2: CATEGORY SELECT */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="block text-[11px] font-black uppercase tracking-wider text-stone-500">
                          STEP 2: CATEGORY
                        </label>
                        {selectedCategory !== 'all' && (
                          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-600 text-[11px] font-bold">
                            <ServiceCategoryIcon
                              name={categories.find((c) => c.id === selectedCategory)?.name || ''}
                              animated={true}
                              size="sm"
                            />
                            <span className="truncate max-w-[150px]">
                              {categories.find((c) => c.id === selectedCategory)?.name}
                            </span>
                          </div>
                        )}
                      </div>
                      <CategoryDropdown
                        categories={filteredCategories}
                        allCategories={categories}
                        onSelectCategory={(val) => {
                          setSelectedCategory(val);
                          const currentStillMatches = services.some(
                            (s) => s.id === selectedServiceId && (val === 'all' || s.categoryId === val)
                          );
                          if (!currentStillMatches) {
                            setSelectedServiceId(null);
                          }
                        }}
                        isDarkMode={isDarkMode}
                      />
                    </div>

                    {/* STEP 3: SERVICE SELECT - STRICTLY NO ICONS */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="block text-[11px] font-black uppercase tracking-wider text-stone-500">
                          STEP 3: SERVICE
                        </label>
                        {selectedServiceId && (
                          <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-[11px] font-mono font-bold">
                            <span>
                              ₹{services.find((s) => s.id === selectedServiceId)?.pricePerThousand}/1K
                            </span>
                          </div>
                        )}
                      </div>
                      <ServiceDropdown
                        services={filteredServices}
                        selectedServiceId={selectedServiceId}
                        onSelectService={(id) => setSelectedServiceId(id)}
                        isDarkMode={isDarkMode}
                        formatPrice={formatPrice}
                      />
                    </div>

                    {/* STEP 4: TARGET LINK */}
                    <div>
                      <label className="block text-[11px] font-black uppercase tracking-wider text-stone-500 mb-2">
                        STEP 4: TARGET LINK / PROFILE / POST URL
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="https://instagram.com/p/... or target username"
                        value={link}
                        onChange={(e) => setLink(e.target.value)}
                        className={`w-full px-4 py-3.5 rounded-2xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-red-500/30 border transition-all ${
                          isDarkMode
                            ? 'bg-slate-800/80 border-slate-700 text-white placeholder-gray-500'
                            : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-900 placeholder-stone-400 focus:bg-[#FFFDF8]'
                        }`}
                      />
                    </div>

                    {/* QUANTITY */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <label className="block text-[11px] font-black uppercase tracking-wider text-stone-500">
                          QUANTITY
                        </label>
                        {selectedService && (
                          <span className="text-[10px] font-bold text-stone-400 font-mono">
                            Min: {selectedService.minAmount.toLocaleString()} · Max:{' '}
                            {selectedService.maxAmount.toLocaleString()}
                          </span>
                        )}
                      </div>
                      <input
                        type="number"
                        required
                        min={selectedService?.minAmount || 1}
                        max={selectedService?.maxAmount || 1000000}
                        placeholder="e.g. 1000"
                        value={quantity}
                        onChange={(e) =>
                          setQuantity(e.target.value ? Number(e.target.value) : '')
                        }
                        className={`w-full px-4 py-3.5 rounded-2xl text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-red-500/30 border transition-all ${
                          isDarkMode
                            ? 'bg-slate-800/80 border-slate-700 text-white placeholder-gray-500'
                            : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-900 placeholder-stone-400 focus:bg-[#FFFDF8]'
                        }`}
                      />

                      {/* DYNAMIC AMOUNT CALCULATION ACCORDING TO QUANTITY */}
                      <div
                        className={`mt-2.5 px-4 py-2.5 rounded-xl border flex items-center justify-between transition-all ${
                          isDarkMode
                            ? 'bg-slate-800/50 border-slate-700/80 text-stone-300'
                            : 'bg-[#FAF6ED] border-[#DDD3BC] text-stone-800'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 text-xs font-semibold">
                          <span className="text-stone-500 dark:text-stone-400">Total Amount:</span>
                          {selectedService && quantity && Number(quantity) > 0 ? (
                            <span className="text-[11px] text-stone-400 font-mono">
                              ({Number(quantity).toLocaleString()} × ₹{selectedService.pricePerThousand}/1K)
                            </span>
                          ) : null}
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-sm font-black font-mono text-[#DC2626]">
                            {formatPrice(Number(estimatedCharge))}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* COUPON CODE */}
                    <div>
                      <label className="block text-[11px] font-black uppercase tracking-wider text-stone-500 mb-2">
                        COUPON CODE (OPTIONAL)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. DISCO10"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        className={`w-full px-4 py-3.5 rounded-2xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-red-500/30 border transition-all ${
                          isDarkMode
                            ? 'bg-slate-800/80 border-slate-700 text-white placeholder-gray-500'
                            : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-900 placeholder-stone-400 focus:bg-[#FFFDF8]'
                        }`}
                      />
                    </div>

                    {/* BIG RED PLACE ORDER BUTTON (EXACTLY MATCHING SCREENSHOT) */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 rounded-2xl bg-[#DC2626] hover:bg-red-700 text-white font-black text-base shadow-lg shadow-red-600/30 flex items-center justify-center space-x-2.5 transition-all cursor-pointer active:scale-[0.99] disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <RefreshCw className="w-5 h-5 animate-spin" />
                          <span>Processing Order...</span>
                        </>
                      ) : (
                        <>
                          <Zap className="w-5 h-5 fill-current" />
                          <span>Place Order</span>
                        </>
                      )}
                    </button>
                  </form>
                </div>

                {/* RIGHT COLUMN: ORDER SUMMARY & LIVE UPDATES CARDS */}
                <div className="space-y-6">
                  {/* ORDER SUMMARY CARD (MATCHING SCREENSHOT) */}
                  <div
                    className={`rounded-3xl border shadow-xs overflow-hidden transition-colors ${
                      isDarkMode
                        ? 'bg-slate-900/90 border-slate-800'
                        : 'bg-[#FFFDF8] border-[#EAE3D2]'
                    }`}
                  >
                    {/* Red Header Bar */}
                    <div className="bg-[#DC2626] px-5 py-3.5 flex items-center justify-between text-white font-extrabold text-xs uppercase tracking-wider">
                      <div className="flex items-center space-x-2">
                        <ListOrdered className="w-4 h-4" />
                        <span>ORDER SUMMARY</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setActiveTab('orders')}
                        className="text-white/90 hover:text-white hover:underline flex items-center space-x-1 font-bold text-[11px]"
                      >
                        <span>Order status?</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Summary Body */}
                    <div className="p-6 space-y-4 text-xs font-semibold">
                      <div className="flex items-start justify-between gap-2 border-b border-[#EAE3D2] dark:border-gray-800 pb-3">
                        <span className="text-stone-400">Service</span>
                        <span className="font-bold text-right max-w-[180px] truncate text-stone-900 dark:text-white">
                          {selectedService?.name || 'No service selected'}
                        </span>
                      </div>

                      <div className="flex items-center justify-between border-b border-[#EAE3D2] dark:border-gray-800 pb-3">
                        <span className="text-stone-400">Quantity</span>
                        <span className="font-mono font-bold text-stone-900 dark:text-white">
                          {quantity ? Number(quantity).toLocaleString() : '—'}
                        </span>
                      </div>

                      <div className="flex items-center justify-between border-b border-[#EAE3D2] dark:border-gray-800 pb-3">
                        <span className="text-stone-400">Rate / 1000</span>
                        <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                          {selectedService ? formatPrice(Number(selectedService.pricePerThousand)) : '—'}
                        </span>
                      </div>

                      <div className="pt-2 flex items-center justify-between">
                        <span className="text-sm font-extrabold text-stone-900 dark:text-white">Total Charge</span>
                        <span className="text-xl font-black font-mono text-[#DC2626]">
                          {formatPrice(Number(estimatedCharge))}
                        </span>
                      </div>

                      <div className="pt-1 text-[11px] text-stone-400 text-center">
                        Balance after order: {formatPrice(userBalance - Number(estimatedCharge))}
                      </div>
                    </div>
                  </div>

                  {/* LIVE UPDATES CARD (MATCHING SCREENSHOT) */}
                  <div
                    className={`rounded-3xl p-6 border shadow-xs transition-colors space-y-3 ${
                      isDarkMode
                        ? 'bg-slate-900/90 border-slate-800'
                        : 'bg-[#FFFDF8] border-[#EAE3D2]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 font-black text-sm">
                        <Bell className="w-4 h-4 text-[#DC2626]" />
                        <span>Live Updates</span>
                      </div>
                      <span className="bg-[#DC2626]/10 text-[#DC2626] font-black text-[10px] px-2.5 py-0.5 rounded-full border border-red-500/20 uppercase tracking-wider">
                        Active
                      </span>
                    </div>

                    <div
                      className={`p-3.5 rounded-2xl border text-xs font-medium space-y-1.5 ${
                        isDarkMode
                          ? 'bg-slate-800/40 border-slate-700/60 text-gray-300'
                          : 'bg-[#F4EFE3] border-[#EAE3D2] text-stone-700'
                      }`}
                    >
                      <p className="leading-relaxed">
                        ⚡ <strong className="text-stone-900 dark:text-white">Instagram & YouTube</strong>{' '}
                        services updated with ultra-fast speed. 100% stable refill guarantees active!
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* ===================== TAB: MASS ORDER ===================== */}
          {activeTab === 'mass_order' && (
            <div
              className={`rounded-3xl p-6 sm:p-8 border shadow-xs max-w-3xl mx-auto space-y-6 ${
                isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
              }`}
            >
              <div>
                <h2 className="text-xl font-black flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-[#DC2626]" />
                  <span>Mass Order</span>
                </h2>
                <p className="text-xs text-stone-500 mt-1">
                  Place multiple orders at once. One order per line in the format:{' '}
                  <code className="text-red-500 font-mono font-bold">
                    service_id | link | quantity
                  </code>
                </p>
              </div>

              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!massInput.trim()) return;
                  setIsSubmitting(true);
                  try {
                    const res = await fetch('/api/orders/mass', {
                      method: 'POST',
                      headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${token}`,
                      },
                      body: JSON.stringify({ massInput }),
                    });
                    const d = await res.json();
                    setMassResults(d.results || []);
                    fetchData();
                    onRefreshUser();
                  } catch (err: any) {
                    console.error('Mass order error:', err);
                  } finally {
                    setIsSubmitting(false);
                  }
                }}
                className="space-y-4"
              >
                <textarea
                  rows={8}
                  value={massInput}
                  onChange={(e) => setMassInput(e.target.value)}
                  placeholder="7833 | https://instagram.com/reel/1 | 1000&#10;7833 | https://instagram.com/reel/2 | 2000"
                  className={`w-full p-4 rounded-2xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-red-500/30 border transition-all ${
                    isDarkMode
                      ? 'bg-slate-800/80 border-slate-700 text-white'
                      : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-900 placeholder-stone-400 focus:bg-[#FFFDF8]'
                  }`}
                />

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 rounded-2xl bg-[#DC2626] hover:bg-red-700 text-white font-black text-xs shadow-md shadow-red-600/30 flex items-center justify-center space-x-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  <span>Submit Mass Orders</span>
                </button>
              </form>

              {massResults && (
                <div className="space-y-2 border border-[#EAE3D2] dark:border-slate-800 rounded-2xl p-4 bg-[#F4EFE3] dark:bg-slate-800/50">
                  <span className="text-xs font-bold block text-stone-900 dark:text-white">Submission Results:</span>
                  <div className="space-y-1.5 text-xs font-mono">
                    {massResults.map((r, i) => (
                      <div
                        key={i}
                        className={`p-2.5 rounded-xl ${
                          r.success
                            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                            : 'bg-red-500/10 text-red-600 dark:text-red-400'
                        }`}
                      >
                        {r.success ? `Order #${r.orderId} created successfully` : `Error: ${r.error}`}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ===================== TAB: ORDERS HISTORY ===================== */}
          {activeTab === 'orders' && (
            <div
              className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5 ${
                isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black flex items-center gap-2">
                    <ListOrdered className="w-5 h-5 text-[#DC2626]" />
                    <span>Orders History</span>
                  </h2>
                  <p className="text-xs text-gray-500">Track delivery progression and live order updates.</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSyncOrders}
                    disabled={isSyncing}
                    className="px-4 py-2 bg-stone-100 hover:bg-stone-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs rounded-xl flex items-center gap-1.5 font-bold transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-red-600' : ''}`} />
                    <span>Sync Orders</span>
                  </button>
                </div>
              </div>

              {/* Status filter bar */}
              <div className="flex flex-wrap gap-1.5 border-b border-gray-100 dark:border-gray-800 pb-3">
                {['all', 'processing', 'pending', 'completed', 'cancelled'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setOrderFilter(st)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                      orderFilter === st
                        ? 'bg-[#DC2626] text-white shadow-xs'
                        : isDarkMode
                        ? 'bg-slate-800 text-gray-400 hover:text-white'
                        : 'bg-stone-100 text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    {st === 'processing' ? 'In Progress' : st}
                  </button>
                ))}
              </div>

              {filteredOrders.length === 0 ? (
                <div className="text-center py-16 text-gray-400 text-xs space-y-2">
                  <Clock className="w-9 h-9 mx-auto opacity-40 text-gray-400" />
                  <p className="font-semibold">No orders found.</p>
                </div>
              ) : (
                <>
                  {/* Mobile Order Cards View (md:hidden) */}
                  <div className="md:hidden space-y-3">
                    {filteredOrders.map((o) => {
                      const statusColor =
                        o.status === 'completed'
                          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20'
                          : o.status === 'processing' || o.status === 'in_progress'
                          ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20'
                          : o.status === 'pending'
                          ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20'
                          : 'bg-gray-500/10 text-gray-600 dark:text-gray-400 border-gray-500/20';

                      return (
                        <div
                          key={o.id}
                          className={`p-4 rounded-2xl border transition-all ${
                            isDarkMode ? 'bg-slate-800/40 border-slate-700/60' : 'bg-[#FAF8F5] border-stone-200/80'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-mono font-black text-xs text-gray-900 dark:text-white">
                              #{o.id}
                            </span>
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold border capitalize ${statusColor}`}
                            >
                              {o.status.replace('_', ' ')}
                            </span>
                          </div>

                          <h3 className="font-bold text-xs mt-2 text-gray-900 dark:text-white">
                            {o.serviceName || `Service #${o.serviceId}`}
                          </h3>

                          <div className="mt-1">
                            <a
                              href={o.link.startsWith('http') ? o.link : `https://${o.link}`}
                              target="_blank"
                              rel="noreferrer"
                              className="text-red-600 text-xs hover:underline flex items-center gap-1 font-mono truncate"
                            >
                              <span className="truncate">{o.link}</span>
                              <ExternalLink className="w-3 h-3 shrink-0" />
                            </a>
                          </div>

                          <div className="mt-3 pt-2.5 border-t border-gray-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-gray-500 dark:text-gray-400">
                            <div>
                              <span>Qty: </span>
                              <span className="font-mono font-bold text-gray-900 dark:text-white">
                                {o.quantity.toLocaleString()}
                              </span>
                            </div>
                            <div className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                              ₹{Number(o.charge).toFixed(2)}
                            </div>
                            <div className="text-[11px] font-mono">
                              {new Date(o.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Desktop Table View (hidden md:block) */}
                  <div className="hidden md:block overflow-x-auto rounded-2xl border border-gray-200 dark:border-gray-800">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-stone-50 dark:bg-slate-800/80 text-gray-500 font-mono text-[11px] border-b border-gray-200 dark:border-gray-800">
                        <tr>
                          <th className="py-3 px-4">Order ID</th>
                          <th className="py-3 px-4">Service</th>
                          <th className="py-3 px-4">Link</th>
                          <th className="py-3 px-4">Quantity</th>
                          <th className="py-3 px-4">Charge</th>
                          <th className="py-3 px-4">Status</th>
                          <th className="py-3 px-4">Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                        {filteredOrders.map((o) => {
                          const statusColor =
                            o.status === 'completed'
                              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20'
                              : o.status === 'processing' || o.status === 'in_progress'
                              ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20'
                              : o.status === 'pending'
                              ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20'
                              : 'bg-gray-500/10 text-gray-600 dark:text-gray-400 border-gray-500/20';

                          return (
                            <tr key={o.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/40 transition-colors">
                              <td className="py-3 px-4 font-mono font-bold text-gray-900 dark:text-white">
                                #{o.id}
                              </td>
                              <td className="py-3 px-4 max-w-xs truncate font-medium">
                                {o.serviceName || `Service #${o.serviceId}`}
                              </td>
                              <td className="py-3 px-4 max-w-xs truncate font-mono">
                                <a
                                  href={o.link.startsWith('http') ? o.link : `https://${o.link}`}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="text-red-600 hover:underline flex items-center gap-1"
                                >
                                  {o.link.length > 25 ? `${o.link.slice(0, 25)}...` : o.link}
                                  <ExternalLink className="w-3 h-3 inline" />
                                </a>
                              </td>
                              <td className="py-3 px-4 font-mono">{o.quantity.toLocaleString()}</td>
                              <td className="py-3 px-4 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                                ₹{Number(o.charge).toFixed(2)}
                              </td>
                              <td className="py-3 px-4">
                                <span
                                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold border capitalize ${statusColor}`}
                                >
                                  {o.status.replace('_', ' ')}
                                </span>
                              </td>
                              <td className="py-3 px-4 font-mono text-gray-400 text-[11px]">
                                {new Date(o.createdAt).toLocaleDateString()}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </div>
          )}

          {/* ===================== TAB: SERVICES LIST ===================== */}
          {activeTab === 'services' && (
            <div
              className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5 ${
                isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black flex items-center gap-2">
                    <Layers className="w-5 h-5 text-[#DC2626]" />
                    <span>Available Services ({services.length})</span>
                  </h2>
                  <p className="text-xs text-stone-500">Wholesale pricing with instant automated dispatch.</p>
                </div>
                <div className="relative">
                  <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search services..."
                    value={serviceSearch}
                    onChange={(e) => setServiceSearch(e.target.value)}
                    className="bg-[#F4EFE3] dark:bg-slate-800 border border-[#DDD3BC] dark:border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs focus:outline-none focus:border-red-500 font-sans text-stone-900 dark:text-white placeholder-stone-400"
                  />
                </div>
              </div>

              {/* Mobile Services Card View (md:hidden) */}
              <div className="md:hidden space-y-2.5">
                {filteredServices.map((s) => (
                  <div
                    key={s.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      isDarkMode ? 'bg-slate-800/40 border-slate-700/60' : 'bg-[#F4EFE3] border-[#EAE3D2]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-start gap-2.5 min-w-0 flex-1">
                        <div className="pt-0.5 shrink-0">
                          <ServiceCategoryIcon name={s.name} animated={true} size="md" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <span className="font-mono text-[10px] text-stone-400 font-bold">#{s.id}</span>
                          <h3 className="font-bold text-xs text-stone-900 dark:text-white mt-0.5 leading-snug">
                            {s.name}
                          </h3>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedCategory(s.categoryId);
                          setSelectedServiceId(s.id);
                          setActiveTab('new_order');
                        }}
                        className="px-3 py-1.5 bg-[#DC2626] hover:bg-red-700 text-white rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer shadow-xs"
                      >
                        Order
                      </button>
                    </div>
                    <div className="mt-2.5 pt-2 border-t border-[#EAE3D2] dark:border-slate-700/60 flex items-center justify-between text-[11px] text-stone-600 dark:text-gray-400">
                      <div>
                        <span>Rate: </span>
                        <span className="font-mono font-black text-emerald-600 dark:text-emerald-400 text-xs">
                          {formatPrice(s.pricePerThousand)}
                        </span>
                        <span className="text-[10px]"> / 1k</span>
                      </div>
                      <div className="font-mono text-[10px]">
                        Min: {s.minAmount.toLocaleString()} · Max: {s.maxAmount.toLocaleString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Desktop Table View (hidden md:block) */}
              <div className="hidden md:block overflow-x-auto rounded-2xl border border-[#EAE3D2] dark:border-gray-800">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F4EFE3] dark:bg-slate-800/80 text-stone-600 font-mono text-[11px] border-b border-[#EAE3D2] dark:border-gray-800">
                    <tr>
                      <th className="py-3 px-4">ID</th>
                      <th className="py-3 px-4">Service Name</th>
                      <th className="py-3 px-4">Rate / 1K</th>
                      <th className="py-3 px-4">Min</th>
                      <th className="py-3 px-4">Max</th>
                      <th className="py-3 px-4">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EAE3D2] dark:divide-gray-800">
                    {filteredServices.map((s) => (
                      <tr key={s.id} className="hover:bg-[#FAF6EE] dark:hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-stone-400">#{s.id}</td>
                        <td className="py-3 px-4 font-bold text-stone-900 dark:text-white">
                          <div className="flex items-center gap-2.5">
                            <ServiceCategoryIcon name={s.name} animated={true} size="sm" />
                            <span>{s.name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                          {formatPrice(s.pricePerThousand)}
                        </td>
                        <td className="py-3 px-4 font-mono text-stone-500">{s.minAmount.toLocaleString()}</td>
                        <td className="py-3 px-4 font-mono text-stone-500">{s.maxAmount.toLocaleString()}</td>
                        <td className="py-3 px-4">
                          <button
                            onClick={() => {
                              setSelectedCategory(s.categoryId);
                              setSelectedServiceId(s.id);
                              setActiveTab('new_order');
                            }}
                            className="px-3 py-1 bg-[#DC2626] hover:bg-red-700 text-white rounded-lg text-[10px] font-black transition-all cursor-pointer shadow-xs"
                          >
                            Order
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ===================== TAB: ADD FUNDS ===================== */}
          {activeTab === 'add_funds' && (
            <div
              className={`rounded-3xl p-6 sm:p-8 border shadow-xs transition-colors ${
                isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
              }`}
            >
              <AddFundsSection
                token={token}
                user={currentUser}
                publicSettings={publicSettings}
                onRefreshProfile={() => {
                  fetchData();
                  onRefreshUser();
                }}
                isDarkMode={isDarkMode}
                currency={currency}
                formatAmount={(val: number) => `₹${val.toFixed(2)}`}
              />
            </div>
          )}

          {/* ===================== TAB: TICKETS ===================== */}
          {activeTab === 'tickets' && (
            <UserTicketsSection
              token={token}
              currentUser={currentUser}
              isDarkMode={isDarkMode}
              publicSettings={publicSettings}
            />
          )}

          {/* ===================== TAB: RESELLER API ===================== */}
          {activeTab === 'api' && (
            <UserApiDocsSection
              token={token}
              currentUser={currentUser}
              isDarkMode={isDarkMode}
              onRefreshUser={onRefreshUser}
              services={services}
              publicSettings={publicSettings}
            />
          )}

          {/* ===================== TAB: REFILL HISTORY ===================== */}
          {activeTab === 'refills' && (
            <UserRefillsSection
              token={token}
              orders={orders}
              isDarkMode={isDarkMode}
              onRefreshOrders={() => fetchData(true)}
            />
          )}

          {/* ===================== TAB: CHILD PANELS ===================== */}
          {activeTab === 'child_panels' && (
            <UserChildPanelsSection
              token={token}
              currentUser={currentUser}
              isDarkMode={isDarkMode}
              publicSettings={publicSettings}
              onRefreshUser={onRefreshUser}
              formatPrice={formatPrice}
            />
          )}

          {/* ===================== TAB: AFFILIATES ===================== */}
          {activeTab === 'affiliate' && (
            <UserAffiliateSection
              token={token}
              currentUser={currentUser}
              isDarkMode={isDarkMode}
              publicSettings={publicSettings}
            />
          )}

          {/* ===================== TAB: BLOGS & NEWS ===================== */}
          {activeTab === 'blogs' && (
            <UserBlogsSection
              isDarkMode={isDarkMode}
              announcementsList={announcementsList}
              publicSettings={publicSettings}
            />
          )}

          {/* ===================== TAB: FAQ ===================== */}
          {activeTab === 'faq' && (
            <UserFaqSection
              isDarkMode={isDarkMode}
              publicSettings={publicSettings}
              onSwitchToTickets={() => setActiveTab('tickets')}
            />
          )}

          {/* ===================== TAB: SUPPORT CHANNELS ===================== */}
          {activeTab === 'support_channels' && (
            <UserSupportChannelsSection
              isDarkMode={isDarkMode}
              publicSettings={publicSettings}
              onOpenAiChat={() => setIsAiChatOpen(true)}
              onOpenTickets={() => setActiveTab('tickets')}
            />
          )}
        </main>
      </div>

      {/* ===================== REWARDS MODAL ===================== */}
      {showRewardsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-3xl p-6 sm:p-7 border shadow-2xl space-y-5 animate-in fade-in zoom-in-95 ${
              isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-[#FFFDF8] border-[#EAE3D2] text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
                  <Trophy className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-black">Rewards & VIP Tiers</h3>
                  <span className="text-xs text-stone-400">Unlock wholesale rebates & badges</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowRewardsModal(false)}
                className="w-8 h-8 rounded-full bg-[#F4EFE3] dark:bg-slate-800 flex items-center justify-center text-stone-500 hover:text-stone-900 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3.5 rounded-2xl border border-[#EAE3D2] dark:border-slate-800 bg-amber-500/5">
                <div className="flex items-center justify-between font-bold">
                  <span className="text-amber-600 dark:text-amber-400">🥉 Bronze VIP (Level 1-3)</span>
                  <span className="text-[10px] font-mono bg-amber-500/20 text-amber-600 px-2 py-0.5 rounded-full">Active</span>
                </div>
                <p className="text-stone-500 mt-1">Default starting rank. Access to standard wholesale rates.</p>
              </div>

              <div className="p-3.5 rounded-2xl border border-[#EAE3D2] dark:border-slate-800 bg-[#F4EFE3]/50">
                <div className="flex items-center justify-between font-bold">
                  <span className="text-slate-400">🥈 Silver VIP (Spend ₹1,000+)</span>
                  <span className="text-[10px] text-stone-400">Locked</span>
                </div>
                <p className="text-stone-500 mt-1">Unlock 2% instant bonus on every deposit + dedicated support.</p>
              </div>

              <div className="p-3.5 rounded-2xl border border-[#EAE3D2] dark:border-slate-800 bg-[#F4EFE3]/50">
                <div className="flex items-center justify-between font-bold">
                  <span className="text-yellow-600 dark:text-yellow-500">🥇 Gold VIP (Spend ₹5,000+)</span>
                  <span className="text-[10px] text-stone-400">Locked</span>
                </div>
                <p className="text-stone-500 mt-1">Unlock 5% instant bonus + priority order queue + private manager.</p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowRewardsModal(false);
                setActiveTab('add_funds');
              }}
              className="w-full py-3.5 rounded-2xl bg-[#DC2626] hover:bg-red-700 text-white font-black text-xs shadow-md transition-all cursor-pointer"
            >
              Deposit Funds to Level Up
            </button>
          </div>
        </div>
      )}

      {/* ===================== FLOATING WHATSAPP BUTTON (BOTTOM-LEFT) ===================== */}
      <WhatsAppSupportButton
        phoneNumber={publicSettings?.whatsappNumber || publicSettings?.bharatpePhone || '8795005604'}
        websiteName={publicSettings?.websiteName || 'YouthSMM'}
        userName={displayName}
      />

      {/* ===================== FLOATING 24/7 AI SUPPORT CHATBOT (BOTTOM-RIGHT) ===================== */}
      <AiChatBot
        userId={user.id}
        userName={displayName}
        isDarkMode={isDarkMode}
        latestOrderId={orders[0]?.id}
        onNavigateTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        whatsappNumber={publicSettings?.whatsappNumber || '8795005604'}
        telegramUsername={publicSettings?.telegramUsername || '@securesmmtursted'}
        telegramChannel={publicSettings?.telegramChannel || 'https://t.me/securesmmtursted'}
        websiteName={publicSettings?.websiteName || 'YouthSMM'}
        isOpen={isAiChatOpen}
        onClose={() => setIsAiChatOpen(false)}
        onToggleOpen={(open) => setIsAiChatOpen(open)}
      />

      {/* ===================== ACCOUNT SETTINGS MODAL ===================== */}
      {showAccountSettingsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-lg rounded-3xl p-6 sm:p-7 shadow-2xl border space-y-5 animate-in fade-in zoom-in-95 max-h-[90vh] overflow-y-auto select-none ${
              isDarkMode
                ? 'bg-[#0F172A] border-slate-700 text-white shadow-black/90'
                : 'bg-[#FFFDF8] border-[#EAE3D2] text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-4 border-[#EAE3D2] dark:border-slate-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-10 h-10 rounded-xl bg-sky-500/15 text-sky-500 dark:text-sky-400 flex items-center justify-center">
                  <UserIcon className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div>
                  <h3 className="text-lg font-black tracking-tight text-stone-900 dark:text-white">Account Settings</h3>
                  <p className="text-xs text-stone-500 dark:text-gray-300">Manage your profile, credentials & API access</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowAccountSettingsModal(false);
                  setAccountSettingsSuccess('');
                }}
                className="w-8 h-8 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 flex items-center justify-center text-stone-600 dark:text-white cursor-pointer transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {accountSettingsSuccess && (
              <div className="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 shrink-0 text-emerald-500" />
                <span>{accountSettingsSuccess}</span>
              </div>
            )}

            {/* Profile Overview */}
            <div className="p-4 rounded-2xl bg-[#F4EFE3] dark:bg-slate-800/80 border border-[#EAE3D2] dark:border-slate-700 space-y-3">
              <span className="text-[11px] font-black uppercase tracking-wider text-stone-700 dark:text-gray-200 block">Profile Information</span>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-stone-500 dark:text-gray-400 block text-[10px] font-bold">Email Address</span>
                  <span className="font-black truncate block text-stone-900 dark:text-white">{user.email}</span>
                </div>
                <div>
                  <span className="text-stone-500 dark:text-gray-400 block text-[10px] font-bold">Account Role</span>
                  <span className="font-black text-rose-600 dark:text-rose-400 uppercase">{user.role || (isAdmin ? 'Admin' : 'User')}</span>
                </div>
                <div>
                  <span className="text-stone-500 dark:text-gray-400 block text-[10px] font-bold">Current Balance</span>
                  <span className="font-black font-mono text-emerald-600 dark:text-emerald-400">₹{Number(userBalance ?? 728.91).toFixed(2)}</span>
                </div>
                <div>
                  <span className="text-stone-500 dark:text-gray-400 block text-[10px] font-bold">User ID</span>
                  <span className="font-black font-mono text-stone-900 dark:text-white">#{user.id}</span>
                </div>
              </div>
            </div>

            {/* API Key */}
            <div className="p-4 rounded-2xl bg-[#F4EFE3] dark:bg-slate-800/80 border border-[#EAE3D2] dark:border-slate-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black uppercase tracking-wider text-stone-700 dark:text-gray-200">Reseller API Key</span>
                <button
                  type="button"
                  onClick={() => {
                    const key = user.apiKey || `ysmm_${user.id}_${btoa(user.email).slice(0, 16)}`;
                    navigator.clipboard.writeText(key);
                    setCopiedApiKey(true);
                    setTimeout(() => setCopiedApiKey(false), 2000);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-[#EFE8D8] dark:bg-sky-500/20 text-stone-800 dark:text-sky-300 border border-[#DDD3BC] dark:border-sky-500/30 text-[10px] font-black hover:bg-[#EAE1CD] dark:hover:bg-sky-500/30 cursor-pointer transition-colors"
                >
                  {copiedApiKey ? 'COPIED!' : 'COPY API KEY'}
                </button>
              </div>
              <div className="p-2.5 rounded-xl bg-[#FFFDF8] dark:bg-slate-900 border border-[#DDD3BC] dark:border-slate-700 font-mono text-xs text-stone-900 dark:text-white truncate">
                {user.apiKey || `ysmm_${user.id}_••••••••••••••••••••••••`}
              </div>
            </div>

            {/* Change Password */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!newPassword || newPassword.length < 6) {
                  alert('Password must be at least 6 characters long.');
                  return;
                }
                setAccountSettingsSuccess('Password updated successfully!');
                setOldPassword('');
                setNewPassword('');
                setTimeout(() => setAccountSettingsSuccess(''), 3000);
              }}
              className="space-y-3 pt-1"
            >
              <span className="text-[11px] font-black uppercase tracking-wider text-stone-700 dark:text-gray-200 block">Change Password</span>
              <div className="space-y-2">
                <input
                  type="password"
                  placeholder="Current Password"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-700 bg-[#F4EFE3] dark:bg-slate-800 text-xs font-semibold text-stone-900 dark:text-white placeholder-stone-400 dark:placeholder-gray-400 focus:outline-hidden focus:ring-2 focus:ring-red-500"
                />
                <input
                  type="password"
                  placeholder="New Password (min 6 characters)"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-700 bg-[#F4EFE3] dark:bg-slate-800 text-xs font-semibold text-stone-900 dark:text-white placeholder-stone-400 dark:placeholder-gray-400 focus:outline-hidden focus:ring-2 focus:ring-red-500"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#DC2626] hover:bg-red-700 text-white font-black text-xs shadow-md transition-all cursor-pointer"
              >
                Update Password
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ===================== ABOUT US & PLATFORM MODAL ===================== */}
      {showAboutModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl border space-y-4 animate-in fade-in zoom-in-95 select-none ${
              isDarkMode
                ? 'bg-[#0F172A] border-slate-700 text-white shadow-black/90'
                : 'bg-[#FFFDF8] border-[#EAE3D2] text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-[#EAE3D2] dark:border-slate-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-10 h-10 rounded-xl bg-red-500/15 text-red-500 dark:text-red-400 flex items-center justify-center">
                  <Info className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div>
                  <h3 className="text-lg font-black tracking-tight text-stone-900 dark:text-white">About YouthSMM</h3>
                  <p className="text-xs text-stone-500 dark:text-gray-300">High-speed social media growth platform</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAboutModal(false)}
                className="w-8 h-8 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 flex items-center justify-center text-stone-600 dark:text-white cursor-pointer transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-stone-600 dark:text-gray-200 leading-relaxed font-medium">
              YouthSMM is India's premier automated SMM panel offering direct wholesale supplier rates for Instagram, YouTube, Facebook, Telegram, TikTok, and 50+ other networks.
            </p>
            <div className="space-y-2 pt-1 text-xs">
              <div className="flex items-center space-x-2 text-stone-800 dark:text-white font-medium">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Zero bot delays: Direct API provider automated order routing</span>
              </div>
              <div className="flex items-center space-x-2 text-stone-800 dark:text-white font-medium">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Instant automated BharatPe & UPI payment settlements</span>
              </div>
              <div className="flex items-center space-x-2 text-stone-800 dark:text-white font-medium">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>24x7 WhatsApp & live AI agent ticket resolution</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowAboutModal(false)}
              className="w-full py-2.5 mt-2 rounded-xl bg-[#F4EFE3] dark:bg-slate-800 hover:bg-[#EAE3D0] dark:hover:bg-slate-700 text-stone-900 dark:text-white font-bold text-xs cursor-pointer border border-[#DDD3BC] dark:border-slate-700"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* ===================== TERMS & CONDITIONS MODAL ===================== */}
      {showTermsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-lg rounded-3xl p-6 sm:p-7 shadow-2xl border space-y-4 animate-in fade-in zoom-in-95 max-h-[85vh] overflow-y-auto select-none ${
              isDarkMode
                ? 'bg-[#0F172A] border-slate-700 text-white shadow-black/90'
                : 'bg-[#FFFDF8] border-[#EAE3D2] text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-[#EAE3D2] dark:border-slate-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-10 h-10 rounded-xl bg-sky-500/15 text-sky-500 dark:text-sky-400 flex items-center justify-center">
                  <FileText className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div>
                  <h3 className="text-lg font-black tracking-tight text-stone-900 dark:text-white">Terms & Conditions</h3>
                  <p className="text-xs text-stone-500 dark:text-gray-300">Service usage and ordering agreement</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowTermsModal(false)}
                className="w-8 h-8 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 flex items-center justify-center text-stone-600 dark:text-white cursor-pointer transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-3 text-xs text-stone-700 dark:text-gray-200 leading-relaxed font-medium">
              <p>
                <strong className="text-stone-900 dark:text-white">1. Acceptance:</strong> By placing an order with YouthSMM, you automatically agree to our terms of service and guarantee that your target links comply with social network policies.
              </p>
              <p>
                <strong className="text-stone-900 dark:text-white">2. Order Fulfillment:</strong> Delivery speeds and start times are estimated. High server load may slightly vary processing times.
              </p>
              <p>
                <strong className="text-stone-900 dark:text-white">3. Refills & Guarantees:</strong> Services marked with [Refill] qualify for free refill within the stated warranty period via the automated Refill button.
              </p>
              <p>
                <strong className="text-stone-900 dark:text-white">4. Account Safety:</strong> Ensure your social profile remains public during order execution. Changing account handles mid-order will void refills.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowTermsModal(false)}
              className="w-full py-2.5 rounded-xl bg-[#F4EFE3] dark:bg-slate-800 hover:bg-[#EAE3D0] dark:hover:bg-slate-700 text-stone-900 dark:text-white font-bold text-xs cursor-pointer border border-[#DDD3BC] dark:border-slate-700"
            >
              Understood
            </button>
          </div>
        </div>
      )}

      {/* ===================== PRIVACY POLICY MODAL ===================== */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-lg rounded-3xl p-6 sm:p-7 shadow-2xl border space-y-4 animate-in fade-in zoom-in-95 max-h-[85vh] overflow-y-auto select-none ${
              isDarkMode
                ? 'bg-[#0F172A] border-slate-700 text-white shadow-black/90'
                : 'bg-[#FFFDF8] border-[#EAE3D2] text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-[#EAE3D2] dark:border-slate-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div>
                  <h3 className="text-lg font-black tracking-tight text-stone-900 dark:text-white">Privacy Policy</h3>
                  <p className="text-xs text-stone-500 dark:text-gray-300">Your data protection & confidentiality</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowPrivacyModal(false)}
                className="w-8 h-8 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 flex items-center justify-center text-stone-600 dark:text-white cursor-pointer transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-3 text-xs text-stone-700 dark:text-gray-200 leading-relaxed font-medium">
              <p>
                <strong className="text-stone-900 dark:text-white">1. Data Encryption:</strong> All communications between your device and YouthSMM are secured using 256-bit TLS/SSL encryption.
              </p>
              <p>
                <strong className="text-stone-900 dark:text-white">2. Zero Credential Request:</strong> YouthSMM will never ask for your social media account passwords. We only require public profile or post links.
              </p>
              <p>
                <strong className="text-stone-900 dark:text-white">3. Financial Privacy:</strong> Payment transactions processed via BharatPe and UPI gateways are handled under PCI-DSS compliant protocols.
              </p>
              <p>
                <strong className="text-stone-900 dark:text-white">4. Confidentiality:</strong> Your identity and ordering history are strictly private and never shared with third-party advertising networks.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowPrivacyModal(false)}
              className="w-full py-2.5 rounded-xl bg-[#F4EFE3] dark:bg-slate-800 hover:bg-[#EAE3D0] dark:hover:bg-slate-700 text-stone-900 dark:text-white font-bold text-xs cursor-pointer border border-[#DDD3BC] dark:border-slate-700"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* ===================== MOBILE BOTTOM NAVIGATION BAR (MATCHING USER SCREENSHOT) ===================== */}
      <nav
        aria-label="Mobile Navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FAF6EE]/98 dark:bg-[#0F172A]/98 backdrop-blur-md border-t border-[#EAE3D2] dark:border-slate-800/80 px-2 pt-1.5 pb-[max(0.6rem,env(safe-area-inset-bottom))] shadow-[0_-4px_25px_rgba(150,130,90,0.08)] select-none"
      >
        <div className="max-w-md mx-auto grid grid-cols-5 items-end relative">
          {/* 1. New */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('new_order');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${
              activeTab === 'new_order'
                ? 'text-[#DC2626] font-bold'
                : 'text-stone-500 dark:text-slate-400 font-medium hover:text-stone-800'
            }`}
          >
            <Zap
              className={`w-5 h-5 stroke-[2.2] transition-colors ${
                activeTab === 'new_order' ? 'stroke-[#DC2626]' : 'stroke-current'
              }`}
            />
            <span className="text-[11px] mt-1 tracking-tight">New</span>
          </button>

          {/* 2. Orders */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('orders');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex flex-col items-center justify-center py-1 transition-all cursor-pointer relative ${
              activeTab === 'orders'
                ? 'text-[#DC2626] font-bold'
                : 'text-stone-500 dark:text-slate-400 font-medium hover:text-stone-800'
            }`}
          >
            <div className="relative">
              <Package
                className={`w-5 h-5 stroke-[1.8] transition-colors ${
                  activeTab === 'orders' ? 'stroke-[#DC2626]' : 'stroke-current'
                }`}
              />
              {orders.length > 0 && (
                <span className="absolute -top-1 -right-2 px-1 min-w-[15px] h-3.5 rounded-full bg-red-600 text-white text-[8px] font-mono font-bold flex items-center justify-center">
                  {orders.length > 99 ? '99+' : orders.length}
                </span>
              )}
            </div>
            <span className="text-[11px] mt-1 tracking-tight">Orders</span>
          </button>

          {/* 3. Center Elevated Floating Funds Button */}
          <div className="flex flex-col items-center justify-center relative -top-4">
            <button
              type="button"
              onClick={() => {
                setActiveTab('add_funds');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-gradient-to-tr from-[#DC2626] to-[#EF4444] text-white flex items-center justify-center shadow-[0_8px_20px_-2px_rgba(220,38,38,0.5)] border-4 border-[#FAF6EE] dark:border-[#0F172A] hover:scale-105 active:scale-95 transition-all cursor-pointer select-none"
              title="Add Funds"
            >
              <Plus className="w-7 h-7 stroke-[3] text-white" />
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('add_funds');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`text-[11px] mt-0.5 tracking-tight font-bold cursor-pointer transition-colors ${
                activeTab === 'add_funds' ? 'text-[#DC2626]' : 'text-stone-600 dark:text-slate-300'
              }`}
            >
              Funds
            </button>
          </div>

          {/* 4. Services */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('services');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${
              activeTab === 'services'
                ? 'text-[#DC2626] font-bold'
                : 'text-stone-500 dark:text-slate-400 font-medium hover:text-stone-800'
            }`}
          >
            <Layers
              className={`w-5 h-5 stroke-[1.8] transition-colors ${
                activeTab === 'services' ? 'stroke-[#DC2626]' : 'stroke-current'
              }`}
            />
            <span className="text-[11px] mt-1 tracking-tight">Services</span>
          </button>

          {/* 5. More (Three-Dot Menu) */}
          <button
            type="button"
            onClick={() => setShowMobileNavDrawer(true)}
            className="flex flex-col items-center justify-center py-1 text-stone-500 dark:text-slate-400 font-medium hover:text-stone-800 dark:hover:text-white transition-all cursor-pointer"
            aria-label="More Menu"
          >
            <MoreHorizontal className="w-5 h-5 stroke-[2.2]" />
            <span className="text-[11px] mt-1 tracking-tight">More</span>
          </button>
        </div>
      </nav>

      {/* ===================== MOBILE FULL MENU DRAWER ===================== */}
      {showMobileNavDrawer && (
        <div
          className="fixed inset-0 z-50 flex justify-start animate-in fade-in duration-200 lg:hidden overflow-hidden"
          role="dialog"
          aria-modal="true"
          aria-label="Navigation Menu"
        >
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={() => setShowMobileNavDrawer(false)}
            aria-hidden="true"
          />

          {/* Drawer content */}
          <aside
            className={`relative h-[100dvh] shadow-2xl flex flex-col z-10 select-none border-r animate-in slide-in-from-left duration-200 ${
              isDarkMode
                ? 'bg-[#0F172A] text-white border-slate-800'
                : 'bg-[#FAF6EE] text-stone-900 border-[#EAE3D2]'
            }`}
            style={{
              width: 'min(86vw, 360px)',
              maxWidth: 'calc(100vw - 16px)',
            }}
          >
            {/* 1. Sticky Header with Top Safe Area */}
            <div className="shrink-0 pt-[max(0.75rem,env(safe-area-inset-top))] px-4 pb-3 border-b border-gray-200/90 dark:border-slate-800/90 flex items-center justify-between gap-3 bg-inherit">
              <div className="min-w-0 flex items-center overflow-hidden">
                <AnimatedLogo size="xs" showText={true} theme={isDarkMode ? 'dark' : 'light'} />
              </div>
              <button
                type="button"
                onClick={() => setShowMobileNavDrawer(false)}
                className="w-8 h-8 rounded-full bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer shrink-0 active:scale-95"
                aria-label="Close menu"
              >
                <X className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>

            {/* Profile Quick Trigger Card */}
            <div className="shrink-0 px-4 pt-3 pb-1">
              <button
                type="button"
                onClick={() => {
                  setShowMobileNavDrawer(false);
                  setShowUserMenu(true);
                }}
                className={`w-full p-2.5 rounded-2xl flex items-center justify-between border transition-all text-left cursor-pointer group ${
                  isDarkMode
                    ? 'bg-slate-800/80 hover:bg-slate-800 border-slate-700 text-white'
                    : 'bg-white hover:bg-stone-50 border-[#EAE3D2] text-stone-900 shadow-xs'
                }`}
              >
                <div className="flex items-center space-x-2.5 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#DC2626] to-[#EF4444] text-white flex items-center justify-center font-black text-sm shadow-xs shrink-0 uppercase">
                    {user.email ? user.email.charAt(0) : 'U'}
                  </div>
                  <div className="min-w-0">
                    <span className="text-[10px] font-black uppercase tracking-wider text-stone-500 dark:text-gray-400 block">
                      Profile
                    </span>
                    <span className="text-xs font-black text-stone-900 dark:text-white truncate block">
                      {user.email || user.name || 'Member'}
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-1 text-xs font-bold text-red-600 dark:text-red-400">
                  <span className="text-[11px] font-bold">Manage</span>
                  <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>
            </div>

            {/* 2. User Balance Card */}
            <div className="shrink-0 px-4 pt-3.5 pb-2">
              <div className="p-3.5 rounded-2xl bg-[#DC2626] text-white flex items-center justify-between shadow-md shadow-red-600/20 gap-2.5">
                <div className="min-w-0 flex-1">
                  <span className="text-[10px] font-black uppercase tracking-wider text-white/80 block">
                    Balance
                  </span>
                  <div className="text-lg sm:text-xl font-black font-mono tracking-tight truncate mt-0.5">
                    {formatPrice(userBalance)}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('add_funds');
                    setShowMobileNavDrawer(false);
                  }}
                  className="px-3.5 py-1.5 rounded-full bg-white text-[#DC2626] hover:bg-red-50 text-xs font-black shadow-xs cursor-pointer shrink-0 transition-transform active:scale-95"
                >
                  + Add
                </button>
              </div>
            </div>

            {/* 3. Vertically Scrollable Navigation List (NO NATIVE SCROLLBAR) */}
            <div 
              className="flex-1 overflow-y-auto overscroll-contain px-4 py-2 space-y-1 no-scrollbar [&::-webkit-scrollbar]:hidden"
              style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
              {/* 1. New Order */}
              <button
                type="button"
                onClick={() => { setActiveTab('new_order'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'new_order'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#DC2626] text-white shrink-0 shadow-xs">
                  <Zap className="w-4 h-4 fill-current" />
                </div>
                <span className="truncate flex-1 text-left">New Order</span>
              </button>

              {/* 2. Mass Order */}
              <button
                type="button"
                onClick={() => { setActiveTab('mass_order'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'mass_order'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#6366F1] text-white shrink-0 shadow-xs">
                  <Sliders className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">Mass Order</span>
              </button>

              {/* 3. Orders History */}
              <button
                type="button"
                onClick={() => { setActiveTab('orders'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'orders'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#3B82F6] text-white shrink-0 shadow-xs">
                  <ListOrdered className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">Orders History</span>
                {orders.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300 shrink-0">
                    {orders.length}
                  </span>
                )}
              </button>

              {/* 4. Services List */}
              <button
                type="button"
                onClick={() => { setActiveTab('services'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'services'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#06B6D4] text-white shrink-0 shadow-xs">
                  <Layers className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">Services List</span>
                {services.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-100 text-cyan-700 dark:bg-cyan-950 dark:text-cyan-300 shrink-0">
                    {services.length}
                  </span>
                )}
              </button>

              {/* 5. Add Funds */}
              <button
                type="button"
                onClick={() => { setActiveTab('add_funds'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'add_funds'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#10B981] text-white shrink-0 shadow-xs">
                  <Wallet className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">Add Funds</span>
              </button>

              {/* Divider */}
              <div className="pt-2 pb-1">
                <div className="border-t border-gray-200/80 dark:border-slate-800" />
              </div>

              {/* 6. Tickets */}
              <button
                type="button"
                onClick={() => { setActiveTab('tickets'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'tickets'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#FF5376] text-white shrink-0 shadow-xs">
                  <Ticket className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">Tickets</span>
                {userTickets.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 shrink-0">
                    {userTickets.length}
                  </span>
                )}
              </button>

              {/* 7. Api */}
              <button
                type="button"
                onClick={() => { setActiveTab('api'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'api'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#FF1A1A] text-white shrink-0 shadow-xs">
                  <FileCode className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">API Docs</span>
              </button>

              {/* 8. Refill History */}
              <button
                type="button"
                onClick={() => { setActiveTab('refills'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'refills'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#FF9900] text-white shrink-0 shadow-xs">
                  <RefreshCw className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">Refill History</span>
              </button>

              {/* 9. Child Panels */}
              <button
                type="button"
                onClick={() => { setActiveTab('child_panels'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'child_panels'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#00B4B6] text-white shrink-0 shadow-xs">
                  <Globe className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">
                  {publicSettings?.childPanelTitle || 'Child Panels'}
                </span>
              </button>

              {/* 10. Affiliates */}
              <button
                type="button"
                onClick={() => { setActiveTab('affiliate'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'affiliate'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#8E44AD] text-white shrink-0 shadow-xs">
                  <Users className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">Affiliates</span>
              </button>

              {/* 11. Blogs & News */}
              <button
                type="button"
                onClick={() => { setActiveTab('blogs'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'blogs'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#E91E63] text-white shrink-0 shadow-xs">
                  <BookOpen className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">Blogs & News</span>
              </button>

              {/* 12. FAQ */}
              <button
                type="button"
                onClick={() => { setActiveTab('faq'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'faq'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#2196F3] text-white shrink-0 shadow-xs">
                  <HelpCircle className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">FAQ</span>
              </button>

              {/* 13. Support Channels */}
              <button
                type="button"
                onClick={() => { setActiveTab('support_channels'); setShowMobileNavDrawer(false); }}
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold cursor-pointer transition-all ${
                  activeTab === 'support_channels'
                    ? 'bg-[#EDE8DE] dark:bg-slate-800 text-stone-900 dark:text-white font-extrabold shadow-xs'
                    : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#00897B] text-white shrink-0 shadow-xs">
                  <Headphones className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">Support Channels</span>
              </button>

              {/* 14. Rewards & Level Tier */}
              <button
                type="button"
                onClick={() => { setShowRewardsModal(true); setShowMobileNavDrawer(false); }}
                className="w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-bold text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer transition-all"
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#F59E0B] text-white shrink-0 shadow-xs">
                  <Award className="w-4 h-4" />
                </div>
                <span className="truncate flex-1 text-left">Rewards & Level Tier</span>
              </button>

              {/* 15. Admin Switcher (Only if Admin) */}
              {isAdmin && (
                <button
                  type="button"
                  onClick={() => { onSwitchToAdmin(); setShowMobileNavDrawer(false); }}
                  className="w-full flex items-center space-x-3 px-3 py-2 rounded-2xl text-[13.5px] font-extrabold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-500/20 cursor-pointer transition-all"
                >
                  <div className="w-8 h-8 rounded-full flex items-center justify-center bg-[#4F46E5] text-white shrink-0 shadow-xs">
                    <Shield className="w-4 h-4" />
                  </div>
                  <span className="truncate flex-1 text-left">👑 Switch to Admin Panel</span>
                </button>
              )}

              {/* Informational Links */}
              <div className="pt-2.5 pb-1 border-t border-gray-200/80 dark:border-slate-800 space-y-0.5">
                <button
                  type="button"
                  onClick={() => { setShowAboutModal(true); setShowMobileNavDrawer(false); }}
                  className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer"
                >
                  <Info className="w-3.5 h-3.5 text-gray-400" />
                  <span>About Us</span>
                </button>
                <button
                  type="button"
                  onClick={() => { setShowTermsModal(true); setShowMobileNavDrawer(false); }}
                  className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-gray-400" />
                  <span>Terms & Conditions</span>
                </button>
                <button
                  type="button"
                  onClick={() => { setShowPrivacyModal(true); setShowMobileNavDrawer(false); }}
                  className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-gray-400" />
                  <span>Privacy Policy</span>
                </button>
              </div>
            </div>

            {/* 4. Drawer Footer (Sticky Bottom) */}
            <div className="shrink-0 p-4 border-t border-gray-200 dark:border-slate-800 bg-[#FAF6EE] dark:bg-[#0F172A] space-y-2 pb-[max(1rem,env(safe-area-inset-bottom))]">
              <button
                type="button"
                onClick={() => {
                  setShowMobileNavDrawer(false);
                  onLogout();
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-[#DC2626] font-extrabold text-xs flex items-center justify-center space-x-2 cursor-pointer transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
              <div className="text-[10px] text-center text-gray-400 font-medium select-none truncate">
                {publicSettings?.footerCopyright || '© YouthSMM | Main SMM Provider'}
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
};
