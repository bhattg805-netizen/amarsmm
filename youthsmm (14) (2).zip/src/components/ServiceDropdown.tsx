import React, { useState, useRef, useEffect, useId } from 'react';
import { ChevronDown, Check } from 'lucide-react';
import type { Service } from '../types';

interface ServiceDropdownProps {
  services: Service[];
  selectedServiceId: number | '';
  onSelectService: (serviceId: number) => void;
  isDarkMode?: boolean;
  disabled?: boolean;
  formatPrice?: (val: number) => string;
}

export const ServiceDropdown: React.FC<ServiceDropdownProps> = ({
  services,
  selectedServiceId,
  onSelectService,
  isDarkMode = false,
  disabled = false,
  formatPrice = (val) => `₹${Number(val).toFixed(2)}`,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState<number>(-1);

  const containerRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const listboxId = useId();

  // Find currently selected service object
  const selectedService = services.find((s) => s.id === selectedServiceId) || null;

  // Close dropdown on click outside
  useEffect(() => {
    if (!isOpen) return;

    const handlePointerDownOutside = (e: MouseEvent | TouchEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handlePointerDownOutside);
    document.addEventListener('touchstart', handlePointerDownOutside);
    return () => {
      document.removeEventListener('mousedown', handlePointerDownOutside);
      document.removeEventListener('touchstart', handlePointerDownOutside);
    };
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) {
      setHighlightedIndex(-1);
    }
  }, [isOpen]);

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (disabled) return;

    if (!isOpen) {
      if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
        e.preventDefault();
        setIsOpen(true);
      }
      return;
    }

    if (e.key === 'Escape') {
      e.preventDefault();
      setIsOpen(false);
      triggerRef.current?.focus();
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightedIndex((prev) => {
        const next = prev < services.length - 1 ? prev + 1 : 0;
        scrollToIndex(next);
        return next;
      });
      return;
    }

    if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightedIndex((prev) => {
        const next = prev > 0 ? prev - 1 : services.length - 1;
        scrollToIndex(next);
        return next;
      });
      return;
    }

    if (e.key === 'Enter' && highlightedIndex >= 0 && highlightedIndex < services.length) {
      e.preventDefault();
      const chosen = services[highlightedIndex];
      onSelectService(chosen.id);
      setIsOpen(false);
      triggerRef.current?.focus();
      return;
    }

    if (e.key === 'Tab') {
      setIsOpen(false);
    }
  };

  const scrollToIndex = (idx: number) => {
    if (!listRef.current) return;
    const items = listRef.current.querySelectorAll('[data-service-item]');
    const target = items[idx] as HTMLElement;
    if (target) {
      target.scrollIntoView({ block: 'nearest' });
    }
  };

  const handleSelect = (serviceId: number) => {
    onSelectService(serviceId);
    setIsOpen(false);
    triggerRef.current?.focus();
  };

  // Helper to extract clean service title and badge info (e.g. Refill, Start Time, Guaranteed)
  const extractServiceSpecs = (s: Service) => {
    const raw = `${s.name} ${s.description || ''}`.toLowerCase();
    const hasRefill = /refill|lifetime|guarantee|30d|60d|365d/i.test(raw);
    const isInstant = /instant|0-1h|fast|speed|bullet|turbo/i.test(raw);
    const isNonDrop = /non-?drop|no drop|real/i.test(raw);
    return { hasRefill, isInstant, isNonDrop };
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full max-w-full"
      onKeyDown={handleKeyDown}
    >
      {/* TRIGGER BUTTON - NO ICONS, PURE TEXT + PRICE BADGE + CHEVRON */}
      <button
        ref={triggerRef}
        type="button"
        disabled={disabled || services.length === 0}
        onClick={() => {
          if (!disabled && services.length > 0) setIsOpen((prev) => !prev);
        }}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        aria-controls={listboxId}
        className={`w-full box-border rounded-2xl px-4 py-3 sm:py-3.5 min-h-[44px] flex items-center justify-between gap-2.5 text-left transition-all duration-150 select-none cursor-pointer outline-none ${
          disabled || services.length === 0 ? 'opacity-50 cursor-not-allowed' : ''
        } ${
          isOpen
            ? 'ring-2 ring-red-500/30 border-[#DC2626] shadow-sm'
            : isDarkMode
            ? 'hover:border-slate-600 focus:ring-2 focus:ring-red-500/30'
            : 'hover:border-[#DDD3BC] focus:ring-2 focus:ring-red-500/30'
        } ${
          isDarkMode
            ? 'bg-slate-800/90 border-slate-700 text-white'
            : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-900'
        }`}
      >
        {/* Left: Service info without any icons */}
        <div className="flex-1 min-w-0 pr-1">
          {selectedService ? (
            <div className="flex flex-col gap-0.5">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-mono text-[11px] font-extrabold text-red-600 dark:text-red-400 shrink-0">
                  #{selectedService.id}
                </span>
                <span className="truncate font-bold text-xs sm:text-sm text-stone-900 dark:text-white">
                  {selectedService.name}
                </span>
              </div>
              <div className="flex items-center gap-2 text-[10px] sm:text-[11px] font-semibold text-stone-500 dark:text-stone-400 font-mono">
                <span>Min: {selectedService.minAmount?.toLocaleString()}</span>
                <span>•</span>
                <span>Max: {selectedService.maxAmount?.toLocaleString()}</span>
                {extractServiceSpecs(selectedService).hasRefill && (
                  <>
                    <span>•</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">Refill Guaranteed</span>
                  </>
                )}
              </div>
            </div>
          ) : (
            <span className="text-stone-500 dark:text-stone-400 text-xs font-semibold">
              {services.length === 0 ? 'No services available' : 'Select a Service'}
            </span>
          )}
        </div>

        {/* Right: Price Badge + Blue Chevron Indicator (Matching YouthSMM Design) */}
        <div className="flex items-center gap-2 shrink-0">
          {selectedService && (
            <div className="hidden xs:flex sm:flex items-center px-2 py-0.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-[11px] font-mono font-extrabold whitespace-nowrap">
              {formatPrice(Number(selectedService.pricePerThousand))}/1K
            </div>
          )}
          <div
            className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all duration-150 ${
              isOpen ? 'bg-[#DC2626] text-white rotate-180 shadow-xs' : 'bg-blue-600 text-white'
            }`}
          >
            <ChevronDown className="w-4 h-4 stroke-[2.5]" />
          </div>
        </div>
      </button>

      {/* DROPDOWN PANEL - NO ICONS, NO SEARCH BOX, COMPACT VIEWPORT-AWARE MAX HEIGHT, INTERNAL SCROLL */}
      {isOpen && (
        <div
          id={listboxId}
          role="listbox"
          aria-label="Services"
          className={`absolute left-0 right-0 top-full mt-1.5 z-50 w-full max-w-full box-border rounded-2xl border shadow-xl flex flex-col overflow-hidden transition-all duration-150 max-h-[min(260px,36vh)] sm:max-h-[min(320px,42vh)] ${
            isDarkMode
              ? 'bg-slate-900 border-slate-700/90 text-white shadow-black/50'
              : 'bg-[#FFFDF8] border-[#DDD3BC] text-stone-900 shadow-stone-900/10'
          }`}
        >
          {/* Internally Scrollable Service Items List - STRICTLY NO ICONS & NO SEARCH BOX */}
          <div
            ref={listRef}
            className="overflow-y-auto overscroll-contain flex-1 divide-y divide-stone-100 dark:divide-slate-800/60 p-1"
            style={{
              WebkitOverflowScrolling: 'touch',
            }}
          >
            {services.length === 0 ? (
              <div className="p-6 text-center text-xs text-stone-400">
                No services available
              </div>
            ) : (
              services.map((service, index) => {
                const isSelected = service.id === selectedServiceId;
                const isHighlighted = index === highlightedIndex;
                const specs = extractServiceSpecs(service);

                return (
                  <div
                    key={service.id}
                    data-service-item
                    role="option"
                    aria-selected={isSelected}
                    onClick={() => handleSelect(service.id)}
                    onMouseEnter={() => setHighlightedIndex(index)}
                    className={`min-h-[44px] px-3 py-2.5 rounded-xl cursor-pointer transition-colors duration-100 flex items-center justify-between gap-2.5 select-none ${
                      isSelected
                        ? isDarkMode
                          ? 'bg-red-500/15 border-l-4 border-red-500 text-white'
                          : 'bg-red-50 border-l-4 border-red-600 text-stone-900'
                        : isHighlighted
                        ? isDarkMode
                          ? 'bg-slate-800/80 text-white'
                          : 'bg-[#F4EFE3]/80 text-stone-900'
                        : 'hover:bg-black/5 dark:hover:bg-white/5'
                    }`}
                  >
                    {/* Left: ID + Name + Meta Info (NO ICONS) */}
                    <div className="flex-1 min-w-0 pr-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-[10px] sm:text-[11px] font-extrabold text-red-600 dark:text-red-400 shrink-0">
                          #{service.id}
                        </span>
                        <span
                          className={`text-xs font-semibold truncate ${
                            isSelected
                              ? 'font-bold text-red-700 dark:text-red-300'
                              : 'text-stone-800 dark:text-stone-200'
                          }`}
                        >
                          {service.name}
                        </span>
                      </div>

                      {/* Service Details: Min/Max, Refill guarantee, Speed info */}
                      <div className="flex items-center gap-2 text-[10px] text-stone-500 dark:text-stone-400 font-mono mt-0.5 flex-wrap">
                        <span>Min: {service.minAmount?.toLocaleString()}</span>
                        <span>•</span>
                        <span>Max: {service.maxAmount?.toLocaleString()}</span>
                        {specs.hasRefill && (
                          <>
                            <span>•</span>
                            <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                              Refill Guaranteed
                            </span>
                          </>
                        )}
                        {specs.isInstant && (
                          <>
                            <span>•</span>
                            <span className="text-blue-600 dark:text-blue-400 font-bold">
                              Fast Start
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Right: Price per 1K + Checkmark if selected */}
                    <div className="flex items-center gap-2 shrink-0">
                      <div
                        className={`px-2 py-0.5 rounded-lg text-[11px] font-mono font-bold whitespace-nowrap ${
                          isSelected
                            ? 'bg-red-600 text-white shadow-xs'
                            : 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {formatPrice(Number(service.pricePerThousand))}/1K
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center shrink-0">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
