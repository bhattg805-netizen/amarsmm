import React, { useState, useMemo } from 'react';
import {
  SlidersHorizontal,
  Activity,
  Globe,
  RefreshCw,
  Search,
  Check,
  ChevronDown,
  Layers,
  Sparkles,
  ArrowRight,
  TrendingUp,
  AlertCircle,
  Plus
} from 'lucide-react';
import { broadcastAdminChange } from '../lib/api.ts';

interface ManualSellerSyncProps {
  token: string;
  providersList: any[];
  servicesList: any[];
  onRefresh: () => Promise<void>;
  showSuccess: (msg: string) => void;
  showError: (msg: string) => void;
  isLight: boolean;
  cardBgClasses: string;
  subCardBg: string;
}

export const ManualSellerSync: React.FC<ManualSellerSyncProps> = ({
  token,
  providersList,
  servicesList,
  onRefresh,
  showSuccess,
  showError,
  isLight,
  cardBgClasses,
  subCardBg,
}) => {
  // 1. Provider Selection
  const [selectedProviderId, setSelectedProviderId] = useState<string>(
    providersList[0]?.id ? String(providersList[0].id) : ''
  );

  // 2. Sync Scope ('all' | 'new_only' | 'price_only' | 'selected')
  const [syncScope, setSyncScope] = useState<'all' | 'new_only' | 'price_only' | 'selected'>('all');

  // 3. Profit Percentage Markup
  const [profitPercentage, setProfitPercentage] = useState<number>(30);

  // Remote Preview State
  const [loadingPreview, setLoadingPreview] = useState(false);
  const [remoteListings, setRemoteListings] = useState<any[]>([]);
  const [previewLoadedForProvider, setPreviewLoadedForProvider] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('all');
  const [selectedRemoteIds, setSelectedRemoteIds] = useState<Set<string | number>>(new Set());

  // Quick single add row states
  const [quickServiceId, setQuickServiceId] = useState<string>('');
  const [isQuickAdding, setIsQuickAdding] = useState(false);

  // Sync execution state
  const [isSyncing, setIsSyncing] = useState(false);

  // Calculate Example Math
  const exampleBaseCost = 10.0;
  const exampleMarkupAmount = (exampleBaseCost * profitPercentage) / 100;
  const exampleFinalPrice = exampleBaseCost + exampleMarkupAmount;

  // Existing service map for the selected provider
  const existingProviderServiceIds = useMemo(() => {
    const set = new Set<string>();
    servicesList.forEach((s) => {
      if (s.providerId === Number(selectedProviderId) && s.providerServiceId) {
        set.add(String(s.providerServiceId));
      }
    });
    return set;
  }, [servicesList, selectedProviderId]);

  // Load Remote Listings Preview
  const handleFetchPreview = async () => {
    if (!selectedProviderId) {
      showError('Please select an SMM Provider first.');
      return;
    }

    setLoadingPreview(true);
    try {
      const res = await fetch(`/api/admin/providers/${selectedProviderId}/services`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok && Array.isArray(data)) {
        setRemoteListings(data);
        setPreviewLoadedForProvider(Number(selectedProviderId));
        // Reset selections to empty or preselect
        setSelectedRemoteIds(new Set());
        showSuccess(`Loaded ${data.length} remote services for preview.`);
      } else {
        showError(data.error || 'Failed to fetch remote services from provider API.');
      }
    } catch (err: any) {
      showError(`Connection error: ${err.message || err}`);
    } finally {
      setLoadingPreview(false);
    }
  };

  // Extract unique categories from remote listings
  const remoteCategories = useMemo(() => {
    return Array.from(
      new Set(remoteListings.map((s) => s.category || 'General').filter(Boolean))
    );
  }, [remoteListings]);

  // Filtered remote listings
  const filteredListings = useMemo(() => {
    return remoteListings.filter((item) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        String(item.service || '').includes(q) ||
        (item.name && item.name.toLowerCase().includes(q)) ||
        (item.category && item.category.toLowerCase().includes(q));

      const matchesCat =
        selectedCategoryFilter === 'all' ||
        (item.category && item.category.toLowerCase() === selectedCategoryFilter.toLowerCase());

      return matchesSearch && matchesCat;
    });
  }, [remoteListings, searchQuery, selectedCategoryFilter]);

  // Handle single selection toggle
  const toggleSelectRemote = (id: string | number) => {
    const next = new Set(selectedRemoteIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedRemoteIds(next);
  };

  // Select all filtered toggle
  const toggleSelectAllFiltered = () => {
    if (selectedRemoteIds.size === filteredListings.length && filteredListings.length > 0) {
      setSelectedRemoteIds(new Set());
    } else {
      const next = new Set<string | number>();
      filteredListings.forEach((s) => next.add(s.service));
      setSelectedRemoteIds(next);
    }
  };

  // Handle Quick Add Single Service
  const handleQuickAddSingle = async () => {
    if (!quickServiceId) {
      showError('Please select a service from dropdown to add.');
      return;
    }

    const item = remoteListings.find((s) => String(s.service) === String(quickServiceId));
    if (!item) {
      showError('Selected service not found in remote listings.');
      return;
    }

    setIsQuickAdding(true);
    try {
      const res = await fetch('/api/admin/services/seller-sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          providerId: Number(selectedProviderId),
          syncScope: 'selected',
          profitPercentage,
          selectedServiceIds: [String(quickServiceId)],
        }),
      });

      const data = await res.json();
      if (res.ok) {
        showSuccess(`Service "${item.name}" added / updated successfully!`);
        await onRefresh();
        broadcastAdminChange();
      } else {
        showError(data.error || 'Failed to add service.');
      }
    } catch (err: any) {
      showError(`Error adding service: ${err.message || err}`);
    } finally {
      setIsQuickAdding(false);
    }
  };

  // Run Full Sync Operations
  const handleRunSync = async () => {
    if (!selectedProviderId) {
      showError('Please select an SMM Provider.');
      return;
    }

    if (syncScope === 'selected' && selectedRemoteIds.size === 0) {
      showError('Please select at least one service from the table to sync.');
      return;
    }

    setIsSyncing(true);
    try {
      const res = await fetch('/api/admin/services/seller-sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          providerId: Number(selectedProviderId),
          syncScope,
          profitPercentage,
          selectedServiceIds: Array.from(selectedRemoteIds).map(String),
        }),
      });

      const data = await res.json();
      if (res.ok) {
        const added = data.added ?? 0;
        const updated = data.updated ?? 0;
        showSuccess(`Sync Complete! Added: ${added}, Updated: ${updated} services with +${profitPercentage}% markup.`);
        await onRefresh();
        broadcastAdminChange();
      } else {
        showError(data.error || 'Sync operations failed.');
      }
    } catch (err: any) {
      showError(`Sync error: ${err.message || err}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const currentProvider = providersList.find((p) => String(p.id) === String(selectedProviderId));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* ===================== LEFT COLUMN: SYNC CONFIGURATIONS (SCREENSHOT 1 & 2) ===================== */}
      <div className="lg:col-span-5 space-y-6">
        <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-6 ${cardBgClasses}`}>
          {/* Header */}
          <div className="flex items-center space-x-2.5">
            <SlidersHorizontal className="w-5 h-5 text-amber-500" />
            <h3 className="text-xl font-black tracking-tight text-gray-900 dark:text-white">
              Sync Configurations
            </h3>
          </div>

          {/* 1. SELECT SMM SELLER */}
          <div className="space-y-2">
            <label className="block text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
              1. SELECT SMM SELLER
            </label>
            <div className="relative">
              <select
                value={selectedProviderId}
                onChange={(e) => {
                  setSelectedProviderId(e.target.value);
                  setRemoteListings([]);
                  setPreviewLoadedForProvider(null);
                }}
                className={`w-full px-4 py-3 rounded-2xl border text-xs font-bold appearance-none cursor-pointer focus:outline-hidden focus:ring-2 focus:ring-amber-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              >
                <option value="">-- Choose SMM Provider --</option>
                {providersList.map((p) => (
                  <option key={p.id} value={String(p.id)}>
                    {p.name} (Balance: ₹{Number(p.balance || 0).toFixed(2)})
                  </option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400" />
            </div>
          </div>

          {/* 2. SYNC SCOPE */}
          <div className="space-y-3">
            <label className="block text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
              2. SYNC SCOPE
            </label>

            {/* Option A: Sync All Services */}
            <div
              onClick={() => setSyncScope('all')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                syncScope === 'all'
                  ? 'border-amber-400/80 bg-amber-50/70 dark:bg-amber-950/20 ring-2 ring-amber-500/20'
                  : isLight
                  ? 'border-stone-200 bg-white hover:border-amber-300'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start space-x-3">
                <input
                  type="radio"
                  name="syncScope"
                  checked={syncScope === 'all'}
                  onChange={() => setSyncScope('all')}
                  className="mt-1 text-amber-500 focus:ring-amber-500 cursor-pointer"
                />
                <div className="space-y-0.5">
                  <span className="text-sm font-black text-gray-900 dark:text-white block">
                    Sync All Services
                  </span>
                  <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                    Add brand new items & update price/limits of matched ones
                  </p>
                </div>
              </div>
            </div>

            {/* Option B: New Services Only */}
            <div
              onClick={() => setSyncScope('new_only')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                syncScope === 'new_only'
                  ? 'border-amber-400/80 bg-amber-50/70 dark:bg-amber-950/20 ring-2 ring-amber-500/20'
                  : isLight
                  ? 'border-stone-200 bg-white hover:border-amber-300'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start space-x-3">
                <input
                  type="radio"
                  name="syncScope"
                  checked={syncScope === 'new_only'}
                  onChange={() => setSyncScope('new_only')}
                  className="mt-1 text-amber-500 focus:ring-amber-500 cursor-pointer"
                />
                <div className="space-y-0.5">
                  <span className="text-sm font-black text-gray-900 dark:text-white block">
                    New Services Only
                  </span>
                  <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                    Only import services not already in our catalog
                  </p>
                </div>
              </div>
            </div>

            {/* Option C: Price & Limits Only */}
            <div
              onClick={() => setSyncScope('price_only')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                syncScope === 'price_only'
                  ? 'border-amber-400/80 bg-amber-50/70 dark:bg-amber-950/20 ring-2 ring-amber-500/20'
                  : isLight
                  ? 'border-stone-200 bg-white hover:border-amber-300'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start space-x-3">
                <input
                  type="radio"
                  name="syncScope"
                  checked={syncScope === 'price_only'}
                  onChange={() => setSyncScope('price_only')}
                  className="mt-1 text-amber-500 focus:ring-amber-500 cursor-pointer"
                />
                <div className="space-y-0.5">
                  <span className="text-sm font-black text-gray-900 dark:text-white block">
                    Price & Limits Only
                  </span>
                  <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                    Only update customer prices & amount boundaries
                  </p>
                </div>
              </div>
            </div>

            {/* Option D: Only Selected Services */}
            <div
              onClick={() => setSyncScope('selected')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                syncScope === 'selected'
                  ? 'border-amber-400/80 bg-amber-50/70 dark:bg-amber-950/20 ring-2 ring-amber-500/20'
                  : isLight
                  ? 'border-stone-200 bg-white hover:border-amber-300'
                  : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start space-x-3">
                <input
                  type="radio"
                  name="syncScope"
                  checked={syncScope === 'selected'}
                  onChange={() => setSyncScope('selected')}
                  className="mt-1 text-amber-500 focus:ring-amber-500 cursor-pointer"
                />
                <div className="space-y-0.5">
                  <span className="text-sm font-black text-gray-900 dark:text-white block">
                    Only Selected Services
                  </span>
                  <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                    Manually check specific services from list below to import
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 3. PROFIT PERCENTAGE MARKUP */}
          <div className="space-y-3">
            <label className="block text-xs font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
              3. PROFIT PERCENTAGE MARKUP
            </label>

            {/* Percentage Input */}
            <div className="relative">
              <input
                type="number"
                min="0"
                step="1"
                value={profitPercentage}
                onChange={(e) => setProfitPercentage(Number(e.target.value) || 0)}
                className={`w-full px-4 py-3 rounded-2xl border text-sm font-black focus:outline-hidden focus:ring-2 focus:ring-amber-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">
                %
              </span>
            </div>

            {/* Quick Preset Buttons (+15%, +30%, +50%, +100%) */}
            <div className="grid grid-cols-4 gap-2 pt-1">
              {[15, 30, 50, 100].map((val) => {
                const isActive = profitPercentage === val;
                return (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setProfitPercentage(val)}
                    className={`py-2 px-1 rounded-xl border text-xs font-black transition-all cursor-pointer ${
                      isActive
                        ? 'border-amber-400 bg-amber-100/70 text-amber-900 dark:bg-amber-950/40 dark:text-amber-300 ring-2 ring-amber-500/20'
                        : isLight
                        ? 'border-stone-200 bg-white hover:bg-stone-50 text-gray-700'
                        : 'border-slate-700 bg-slate-800 hover:bg-slate-700 text-gray-300'
                    }`}
                  >
                    +{val}%
                  </button>
                );
              })}
            </div>
          </div>

          {/* EXAMPLE MARKUP MATH CARD (SCREENSHOT 2) */}
          <div className="rounded-2xl p-4 bg-[#0D131F] text-white border border-slate-800 space-y-2.5 shadow-md">
            <span className="text-[10px] font-black tracking-wider uppercase text-slate-400 block">
              EXAMPLE MARKUP MATH:
            </span>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Provider base cost:</span>
              <span className="font-mono text-slate-400">₹{exampleBaseCost.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Margin markup:</span>
              <span className="font-mono font-bold text-amber-400">+{profitPercentage}%</span>
            </div>
            <div className="border-t border-slate-800 pt-2 flex items-center justify-between text-xs">
              <span className="font-bold text-slate-200">Our Catalog Price:</span>
              <span className="font-mono font-black text-emerald-400 text-sm">
                ₹{exampleFinalPrice.toFixed(2)}
              </span>
            </div>
          </div>

          {/* ACTION BUTTONS (SCREENSHOT 2) */}
          <div className="space-y-3 pt-1">
            {/* 1. Preview Remote Listings */}
            <button
              type="button"
              onClick={handleFetchPreview}
              disabled={loadingPreview || !selectedProviderId}
              className={`w-full py-3.5 px-4 rounded-2xl border text-xs font-black transition-all cursor-pointer flex items-center justify-center space-x-2 ${
                isLight
                  ? 'bg-white hover:bg-stone-50 border-stone-200 text-gray-700'
                  : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-gray-200'
              }`}
            >
              <RefreshCw className={`w-4 h-4 ${loadingPreview ? 'animate-spin text-amber-500' : ''}`} />
              <span>{loadingPreview ? 'Fetching Remote Services...' : 'Preview Remote Listings'}</span>
            </button>

            {/* 2. RUN SYNC OPERATIONS */}
            <button
              type="button"
              onClick={handleRunSync}
              disabled={isSyncing || !selectedProviderId}
              className="w-full py-3.5 px-4 rounded-2xl bg-[#FDBA74] hover:bg-[#F97316] text-[#7C2D12] hover:text-white font-black text-xs uppercase tracking-wider shadow-md shadow-amber-500/20 transition-all cursor-pointer flex items-center justify-center space-x-2"
            >
              <Activity className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Processing Sync...' : 'RUN SYNC OPERATIONS'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* ===================== RIGHT COLUMN: REMOTE SMM INVENTORY PREVIEW (SCREENSHOT 1) ===================== */}
      <div className="lg:col-span-7 space-y-6">
        <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
          {/* Top Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="flex items-center space-x-2">
                <Activity className="w-5 h-5 text-amber-500" />
                <h3 className="text-lg font-black tracking-tight text-gray-900 dark:text-white">
                  REMOTE SMM INVENTORY PREVIEW
                </h3>
              </div>
              <p className="text-xs text-gray-400">
                Real-time mapping & cost simulations for selected seller
              </p>
            </div>

            {/* Search Input */}
            <div className="relative sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search remote listings..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full pl-9 pr-3 py-2 rounded-xl border text-xs focus:outline-hidden focus:ring-2 focus:ring-amber-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>
          </div>

          {/* Provider / Category / Service Filter Bar (Screenshot 1 top inputs) */}
          <div className={`p-4 rounded-2xl border grid grid-cols-1 sm:grid-cols-12 gap-3 items-center ${subCardBg}`}>
            {/* 1. PROVIDER */}
            <div className="sm:col-span-4 space-y-1">
              <label className="block text-[10px] font-black uppercase text-gray-400">1. PROVIDER</label>
              <select
                value={selectedProviderId}
                onChange={(e) => {
                  setSelectedProviderId(e.target.value);
                  setRemoteListings([]);
                  setPreviewLoadedForProvider(null);
                }}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-amber-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              >
                <option value="">-- Choose SMM Provider... --</option>
                {providersList.map((p) => (
                  <option key={p.id} value={String(p.id)}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            {/* 2. CATEGORY */}
            <div className="sm:col-span-4 space-y-1">
              <label className="block text-[10px] font-black uppercase text-gray-400">2. CATEGORY</label>
              <select
                value={selectedCategoryFilter}
                onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                disabled={remoteListings.length === 0}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-amber-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              >
                {remoteListings.length === 0 ? (
                  <option value="all">-- Select Provider First --</option>
                ) : (
                  <>
                    <option value="all">All Categories ({remoteCategories.length})</option>
                    {remoteCategories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </>
                )}
              </select>
            </div>

            {/* 3. SERVICE */}
            <div className="sm:col-span-3 space-y-1">
              <label className="block text-[10px] font-black uppercase text-gray-400">3. SERVICE</label>
              <select
                value={quickServiceId}
                onChange={(e) => setQuickServiceId(e.target.value)}
                disabled={filteredListings.length === 0}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-amber-500 truncate ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              >
                {filteredListings.length === 0 ? (
                  <option value="">-- Select Provider First --</option>
                ) : (
                  <>
                    <option value="">-- Choose Service --</option>
                    {filteredListings.slice(0, 50).map((s) => (
                      <option key={s.service} value={String(s.service)}>
                        #{s.service} {s.name}
                      </option>
                    ))}
                  </>
                )}
              </select>
            </div>

            {/* ADD BUTTON */}
            <div className="sm:col-span-1 pt-4 sm:pt-4">
              <button
                type="button"
                onClick={handleQuickAddSingle}
                disabled={isQuickAdding || !quickServiceId}
                className="w-full py-2 px-3 rounded-xl bg-[#FDBA74] hover:bg-[#F97316] text-[#7C2D12] hover:text-white font-black text-xs transition-all cursor-pointer shadow-xs"
              >
                {isQuickAdding ? '...' : 'Add'}
              </button>
            </div>
          </div>

          {/* MAIN PREVIEW CONTAINER (SCREENSHOT 1) */}
          {remoteListings.length === 0 ? (
            /* EMPTY STATE BOX MATCHING SCREENSHOT 1 */
            <div className="rounded-3xl p-12 sm:p-16 border-2 border-dashed border-stone-300 dark:border-slate-800 bg-stone-100/70 dark:bg-slate-900/60 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-stone-200 dark:bg-slate-800 flex items-center justify-center mx-auto text-gray-400">
                <Globe className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h4 className="text-base font-black text-gray-700 dark:text-gray-200">
                  No SMM Seller Preview Loaded
                </h4>
                <p className="text-xs text-gray-400 max-w-md mx-auto leading-relaxed">
                  Choose an SMM Seller on the left control panel and click "Preview Remote Listings" to run live mapping before sync.
                </p>
              </div>
            </div>
          ) : (
            /* LOADED TABLE WITH COST SIMULATIONS */
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-gray-500 px-1">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="selectAllRemote"
                    checked={
                      selectedRemoteIds.size === filteredListings.length &&
                      filteredListings.length > 0
                    }
                    onChange={toggleSelectAllFiltered}
                    className="w-4 h-4 rounded-md text-amber-600 focus:ring-amber-500 cursor-pointer"
                  />
                  <label htmlFor="selectAllRemote" className="cursor-pointer select-none">
                    Select All ({filteredListings.length})
                  </label>
                </div>

                <span>
                  Selected:{' '}
                  <strong className="text-amber-600">{selectedRemoteIds.size}</strong> services
                </span>
              </div>

              <div className="overflow-x-auto max-h-[500px] rounded-2xl border border-gray-100 dark:border-gray-800">
                <table className="w-full text-left text-xs whitespace-nowrap">
                  <thead className={`font-mono text-[11px] font-bold ${subCardBg} text-gray-400 sticky top-0`}>
                    <tr>
                      <th className="py-2.5 px-3 w-8"></th>
                      <th className="py-2.5 px-3">Remote ID</th>
                      <th className="py-2.5 px-4">Service Name</th>
                      <th className="py-2.5 px-3">Category</th>
                      <th className="py-2.5 px-3">Base Cost</th>
                      <th className="py-2.5 px-3 text-emerald-600">
                        Selling (+{profitPercentage}%)
                      </th>
                      <th className="py-2.5 px-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                    {filteredListings.map((item) => {
                      const isSelected = selectedRemoteIds.has(item.service);
                      const baseCost = parseFloat(item.rate || 0);
                      const markupMul = 1 + profitPercentage / 100;
                      const sellPrice = baseCost * markupMul;
                      const isAlreadyInCatalog = existingProviderServiceIds.has(String(item.service));

                      return (
                        <tr
                          key={item.service}
                          onClick={() => toggleSelectRemote(item.service)}
                          className={`cursor-pointer transition-colors ${
                            isSelected
                              ? 'bg-amber-50/70 dark:bg-amber-950/20'
                              : 'hover:bg-gray-50/50 dark:hover:bg-slate-800/40'
                          }`}
                        >
                          <td className="py-2.5 px-3" onClick={(e) => e.stopPropagation()}>
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleSelectRemote(item.service)}
                              className="rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                            />
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold text-gray-400">
                            #{item.service}
                          </td>
                          <td className="py-2.5 px-4 font-semibold max-w-[260px] truncate">
                            {item.name}
                          </td>
                          <td className="py-2.5 px-3 text-gray-400 truncate max-w-[130px]">
                            {item.category || 'General'}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-gray-500">
                            ₹{baseCost.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-3 font-mono font-black text-emerald-600">
                            ₹{sellPrice.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-3">
                            {isAlreadyInCatalog ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/10 text-blue-600">
                                In Catalog
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600">
                                Brand New
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
