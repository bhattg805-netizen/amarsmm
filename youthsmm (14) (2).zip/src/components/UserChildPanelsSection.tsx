import React, { useState, useEffect } from 'react';
import {
  Globe,
  Plus,
  CheckCircle,
  AlertCircle,
  Server,
  Lock,
  User as UserIcon,
  RefreshCw,
  Clock,
  ExternalLink,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface UserChildPanelsSectionProps {
  token: string;
  currentUser: any;
  isDarkMode: boolean;
  publicSettings: any;
  onRefreshUser: () => void;
  formatPrice: (inrAmount: number) => string;
}

export const UserChildPanelsSection: React.FC<UserChildPanelsSectionProps> = ({
  token,
  currentUser,
  isDarkMode,
  publicSettings,
  onRefreshUser,
  formatPrice,
}) => {
  const [childPanels, setChildPanels] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [domain, setDomain] = useState('');
  const [currency, setCurrency] = useState<'INR' | 'USD'>('INR');
  const [adminUsername, setAdminUsername] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const configPriceStr = publicSettings?.childPanelPrice || '₹ 1,500 / month';
  const parsedPrice = parseFloat(configPriceStr.replace(/[^0-9.]/g, '')) || 1500;
  const userBalance = Number(currentUser?.balance || 0);

  const fetchChildPanels = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/user/child-panels?_t=${Date.now()}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json',
        },
      });
      if (res.ok) {
        const data = await res.json();
        setChildPanels(Array.isArray(data) ? data : []);
      }
    } catch (err) {
      console.error('Error fetching child panels:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchChildPanels();
  }, [token]);

  const handleOrderChildPanel = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanDomain = domain.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (!cleanDomain || !adminUsername.trim() || !adminPassword.trim()) {
      setErrorMsg('Please provide your Domain, Admin Username, and Admin Password.');
      return;
    }

    if (userBalance < parsedPrice) {
      setErrorMsg(
        `Insufficient balance! The monthly rent is ${formatPrice(parsedPrice)}, but your balance is ${formatPrice(
          userBalance
        )}. Please add funds first.`
      );
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/user/child-panels', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          domain: cleanDomain,
          currency,
          adminUsername: adminUsername.trim(),
          adminPassword: adminPassword.trim(),
          price: parsedPrice,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSuccessMsg(
          `🎉 Child Panel ordered successfully for ${cleanDomain}! Point your domain nameservers to activate.`
        );
        setDomain('');
        setAdminUsername('');
        setAdminPassword('');
        fetchChildPanels();
        onRefreshUser();
      } else {
        setErrorMsg(data.error || 'Failed to place child panel order.');
      }
    } catch (err) {
      setErrorMsg('Network error placing child panel order.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-7 transition-colors ${
        isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
      }`}
    >
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#00B4B6] flex items-center justify-center text-white shadow-xs">
              <Globe className="w-5 h-5" />
            </div>
            <span>{publicSettings?.childPanelTitle || 'Child Panels'}</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-teal-500/10 text-teal-600 border border-teal-500/20">
              White-label Reseller
            </span>
          </h2>
          <p className="text-xs text-stone-500 dark:text-gray-400 mt-1">
            Rent your own standalone SMM reseller panel with custom domain, automated order fulfillment, and high profit margins.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto">
          <div className="px-3.5 py-1.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 text-xs font-mono font-bold bg-[#F4EFE3] dark:bg-slate-800 text-stone-900 dark:text-white">
            Rent: <strong className="text-emerald-600 dark:text-emerald-400">{formatPrice(parsedPrice)} / mo</strong>
          </div>
          <button
            type="button"
            onClick={fetchChildPanels}
            disabled={loading}
            className="p-2 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] text-stone-700 dark:text-gray-200 text-xs font-bold hover:bg-[#EAE3D0] dark:hover:bg-slate-800 cursor-pointer"
            title="Refresh list"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-teal-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Domain Nameserver Notice Box */}
      <div className="p-4 sm:p-5 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-xs space-y-2">
        <div className="flex items-center gap-2 font-black text-teal-700 dark:text-teal-300">
          <Server className="w-4 h-4 shrink-0" />
          <span>Required Nameservers Setup</span>
        </div>
        <p className="text-teal-900 dark:text-teal-200 leading-relaxed">
          Before or immediately after ordering, log in to your domain registrar (GoDaddy, Namecheap, Cloudflare, Hostinger) and point your domain's NS records to:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 font-mono font-bold">
          <div className="p-2.5 rounded-xl bg-[#F4EFE3]/80 dark:bg-slate-900/80 border border-teal-500/30 flex items-center justify-between text-teal-800 dark:text-teal-300">
            <span>ns1.youthsmm.com</span>
            <span className="text-[10px] text-teal-500 uppercase">Primary</span>
          </div>
          <div className="p-2.5 rounded-xl bg-[#F4EFE3]/80 dark:bg-slate-900/80 border border-teal-500/30 flex items-center justify-between text-teal-800 dark:text-teal-300">
            <span>ns2.youthsmm.com</span>
            <span className="text-[10px] text-teal-500 uppercase">Secondary</span>
          </div>
        </div>
      </div>

      {/* Order Child Panel Form */}
      <div className="p-5 sm:p-6 rounded-2xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3]/50 dark:bg-slate-800/30 space-y-4">
        <h3 className="text-sm font-black flex items-center gap-2 text-stone-900 dark:text-white">
          <Zap className="w-4 h-4 text-[#00B4B6]" />
          <span>Rent a New Child Panel</span>
        </h3>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-600 text-xs font-bold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 text-xs font-bold flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        <form onSubmit={handleOrderChildPanel} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1">
                Domain Name
              </label>
              <div className="relative">
                <Globe className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
                <input
                  type="text"
                  placeholder="e.g. reseller.yourbrand.com or yourbrand.com"
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900 text-stone-900 dark:text-white placeholder-stone-400 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1">
                Base Panel Currency
              </label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as 'INR' | 'USD')}
                className="w-full px-3.5 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900 text-stone-900 dark:text-white font-bold focus:outline-hidden focus:ring-2 focus:ring-teal-500"
              >
                <option value="INR">INR (₹ - Indian Rupee)</option>
                <option value="USD">USD ($ - US Dollar)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1">
                Admin Username
              </label>
              <div className="relative">
                <UserIcon className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
                <input
                  type="text"
                  placeholder="e.g. admin"
                  value={adminUsername}
                  onChange={(e) => setAdminUsername(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900 text-stone-900 dark:text-white placeholder-stone-400 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1">
                Admin Password
              </label>
              <div className="relative">
                <Lock className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
                <input
                  type="password"
                  placeholder="Create strong administrator password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900 text-stone-900 dark:text-white placeholder-stone-400 font-medium focus:outline-hidden focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
            <div className="text-[11px] text-gray-500 font-medium">
              Monthly rent of <strong className="font-mono text-gray-900 dark:text-white">{formatPrice(parsedPrice)}</strong> will be deducted from your wallet balance.
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-xl bg-[#00B4B6] hover:bg-teal-600 text-white font-black shadow-md shadow-teal-500/20 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5 transition-all"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <span>Confirm & Rent Panel ({formatPrice(parsedPrice)})</span>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* User's Existing Child Panels */}
      <div className="space-y-3">
        <h3 className="text-sm font-black flex items-center gap-2">
          <span>Your Registered Child Panels</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-stone-100 dark:bg-slate-800 text-gray-500 font-bold">
            {childPanels.length}
          </span>
        </h3>

        {childPanels.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-stone-200 dark:border-slate-800 rounded-2xl text-xs text-gray-400 space-y-1">
            <Globe className="w-8 h-8 mx-auto opacity-40 text-gray-400 mb-1" />
            <p className="font-bold">You have not rented any child panels yet.</p>
            <p className="text-[11px]">Fill the form above to start your own white-label social media reseller panel.</p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-2xl border border-stone-200 dark:border-slate-800">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 dark:bg-slate-800/80 text-gray-500 font-mono text-[11px] border-b border-stone-200 dark:border-slate-800 uppercase">
                <tr>
                  <th className="py-3 px-4">Panel ID</th>
                  <th className="py-3 px-4">Domain</th>
                  <th className="py-3 px-4">Currency</th>
                  <th className="py-3 px-4">Monthly Rate</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Created Date</th>
                  <th className="py-3 px-4 text-right">Link</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {childPanels.map((cp) => {
                  const statusColor =
                    cp.status === 'active'
                      ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
                      : cp.status === 'terminated'
                      ? 'bg-rose-500/10 text-rose-600 border-rose-500/20'
                      : 'bg-amber-500/10 text-amber-600 border-amber-500/20';

                  return (
                    <tr key={cp.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-gray-400">#{cp.id}</td>
                      <td className="py-3 px-4 font-bold text-teal-600 dark:text-teal-400">
                        {cp.domain}
                      </td>
                      <td className="py-3 px-4 font-mono">{cp.currency || 'INR'}</td>
                      <td className="py-3 px-4 font-mono font-bold text-emerald-600">
                        {formatPrice(Number(cp.price || parsedPrice))}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border inline-block ${statusColor}`}>
                          {cp.status || 'pending'}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-gray-500 text-[11px]">
                        {cp.createdAt ? new Date(cp.createdAt).toLocaleDateString() : 'Recent'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <a
                          href={`https://${cp.domain}`}
                          target="_blank"
                          rel="noreferrer"
                          className="px-2.5 py-1 rounded-lg bg-teal-500/10 hover:bg-teal-500/20 text-[#00B4B6] font-bold text-xs inline-flex items-center gap-1 cursor-pointer"
                        >
                          <span>Visit</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
