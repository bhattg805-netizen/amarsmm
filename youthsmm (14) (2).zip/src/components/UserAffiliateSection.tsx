import React, { useState, useEffect } from 'react';
import {
  Users,
  Copy,
  Check,
  Gift,
  DollarSign,
  TrendingUp,
  Share2,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  Wallet,
} from 'lucide-react';

interface UserAffiliateSectionProps {
  token: string;
  currentUser: any;
  isDarkMode: boolean;
  publicSettings: any;
}

export const UserAffiliateSection: React.FC<UserAffiliateSectionProps> = ({
  token,
  currentUser,
  isDarkMode,
  publicSettings,
}) => {
  const [affiliate, setAffiliate] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const bonusPercent = publicSettings?.referralBonusPercent || '5%';
  const refCode = affiliate?.referralCode || `REF-${currentUser?.id || '101'}`;
  const referralLink = `${typeof window !== 'undefined' ? window.location.origin : ''}/?ref=${refCode}`;

  const fetchAffiliate = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/user/affiliate?_t=${Date.now()}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json',
        },
      });
      if (res.ok) {
        const data = await res.json();
        setAffiliate(data);
      }
    } catch (err) {
      console.error('Error fetching affiliate:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAffiliate();
  }, [token]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(refCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div
      className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-7 transition-colors ${
        isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
      }`}
    >
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#8E44AD] flex items-center justify-center text-white shadow-xs">
              <Users className="w-5 h-5" />
            </div>
            <span>Affiliates Program</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-purple-500/10 text-purple-600 border border-purple-500/20">
              {bonusPercent} Instant Bonus
            </span>
          </h2>
          <p className="text-xs text-stone-500 dark:text-gray-400 mt-1">
            Share your unique referral link with friends or clients and earn lifetime {bonusPercent} commission on every wallet top-up they make.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchAffiliate}
          disabled={loading}
          className="p-2 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] text-stone-700 dark:text-gray-200 text-xs font-bold hover:bg-[#EAE3D0] dark:hover:bg-slate-800 cursor-pointer self-start sm:self-auto"
          title="Refresh stats"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-purple-500' : ''}`} />
        </button>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 sm:p-5 rounded-2xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3]/60 dark:bg-slate-800/40 space-y-1">
          <div className="flex items-center justify-between text-stone-400 dark:text-gray-400">
            <span className="text-xs font-bold uppercase tracking-wider">Total Referrals</span>
            <Users className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-2xl font-black font-mono mt-1 text-stone-900 dark:text-white">
            {affiliate?.referralsCount ?? 0}
          </div>
          <p className="text-[11px] text-stone-400 dark:text-gray-400">Registered users signed up via your link</p>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl border border-purple-500/20 bg-purple-500/5 space-y-1">
          <div className="flex items-center justify-between text-purple-600 dark:text-purple-400">
            <span className="text-xs font-bold uppercase tracking-wider">Commission Rate</span>
            <Gift className="w-4 h-4" />
          </div>
          <div className="text-2xl font-black font-mono mt-1 text-purple-600 dark:text-purple-400">
            {bonusPercent}
          </div>
          <p className="text-[11px] text-stone-400 dark:text-gray-400">Earned on every single deposit made</p>
        </div>

        <div className="p-4 sm:p-5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5 space-y-1">
          <div className="flex items-center justify-between text-emerald-600 dark:text-emerald-400">
            <span className="text-xs font-bold uppercase tracking-wider">Total Earned</span>
            <Wallet className="w-4 h-4" />
          </div>
          <div className="text-2xl font-black font-mono mt-1 text-emerald-600 dark:text-emerald-400">
            ₹{Number(affiliate?.earnings ?? 0).toFixed(2)}
          </div>
          <p className="text-[11px] text-stone-400 dark:text-gray-400">Directly withdrawable or usable for orders</p>
        </div>
      </div>

      {/* Referral Link & Code Box */}
      <div className="p-5 sm:p-6 rounded-2xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3]/50 dark:bg-slate-800/30 space-y-4">
        <h3 className="text-sm font-black flex items-center gap-2 text-stone-900 dark:text-white">
          <Share2 className="w-4 h-4 text-[#8E44AD]" />
          <span>Your Referral Link & Promo Code</span>
        </h3>

        <div className="space-y-3 text-xs">
          <div>
            <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1">
              Direct Invitation URL
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                readOnly
                value={referralLink}
                className="flex-1 px-4 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900 text-stone-900 dark:text-white font-mono text-xs font-bold select-all"
              />
              <button
                type="button"
                onClick={handleCopyLink}
                className="px-4 py-2.5 rounded-xl bg-[#8E44AD] hover:bg-purple-700 text-white font-black flex items-center gap-1.5 cursor-pointer shadow-xs transition-all"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1">
              Referral Code
            </label>
            <div className="flex items-center gap-2 max-w-xs">
              <span className="px-4 py-2 rounded-xl bg-[#FFFDF8] dark:bg-slate-900 border border-[#DDD3BC] dark:border-slate-800 font-mono font-black text-xs text-purple-600 dark:text-purple-400">
                {refCode}
              </span>
              <button
                type="button"
                onClick={handleCopyCode}
                className="px-3 py-2 rounded-xl border border-stone-200 dark:border-slate-800 hover:bg-stone-50 dark:hover:bg-slate-800 text-gray-600 dark:text-gray-300 font-bold text-xs flex items-center gap-1 cursor-pointer"
              >
                {copiedCode ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCode ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Program Terms & Payout Guide */}
      <div className="p-4 rounded-2xl border border-stone-200 dark:border-slate-800 text-xs space-y-2">
        <span className="text-[11px] font-black uppercase tracking-wider text-gray-400 block">
          Affiliate Program Rules & Payouts
        </span>
        <ul className="space-y-1.5 text-gray-600 dark:text-gray-300 list-disc list-inside leading-relaxed text-[11px]">
          <li>Commissions are automatically credited to your main balance whenever your referral adds funds.</li>
          <li>Minimum withdrawal payout is ₹ 500 via UPI (Google Pay, PhonePe, Paytm).</li>
          <li>You can also use your commission balance directly to place social media orders at wholesale prices.</li>
          <li>Self-referrals via duplicate accounts are strictly monitored and will result in disqualification.</li>
        </ul>
      </div>
    </div>
  );
};
