import React, { useState, useMemo, useEffect } from 'react';
import {
  FileCode,
  Copy,
  Check,
  Key,
  RefreshCw,
  Eye,
  EyeOff,
  Terminal,
  Code2,
  Server,
  Zap,
  Play,
  Download,
  AlertTriangle,
  AlertCircle,
  HelpCircle,
  Clock,
  Layers,
  ArrowRight,
  ShieldCheck,
  Globe,
  Lock,
  X,
  ExternalLink,
} from 'lucide-react';
import { Service } from '../types';

interface UserApiDocsSectionProps {
  token: string;
  currentUser: any;
  isDarkMode: boolean;
  onRefreshUser: () => void;
  services?: Service[];
  publicSettings?: any;
}

export const UserApiDocsSection: React.FC<UserApiDocsSectionProps> = ({
  token,
  currentUser,
  isDarkMode,
  onRefreshUser,
  services = [],
  publicSettings,
}) => {
  // Navigation tabs within API section
  const [activeView, setActiveView] = useState<'docs' | 'tester' | 'snippets'>('docs');

  // Credential card states
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedEndpoint, setCopiedEndpoint] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showRegenerateConfirm, setShowRegenerateConfirm] = useState(false);
  const [generateMsg, setGenerateMsg] = useState<string | null>(null);
  const [generateError, setGenerateError] = useState<string | null>(null);

  // Local state for instant zero-reload key updates
  const [localApiKey, setLocalApiKey] = useState<string>(currentUser?.apiKey || '');

  // Synchronize localApiKey when currentUser changes
  useEffect(() => {
    if (currentUser?.apiKey) {
      setLocalApiKey(currentUser.apiKey);
    }
  }, [currentUser?.apiKey]);

  // Copied indicator for request example blocks
  const [copiedBlockId, setCopiedBlockId] = useState<string | null>(null);

  // Code Snippet state
  const [selectedSnippet, setSelectedSnippet] = useState<'curl' | 'php' | 'php_class' | 'python' | 'node'>('curl');
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  // Live Tester Sandbox State
  const [testerAction, setTesterAction] = useState<
    'balance' | 'services' | 'status' | 'add' | 'refill' | 'refill_status' | 'cancel'
  >('balance');
  const [testerServiceId, setTesterServiceId] = useState<string>(services[0]?.id?.toString() || '1');
  const [testerLink, setTesterLink] = useState('https://instagram.com/p/your_post');
  const [testerQuantity, setTesterQuantity] = useState('1000');
  const [testerOrderId, setTesterOrderId] = useState('');
  const [testerRefillId, setTesterRefillId] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  const [testResponse, setTestResponse] = useState<any>(null);
  const [testStatusCode, setTestStatusCode] = useState<number | null>(null);
  const [testLatency, setTestLatency] = useState<number | null>(null);
  const [copiedTestResponse, setCopiedTestResponse] = useState(false);

  const apiKey = localApiKey || currentUser?.apiKey || '';
  // Official endpoint specified by user requirements
  const apiEndpointUrl = publicSettings?.apiUrl || 'https://www.youthsmm.com/api/v2';
  const currencySymbol = publicSettings?.currencySymbol || '₹';
  const userCurrency = currentUser?.currency || 'INR';

  // Copy Key handler
  const handleCopyKey = () => {
    if (!apiKey) return;
    navigator.clipboard.writeText(apiKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  // Copy Endpoint handler
  const handleCopyEndpoint = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedEndpoint(true);
    setTimeout(() => setCopiedEndpoint(false), 2000);
  };

  // Copy example snippet helper
  const handleCopyCodeBlock = (blockId: string, textToCopy: string) => {
    navigator.clipboard.writeText(textToCopy);
    setCopiedBlockId(blockId);
    setTimeout(() => setCopiedBlockId(null), 2000);
  };

  // Cryptographically generate/regenerate API key
  const handleConfirmRegenerateKey = async (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (isGenerating) return;
    setShowRegenerateConfirm(false);
    setIsGenerating(true);
    setGenerateMsg(null);
    setGenerateError(null);
    try {
      const res = await fetch('/api/user/generate-key', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      const data = await res.json();
      if (res.ok && data.apiKey) {
        setLocalApiKey(data.apiKey);
        setGenerateMsg('New API Secret Key generated successfully! Your previous key has been invalidated.');
        setShowKey(true);
        setTimeout(() => setGenerateMsg(null), 6000);
        if (onRefreshUser) {
          onRefreshUser();
        }
      } else {
        setGenerateError(data.error || 'Failed to generate API Key');
        setTimeout(() => setGenerateError(null), 6000);
      }
    } catch (err) {
      console.error('API key regeneration error:', err);
      setGenerateError('Network error while generating API key. Please check your connection.');
      setTimeout(() => setGenerateError(null), 6000);
    } finally {
      setIsGenerating(false);
    }
  };

  // Export Services Catalog as JSON
  const handleExportServicesJson = () => {
    const exportData = services.map((s) => ({
      service: s.id.toString(),
      name: s.name,
      type: 'Default',
      category: s.category || 'General',
      rate: s.pricePerThousand.toFixed(4),
      min: s.minAmount.toString(),
      max: s.maxAmount.toString(),
      refill: (s.description || '').toLowerCase().includes('refill'),
      cancel: true,
      description: s.description || '',
    }));

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `youthsmm_services_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Interactive Live API Tester Request
  const handleRunApiTest = async () => {
    if (!currentUser?.apiKey) {
      alert('Please generate an API key first before testing the API.');
      return;
    }

    setIsTesting(true);
    setTestResponse(null);
    setTestStatusCode(null);
    setTestLatency(null);

    const startTime = performance.now();
    try {
      const params = new URLSearchParams();
      params.append('key', currentUser.apiKey);
      params.append('action', testerAction);

      if (testerAction === 'add') {
        params.append('service', testerServiceId);
        params.append('link', testerLink);
        params.append('quantity', testerQuantity);
      } else if (testerAction === 'status' || testerAction === 'cancel') {
        params.append('order', testerOrderId || '1042');
      } else if (testerAction === 'refill') {
        params.append('order', testerOrderId || '1042');
      } else if (testerAction === 'refill_status') {
        params.append('refill', testerRefillId || '101');
      }

      const res = await fetch('/api/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: params.toString(),
      });

      const endTime = performance.now();
      setTestLatency(Math.round(endTime - startTime));
      setTestStatusCode(res.status);

      const data = await res.json().catch(() => ({ error: 'Unable to parse JSON response' }));
      setTestResponse(data);

      if (testerAction === 'balance' || testerAction === 'add') {
        onRefreshUser();
      }
    } catch (err: any) {
      console.error(err);
      setTestStatusCode(500);
      setTestResponse({ error: err.message || 'Network request failed' });
    } finally {
      setIsTesting(false);
    }
  };

  // Multi-Language Code Snippets
  const snippets = useMemo(() => {
    const keyVal = currentUser?.apiKey || 'YOUR_API_KEY';
    return {
      curl: `# 1. Fetch Balance
curl -X POST "${apiEndpointUrl}" \\
  -d "key=${keyVal}" \\
  -d "action=balance"

# 2. List All Active Services
curl -X POST "${apiEndpointUrl}" \\
  -d "key=${keyVal}" \\
  -d "action=services"

# 3. Add New Order
curl -X POST "${apiEndpointUrl}" \\
  -d "key=${keyVal}" \\
  -d "action=add" \\
  -d "service=1" \\
  -d "link=https://instagram.com/username" \\
  -d "quantity=1000"

# 4. Check Single Order Status
curl -X POST "${apiEndpointUrl}" \\
  -d "key=${keyVal}" \\
  -d "action=status" \\
  -d "order=1042"

# 5. Check Multiple Orders Status
curl -X POST "${apiEndpointUrl}" \\
  -d "key=${keyVal}" \\
  -d "action=status" \\
  -d "orders=1042,1043,1044"`,

      php: `<?php
// Standard PHP cURL Implementation
$url = "${apiEndpointUrl}";
$apiKey = "${keyVal}";

// Example: Add Order
$postData = [
    'key'      => $apiKey,
    'action'   => 'add',
    'service'  => 1,
    'link'     => 'https://instagram.com/username',
    'quantity' => 1000
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
print_r($result);
?>`,

      php_class: `<?php
/**
 * Drop-in SMM Reseller API Client Class
 * Compatible with SmartPanel & PerfectPanel standards
 */
class SMMClient {
    private $apiUrl = "${apiEndpointUrl}";
    private $apiKey;

    public function __construct($apiKey = "${keyVal}") {
        $this->apiKey = $apiKey;
    }

    private function request($params) {
        $params['key'] = $this->apiKey;
        $ch = curl_init($this->apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $res = curl_exec($ch);
        curl_close($ch);
        return json_decode($res, true);
    }

    public function services() {
        return $this->request(['action' => 'services']);
    }

    public function balance() {
        return $this->request(['action' => 'balance']);
    }

    public function order($serviceId, $link, $quantity) {
        return $this->request([
            'action' => 'add',
            'service' => $serviceId,
            'link' => $link,
            'quantity' => $quantity
        ]);
    }

    public function status($orderId) {
        return $this->request(['action' => 'status', 'order' => $orderId]);
    }

    public function multiStatus($orderIds) {
        return $this->request(['action' => 'status', 'orders' => implode(',', (array)$orderIds)]);
    }

    public function refill($orderId) {
        return $this->request(['action' => 'refill', 'order' => $orderId]);
    }

    public function refillStatus($refillId) {
        return $this->request(['action' => 'refill_status', 'refill' => $refillId]);
    }
}

// Usage:
// $api = new SMMClient();
// $balance = $api->balance();
?>`,

      python: `import requests

API_URL = "${apiEndpointUrl}"
API_KEY = "${keyVal}"

def smm_request(action, **kwargs):
    payload = {"key": API_KEY, "action": action, **kwargs}
    response = requests.post(API_URL, data=payload)
    return response.json()

# 1. Fetch Balance
print("Balance:", smm_request("balance"))

# 2. List Services
# print("Services:", smm_request("services"))

# 3. Add Order
# print("Order:", smm_request("add", service=1, link="https://instagram.com/username", quantity=1000))

# 4. Check Order Status
# print("Status:", smm_request("status", order=1042))`,

      node: `// Node.js (Axios) Integration
import axios from 'axios';

const API_URL = '${apiEndpointUrl}';
const API_KEY = '${keyVal}';

async function sendSmmRequest(action, extraParams = {}) {
  const params = new URLSearchParams({
    key: API_KEY,
    action,
    ...extraParams
  });

  const response = await axios.post(API_URL, params.toString(), {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });
  return response.data;
}

// Examples:
async function run() {
  const balance = await sendSmmRequest('balance');
  console.log('Balance:', balance);

  const services = await sendSmmRequest('services');
  console.log('Services Count:', services.length);
}

run();`,
    };
  }, [apiEndpointUrl, currentUser?.apiKey]);

  const handleCopySnippet = () => {
    navigator.clipboard.writeText(snippets[selectedSnippet]);
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Success Notification Banner */}
      {generateMsg && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center space-x-2 animate-fadeIn">
          <Check className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>{generateMsg}</span>
        </div>
      )}

      {/* Error Notification Banner */}
      {generateError && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center space-x-2 animate-fadeIn">
          <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
          <span>{generateError}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. DEVELOPER HUB HEADER & CREDENTIALS / ENDPOINT CARDS                    */}
      {/* ========================================================================= */}
      <div className="space-y-4">
        {/* Header Title & Description */}
        <div className="p-5 sm:p-6 rounded-3xl border border-[#EAE3D2] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900/90 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-red-100 text-[#DC2626] dark:bg-red-950/60 dark:text-red-400 border border-red-200 dark:border-red-900/50">
                REST API v2
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-900/50">
                Live Production
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-stone-900 dark:text-white tracking-tight">
              YouthSMM Reseller API Hub
            </h1>
            <p className="text-xs text-stone-500 dark:text-gray-400 max-w-2xl leading-relaxed">
              Connect external SMM panels, custom software, WordPress plugins, Telegram bots, or mobile apps directly to YouthSMM. All endpoints use standard SMM REST protocols.
            </p>
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            <button
              type="button"
              onClick={handleExportServicesJson}
              className="px-3.5 py-2.5 rounded-2xl bg-[#EFE8D8] dark:bg-slate-800 hover:bg-[#E5DDCB] dark:hover:bg-slate-700 text-stone-800 dark:text-gray-200 text-xs font-bold transition-all flex items-center space-x-2 border border-[#DDD3BC] dark:border-slate-700 cursor-pointer shadow-xs active:scale-95"
              title="Download services as JSON file"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Services (JSON)</span>
            </button>
          </div>
        </div>

        {/* Credentials Grid: Secret API Key & Endpoint Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Card 1: Reseller API Secret Key */}
          <div className="lg:col-span-7 p-5 rounded-3xl border border-[#EAE3D2] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900/90 shadow-sm space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center">
                  <Key className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[11px] font-black uppercase tracking-wider text-stone-500 dark:text-gray-400 block">
                    Your API Secret Key
                  </span>
                  <span className="text-[10px] text-stone-400 dark:text-gray-500">
                    Keep confidential. Authenticates all API requests.
                  </span>
                </div>
              </div>

              {apiKey ? (
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setShowRegenerateConfirm(true);
                  }}
                  disabled={isGenerating}
                  className="px-2.5 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 dark:bg-red-950/40 dark:hover:bg-red-900/50 text-[#DC2626] dark:text-red-400 text-[11px] font-black border border-red-200 dark:border-red-900/50 flex items-center space-x-1.5 transition-all cursor-pointer disabled:opacity-50"
                  title="Generate a new API key (invalidates previous)"
                >
                  <RefreshCw className={`w-3 h-3 ${isGenerating ? 'animate-spin' : ''}`} />
                  <span>{isGenerating ? 'Regenerating...' : 'Regenerate'}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    handleConfirmRegenerateKey(e);
                  }}
                  disabled={isGenerating}
                  className="px-3 py-1.5 rounded-xl bg-[#DC2626] hover:bg-red-700 text-white text-[11px] font-black flex items-center space-x-1.5 transition-all shadow-xs cursor-pointer disabled:opacity-50"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>{isGenerating ? 'Generating...' : 'Generate API Key'}</span>
                </button>
              )}
            </div>

            {/* API Key Box */}
            <div className="p-3 rounded-2xl bg-[#F4EFE3] dark:bg-slate-800/80 border border-[#DDD3BC] dark:border-slate-700/80 flex items-center justify-between gap-2">
              <div className="font-mono text-xs sm:text-sm text-stone-800 dark:text-gray-200 truncate select-all">
                {apiKey ? (
                  showKey ? (
                    apiKey
                  ) : (
                    <span className="tracking-widest">
                      {apiKey.slice(0, 8)}••••••••••••••••••••••••••••••••{apiKey.slice(-4)}
                    </span>
                  )
                ) : (
                  <span className="text-stone-400 dark:text-gray-500 italic">No API key generated yet</span>
                )}
              </div>

              <div className="flex items-center space-x-1.5 shrink-0">
                {apiKey && (
                  <>
                    <button
                      type="button"
                      onClick={() => setShowKey(!showKey)}
                      className="p-1.5 rounded-xl bg-[#EAE1CD] dark:bg-slate-700 hover:bg-[#DFD4BB] text-stone-700 dark:text-gray-300 transition-colors cursor-pointer"
                      title={showKey ? 'Hide Secret Key' : 'Reveal Secret Key'}
                    >
                      {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={handleCopyKey}
                      className="px-2.5 py-1.5 rounded-xl bg-[#DC2626] hover:bg-red-700 text-white text-xs font-black transition-all flex items-center space-x-1 cursor-pointer shadow-xs active:scale-95"
                      title="Copy API key to clipboard"
                    >
                      {copiedKey ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedKey ? 'Copied' : 'Copy'}</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Card 2: Official API Endpoint URL */}
          <div className="lg:col-span-5 p-5 rounded-3xl border border-[#EAE3D2] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900/90 shadow-sm space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 rounded-xl bg-sky-500/10 text-sky-500 flex items-center justify-center">
                  <Server className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[11px] font-black uppercase tracking-wider text-stone-500 dark:text-gray-400 block">
                    API Endpoint URL
                  </span>
                  <span className="text-[10px] text-stone-400 dark:text-gray-500">
                    HTTP POST • JSON Response
                  </span>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-[10px] font-black">
                200 OK
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-[#F4EFE3] dark:bg-slate-800/80 border border-[#DDD3BC] dark:border-slate-700/80 flex items-center justify-between gap-2">
              <div className="flex items-center space-x-2 min-w-0">
                <span className="px-2 py-0.5 rounded-md bg-[#DC2626] text-white font-mono font-black text-[10px] shrink-0">
                  POST
                </span>
                <span className="font-mono text-xs text-stone-800 dark:text-emerald-400 font-bold truncate select-all">
                  {apiEndpointUrl}
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleCopyEndpoint(apiEndpointUrl)}
                className="px-2.5 py-1.5 rounded-xl bg-[#EAE1CD] dark:bg-slate-700 hover:bg-[#DFD4BB] text-stone-800 dark:text-white text-xs font-bold transition-colors shrink-0 flex items-center space-x-1 cursor-pointer"
                title="Copy API endpoint URL"
              >
                {copiedEndpoint ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedEndpoint ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Subtabs Switcher: Docs | Interactive Tester | Code Snippets */}
        <div className="flex items-center space-x-2 p-1.5 rounded-2xl bg-[#F4EFE3] dark:bg-slate-800/90 border border-[#DDD3BC] dark:border-slate-700/80 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveView('docs')}
            className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-extrabold transition-all flex items-center justify-center space-x-2 cursor-pointer ${
              activeView === 'docs'
                ? 'bg-[#DC2626] text-white shadow-sm'
                : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>API Documentation</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('tester')}
            className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl text-xs font-extrabold transition-all flex items-center justify-center space-x-2 cursor-pointer ${
              activeView === 'tester'
                ? 'bg-[#DC2626] text-white shadow-sm'
                : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
            }`}
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Live Tester & Console</span>
            <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black uppercase bg-emerald-500 text-white animate-pulse">
              LIVE
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveView('snippets')}
            className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-extrabold transition-all flex items-center justify-center space-x-2 cursor-pointer ${
              activeView === 'snippets'
                ? 'bg-[#DC2626] text-white shadow-sm'
                : 'text-stone-700 dark:text-gray-300 hover:bg-black/5 dark:hover:bg-white/5'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>Code Implementations</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. MAIN VIEW: HTTP API ENDPOINTS & REQUEST EXAMPLES (DARK CODE PANEL)         */}
      {/* ========================================================================= */}
      {activeView === 'docs' && (
        <div className="space-y-4">
          {/* LARGE DARK CODE-DOCUMENTATION PANEL MATCHING USER SPECIFICATION */}
          <div className="rounded-3xl bg-[#0d1117] text-[#e6edf3] p-5 sm:p-7 border border-[#30363d] shadow-2xl font-mono text-xs sm:text-sm space-y-6">
            <div className="space-y-6">
              {/* API Endpoint URL */}
              <div className="rounded-2xl bg-[#161b22] border border-[#30363d] p-5 space-y-2">
                <div className="flex items-center justify-between border-b border-[#30363d] pb-2.5">
                  <div className="text-gray-400 font-sans font-bold text-xs uppercase tracking-wider">
                    # API Endpoint URL
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopyCodeBlock('endpoint-url', apiEndpointUrl)}
                    className="px-2.5 py-1 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-gray-300 text-xs font-sans flex items-center space-x-1.5 transition-colors cursor-pointer border border-[#30363d]"
                  >
                    {copiedBlockId === 'endpoint-url' ? (
                      <>
                        <Check className="w-3 h-3 text-[#3fb950]" />
                        <span className="text-[#3fb950]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy URL</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="flex items-center space-x-2 pt-1">
                  <span className="px-2 py-0.5 rounded-md bg-[#238636]/20 border border-[#238636]/40 text-[#3fb950] font-black text-xs">
                    POST
                  </span>
                  <span className="text-[#7ee787] font-bold text-sm select-all">
                    {apiEndpointUrl}
                  </span>
                </div>
              </div>

              {/* 1. Request Parameters (User Balance) */}
              <div className="rounded-2xl bg-[#161b22] border border-[#30363d] p-5 space-y-3">
                <div className="flex items-center justify-between border-b border-[#30363d] pb-2.5">
                  <div className="text-gray-400 font-sans font-bold text-xs uppercase tracking-wider">
                    # 1. Request Parameters (User Balance)
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyCodeBlock(
                        'req-balance',
                        `key = ${apiKey || 'YOUR_API_KEY'}\naction = balance`
                      )
                    }
                    className="px-2.5 py-1 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-gray-300 text-xs font-sans flex items-center space-x-1.5 transition-colors cursor-pointer border border-[#30363d]"
                  >
                    {copiedBlockId === 'req-balance' ? (
                      <>
                        <Check className="w-3 h-3 text-[#3fb950]" />
                        <span className="text-[#3fb950]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="space-y-1.5 text-xs sm:text-sm leading-relaxed">
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">key</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">{apiKey ? apiKey.substring(0, 10) + '...' : 'af61a17a0c...'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">action</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">balance</span>
                  </div>
                </div>
                <div className="pt-2 border-t border-[#30363d]">
                  <span className="text-gray-400 font-sans text-[11px] block mb-1">Success Response (JSON):</span>
                  <pre className="text-[#79c0ff] text-xs">
{`{
  "balance": "${Number(currentUser?.balance || 728.91).toFixed(4)}",
  "currency": "INR"
}`}
                  </pre>
                </div>
              </div>

              {/* 2. Request Parameters (Services List) */}
              <div className="rounded-2xl bg-[#161b22] border border-[#30363d] p-5 space-y-3">
                <div className="flex items-center justify-between border-b border-[#30363d] pb-2.5">
                  <div className="text-gray-400 font-sans font-bold text-xs uppercase tracking-wider">
                    # 2. Request Parameters (Services List)
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyCodeBlock(
                        'req-services',
                        `key = ${apiKey || 'YOUR_API_KEY'}\naction = services`
                      )
                    }
                    className="px-2.5 py-1 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-gray-300 text-xs font-sans flex items-center space-x-1.5 transition-colors cursor-pointer border border-[#30363d]"
                  >
                    {copiedBlockId === 'req-services' ? (
                      <>
                        <Check className="w-3 h-3 text-[#3fb950]" />
                        <span className="text-[#3fb950]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="space-y-1.5 text-xs sm:text-sm leading-relaxed">
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">key</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">{apiKey ? apiKey.substring(0, 10) + '...' : 'af61a17a0c...'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">action</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">services</span>
                  </div>
                </div>
                <div className="pt-2 border-t border-[#30363d]">
                  <span className="text-gray-400 font-sans text-[11px] block mb-1">Success Response (JSON Array):</span>
                  <pre className="text-[#79c0ff] text-xs">
{`[
  {
    "service": "1",
    "name": "Instagram Likes [HQ Instant]",
    "type": "Default",
    "category": "Instagram Likes",
    "rate": "15.0000",
    "min": "10",
    "max": "10000",
    "refill": true,
    "cancel": true,
    "description": "High quality instant likes"
  }
]`}
                  </pre>
                </div>
              </div>

              {/* 3. Request Parameters (Add Order) */}
              <div className="rounded-2xl bg-[#161b22] border border-[#30363d] p-5 space-y-3">
                <div className="flex items-center justify-between border-b border-[#30363d] pb-2.5">
                  <div className="text-gray-400 font-sans font-bold text-xs uppercase tracking-wider">
                    # 3. Request Parameters (Add Order)
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyCodeBlock(
                        'req-add',
                        `key = ${apiKey || 'YOUR_API_KEY'}\naction = add\nservice = 1\nlink = https://instagram.com/p/your_post\nquantity = 1000`
                      )
                    }
                    className="px-2.5 py-1 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-gray-300 text-xs font-sans flex items-center space-x-1.5 transition-colors cursor-pointer border border-[#30363d]"
                  >
                    {copiedBlockId === 'req-add' ? (
                      <>
                        <Check className="w-3 h-3 text-[#3fb950]" />
                        <span className="text-[#3fb950]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="space-y-1.5 text-xs sm:text-sm leading-relaxed">
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">key</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">{apiKey ? apiKey.substring(0, 10) + '...' : 'af61a17a0c...'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">action</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">add</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">service</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#79c0ff]">1</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">link</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">https://instagram.com/p/123</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">quantity</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#79c0ff]">1000</span>
                  </div>
                </div>
                <div className="pt-2 border-t border-[#30363d]">
                  <span className="text-gray-400 font-sans text-[11px] block mb-1">Success Response (JSON):</span>
                  <pre className="text-[#79c0ff] text-xs">
{`{
  "order": "1042"
}`}
                  </pre>
                </div>
              </div>

              {/* 4. Request Parameters (Order Status) */}
              <div className="rounded-2xl bg-[#161b22] border border-[#30363d] p-5 space-y-3">
                <div className="flex items-center justify-between border-b border-[#30363d] pb-2.5">
                  <div className="text-gray-400 font-sans font-bold text-xs uppercase tracking-wider">
                    # 4. Request Parameters (Order Status)
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyCodeBlock(
                        'req-status',
                        `key = ${apiKey || 'YOUR_API_KEY'}\naction = status\norder = 1042`
                      )
                    }
                    className="px-2.5 py-1 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-gray-300 text-xs font-sans flex items-center space-x-1.5 transition-colors cursor-pointer border border-[#30363d]"
                  >
                    {copiedBlockId === 'req-status' ? (
                      <>
                        <Check className="w-3 h-3 text-[#3fb950]" />
                        <span className="text-[#3fb950]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="space-y-1.5 text-xs sm:text-sm leading-relaxed">
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">key</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">{apiKey ? apiKey.substring(0, 10) + '...' : 'af61a17a0c...'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">action</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">status</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">order</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#79c0ff]">1042</span>
                  </div>
                </div>
                <div className="pt-2 border-t border-[#30363d]">
                  <span className="text-gray-400 font-sans text-[11px] block mb-1">Success Response (JSON):</span>
                  <pre className="text-[#79c0ff] text-xs">
{`{
  "charge": "15.0000",
  "start_count": "120",
  "status": "In progress",
  "remains": "880",
  "currency": "INR"
}`}
                  </pre>
                </div>
              </div>

              {/* 5. Request Parameters (Refill & Refill Status) */}
              <div className="rounded-2xl bg-[#161b22] border border-[#30363d] p-5 space-y-3">
                <div className="flex items-center justify-between border-b border-[#30363d] pb-2.5">
                  <div className="text-gray-400 font-sans font-bold text-xs uppercase tracking-wider">
                    # 5. Request Parameters (Refill Order)
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyCodeBlock(
                        'req-refill',
                        `key = ${apiKey || 'YOUR_API_KEY'}\naction = refill\norder = 1042`
                      )
                    }
                    className="px-2.5 py-1 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-gray-300 text-xs font-sans flex items-center space-x-1.5 transition-colors cursor-pointer border border-[#30363d]"
                  >
                    {copiedBlockId === 'req-refill' ? (
                      <>
                        <Check className="w-3 h-3 text-[#3fb950]" />
                        <span className="text-[#3fb950]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="space-y-1.5 text-xs sm:text-sm leading-relaxed">
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">key</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">{apiKey ? apiKey.substring(0, 10) + '...' : 'af61a17a0c...'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">action</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">refill</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">order</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#79c0ff]">1042</span>
                  </div>
                </div>
                <div className="pt-2 border-t border-[#30363d]">
                  <span className="text-gray-400 font-sans text-[11px] block mb-1">Success Response (JSON):</span>
                  <pre className="text-[#79c0ff] text-xs">
{`{
  "refill": "101"
}`}
                  </pre>
                </div>
              </div>

              {/* 6. Request Parameters (Cancel Order) */}
              <div className="rounded-2xl bg-[#161b22] border border-[#30363d] p-5 space-y-3">
                <div className="flex items-center justify-between border-b border-[#30363d] pb-2.5">
                  <div className="text-gray-400 font-sans font-bold text-xs uppercase tracking-wider">
                    # 6. Request Parameters (Cancel Order)
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyCodeBlock(
                        'req-cancel',
                        `key = ${apiKey || 'YOUR_API_KEY'}\naction = cancel\norder = 1042`
                      )
                    }
                    className="px-2.5 py-1 rounded-lg bg-[#21262d] hover:bg-[#30363d] text-gray-300 text-xs font-sans flex items-center space-x-1.5 transition-colors cursor-pointer border border-[#30363d]"
                  >
                    {copiedBlockId === 'req-cancel' ? (
                      <>
                        <Check className="w-3 h-3 text-[#3fb950]" />
                        <span className="text-[#3fb950]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="space-y-1.5 text-xs sm:text-sm leading-relaxed">
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">key</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">{apiKey ? apiKey.substring(0, 10) + '...' : 'af61a17a0c...'}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">action</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#7ee787]">cancel</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[#d2a8ff] font-bold">order</span>
                    <span className="text-gray-400">=</span>
                    <span className="text-[#79c0ff]">1042</span>
                  </div>
                </div>
                <div className="pt-2 border-t border-[#30363d]">
                  <span className="text-gray-400 font-sans text-[11px] block mb-1">Success Response (JSON):</span>
                  <pre className="text-[#79c0ff] text-xs">
{`{
  "cancel": "1042"
}`}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. INTERACTIVE LIVE API SANDBOX / TESTER VIEW                             */}
      {/* ========================================================================= */}
      {activeView === 'tester' && (
        <div className="p-6 sm:p-7 rounded-3xl border border-[#EAE3D2] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900/90 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#EAE3D2] dark:border-slate-800/80 pb-4">
            <div>
              <h2 className="text-lg font-black text-stone-900 dark:text-white flex items-center space-x-2">
                <Play className="w-5 h-5 text-emerald-500 fill-current" />
                <span>Interactive Live API Sandbox & Console</span>
              </h2>
              <p className="text-xs text-stone-500 dark:text-gray-400 mt-0.5">
                Send real authenticated requests directly to <code className="font-mono text-red-500">/api/v2</code> and inspect the live JSON response.
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 text-xs font-black self-start sm:self-auto">
              Real-time Endpoint
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Request Builder Form */}
            <div className="lg:col-span-5 space-y-4">
              <div>
                <label className="block text-xs font-black text-gray-700 dark:text-gray-300 mb-1.5 uppercase tracking-wider">
                  Select Action
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'balance', label: '1. balance' },
                    { id: 'services', label: '2. services' },
                    { id: 'status', label: '3. status' },
                    { id: 'add', label: '4. add (Order)' },
                    { id: 'refill', label: '5. refill' },
                    { id: 'refill_status', label: '6. refill_status' },
                    { id: 'cancel', label: '7. cancel (Order)' },
                  ].map((act) => (
                    <button
                      key={act.id}
                      type="button"
                      onClick={() => setTesterAction(act.id as any)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold transition-all text-left cursor-pointer border ${
                        testerAction === act.id
                          ? 'bg-[#DC2626] text-white border-red-600 shadow-sm'
                          : 'bg-stone-50 dark:bg-slate-800/70 border-stone-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 hover:bg-stone-100'
                      }`}
                    >
                      {act.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dynamic Action Fields */}
              {testerAction === 'add' && (
                <div className="space-y-3 pt-2 border-t border-stone-200 dark:border-slate-800">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      Service
                    </label>
                    <select
                      value={testerServiceId}
                      onChange={(e) => setTesterServiceId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-bold"
                    >
                      {services.slice(0, 50).map((s) => (
                        <option key={s.id} value={s.id}>
                          #{s.id} - {s.name.slice(0, 40)} ({currencySymbol}
                          {s.pricePerThousand.toFixed(2)})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      Link / URL
                    </label>
                    <input
                      type="text"
                      value={testerLink}
                      onChange={(e) => setTesterLink(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                      Quantity
                    </label>
                    <input
                      type="number"
                      value={testerQuantity}
                      onChange={(e) => setTesterQuantity(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono"
                    />
                  </div>
                </div>
              )}

              {(testerAction === 'status' || testerAction === 'refill' || testerAction === 'cancel') && (
                <div className="pt-2 border-t border-stone-200 dark:border-slate-800">
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    Order ID
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 1042"
                    value={testerOrderId}
                    onChange={(e) => setTesterOrderId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono"
                  />
                </div>
              )}

              {testerAction === 'refill_status' && (
                <div className="pt-2 border-t border-stone-200 dark:border-slate-800">
                  <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                    Refill ID
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 101"
                    value={testerRefillId}
                    onChange={(e) => setTesterRefillId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono"
                  />
                </div>
              )}

              <button
                type="button"
                onClick={handleRunApiTest}
                disabled={isTesting || !apiKey}
                className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-black text-xs transition-all shadow-md flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
              >
                {isTesting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Executing Request...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 fill-current" />
                    <span>Send Live Request (action: {testerAction})</span>
                  </>
                )}
              </button>
            </div>

            {/* Response Console */}
            <div className="lg:col-span-7 flex flex-col">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-extrabold uppercase tracking-wider text-gray-500">
                    Live Response Console
                  </span>
                  {testStatusCode && (
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-black ${
                        testStatusCode === 200
                          ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                          : 'bg-red-500/20 text-red-600 dark:text-red-400'
                      }`}
                    >
                      {testStatusCode} {testStatusCode === 200 ? 'OK' : 'ERROR'}
                    </span>
                  )}
                  {testLatency !== null && (
                    <span className="text-[11px] font-mono text-gray-400">
                      ⚡ {testLatency} ms
                    </span>
                  )}
                </div>

                {testResponse && (
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(JSON.stringify(testResponse, null, 2));
                      setCopiedTestResponse(true);
                      setTimeout(() => setCopiedTestResponse(false), 2000);
                    }}
                    className="text-xs font-bold text-gray-500 hover:text-gray-900 dark:hover:text-white flex items-center space-x-1 cursor-pointer"
                  >
                    {copiedTestResponse ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedTestResponse ? 'Copied' : 'Copy JSON'}</span>
                  </button>
                )}
              </div>

              <div className="flex-1 min-h-[280px] max-h-[420px] rounded-2xl bg-[#0d1117] border border-[#30363d] p-4 font-mono text-xs overflow-y-auto text-[#7ee787] shadow-inner">
                {testResponse ? (
                  <pre className="whitespace-pre-wrap">{JSON.stringify(testResponse, null, 2)}</pre>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-gray-500 space-y-2">
                    <Terminal className="w-8 h-8 opacity-40" />
                    <span>Select an action and click Send Live Request to see output</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. MULTI-LANGUAGE CODE SNIPPETS VIEW                                      */}
      {/* ========================================================================= */}
      {activeView === 'snippets' && (
        <div className="p-6 sm:p-7 rounded-3xl border border-[#EAE3D2] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900/90 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-stone-900 dark:text-white flex items-center space-x-2">
                <Code2 className="w-5 h-5 text-blue-500" />
                <span>Ready-To-Use Code Implementations</span>
              </h2>
              <p className="text-xs text-stone-500 dark:text-gray-400 mt-0.5">
                Drop-in code samples pre-filled with your API endpoint and secret credentials.
              </p>
            </div>

            <div className="flex flex-wrap gap-1.5 p-1 rounded-2xl bg-[#F4EFE3] dark:bg-slate-800 border border-[#DDD3BC] dark:border-slate-700">
              {[
                { id: 'curl', label: 'cURL' },
                { id: 'php', label: 'PHP (cURL)' },
                { id: 'php_class', label: 'PHP (Class)' },
                { id: 'python', label: 'Python' },
                { id: 'node', label: 'Node.js' },
              ].map((lang) => (
                <button
                  key={lang.id}
                  type="button"
                  onClick={() => setSelectedSnippet(lang.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    selectedSnippet === lang.id
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-stone-600 dark:text-gray-300 hover:text-stone-900'
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>

          <div className="relative rounded-2xl bg-[#0d1117] border border-[#30363d] p-5 font-mono text-xs text-[#e6edf3] overflow-x-auto shadow-xl">
            <button
              type="button"
              onClick={handleCopySnippet}
              className="absolute top-4 right-4 px-3 py-1.5 rounded-xl bg-[#21262d] hover:bg-[#30363d] text-white text-xs font-sans font-bold flex items-center space-x-1.5 transition-colors cursor-pointer border border-[#30363d]"
            >
              {copiedSnippet ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Snippet</span>
                </>
              )}
            </button>
            <pre className="pr-20 leading-relaxed text-[#7ee787]">{snippets[selectedSnippet]}</pre>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. REGENERATE CONFIRMATION MODAL                                          */}
      {/* ========================================================================= */}
      {showRegenerateConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-md rounded-3xl bg-[#FFFDF8] dark:bg-slate-900 p-6 border border-[#EAE3D2] dark:border-slate-800 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/40 text-red-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-lg font-black text-stone-900 dark:text-white">
                Regenerate API Secret Key?
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                Rotating your API secret key will <strong>immediately invalidate</strong> your previous key.
                Any existing websites, cron jobs, or reseller panels connected with your current key will stop working until updated.
              </p>
            </div>

            <div className="flex items-center space-x-3 pt-2">
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setShowRegenerateConfirm(false);
                }}
                disabled={isGenerating}
                className="flex-1 py-2.5 rounded-2xl border border-stone-200 dark:border-slate-700 text-xs font-bold text-gray-700 dark:text-gray-300 hover:bg-stone-100 dark:hover:bg-slate-800 transition-colors cursor-pointer disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  handleConfirmRegenerateKey(e);
                }}
                disabled={isGenerating}
                className="flex-1 py-2.5 rounded-2xl bg-red-600 hover:bg-red-700 text-white text-xs font-black transition-colors shadow-sm cursor-pointer disabled:opacity-50 flex items-center justify-center space-x-1.5"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Regenerating...</span>
                  </>
                ) : (
                  <span>Yes, Regenerate Key</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
