import React, { useState, useEffect } from 'react';
import {
  Ticket,
  Plus,
  MessageSquare,
  Clock,
  CheckCircle,
  AlertCircle,
  Send,
  X,
  Search,
  RefreshCw,
  User,
  Shield,
  HelpCircle,
} from 'lucide-react';

interface UserTicketsSectionProps {
  token: string;
  currentUser: any;
  isDarkMode: boolean;
  publicSettings: any;
}

export const UserTicketsSection: React.FC<UserTicketsSectionProps> = ({
  token,
  currentUser,
  isDarkMode,
  publicSettings,
}) => {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState<string>('');

  // Selected ticket / conversation modal
  const [selectedTicket, setSelectedTicket] = useState<any | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [isSendingReply, setIsSendingReply] = useState(false);

  // Create ticket modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketCategory, setTicketCategory] = useState('Order Issues');
  const [ticketMessage, setTicketMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const fetchTickets = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/user/tickets?_t=${Date.now()}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json',
        },
      });
      if (res.ok) {
        const data = await res.json();
        setTickets(Array.isArray(data) ? data : []);
      }
    } catch (err) {
      console.error('Error fetching tickets:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, [token]);

  const openTicketThread = async (t: any) => {
    setSelectedTicket(t);
    setLoadingMessages(true);
    try {
      const res = await fetch(`/api/tickets/${t.id}/messages`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages || []);
      }
    } catch (err) {
      console.error('Error fetching ticket messages:', err);
    } finally {
      setLoadingMessages(false);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !replyText.trim() || isSendingReply) return;
    setIsSendingReply(true);
    try {
      const res = await fetch(`/api/tickets/${selectedTicket.id}/reply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ message: replyText.trim() }),
      });
      if (res.ok) {
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now(),
            message: replyText.trim(),
            createdAt: new Date().toISOString(),
            senderName: currentUser.name || 'You',
            senderRole: 'user',
          },
        ]);
        setReplyText('');
        fetchTickets();
      }
    } catch (err) {
      console.error('Error sending reply:', err);
    } finally {
      setIsSendingReply(false);
    }
  };

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    if (!ticketSubject.trim() || !ticketMessage.trim()) {
      setErrorMsg('Please enter both subject and message.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/tickets/new', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          subject: `[${ticketCategory}] ${ticketSubject.trim()}`,
          message: ticketMessage.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setSuccessMsg('Support ticket submitted! An executive will review and reply shortly.');
        setTicketSubject('');
        setTicketMessage('');
        setTimeout(() => {
          setShowCreateModal(false);
          setSuccessMsg(null);
        }, 1500);
        fetchTickets();
      } else {
        setErrorMsg(data.error || 'Failed to submit ticket.');
      }
    } catch (err) {
      setErrorMsg('Network error submitting support ticket.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredTickets = tickets.filter((t) => {
    const matchesFilter = filter === 'all' ? true : t.status === filter;
    const matchesSearch =
      !search.trim() ||
      t.subject?.toLowerCase().includes(search.toLowerCase()) ||
      String(t.id).includes(search);
    return matchesFilter && matchesSearch;
  });

  const openCount = tickets.filter((t) => t.status === 'open' || t.status === 'pending').length;
  const answeredCount = tickets.filter((t) => t.status === 'answered').length;
  const closedCount = tickets.filter((t) => t.status === 'closed').length;

  return (
    <div
      className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-6 transition-colors ${
        isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
      }`}
    >
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#FF5376] flex items-center justify-center text-white shadow-xs">
              <Ticket className="w-5 h-5" />
            </div>
            <span>Support Tickets</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-rose-500/10 text-rose-600 border border-rose-500/20">
              {tickets.length} Total
            </span>
          </h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            Create support requests for order status, payment verification, speed boosts, or technical queries.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={fetchTickets}
            disabled={loading}
            className="px-3.5 py-2 rounded-xl border border-stone-200 dark:border-slate-800 text-xs font-bold flex items-center gap-1.5 hover:bg-stone-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-rose-500' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            type="button"
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2 rounded-xl bg-[#DC2626] hover:bg-red-700 text-white text-xs font-black flex items-center gap-1.5 shadow-md shadow-red-500/20 cursor-pointer transition-all"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Open New Ticket</span>
          </button>
        </div>
      </div>

      {/* Stats Counter Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl border border-stone-200/80 dark:border-slate-800 bg-stone-50/60 dark:bg-slate-800/40">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">Total Tickets</span>
          <span className="text-xl font-black font-mono mt-0.5 block">{tickets.length}</span>
        </div>
        <div className="p-3.5 rounded-2xl border border-amber-500/20 bg-amber-500/5">
          <span className="text-[11px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider block">Awaiting Reply</span>
          <span className="text-xl font-black font-mono text-amber-600 dark:text-amber-400 mt-0.5 block">{openCount}</span>
        </div>
        <div className="p-3.5 rounded-2xl border border-emerald-500/20 bg-emerald-500/5">
          <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block">Answered by Staff</span>
          <span className="text-xl font-black font-mono text-emerald-600 dark:text-emerald-400 mt-0.5 block">{answeredCount}</span>
        </div>
        <div className="p-3.5 rounded-2xl border border-gray-200 dark:border-slate-800 bg-gray-100/40 dark:bg-slate-800/20">
          <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">Closed</span>
          <span className="text-xl font-black font-mono text-gray-500 mt-0.5 block">{closedCount}</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1 border-t border-gray-100 dark:border-slate-800">
        <div className="flex items-center gap-1.5 flex-wrap">
          {['all', 'open', 'answered', 'closed'].map((st) => (
            <button
              key={st}
              onClick={() => setFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                filter === st
                  ? 'bg-[#DC2626] text-white shadow-xs'
                  : isDarkMode
                  ? 'bg-slate-800 text-gray-400 hover:text-white'
                  : 'bg-stone-100 text-gray-600 hover:text-gray-900'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-gray-400" />
          <input
            type="text"
            placeholder="Search tickets by subject or #ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] dark:bg-slate-900 text-stone-900 dark:text-white placeholder-stone-400 focus:outline-hidden focus:ring-2 focus:ring-red-500"
          />
        </div>
      </div>

      {/* Tickets List */}
      {filteredTickets.length === 0 ? (
        <div className="text-center py-14 border border-dashed border-stone-200 dark:border-slate-800 rounded-3xl space-y-3">
          <Ticket className="w-10 h-10 mx-auto text-gray-300 dark:text-gray-600 stroke-[1.5]" />
          <p className="text-xs font-bold text-gray-400">No tickets found in this view.</p>
          <button
            type="button"
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-600 text-xs font-bold cursor-pointer inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create your first ticket</span>
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-stone-200 dark:border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 dark:bg-slate-800/80 text-gray-500 font-mono text-[11px] border-b border-stone-200 dark:border-slate-800 uppercase">
              <tr>
                <th className="py-3 px-4">Ticket ID</th>
                <th className="py-3 px-4">Subject</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Created Date</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filteredTickets.map((t) => {
                const statusColor =
                  t.status === 'answered'
                    ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
                    : t.status === 'closed'
                    ? 'bg-gray-500/10 text-gray-500 border-gray-500/20'
                    : 'bg-amber-500/10 text-amber-600 border-amber-500/20';

                return (
                  <tr key={t.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-gray-400">#{t.id}</td>
                    <td className="py-3 px-4">
                      <span className="font-bold text-gray-900 dark:text-white block max-w-md truncate">
                        {t.subject}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border inline-block ${statusColor}`}>
                        {t.status || 'open'}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-gray-500 text-[11px]">
                      {t.createdAt ? new Date(t.createdAt).toLocaleString() : 'Recent'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => openTicketThread(t)}
                        className="px-3 py-1 bg-rose-500/10 hover:bg-rose-500/20 text-[#DC2626] font-black rounded-lg text-xs cursor-pointer inline-flex items-center gap-1 transition-all"
                      >
                        <MessageSquare className="w-3 h-3" />
                        <span>View & Reply</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* ===================== VIEW & REPLY MODAL ===================== */}
      {selectedTicket && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-2xl rounded-3xl p-6 shadow-2xl border space-y-4 animate-in fade-in zoom-in-95 max-h-[90vh] flex flex-col ${
              isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-[#FFFDF8] border-[#EAE3D2] text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-gray-100 dark:border-slate-800 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-rose-500/10 text-rose-500 flex items-center justify-center">
                  <Ticket className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black tracking-tight truncate max-w-md">
                    #{selectedTicket.id} - {selectedTicket.subject}
                  </h3>
                  <span className="text-[11px] text-gray-400 font-mono">
                    Status: <strong className="uppercase text-rose-500">{selectedTicket.status || 'open'}</strong>
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTicket(null)}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Conversation Messages Scroll View */}
            <div className="flex-1 overflow-y-auto space-y-3 p-3 rounded-2xl bg-stone-50 dark:bg-slate-950/50 border border-stone-200/80 dark:border-slate-800/80 min-h-[220px] max-h-[360px]">
              {loadingMessages ? (
                <div className="py-12 text-center text-gray-400 text-xs">
                  <RefreshCw className="w-5 h-5 mx-auto animate-spin mb-2" />
                  Loading conversation thread...
                </div>
              ) : messages.length === 0 ? (
                <div className="py-12 text-center text-gray-400 text-xs">
                  No replies on this ticket yet. Write a message below to reach out to support.
                </div>
              ) : (
                messages.map((m, idx) => {
                  const isStaff = m.senderRole === 'admin' || m.senderRole === 'support';
                  return (
                    <div
                      key={m.id || idx}
                      className={`p-3.5 rounded-2xl max-w-[85%] text-xs space-y-1 ${
                        isStaff
                          ? 'mr-auto bg-blue-500/10 border border-blue-500/20 text-blue-900 dark:text-blue-100'
                          : 'ml-auto bg-[#DC2626]/10 border border-red-500/20 text-gray-900 dark:text-gray-100'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[10px] font-bold opacity-80 gap-4">
                        <span className="flex items-center gap-1 font-mono">
                          {isStaff ? <Shield className="w-3 h-3 text-blue-500" /> : <User className="w-3 h-3 text-red-500" />}
                          {isStaff ? 'YouthSMM Support Staff' : 'You'}
                        </span>
                        <span className="font-mono text-[9px]">
                          {m.createdAt ? new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                        </span>
                      </div>
                      <p className="whitespace-pre-wrap leading-relaxed text-xs font-medium">{m.message}</p>
                    </div>
                  );
                })
              )}
            </div>

            {/* Reply Input Box */}
            <form onSubmit={handleSendReply} className="space-y-2 shrink-0 pt-2 border-t border-gray-100 dark:border-slate-800">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Type your reply message..."
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  disabled={isSendingReply}
                  className="flex-1 px-4 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] dark:bg-slate-900 text-stone-900 dark:text-white placeholder-stone-400 text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-red-500"
                />
                <button
                  type="submit"
                  disabled={isSendingReply || !replyText.trim()}
                  className="px-4 py-2.5 rounded-xl bg-[#DC2626] hover:bg-red-700 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================== CREATE TICKET MODAL ===================== */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-lg rounded-3xl p-6 shadow-2xl border space-y-4 animate-in fade-in zoom-in-95 ${
              isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-[#FFFDF8] border-[#EAE3D2] text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-stone-200/60 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-red-500/10 text-red-500 flex items-center justify-center">
                  <Ticket className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black tracking-tight">Open New Support Ticket</h3>
                  <p className="text-[11px] text-stone-400">Average response time is under 15 minutes</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="w-8 h-8 rounded-full bg-[#F4EFE3] dark:bg-slate-800 flex items-center justify-center text-stone-500 hover:text-stone-900 dark:hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-600 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}
            {successMsg && (
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 text-xs font-bold flex items-center gap-2">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            <form onSubmit={handleCreateTicket} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1">
                  Issue Department
                </label>
                <select
                  value={ticketCategory}
                  onChange={(e) => setTicketCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] dark:bg-slate-900 text-stone-900 dark:text-white font-bold focus:outline-hidden focus:ring-2 focus:ring-red-500"
                >
                  <option value="Order Issues">Order Issues (Speed / Delivery / Stalled)</option>
                  <option value="Payment / UTR">Payment Verification / BharatPe UTR</option>
                  <option value="Refill Request">Drop Refill Guarantee Request</option>
                  <option value="Child Panel">Child Panel Domain / Setup Help</option>
                  <option value="API Integration">API Reseller Support</option>
                  <option value="General Query">Other General Query</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1">
                  Subject / Order ID
                </label>
                <input
                  type="text"
                  placeholder="e.g. Order #1245 not completing or UTR verification"
                  value={ticketSubject}
                  onChange={(e) => setTicketSubject(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] dark:bg-slate-900 text-stone-900 dark:text-white font-medium focus:outline-hidden focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-1">
                  Detailed Explanation
                </label>
                <textarea
                  rows={4}
                  placeholder="Provide all details, including order ID, username, link, or transaction UTR so our team can resolve it immediately."
                  value={ticketMessage}
                  onChange={(e) => setTicketMessage(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] dark:bg-slate-900 text-stone-900 dark:text-white font-medium focus:outline-hidden focus:ring-2 focus:ring-red-500 resize-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-stone-200 dark:border-slate-800 font-bold hover:bg-stone-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-[#DC2626] hover:bg-red-700 text-white font-black shadow-md shadow-red-500/20 disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Submitting...</span>
                    </>
                  ) : (
                    <span>Submit Ticket</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
