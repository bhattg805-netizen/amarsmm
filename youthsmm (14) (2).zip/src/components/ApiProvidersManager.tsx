import React, { useState } from 'react';
import {
  RefreshCw,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Search,
  Check,
  X,
  Layers,
  Percent,
  TrendingUp,
  Key,
  Globe,
  Wallet,
  ArrowUpRight,
  ShieldCheck,
  HelpCircle,
  Copy,
  ChevronDown,
  Filter
} from 'lucide-react';
import { Service } from '../types.ts';
import { broadcastAdminChange } from '../lib/api.ts';

export interface ApiProvider {
  id: number;
  name: string;
  apiUrl: string;
  apiKey: string;
  status?: string;
  balance?: number;
  currency?: string;
  createdAt?: string;
}

interface ApiProvidersManagerProps {
  token: string;
  providers: ApiProvider[];
  servicesList: Service[];
  onRefreshProviders: () => Promise<void>;
  showSuccess: (msg: string) => void;
  showError: (msg: string) => void;
  isLight: boolean;
  cardBgClasses: string;
  subCardBg: string;
}

export const ApiProvidersManager: React.FC<ApiProvidersManagerProps> = ({
  token,
  providers,
  servicesList,
  onRefreshProviders,
  showSuccess,
  showError,
  isLight,
  cardBgClasses,
  subCardBg,
}) => {
  // Modals & States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingProvider, setEditingProvider] = useState<ApiProvider | null>(null);
  const [deleteConfirmProvider, setDeleteConfirmProvider] = useState<ApiProvider | null>(null);

  // Form State for Add / Edit
  const [formName, setFormName] = useState('');
  const [formApiUrl, setFormApiUrl] = useState('');
  const [formApiKey, setFormApiKey] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Balance Refreshing State per Provider ID
  const [refreshingBalanceId, setRefreshingBalanceId] = useState<number | null>(null);

  // Upstream Services Modal State
  const [browseProvider, setBrowseProvider] = useState<ApiProvider | null>(null);
  const [loadingRemoteServices, setLoadingRemoteServices] = useState(false);
  const [remoteServices, setRemoteServices] = useState<any[]>([]);
  const [remoteSearchQuery, setRemoteSearchQuery] = useState('');
  const [remoteCategoryFilter, setRemoteCategoryFilter] = useState('all');
  const [selectedRemoteIds, setSelectedRemoteIds] = useState<Set<string | number>>(new Set());
  const [priceMultiplier, setPriceMultiplier] = useState<string>('1.3'); // Default 30% markup
  const [isImporting, setIsImporting] = useState(false);
  const [copiedKeyId, setCopiedKeyId] = useState<number | null>(null);

  // Count services linked to each provider
  const getProviderServiceCount = (providerId: number) => {
    return servicesList.filter((s) => s.providerId === providerId).length;
  };

  // Open Add Modal
  const handleOpenAdd = () => {
    setFormName('');
    setFormApiUrl('https://');
    setFormApiKey('');
    setIsAddModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (p: ApiProvider) => {
    setEditingProvider(p);
    setFormName(p.name);
    setFormApiUrl(p.apiUrl);
    setFormApiKey(p.apiKey || '');
  };

  // Handle Create or Update Provider
  const handleSubmitProvider = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formApiUrl.trim() || !formApiKey.trim()) {
      showError('Please fill in Provider Name, API URL, and API Key.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingProvider) {
        // Update
        const res = await fetch(`/api/admin/providers/${editingProvider.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: formName.trim(),
            apiUrl: formApiUrl.trim(),
            apiKey: formApiKey.trim(),
          }),
        });

        const data = await res.json();
        if (res.ok) {
          showSuccess(`Provider "${formName}" updated successfully.`);
          setEditingProvider(null);
          await onRefreshProviders();
        } else {
          showError(data.error || 'Failed to update provider.');
        }
      } else {
        // Create
        const res = await fetch('/api/admin/providers', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: formName.trim(),
            apiUrl: formApiUrl.trim(),
            apiKey: formApiKey.trim(),
          }),
        });

        const data = await res.json();
        if (res.ok) {
          showSuccess(`Provider "${formName}" added successfully.`);
          setIsAddModalOpen(false);
          await onRefreshProviders();
        } else {
          showError(data.error || 'Failed to add provider.');
        }
      }
    } catch (err: any) {
      showError(`Request failed: ${err.message || err}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Delete Provider
  const handleDeleteProvider = async () => {
    if (!deleteConfirmProvider) return;
    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/admin/providers/${deleteConfirmProvider.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        showSuccess(`Provider "${deleteConfirmProvider.name}" deleted.`);
        setDeleteConfirmProvider(null);
        await onRefreshProviders();
      } else {
        showError(data.error || 'Failed to delete provider.');
      }
    } catch (err: any) {
      showError(`Delete failed: ${err.message || err}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Sync / Refresh Balance for a single provider
  const handleCheckBalance = async (p: ApiProvider) => {
    setRefreshingBalanceId(p.id);
    try {
      const res = await fetch(`/api/admin/providers/${p.id}/balance`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        showSuccess(`Live balance for ${p.name}: ₹${Number(data.balance).toFixed(2)}`);
        await onRefreshProviders();
      } else {
        showError(data.error || `Could not fetch balance from ${p.name}`);
      }
    } catch (err: any) {
      showError(`Connection error: ${err.message || err}`);
    } finally {
      setRefreshingBalanceId(null);
    }
  };

  // Open Upstream Services Browser
  const handleOpenServices = async (p: ApiProvider) => {
    setBrowseProvider(p);
    setLoadingRemoteServices(true);
    setRemoteServices([]);
    setSelectedRemoteIds(new Set());
    setRemoteSearchQuery('');
    setRemoteCategoryFilter('all');

    try {
      const res = await fetch(`/api/admin/providers/${p.id}/services`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok && Array.isArray(data)) {
        setRemoteServices(data);
        showSuccess(`Loaded ${data.length} upstream services from ${p.name}`);
      } else {
        showError(data.error || 'Failed to fetch services from provider.');
      }
    } catch (err: any) {
      showError(`Network error fetching provider services: ${err.message || err}`);
    } finally {
      setLoadingRemoteServices(false);
    }
  };

  // Extract unique categories from remote services
  const remoteCategories = Array.from(
    new Set(remoteServices.map((s) => s.category || 'General').filter(Boolean))
  );

  // Filtered remote services
  const filteredRemoteServices = remoteServices.filter((s) => {
    const matchesSearch =
      remoteSearchQuery.trim() === '' ||
      String(s.service || '').includes(remoteSearchQuery) ||
      (s.name && s.name.toLowerCase().includes(remoteSearchQuery.toLowerCase())) ||
      (s.category && s.category.toLowerCase().includes(remoteSearchQuery.toLowerCase()));

    const matchesCat =
      remoteCategoryFilter === 'all' ||
      (s.category && s.category.toLowerCase() === remoteCategoryFilter.toLowerCase());

    return matchesSearch && matchesCat;
  });

  // Toggle single selection
  const toggleSelectRemote = (id: string | number) => {
    const next = new Set(selectedRemoteIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedRemoteIds(next);
  };

  // Select all filtered
  const toggleSelectAllFiltered = () => {
    if (selectedRemoteIds.size === filteredRemoteServices.length && filteredRemoteServices.length > 0) {
      setSelectedRemoteIds(new Set());
    } else {
      const next = new Set<string | number>();
      filteredRemoteServices.forEach((s) => next.add(s.service));
      setSelectedRemoteIds(next);
    }
  };

  // Handle Bulk Import of selected services
  const handleBulkImport = async () => {
    if (!browseProvider) return;
    if (selectedRemoteIds.size === 0) {
      showError('Please select at least one service to import.');
      return;
    }

    const mult = parseFloat(priceMultiplier) || 1.3;
    const servicesToImport = remoteServices.filter((s) => selectedRemoteIds.has(s.service));

    setIsImporting(true);
    try {
      const res = await fetch('/api/admin/services/import-bulk', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          providerId: browseProvider.id,
          priceMultiplier: mult,
          services: servicesToImport,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        showSuccess(`Successfully imported ${data.count || servicesToImport.length} services with ${((mult - 1) * 100).toFixed(0)}% markup!`);
        setBrowseProvider(null);
        await onRefreshProviders();
        broadcastAdminChange();
      } else {
        showError(data.error || 'Failed to import services.');
      }
    } catch (err: any) {
      showError(`Import error: ${err.message || err}`);
    } finally {
      setIsImporting(false);
    }
  };

  const copyToClipboard = (text: string, id: number) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyId(id);
    setTimeout(() => setCopiedKeyId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className={`rounded-3xl p-6 sm:p-8 border shadow-xs ${cardBgClasses}`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-red-600/10 text-red-600 flex items-center justify-center font-black">
                <RefreshCw className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
                  <span>API Providers Configuration</span>
                  <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-red-500/10 text-red-600 border border-red-500/20">
                    {providers.length} Connected
                  </span>
                </h2>
                <p className="text-xs text-gray-400">
                  Manage upstream wholesale SMM APIs, sync live provider balances, and import services.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-2.5">
            <button
              type="button"
              onClick={handleOpenAdd}
              className="px-4 py-2.5 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-black text-xs flex items-center space-x-2 shadow-md shadow-red-600/20 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add API Provider</span>
            </button>

            <button
              type="button"
              onClick={onRefreshProviders}
              className={`p-2.5 rounded-2xl border text-xs font-bold transition-all cursor-pointer ${
                isLight ? 'bg-stone-50 hover:bg-stone-100 border-stone-200 text-gray-700' : 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-gray-200'
              }`}
              title="Refresh Providers"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Help Banner */}
        <div className="mt-6 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-start space-x-3">
          <HelpCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <span className="font-black text-amber-800 dark:text-amber-400">
              How Upstream Order Dispatch Works:
            </span>
            <p className="text-amber-700/90 dark:text-amber-300/90 leading-relaxed">
              When a user places an order, YouthSMM automatically dispatches it to the service's linked provider via standard V2 SMM API format (<code className="font-mono bg-amber-500/15 px-1 py-0.5 rounded">action=add</code>). Make sure the provider's API key is valid and has sufficient balance.
            </p>
          </div>
        </div>
      </div>

      {/* Providers Grid */}
      {providers.length === 0 ? (
        <div className={`rounded-3xl p-12 text-center border ${cardBgClasses} space-y-4`}>
          <div className="w-14 h-14 rounded-3xl bg-red-500/10 text-red-600 mx-auto flex items-center justify-center font-bold">
            <RefreshCw className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-lg font-black">No API Providers Added Yet</h3>
            <p className="text-xs text-gray-400 max-w-md mx-auto mt-1">
              Add your first wholesale SMM API provider (e.g. SMM Kings, Global Provider) to enable automatic order processing and 1-click service imports.
            </p>
          </div>
          <button
            type="button"
            onClick={handleOpenAdd}
            className="px-5 py-2.5 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-black text-xs inline-flex items-center space-x-2 shadow-lg shadow-red-600/20 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Provider Now</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
          {providers.map((p) => {
            const linkedCount = getProviderServiceCount(p.id);
            const isRefreshing = refreshingBalanceId === p.id;

            return (
              <div
                key={p.id}
                className={`rounded-3xl p-6 border shadow-xs transition-all hover:shadow-md space-y-5 ${cardBgClasses}`}
              >
                {/* Top Row: Name, Status, and Controls */}
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-black text-base sm:text-lg tracking-tight">
                        {p.name}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-red-500/10 text-red-600 border border-red-500/20">
                        ID #{p.id}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600">
                        {p.status || 'Active'}
                      </span>
                    </div>
                    <div className="flex items-center space-x-1.5 text-xs text-gray-400 font-mono">
                      <Globe className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                      <span className="truncate max-w-[260px] sm:max-w-[340px]">{p.apiUrl}</span>
                      <a
                        href={p.apiUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-gray-400 hover:text-red-600 transition-colors"
                      >
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center space-x-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(p)}
                      className={`p-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                        isLight ? 'bg-stone-50 hover:bg-stone-100 border-stone-200 text-gray-700' : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-gray-300'
                      }`}
                      title="Edit Provider"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteConfirmProvider(p)}
                      className="p-2 rounded-xl border border-red-500/20 bg-red-500/10 hover:bg-red-500/20 text-red-600 text-xs font-bold transition-all cursor-pointer"
                      title="Delete Provider"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* API Key Box */}
                <div className={`p-3 rounded-2xl border flex items-center justify-between gap-2 text-xs font-mono ${subCardBg}`}>
                  <div className="flex items-center space-x-2 truncate">
                    <Key className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span className="text-gray-400 select-none">API Key:</span>
                    <span className="text-gray-600 dark:text-gray-300 font-bold truncate">
                      {p.apiKey || '••••••••'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(p.apiKey, p.id)}
                    className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors shrink-0"
                    title="Copy API Key"
                  >
                    {copiedKeyId === p.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Balance & Stats Row */}
                <div className="grid grid-cols-2 gap-3">
                  {/* Upstream Balance */}
                  <div className={`p-3.5 rounded-2xl border ${subCardBg} space-y-1`}>
                    <div className="flex items-center justify-between text-[11px] font-bold text-gray-400">
                      <span>Account Balance</span>
                      <button
                        type="button"
                        onClick={() => handleCheckBalance(p)}
                        disabled={isRefreshing}
                        className="text-red-600 hover:text-red-700 flex items-center space-x-1 cursor-pointer"
                        title="Sync Balance with Provider"
                      >
                        <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : ''}`} />
                        <span>Sync</span>
                      </button>
                    </div>
                    <div className="text-lg font-black text-emerald-600 flex items-center space-x-1">
                      <span>₹{Number(p.balance || 0).toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Linked Services */}
                  <div className={`p-3.5 rounded-2xl border ${subCardBg} space-y-1`}>
                    <div className="flex items-center justify-between text-[11px] font-bold text-gray-400">
                      <span>Linked Services</span>
                      <Layers className="w-3.5 h-3.5 text-blue-500" />
                    </div>
                    <div className="text-lg font-black text-gray-800 dark:text-white">
                      {linkedCount}{' '}
                      <span className="text-xs font-normal text-gray-400">Services</span>
                    </div>
                  </div>
                </div>

                {/* Bottom Actions Row */}
                <div className="pt-1 flex flex-col sm:flex-row items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => handleOpenServices(p)}
                    className="w-full sm:flex-1 py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center justify-center space-x-1.5 shadow-xs transition-all cursor-pointer"
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>Browse & Import Services</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleCheckBalance(p)}
                    disabled={isRefreshing}
                    className={`w-full sm:w-auto py-2.5 px-4 rounded-xl border text-xs font-bold flex items-center justify-center space-x-1.5 transition-all cursor-pointer ${
                      isLight ? 'bg-stone-100 hover:bg-stone-200 border-stone-200 text-gray-800' : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-gray-200'
                    }`}
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-red-600' : ''}`} />
                    <span>{isRefreshing ? 'Checking...' : 'Check Balance'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ===================== MODAL: ADD / EDIT PROVIDER ===================== */}
      {(isAddModalOpen || editingProvider) && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-lg rounded-3xl p-6 sm:p-7 border shadow-2xl space-y-5 animate-in fade-in zoom-in-95 ${
              isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-4">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-red-500/10 text-red-600 flex items-center justify-center font-bold">
                  {editingProvider ? <Edit2 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                </div>
                <div>
                  <h3 className="font-black text-lg">
                    {editingProvider ? 'Edit API Provider' : 'Add New API Provider'}
                  </h3>
                  <p className="text-xs text-gray-400">Standard V2 SMM API compatibility</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingProvider(null);
                }}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitProvider} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">
                  Provider Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. SMM Kings Wholesale, Global Provider"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-red-500 ${
                    isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">
                  API URL endpoint <span className="text-red-500">*</span>
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://smmprovider.com/api/v2"
                  value={formApiUrl}
                  onChange={(e) => setFormApiUrl(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-red-500 ${
                    isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
                <span className="text-[10px] text-gray-400 mt-1 block">
                  Must be the exact standard API v2 endpoint URL.
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">
                  API Key <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Enter API key or secret token"
                  value={formApiKey}
                  onChange={(e) => setFormApiKey(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-red-500 ${
                    isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
                {editingProvider && (
                  <span className="text-[10px] text-gray-400 mt-1 block">
                    Leave unchanged or enter a new key to update.
                  </span>
                )}
              </div>

              <div className="pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-end space-x-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingProvider(null);
                  }}
                  className="px-4 py-2.5 rounded-xl border text-xs font-bold hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black shadow-md shadow-red-600/20 transition-all cursor-pointer flex items-center space-x-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>{editingProvider ? 'Update Provider' : 'Save Provider'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================== MODAL: DELETE CONFIRMATION ===================== */}
      {deleteConfirmProvider && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-3xl p-6 border shadow-2xl space-y-4 animate-in fade-in zoom-in-95 ${
              isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 text-red-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-black text-lg">Delete API Provider?</h3>
              <p className="text-xs text-gray-400">
                Are you sure you want to remove <strong>{deleteConfirmProvider.name}</strong>? Any services currently mapped to this provider will be unlinked.
              </p>
            </div>
            <div className="pt-2 flex items-center justify-center space-x-2.5">
              <button
                type="button"
                onClick={() => setDeleteConfirmProvider(null)}
                className="px-4 py-2.5 rounded-xl border text-xs font-bold hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteProvider}
                disabled={isSubmitting}
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black transition-all cursor-pointer"
              >
                {isSubmitting ? 'Deleting...' : 'Yes, Delete Provider'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== MODAL: BROWSE & IMPORT SERVICES ===================== */}
      {browseProvider && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
          <div
            className={`w-full max-w-5xl max-h-[92vh] rounded-3xl border shadow-2xl flex flex-col animate-in fade-in zoom-in-95 overflow-hidden ${
              isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            {/* Header */}
            <div className="p-5 sm:p-6 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between shrink-0">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="text-lg sm:text-xl font-black">
                    Upstream Services: {browseProvider.name}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-red-500/10 text-red-600 border border-red-500/20">
                    {remoteServices.length} Available
                  </span>
                </div>
                <p className="text-xs text-gray-400">
                  Select upstream wholesale services and set your markup percentage to import directly into your catalog.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setBrowseProvider(null)}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Filter and Settings Bar */}
            <div className={`p-4 border-b border-gray-100 dark:border-gray-800 grid grid-cols-1 sm:grid-cols-12 gap-3 shrink-0 ${subCardBg}`}>
              {/* Search */}
              <div className="sm:col-span-5 relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search service by name or ID..."
                  value={remoteSearchQuery}
                  onChange={(e) => setRemoteSearchQuery(e.target.value)}
                  className={`w-full pl-9 pr-3 py-2 rounded-xl border text-xs focus:outline-hidden focus:ring-2 focus:ring-red-500 ${
                    isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              {/* Category Filter */}
              <div className="sm:col-span-4 relative">
                <select
                  value={remoteCategoryFilter}
                  onChange={(e) => setRemoteCategoryFilter(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-red-500 ${
                    isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                >
                  <option value="all">All Categories ({remoteCategories.length})</option>
                  {remoteCategories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              {/* Price Markup Multiplier */}
              <div className="sm:col-span-3 flex items-center space-x-2">
                <span className="text-[11px] font-bold text-gray-400 shrink-0">Markup:</span>
                <select
                  value={priceMultiplier}
                  onChange={(e) => setPriceMultiplier(e.target.value)}
                  className={`w-full px-2.5 py-2 rounded-xl border text-xs font-bold text-red-600 focus:outline-hidden focus:ring-2 focus:ring-red-500 ${
                    isLight ? 'bg-white border-stone-200' : 'bg-slate-800 border-slate-700'
                  }`}
                >
                  <option value="1.15">+15% Markup (1.15x)</option>
                  <option value="1.25">+25% Markup (1.25x)</option>
                  <option value="1.30">+30% Markup (1.30x)</option>
                  <option value="1.50">+50% Markup (1.50x)</option>
                  <option value="2.00">+100% Markup (2.00x)</option>
                </select>
              </div>
            </div>

            {/* Content Table / Body */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
              {loadingRemoteServices ? (
                <div className="py-20 text-center space-y-3">
                  <RefreshCw className="w-8 h-8 animate-spin text-red-600 mx-auto" />
                  <p className="text-xs text-gray-400 font-bold">Connecting to upstream API and fetching services...</p>
                </div>
              ) : filteredRemoteServices.length === 0 ? (
                <div className="py-20 text-center text-xs text-gray-400">
                  No services matching your search or filter.
                </div>
              ) : (
                <div className="overflow-x-auto rounded-2xl border border-gray-100 dark:border-gray-800">
                  <table className="w-full text-left text-xs whitespace-nowrap">
                    <thead className={`font-mono text-[11px] font-bold ${subCardBg} text-gray-400 sticky top-0`}>
                      <tr>
                        <th className="py-3 px-3 w-10">
                          <input
                            type="checkbox"
                            checked={
                              selectedRemoteIds.size === filteredRemoteServices.length &&
                              filteredRemoteServices.length > 0
                            }
                            onChange={toggleSelectAllFiltered}
                            className="rounded text-red-600 focus:ring-red-500 cursor-pointer"
                          />
                        </th>
                        <th className="py-3 px-3">ID</th>
                        <th className="py-3 px-4">Service Name</th>
                        <th className="py-3 px-3">Category</th>
                        <th className="py-3 px-3">Cost Price</th>
                        <th className="py-3 px-3 text-red-600">Your Selling Price</th>
                        <th className="py-3 px-3">Min / Max</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                      {filteredRemoteServices.map((srv: any) => {
                        const isSelected = selectedRemoteIds.has(srv.service);
                        const cost = parseFloat(srv.rate || 0);
                        const mult = parseFloat(priceMultiplier) || 1.3;
                        const sellPrice = cost * mult;

                        return (
                          <tr
                            key={srv.service}
                            onClick={() => toggleSelectRemote(srv.service)}
                            className={`cursor-pointer transition-colors ${
                              isSelected
                                ? isLight
                                  ? 'bg-red-50/60'
                                  : 'bg-red-950/20'
                                : 'hover:bg-gray-50/50 dark:hover:bg-slate-800/40'
                            }`}
                          >
                            <td className="py-2.5 px-3" onClick={(e) => e.stopPropagation()}>
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => toggleSelectRemote(srv.service)}
                                className="rounded text-red-600 focus:ring-red-500 cursor-pointer"
                              />
                            </td>
                            <td className="py-2.5 px-3 font-mono font-bold text-gray-400">
                              #{srv.service}
                            </td>
                            <td className="py-2.5 px-4 font-semibold max-w-[280px] truncate">
                              {srv.name}
                            </td>
                            <td className="py-2.5 px-3 text-gray-400 truncate max-w-[140px]">
                              {srv.category || 'General'}
                            </td>
                            <td className="py-2.5 px-3 font-mono font-bold text-gray-500">
                              ₹{cost.toFixed(2)}
                            </td>
                            <td className="py-2.5 px-3 font-mono font-black text-emerald-600">
                              ₹{sellPrice.toFixed(2)}
                            </td>
                            <td className="py-2.5 px-3 font-mono text-[11px] text-gray-400">
                              {srv.min || 10} - {srv.max || 10000}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Footer with Import Action */}
            <div className="p-4 sm:p-5 border-t border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
              <div className="text-xs font-bold text-gray-400">
                Selected: <span className="text-red-600 font-black">{selectedRemoteIds.size}</span> of {filteredRemoteServices.length} filtered services
              </div>

              <div className="flex items-center space-x-2.5">
                <button
                  type="button"
                  onClick={() => setBrowseProvider(null)}
                  className="px-4 py-2.5 rounded-xl border text-xs font-bold hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={handleBulkImport}
                  disabled={selectedRemoteIds.size === 0 || isImporting}
                  className={`px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black shadow-md shadow-red-600/20 transition-all cursor-pointer flex items-center space-x-2 ${
                    selectedRemoteIds.size === 0 || isImporting ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  {isImporting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Importing Services...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Import {selectedRemoteIds.size} Selected Services</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
