import React from 'react';
import { motion } from 'motion/react';
import { fetchPublicSettings, subscribeToAdminChanges } from '../lib/api.ts';

interface AnimatedLogoProps {
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  theme?: 'dark' | 'light' | 'auto';
  subtitle?: string;
  onClick?: () => void;
}

export const AnimatedLogo: React.FC<AnimatedLogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
  theme = 'auto',
  subtitle,
  onClick,
}) => {
  const [siteName, setSiteName] = React.useState<string>('YouthSMM');

  const updateSiteName = React.useCallback(() => {
    fetchPublicSettings(true).then((data) => {
      if (data && data.websiteName && data.websiteName.toLowerCase() !== 'ethicalsmm') {
        setSiteName(data.websiteName);
      }
    });
  }, []);

  React.useEffect(() => {
    const cachedName = localStorage.getItem('websiteName');
    if (cachedName && cachedName.toLowerCase() !== 'ethicalsmm') {
      setSiteName(cachedName);
    } else {
      setSiteName('YouthSMM');
    }

    updateSiteName();
    return subscribeToAdminChanges(updateSiteName);
  }, [updateSiteName]);

  const iconSizes = {
    xs: 'w-6 h-6 sm:w-7 sm:h-7',
    sm: 'w-7 h-7 sm:w-8 sm:h-8',
    md: 'w-8 h-8 sm:w-10 sm:h-10',
    lg: 'w-10 h-10 sm:w-12 sm:h-12',
    xl: 'w-12 h-12 sm:w-16 sm:h-16',
  };

  const textSizes = {
    xs: 'text-sm sm:text-base',
    sm: 'text-base sm:text-lg',
    md: 'text-lg sm:text-2xl',
    lg: 'text-xl sm:text-3xl',
    xl: 'text-2xl sm:text-4xl',
  };

  const badgeSizes = {
    xs: 'text-[7px] px-1 py-0.2',
    sm: 'text-[8px] px-1.5 py-0.2',
    md: 'text-[9px] px-1.5 py-0.5',
    lg: 'text-[10px] px-2 py-0.5',
    xl: 'text-xs px-2.5 py-0.5',
  };

  const rawName = (siteName || 'YouthSMM').trim();
  let prefix = 'Youth';
  let suffix = 'SMM';
  
  if (
    !rawName ||
    rawName.toLowerCase() === 'ethicalsmm' ||
    /^youths*m*$/i.test(rawName) ||
    rawName.toLowerCase() === 'youthsmm' ||
    rawName.toLowerCase() === 'youthsmmm'
  ) {
    prefix = 'Youth';
    suffix = 'SMM';
  } else if (rawName.toLowerCase().startsWith('youth')) {
    prefix = 'Youth';
    suffix = rawName.slice(5) || 'SMM';
  } else {
    const mid = Math.ceil(rawName.length / 2);
    prefix = rawName.slice(0, mid);
    suffix = rawName.slice(mid);
  }

  const isSuffixLight = theme === 'dark';

  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center space-x-2.5 select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      {/* ===================== LOGO EMBLEM (ICONIC YOUTHSMM RED CIRCLE WITH WHITE 'Y' & GOLD ORB) ===================== */}
      <motion.div
        className="relative flex items-center justify-center flex-shrink-0"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        transition={{ type: 'spring', stiffness: 400, damping: 20 }}
      >
        <div
          className={`${iconSizes[size]} relative rounded-full overflow-hidden shadow-md shadow-red-600/25 border border-white/20 flex items-center justify-center`}
        >
          {/* Exact Stylized Vector Logo matching favicon.svg */}
          <svg viewBox="0 0 100 100" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <linearGradient id="badgeRedGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FF3358" />
                <stop offset="45%" stopColor="#EF233C" />
                <stop offset="100%" stopColor="#C90025" />
              </linearGradient>

              <radialGradient id="goldenOrbGradient" cx="40%" cy="35%" r="65%">
                <stop offset="0%" stopColor="#FEF08A" />
                <stop offset="40%" stopColor="#FBBF24" />
                <stop offset="85%" stopColor="#F59E0B" />
                <stop offset="100%" stopColor="#D97706" />
              </radialGradient>

              <linearGradient id="sparkleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#FEF08A" />
                <stop offset="100%" stopColor="#F59E0B" />
              </linearGradient>
            </defs>

            {/* Badge Background Circle */}
            <circle cx="50" cy="50" r="49" fill="url(#badgeRedGradient)" />
            <circle cx="50" cy="50" r="47.5" stroke="#FFFFFF" strokeWidth="1.2" strokeOpacity="0.28" />

            {/* The White "Y" */}
            <line x1="27" y1="27" x2="50" y2="50" stroke="#FFFFFF" strokeWidth="13" strokeLinecap="round" />
            <line x1="73" y1="27" x2="50" y2="50" stroke="#FFFFFF" strokeWidth="13" strokeLinecap="round" />
            <line x1="50" y1="49" x2="50" y2="75" stroke="#FFFFFF" strokeWidth="13" strokeLinecap="round" />

            {/* Lower Stem Golden Light Node */}
            <circle cx="50" cy="74" r="4.8" fill="#FDE047" fillOpacity="0.9" />

            {/* Golden Center Orb */}
            <circle cx="50" cy="50" r="9.5" fill="url(#goldenOrbGradient)" />
            <circle cx="47.5" cy="47.5" r="2.5" fill="#FFFFFF" fillOpacity="0.7" />

            {/* Top-Right Golden Sparkle Accent */}
            <g transform="translate(80, 16)">
              <path d="M 0,-8 Q 0,0 -8,0 Q 0,0 0,8 Q 0,0 8,0 Q 0,0 0,-8 Z" fill="url(#sparkleGradient)" />
            </g>
          </svg>
        </div>
      </motion.div>

      {/* ===================== BRAND NAME: "Youth" (Navy/Stone) + "SMM" (Vibrant Red) ===================== */}
      {showText && (
        <div className="flex flex-col items-start leading-none">
          <div className="flex items-center tracking-tight">
            {/* "Youth" in bold dark stone/navy (or white in dark mode) */}
            <span
              className={`${textSizes[size]} font-black ${
                isSuffixLight ? 'text-white' : 'text-stone-900'
              } font-sans`}
            >
              {prefix}
            </span>

            {/* "SMM" in bold vibrant red */}
            <span
              className={`${textSizes[size]} font-black text-[#DC2626] font-sans ml-0.5`}
            >
              {suffix}
            </span>
          </div>

          {/* SMM PANEL Badge if specified */}
          {subtitle && (
            <div className="flex items-center space-x-1 mt-0.5">
              <span
                className={`${badgeSizes[size]} font-black uppercase tracking-wider text-red-600 bg-red-500/10 border border-red-500/20 rounded font-sans`}
              >
                {subtitle}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
