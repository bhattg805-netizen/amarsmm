import React, { useState, useMemo } from 'react';
import {
  Palette,
  Search,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Layers,
  Sparkles,
  Star,
  Heart,
  Video,
  Globe,
  RefreshCw,
  Filter,
  ArrowUpDown,
  CheckCircle,
  ExternalLink,
  ChevronDown,
  Shield,
  Tag,
  DollarSign
} from 'lucide-react';
import { Category, Service } from '../types.ts';
import {
  TikTokColorIcon,
  InstagramIcon,
  YouTubeIcon,
  TelegramIcon,
  FacebookIcon,
  SpotifyIcon,
  TwitterXIcon,
  WhatsAppIcon,
  SnapchatIcon,
  DiscordIcon,
  LinkedInIcon,
  ThreadsIcon,
  TwitchIcon,
} from './BrandIcons.tsx';
import { broadcastAdminChange } from '../lib/api';

interface CatalogManagerProps {
  token: string;
  categoriesList: (Category & { servicesCount?: number })[];
  servicesList: Service[];
  providersList: any[];
  onRefresh: () => Promise<void>;
  showSuccess: (msg: string) => void;
  showError: (msg: string) => void;
  isLight: boolean;
  cardBgClasses: string;
  subCardBg: string;
}

// 18 Preset Platform Icons matching Screenshot 1
const PRESET_ICONS = [
  { id: 'tiktok', name: 'TikTok', icon: TikTokColorIcon, color: '#000000' },
  { id: 'instagram', name: 'Instagram', icon: InstagramIcon, color: '#E1306C' },
  { id: 'youtube', name: 'YouTube', icon: YouTubeIcon, color: '#FF0000' },
  { id: 'telegram', name: 'Telegram', icon: TelegramIcon, color: '#0088CC' },
  { id: 'facebook', name: 'Facebook', icon: FacebookIcon, color: '#1877F2' },
  { id: 'spotify', name: 'Spotify', icon: SpotifyIcon, color: '#1DB954' },
  { id: 'twitter', name: 'Twitter (X)', icon: TwitterXIcon, color: '#000000' },
  { id: 'whatsapp', name: 'WhatsApp', icon: WhatsAppIcon, color: '#25D366' },
  { id: 'snapchat', name: 'Snapchat', icon: SnapchatIcon, color: '#FFFC00' },
  { id: 'discord', name: 'Discord', icon: DiscordIcon, color: '#5865F2' },
  { id: 'linkedin', name: 'LinkedIn', icon: LinkedInIcon, color: '#0A66C2' },
  { id: 'threads', name: 'Threads', icon: ThreadsIcon, color: '#000000' },
  { id: 'twitch', name: 'Twitch', icon: TwitchIcon, color: '#9146FF' },
  { id: 'website', name: 'Website ...', icon: Globe, color: '#3B82F6' },
  { id: 'vip', name: 'VIP / Pre...', icon: Sparkles, color: '#F59E0B' },
  { id: 'favorites', name: 'Favorites', icon: Star, color: '#EAB308' },
  { id: 'likes', name: 'Likes / E...', icon: Heart, color: '#EC4899' },
  { id: 'video', name: 'Video Se...', icon: Video, color: '#14B8A6' },
];

export const CatalogManager: React.FC<CatalogManagerProps> = ({
  token,
  categoriesList,
  servicesList,
  providersList,
  onRefresh,
  showSuccess,
  showError,
  isLight,
  cardBgClasses,
  subCardBg,
}) => {
  // Main Tab: 'categories' vs 'services'
  const [activeCatalogTab, setActiveCatalogTab] = useState<'categories' | 'services'>('categories');

  // Category Creation Form State (Screenshot 1)
  const [newCategoryName, setNewCategoryName] = useState('');
  const [selectedIconId, setSelectedIconId] = useState<string>('tiktok');
  const [customEmojiOrUrl, setCustomEmojiOrUrl] = useState('');
  const [isCreatingCategory, setIsCreatingCategory] = useState(false);

  // Category Management State (Screenshot 2)
  const [categorySearch, setCategorySearch] = useState('');
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<Set<number>>(new Set());
  const [editingCategory, setEditingCategory] = useState<(Category & { servicesCount?: number }) | null>(null);
  const [editCategoryName, setEditCategoryName] = useState('');
  const [editCategoryIcon, setEditCategoryIcon] = useState('');
  const [isUpdatingCategory, setIsUpdatingCategory] = useState(false);
  const [deleteConfirmCategory, setDeleteConfirmCategory] = useState<(Category & { servicesCount?: number }) | null>(null);

  // Services Tab State
  const [serviceSearch, setServiceSearch] = useState('');
  const [serviceCategoryFilter, setServiceCategoryFilter] = useState('all');
  const [isAddServiceModalOpen, setIsAddServiceModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [deleteConfirmService, setDeleteConfirmService] = useState<Service | null>(null);

  // Add / Edit Service Form
  const [srvName, setSrvName] = useState('');
  const [srvCategoryId, setSrvCategoryId] = useState<number>(categoriesList[0]?.id || 1);
  const [srvPrice, setSrvPrice] = useState('25.00');
  const [srvMin, setSrvMin] = useState('10');
  const [srvMax, setSrvMax] = useState('10000');
  const [srvDesc, setSrvDesc] = useState('');
  const [srvProviderId, setSrvProviderId] = useState<string>('');
  const [srvProviderServiceId, setSrvProviderServiceId] = useState<string>('');
  const [isSavingService, setIsSavingService] = useState(false);

  // Calculate actual services count per category
  const serviceCountMap = useMemo(() => {
    const map: Record<number, number> = {};
    servicesList.forEach((s) => {
      if (s.categoryId) {
        map[s.categoryId] = (map[s.categoryId] || 0) + 1;
      }
    });
    return map;
  }, [servicesList]);

  // Filter Categories by search
  const filteredCategories = useMemo(() => {
    return categoriesList.filter((cat) => {
      if (!categorySearch.trim()) return true;
      const q = categorySearch.toLowerCase().trim();
      return (
        cat.name.toLowerCase().includes(q) ||
        String(cat.id).includes(q) ||
        (cat.icon && cat.icon.toLowerCase().includes(q))
      );
    });
  }, [categoriesList, categorySearch]);

  // Select all categories logic
  const isAllSelected =
    filteredCategories.length > 0 &&
    filteredCategories.every((cat) => selectedCategoryIds.has(cat.id));

  const handleToggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedCategoryIds(new Set());
    } else {
      const next = new Set<number>();
      filteredCategories.forEach((cat) => next.add(cat.id));
      setSelectedCategoryIds(next);
    }
  };

  const handleToggleSelectCategory = (id: number) => {
    const next = new Set(selectedCategoryIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedCategoryIds(next);
  };

  // Helper to render Category Icon
  const renderCategoryIcon = (iconValue?: string | null, catName: string = '', sizeClasses = 'w-5 h-5') => {
    const raw = (iconValue || catName || '').toLowerCase().trim();

    // Check if URL
    if (iconValue && (iconValue.startsWith('http://') || iconValue.startsWith('https://'))) {
      return (
        <img
          src={iconValue}
          alt=""
          className={`${sizeClasses} object-contain rounded-md`}
          referrerPolicy="no-referrer"
        />
      );
    }

    // Check if single emoji
    if (iconValue && iconValue.trim().length <= 2) {
      return <span className="text-base select-none">{iconValue.trim()}</span>;
    }

    // Match preset icons
    if (raw.includes('tiktok')) return <TikTokColorIcon className={sizeClasses} />;
    if (raw.includes('instagram') || raw.includes('insta')) return <InstagramIcon className={sizeClasses} />;
    if (raw.includes('youtube')) return <YouTubeIcon className={sizeClasses} />;
    if (raw.includes('telegram')) return <TelegramIcon className={sizeClasses} />;
    if (raw.includes('facebook') || raw.includes('fb')) return <FacebookIcon className={sizeClasses} />;
    if (raw.includes('spotify')) return <SpotifyIcon className={sizeClasses} />;
    if (raw.includes('twitter') || raw === 'x' || raw.includes('twitter (x)')) return <TwitterXIcon className={sizeClasses} />;
    if (raw.includes('whatsapp')) return <WhatsAppIcon className={sizeClasses} />;
    if (raw.includes('snapchat')) return <SnapchatIcon className={sizeClasses} />;
    if (raw.includes('discord')) return <DiscordIcon className={sizeClasses} />;
    if (raw.includes('linkedin')) return <LinkedInIcon className={sizeClasses} />;
    if (raw.includes('threads')) return <ThreadsIcon className={sizeClasses} />;
    if (raw.includes('twitch')) return <TwitchIcon className={sizeClasses} />;
    if (raw.includes('website') || raw.includes('traffic') || raw.includes('web')) return <Globe className={`${sizeClasses} text-blue-500`} />;
    if (raw.includes('vip') || raw.includes('premium')) return <Sparkles className={`${sizeClasses} text-amber-500`} />;
    if (raw.includes('favorite') || raw.includes('star')) return <Star className={`${sizeClasses} text-yellow-500`} />;
    if (raw.includes('like') || raw.includes('heart')) return <Heart className={`${sizeClasses} text-pink-500`} />;
    if (raw.includes('video') || raw.includes('view')) return <Video className={`${sizeClasses} text-teal-500`} />;

    // Fallback default
    return <Layers className={`${sizeClasses} text-gray-400`} />;
  };

  // Submit Create Category (Screenshot 1)
  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) {
      showError('Please enter a Category Name.');
      return;
    }

    // Determine chosen icon
    const iconToSave = customEmojiOrUrl.trim() ? customEmojiOrUrl.trim() : selectedIconId;

    setIsCreatingCategory(true);
    try {
      const res = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: newCategoryName.trim(),
          icon: iconToSave,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        showSuccess(`Category "${newCategoryName}" created successfully!`);
        setNewCategoryName('');
        setCustomEmojiOrUrl('');
        await onRefresh();
        broadcastAdminChange();
      } else {
        showError(data.error || 'Failed to create category.');
      }
    } catch (err: any) {
      showError(`Error creating category: ${err.message || err}`);
    } finally {
      setIsCreatingCategory(false);
    }
  };

  // Submit Edit Category
  const handleSaveEditCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory || !editCategoryName.trim()) return;

    setIsUpdatingCategory(true);
    try {
      const res = await fetch(`/api/admin/categories/${editingCategory.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: editCategoryName.trim(),
          icon: editCategoryIcon.trim() || null,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        showSuccess(`Category #${editingCategory.id} updated!`);
        setEditingCategory(null);
        await onRefresh();
        broadcastAdminChange();
      } else {
        showError(data.error || 'Failed to update category.');
      }
    } catch (err: any) {
      showError(`Update error: ${err.message || err}`);
    } finally {
      setIsUpdatingCategory(false);
    }
  };

  // Delete Single Category
  const handleDeleteCategory = async () => {
    if (!deleteConfirmCategory) return;
    try {
      const res = await fetch(`/api/admin/categories/${deleteConfirmCategory.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        showSuccess(`Category "${deleteConfirmCategory.name}" deleted.`);
        setDeleteConfirmCategory(null);
        // remove from selected set
        const next = new Set(selectedCategoryIds);
        next.delete(deleteConfirmCategory.id);
        setSelectedCategoryIds(next);
        await onRefresh();
        broadcastAdminChange();
      } else {
        showError(data.error || 'Failed to delete category.');
      }
    } catch (err: any) {
      showError(`Delete error: ${err.message || err}`);
    }
  };

  // Bulk Delete Categories
  const handleBulkDeleteCategories = async () => {
    if (selectedCategoryIds.size === 0) return;
    if (!window.confirm(`Are you sure you want to delete ${selectedCategoryIds.size} selected categories?`)) {
      return;
    }

    try {
      const res = await fetch('/api/admin/categories/bulk-delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ ids: Array.from(selectedCategoryIds) }),
      });
      const data = await res.json();
      if (res.ok) {
        showSuccess(`Deleted ${data.count || selectedCategoryIds.size} categories.`);
        setSelectedCategoryIds(new Set());
        await onRefresh();
        broadcastAdminChange();
      } else {
        showError(data.error || 'Bulk delete failed.');
      }
    } catch (err: any) {
      showError(`Bulk delete failed: ${err.message || err}`);
    }
  };

  // Service Management Handlers
  const handleOpenAddService = () => {
    setSrvName('');
    setSrvCategoryId(categoriesList[0]?.id || 1);
    setSrvPrice('25.00');
    setSrvMin('10');
    setSrvMax('10000');
    setSrvDesc('');
    setSrvProviderId('');
    setSrvProviderServiceId('');
    setIsAddServiceModalOpen(true);
  };

  const handleOpenEditService = (s: Service) => {
    setEditingService(s);
    setSrvName(s.name);
    setSrvCategoryId(s.categoryId);
    setSrvPrice(String(s.pricePerThousand));
    setSrvMin(String(s.minAmount));
    setSrvMax(String(s.maxAmount));
    setSrvDesc(s.description || '');
    setSrvProviderId(s.providerId ? String(s.providerId) : '');
    setSrvProviderServiceId(s.providerServiceId || '');
  };

  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!srvName.trim() || !srvPrice || !srvCategoryId) {
      showError('Please fill in service name, category, and rate.');
      return;
    }

    setIsSavingService(true);
    try {
      const payload = {
        name: srvName.trim(),
        categoryId: Number(srvCategoryId),
        pricePerThousand: parseFloat(srvPrice) || 0,
        minAmount: parseInt(srvMin) || 10,
        maxAmount: parseInt(srvMax) || 10000,
        description: srvDesc.trim() || null,
        providerId: srvProviderId ? Number(srvProviderId) : null,
        providerServiceId: srvProviderServiceId.trim() || null,
      };

      if (editingService) {
        const res = await fetch(`/api/admin/services/${editingService.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          showSuccess(`Service #${editingService.id} updated.`);
          setEditingService(null);
          await onRefresh();
          broadcastAdminChange();
        } else {
          const d = await res.json();
          showError(d.error || 'Failed to update service.');
        }
      } else {
        const res = await fetch('/api/admin/services', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          showSuccess(`Service "${srvName}" added to catalog.`);
          setIsAddServiceModalOpen(false);
          await onRefresh();
          broadcastAdminChange();
        } else {
          const d = await res.json();
          showError(d.error || 'Failed to add service.');
        }
      }
    } catch (err: any) {
      showError(`Request failed: ${err.message || err}`);
    } finally {
      setIsSavingService(false);
    }
  };

  const handleDeleteService = async () => {
    if (!deleteConfirmService) return;
    try {
      const res = await fetch(`/api/admin/services/${deleteConfirmService.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        showSuccess(`Service #${deleteConfirmService.id} deleted.`);
        setDeleteConfirmService(null);
        await onRefresh();
        broadcastAdminChange();
      } else {
        const d = await res.json();
        showError(d.error || 'Failed to delete service.');
      }
    } catch (err: any) {
      showError(`Delete failed: ${err.message || err}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Catalog Manager Main Header & Navigation Switcher */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs ${cardBgClasses}`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-600/10 text-purple-600 flex items-center justify-center font-black">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
                <span>Catalog & Categories Manager</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-purple-500/10 text-purple-600 border border-purple-500/20">
                  {categoriesList.length} Categories · {servicesList.length} Services
                </span>
              </h2>
              <p className="text-xs text-gray-400">
                Create categories with custom platform icons, manage services, and configure wholesale rates.
              </p>
            </div>
          </div>

          {/* Tab Switcher Pills */}
          <div className="flex items-center space-x-2 bg-stone-100 dark:bg-slate-800 p-1.5 rounded-2xl border border-stone-200 dark:border-slate-700/60 self-start sm:self-auto">
            <button
              type="button"
              onClick={() => setActiveCatalogTab('categories')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center space-x-1.5 ${
                activeCatalogTab === 'categories'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-gray-600 dark:text-gray-300 hover:text-purple-600'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Manage Categories ({categoriesList.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveCatalogTab('services')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center space-x-1.5 ${
                activeCatalogTab === 'services'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-gray-600 dark:text-gray-300 hover:text-purple-600'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Services Catalog ({servicesList.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* ===================== TAB 1: CATEGORIES & ICONS (SCREENSHOT 1 & 2) ===================== */}
      {activeCatalogTab === 'categories' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* ===================== LEFT: + CREATE CATEGORY (SCREENSHOT 1) ===================== */}
          <div className="lg:col-span-5">
            <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-6 ${cardBgClasses}`}>
              {/* Header */}
              <div className="flex items-center space-x-2">
                <span className="text-purple-600 font-black text-xl leading-none">+</span>
                <h3 className="text-lg font-black tracking-tight text-gray-900 dark:text-white">
                  Create Category
                </h3>
              </div>

              <form onSubmit={handleCreateCategory} className="space-y-5">
                {/* 1. Category Name Input */}
                <div className="space-y-1.5">
                  <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
                    CATEGORY NAME
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="TikTok High retention"
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    className={`w-full px-4 py-3 rounded-2xl border text-sm font-semibold transition-all focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                      isLight
                        ? 'bg-white border-stone-200 text-gray-900 shadow-xs'
                        : 'bg-slate-800/80 border-slate-700 text-white'
                    }`}
                  />
                </div>

                {/* 2. Category Logo / Icon Grid (Screenshot 1) */}
                <div className="space-y-2.5">
                  <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 dark:text-gray-400">
                    CATEGORY LOGO / ICON
                  </label>

                  <div className="grid grid-cols-4 sm:grid-cols-4 gap-2">
                    {PRESET_ICONS.map((p) => {
                      const IconComp = p.icon;
                      const isSelected = selectedIconId === p.id && !customEmojiOrUrl.trim();

                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            setSelectedIconId(p.id);
                            setCustomEmojiOrUrl('');
                          }}
                          className={`p-2 sm:p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                            isSelected
                              ? 'border-purple-600 bg-purple-50/70 dark:bg-purple-950/30 ring-2 ring-purple-500/20 shadow-xs'
                              : isLight
                              ? 'border-stone-200/90 bg-white hover:bg-stone-50 text-gray-700'
                              : 'border-slate-700/80 bg-slate-800/60 hover:bg-slate-700 text-gray-300'
                          }`}
                        >
                          <div className="w-5 h-5 flex items-center justify-center">
                            <IconComp className="w-4 h-4" />
                          </div>
                          <span className="text-[10px] font-bold truncate max-w-[62px] text-center">
                            {p.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Or Custom Emoji / Image URL Input */}
                  <div className="pt-1">
                    <input
                      type="text"
                      placeholder="Or enter custom Emoji (e.g. 🔥) or Image URL"
                      value={customEmojiOrUrl}
                      onChange={(e) => setCustomEmojiOrUrl(e.target.value)}
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                        isLight
                          ? 'bg-stone-50 border-stone-200 text-gray-900'
                          : 'bg-slate-800/60 border-slate-700 text-white'
                      }`}
                    />
                  </div>
                </div>

                {/* 3. Big Purple Create Category Button (Screenshot 1) */}
                <button
                  type="submit"
                  disabled={isCreatingCategory}
                  className="w-full py-3.5 px-5 rounded-2xl bg-[#7C3AED] hover:bg-[#6D28D9] text-white font-black text-sm shadow-md shadow-purple-600/30 transition-all cursor-pointer flex items-center justify-center space-x-2"
                >
                  {isCreatingCategory ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Creating Category...</span>
                    </>
                  ) : (
                    <span>Create Category</span>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* ===================== RIGHT: MANAGE CATEGORIES (SCREENSHOT 2) ===================== */}
          <div className="lg:col-span-7">
            <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
              {/* Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <div className="w-7 h-7 rounded-xl bg-purple-500/10 text-purple-600 flex items-center justify-center font-bold">
                    <Palette className="w-4 h-4" />
                  </div>
                  <h3 className="text-lg sm:text-xl font-black text-gray-900 dark:text-white">
                    Manage Categories
                  </h3>
                  <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-stone-100 dark:bg-slate-800 text-gray-600 dark:text-gray-300 border border-stone-200 dark:border-slate-700">
                    {categoriesList.length} total
                  </span>
                </div>

                {selectedCategoryIds.size > 0 && (
                  <button
                    type="button"
                    onClick={handleBulkDeleteCategories}
                    className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center space-x-1.5 shadow-xs cursor-pointer transition-all animate-in fade-in"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Selected ({selectedCategoryIds.size})</span>
                  </button>
                )}
              </div>

              {/* Search Bar (Screenshot 2) */}
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search category by name or #ID"
                  value={categorySearch}
                  onChange={(e) => setCategorySearch(e.target.value)}
                  className={`w-full pl-10 pr-4 py-2.5 rounded-2xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                    isLight
                      ? 'bg-white border-stone-200 text-gray-900'
                      : 'bg-slate-800/80 border-slate-700 text-white'
                  }`}
                />
              </div>

              {/* Select All Checkbox */}
              <div className="flex items-center space-x-2.5 py-1 border-b border-stone-100 dark:border-slate-800 text-xs font-bold text-gray-600 dark:text-gray-300">
                <input
                  type="checkbox"
                  id="selectAllCategories"
                  checked={isAllSelected}
                  onChange={handleToggleSelectAll}
                  className="w-4 h-4 rounded-md text-purple-600 focus:ring-purple-500 cursor-pointer"
                />
                <label htmlFor="selectAllCategories" className="cursor-pointer select-none">
                  Select All
                </label>
              </div>

              {/* Categories Cards List (Screenshot 2) */}
              <div className="space-y-3 max-h-[620px] overflow-y-auto pr-1">
                {filteredCategories.length === 0 ? (
                  <div className="py-12 text-center text-xs text-gray-400">
                    No categories found matching "{categorySearch}".
                  </div>
                ) : (
                  filteredCategories.map((cat) => {
                    const isChecked = selectedCategoryIds.has(cat.id);
                    const count = serviceCountMap[cat.id] ?? cat.servicesCount ?? 0;

                    return (
                      <div
                        key={cat.id}
                        className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                          isChecked
                            ? 'border-purple-500/40 bg-purple-50/40 dark:bg-purple-950/20'
                            : isLight
                            ? 'border-stone-200/90 bg-white hover:border-purple-300'
                            : 'border-slate-800 bg-slate-900/60 hover:border-slate-700'
                        }`}
                      >
                        {/* Left: Checkbox + Icon in rounded box + Name & Service count */}
                        <div className="flex items-center space-x-3 min-w-0">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => handleToggleSelectCategory(cat.id)}
                            className="w-4 h-4 rounded-md text-purple-600 focus:ring-purple-500 cursor-pointer shrink-0"
                          />

                          {/* Icon Container (Screenshot 2: rounded box with border) */}
                          <div
                            className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${
                              isLight ? 'bg-stone-50 border-stone-200' : 'bg-slate-800 border-slate-700'
                            }`}
                          >
                            {renderCategoryIcon(cat.icon, cat.name, 'w-5 h-5')}
                          </div>

                          {/* Name & Count */}
                          <div className="min-w-0 truncate">
                            <span className="font-black text-sm text-gray-900 dark:text-white truncate block">
                              {cat.name}
                            </span>
                            <span className="text-[11px] font-semibold text-gray-400 block">
                              {count} {count === 1 ? 'service' : 'services'}
                            </span>
                          </div>
                        </div>

                        {/* Right Action Buttons (Screenshot 2: Edit & Delete) */}
                        <div className="flex items-center space-x-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingCategory(cat);
                              setEditCategoryName(cat.name);
                              setEditCategoryIcon(cat.icon || '');
                            }}
                            className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                              isLight
                                ? 'bg-white hover:bg-stone-50 border-stone-200 text-gray-700'
                                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-gray-200'
                            }`}
                          >
                            Edit
                          </button>

                          <button
                            type="button"
                            onClick={() => setDeleteConfirmCategory(cat)}
                            className="px-3 py-1.5 rounded-xl border border-red-200 dark:border-red-900/40 bg-red-50 hover:bg-red-100 dark:bg-red-950/30 text-red-600 dark:text-red-400 text-xs font-bold transition-all cursor-pointer"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================== TAB 2: SERVICES CATALOG ===================== */}
      {activeCatalogTab === 'services' && (
        <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-xl font-black flex items-center gap-2">
                <Layers className="w-5 h-5 text-purple-600" />
                <span>Services Catalog ({servicesList.length})</span>
              </h3>
              <p className="text-xs text-gray-400">
                Manage service pricing, min/max limits, descriptions, and automated upstream provider routing.
              </p>
            </div>

            <div className="flex items-center space-x-2.5">
              <button
                type="button"
                onClick={handleOpenAddService}
                className="px-4 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-black text-xs flex items-center space-x-1.5 shadow-md shadow-purple-600/20 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Service</span>
              </button>
            </div>
          </div>

          {/* Search & Category Filter */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <div className="sm:col-span-7 relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search services by name, ID, or description..."
                value={serviceSearch}
                onChange={(e) => setServiceSearch(e.target.value)}
                className={`w-full pl-9 pr-3 py-2.5 rounded-xl border text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div className="sm:col-span-5">
              <select
                value={serviceCategoryFilter}
                onChange={(e) => setServiceCategoryFilter(e.target.value)}
                className={`w-full px-3 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              >
                <option value="all">All Categories ({categoriesList.length})</option>
                {categoriesList.map((cat) => (
                  <option key={cat.id} value={String(cat.id)}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Services Table */}
          <div className="overflow-x-auto rounded-2xl border border-gray-100 dark:border-gray-800">
            <table className="w-full text-left text-xs whitespace-nowrap">
              <thead className={`font-mono text-[11px] font-bold ${subCardBg} text-gray-400`}>
                <tr>
                  <th className="py-3 px-4">ID</th>
                  <th className="py-3 px-4">Service Name</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4 text-purple-600">Rate / 1K</th>
                  <th className="py-3 px-4">Min / Max</th>
                  <th className="py-3 px-4">Provider Link</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {servicesList
                  .filter((s) => {
                    const matchQuery =
                      !serviceSearch ||
                      s.name.toLowerCase().includes(serviceSearch.toLowerCase()) ||
                      String(s.id).includes(serviceSearch);
                    const matchCat =
                      serviceCategoryFilter === 'all' || String(s.categoryId) === serviceCategoryFilter;
                    return matchQuery && matchCat;
                  })
                  .slice(0, 150)
                  .map((s) => {
                    const cat = categoriesList.find((c) => c.id === s.categoryId);
                    const prov = providersList.find((p) => p.id === s.providerId);

                    return (
                      <tr key={s.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/40">
                        <td className="py-3 px-4 font-mono font-bold text-gray-400">#{s.id}</td>
                        <td className="py-3 px-4 font-bold max-w-[280px] truncate">{s.name}</td>
                        <td className="py-3 px-4 text-gray-500 font-semibold truncate max-w-[150px]">
                          {cat?.name || `Cat #${s.categoryId}`}
                        </td>
                        <td className="py-3 px-4 font-mono font-black text-emerald-600">
                          ₹{Number(s.pricePerThousand).toFixed(2)}
                        </td>
                        <td className="py-3 px-4 font-mono text-gray-400">
                          {s.minAmount.toLocaleString()} - {s.maxAmount.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 font-mono text-gray-400">
                          {prov ? (
                            <span className="text-purple-600 font-bold">
                              {prov.name} (#{s.providerServiceId || 'Auto'})
                            </span>
                          ) : (
                            <span className="text-gray-400">Direct / Manual</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end space-x-1.5">
                            <button
                              type="button"
                              onClick={() => handleOpenEditService(s)}
                              className="p-1.5 rounded-lg border hover:bg-stone-100 dark:hover:bg-slate-700 text-gray-600 dark:text-gray-300 transition-colors"
                              title="Edit Service"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteConfirmService(s)}
                              className="p-1.5 rounded-lg border border-red-500/20 bg-red-500/10 hover:bg-red-500/20 text-red-600 transition-colors"
                              title="Delete Service"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================== MODAL: EDIT CATEGORY ===================== */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-lg rounded-3xl p-6 sm:p-7 border shadow-2xl space-y-5 animate-in fade-in zoom-in-95 ${
              isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-4">
              <div className="flex items-center space-x-2">
                <Edit2 className="w-5 h-5 text-purple-600" />
                <h3 className="font-black text-lg">Edit Category #{editingCategory.id}</h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingCategory(null)}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-gray-500 hover:text-gray-900 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEditCategory} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">Category Name</label>
                <input
                  type="text"
                  required
                  value={editCategoryName}
                  onChange={(e) => setEditCategoryName(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                    isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">
                  Category Icon (Platform Name, Emoji, or Image URL)
                </label>
                <input
                  type="text"
                  placeholder="e.g. instagram, tiktok, 🔥, or https://..."
                  value={editCategoryIcon}
                  onChange={(e) => setEditCategoryIcon(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                    isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              <div className="pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-end space-x-2.5">
                <button
                  type="button"
                  onClick={() => setEditingCategory(null)}
                  className="px-4 py-2.5 rounded-xl border text-xs font-bold hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUpdatingCategory}
                  className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-black shadow-md shadow-purple-600/20 transition-all flex items-center space-x-1.5"
                >
                  {isUpdatingCategory ? 'Updating...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================== MODAL: DELETE CATEGORY CONFIRMATION ===================== */}
      {deleteConfirmCategory && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-3xl p-6 border shadow-2xl space-y-4 animate-in fade-in zoom-in-95 ${
              isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 text-red-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-black text-lg">Delete Category?</h3>
              <p className="text-xs text-gray-400">
                Are you sure you want to delete <strong>{deleteConfirmCategory.name}</strong>? Any services inside will be unlinked safely.
              </p>
            </div>
            <div className="pt-2 flex items-center justify-center space-x-2.5">
              <button
                type="button"
                onClick={() => setDeleteConfirmCategory(null)}
                className="px-4 py-2.5 rounded-xl border text-xs font-bold hover:bg-gray-100 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteCategory}
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black shadow-md shadow-red-600/20"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================== MODAL: ADD / EDIT SERVICE ===================== */}
      {(isAddServiceModalOpen || editingService) && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-xl rounded-3xl p-6 sm:p-7 border shadow-2xl space-y-5 animate-in fade-in zoom-in-95 ${
              isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-4">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-600/10 text-purple-600 flex items-center justify-center font-bold">
                  {editingService ? <Edit2 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                </div>
                <div>
                  <h3 className="font-black text-lg">
                    {editingService ? `Edit Service #${editingService.id}` : 'Add New Service'}
                  </h3>
                  <p className="text-xs text-gray-400">Configure catalog details, pricing & upstream provider</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsAddServiceModalOpen(false);
                  setEditingService(null);
                }}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-gray-500 hover:text-gray-900 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveService} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">Service Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Instagram Followers [Non Drop] [Instant]"
                  value={srvName}
                  onChange={(e) => setSrvName(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                    isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1">Category *</label>
                  <select
                    value={srvCategoryId}
                    onChange={(e) => setSrvCategoryId(Number(e.target.value))}
                    className={`w-full px-3 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                      isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                    }`}
                  >
                    {categoriesList.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1">Rate per 1000 (₹) *</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={srvPrice}
                    onChange={(e) => setSrvPrice(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                      isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                    }`}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1">Minimum Order Qty</label>
                  <input
                    type="number"
                    value={srvMin}
                    onChange={(e) => setSrvMin(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                      isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1">Maximum Order Qty</label>
                  <input
                    type="number"
                    value={srvMax}
                    onChange={(e) => setSrvMax(e.target.value)}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                      isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                    }`}
                  />
                </div>
              </div>

              {/* Provider Integration Fields */}
              <div className="p-3.5 rounded-2xl border border-purple-500/20 bg-purple-50/20 dark:bg-purple-950/20 space-y-3">
                <span className="text-xs font-black text-purple-700 dark:text-purple-400 block">
                  Automated API Provider Routing (Optional)
                </span>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-gray-500 mb-1">API Provider</label>
                    <select
                      value={srvProviderId}
                      onChange={(e) => setSrvProviderId(e.target.value)}
                      className={`w-full px-3 py-2 rounded-xl border text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                        isLight ? 'bg-white border-stone-200' : 'bg-slate-800 border-slate-700'
                      }`}
                    >
                      <option value="">None (Manual / Direct)</option>
                      {providersList.map((p) => (
                        <option key={p.id} value={String(p.id)}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-gray-500 mb-1">Provider Service ID</label>
                    <input
                      type="text"
                      placeholder="e.g. 1420"
                      value={srvProviderServiceId}
                      onChange={(e) => setSrvProviderServiceId(e.target.value)}
                      className={`w-full px-3 py-2 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                        isLight ? 'bg-white border-stone-200' : 'bg-slate-800 border-slate-700'
                      }`}
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">Description / Instructions</label>
                <textarea
                  rows={2}
                  placeholder="Enter service details, link format, start speed..."
                  value={srvDesc}
                  onChange={(e) => setSrvDesc(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                    isLight ? 'bg-stone-50 border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              <div className="pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-end space-x-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddServiceModalOpen(false);
                    setEditingService(null);
                  }}
                  className="px-4 py-2.5 rounded-xl border text-xs font-bold hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingService}
                  className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-black shadow-md shadow-purple-600/20 transition-all flex items-center space-x-1.5"
                >
                  {isSavingService ? 'Saving...' : editingService ? 'Update Service' : 'Save Service'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================== MODAL: DELETE SERVICE CONFIRMATION ===================== */}
      {deleteConfirmService && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-3xl p-6 border shadow-2xl space-y-4 animate-in fade-in zoom-in-95 ${
              isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 text-red-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-black text-lg">Delete Service?</h3>
              <p className="text-xs text-gray-400">
                Are you sure you want to remove <strong>{deleteConfirmService.name}</strong> from catalog?
              </p>
            </div>
            <div className="pt-2 flex items-center justify-center space-x-2.5">
              <button
                type="button"
                onClick={() => setDeleteConfirmService(null)}
                className="px-4 py-2.5 rounded-xl border text-xs font-bold hover:bg-gray-100 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteService}
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black shadow-md shadow-red-600/20"
              >
                Yes, Delete Service
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
