import React, { useState, useEffect } from 'react';
import {
  RefreshCw,
  Clock,
  CheckCircle,
  AlertCircle,
  ShieldCheck,
  Search,
  ExternalLink,
  ChevronRight,
  Zap,
} from 'lucide-react';
import { Order } from '../types';

interface UserRefillsSectionProps {
  token: string;
  orders: Order[];
  isDarkMode: boolean;
  onRefreshOrders: () => void;
}

export const UserRefillsSection: React.FC<UserRefillsSectionProps> = ({
  token,
  orders,
  isDarkMode,
  onRefreshOrders,
}) => {
  const [refillRequests, setRefillRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [actionMsg, setActionMsg] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState<string>('');

  const fetchRefills = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/user/refill-requests?_t=${Date.now()}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json',
        },
      });
      if (res.ok) {
        const data = await res.json();
        setRefillRequests(Array.isArray(data) ? data : []);
      }
    } catch (err) {
      console.warn('Failed to fetch refill requests:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRefills();
  }, [token]);

  const handleRequestRefill = async (orderIdToRefill: number) => {
    setActionMsg(null);
    setActionError(null);
    setIsSubmitting(true);
    try {
      const res = await fetch(`/api/user/orders/${orderIdToRefill}/refill`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setActionMsg(`Refill request placed successfully for Order #${orderIdToRefill}!`);
        setSelectedOrderId('');
        fetchRefills();
        onRefreshOrders();
      } else {
        setActionError(data.error || 'Failed to submit refill request for this order.');
      }
    } catch (err) {
      setActionError('Network error requesting order refill.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const eligibleOrders = orders.filter((o) => o.status === 'completed' || o.status === 'in_progress');

  const filteredRequests = refillRequests.filter((r) => {
    const matchesFilter = filter === 'all' ? true : r.status === filter;
    const matchesSearch =
      !search.trim() ||
      String(r.orderId).includes(search) ||
      r.serviceName?.toLowerCase().includes(search.toLowerCase()) ||
      r.link?.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div
      className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-6 transition-colors ${
        isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
      }`}
    >
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#FF9900] flex items-center justify-center text-white shadow-xs">
              <RefreshCw className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span>Refill History</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-amber-500/10 text-amber-600 border border-amber-500/20">
              {refillRequests.length} Requests
            </span>
          </h2>
          <p className="text-xs text-stone-500 dark:text-gray-400 mt-1">
            Track drop protection refills and trigger non-drop replenishment guarantees on your completed orders.
          </p>
        </div>

        <button
          type="button"
          onClick={fetchRefills}
          disabled={loading}
          className="px-3.5 py-2 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] dark:bg-slate-800 text-xs font-bold flex items-center gap-1.5 hover:bg-[#EAE3D0] dark:hover:bg-slate-700 cursor-pointer self-start sm:self-auto text-stone-700 dark:text-gray-200"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-amber-500' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* Refill Guarantee Policy Banner */}
      <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs space-y-1.5">
        <div className="flex items-center gap-2 font-black text-amber-800 dark:text-amber-300">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span>30-Days Non-Drop Refill Guarantee</span>
        </div>
        <p className="text-amber-900 dark:text-amber-200 text-[11px] leading-relaxed">
          If your followers, likes, or views count drops below the initial delivered start count within the guarantee period, our automated server refills the deficit back to 100% within 1-24 hours free of charge.
        </p>
      </div>

      {/* Quick Request Refill Bar */}
      <div className="p-4 sm:p-5 rounded-2xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3]/50 dark:bg-slate-800/30 space-y-3">
        <span className="text-xs font-black uppercase tracking-wider text-stone-500 dark:text-gray-400 block">
          Request Refill on an Existing Order
        </span>

        {actionMsg && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 text-xs font-bold flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>{actionMsg}</span>
          </div>
        )}
        {actionError && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-600 text-xs font-bold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{actionError}</span>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-2">
          <select
            value={selectedOrderId}
            onChange={(e) => setSelectedOrderId(e.target.value)}
            className="flex-1 px-3.5 py-2.5 rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#FFFDF8] dark:bg-slate-900 text-xs font-bold text-stone-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
          >
            <option value="">-- Select Completed Order to Refill --</option>
            {eligibleOrders.map((o) => (
              <option key={o.id} value={o.id}>
                Order #{o.id} - {o.serviceName || `Service #${o.serviceId}`} ({o.quantity} qty)
              </option>
            ))}
          </select>

          <button
            type="button"
            disabled={!selectedOrderId || isSubmitting}
            onClick={() => handleRequestRefill(Number(selectedOrderId))}
            className="px-5 py-2.5 rounded-xl bg-[#FF9900] hover:bg-amber-600 text-white text-xs font-black shadow-md shadow-amber-500/20 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5 transition-all"
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Requesting...</span>
              </>
            ) : (
              <>
                <Zap className="w-3.5 h-3.5" />
                <span>Submit Refill Request</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1 border-t border-gray-100 dark:border-slate-800">
        <div className="flex items-center gap-1.5 flex-wrap">
          {['all', 'pending', 'completed', 'rejected'].map((st) => (
            <button
              key={st}
              onClick={() => setFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                filter === st
                  ? 'bg-[#FF9900] text-white shadow-xs'
                  : isDarkMode
                  ? 'bg-slate-800 text-gray-400 hover:text-white'
                  : 'bg-stone-100 text-gray-600 hover:text-gray-900'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-gray-400" />
          <input
            type="text"
            placeholder="Search by Order # or link..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] dark:bg-slate-900 text-stone-900 dark:text-white placeholder-stone-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
          />
        </div>
      </div>

      {/* Refills Table */}
      {filteredRequests.length === 0 ? (
        <div className="text-center py-14 border border-dashed border-stone-200 dark:border-slate-800 rounded-2xl text-xs text-gray-400 space-y-1">
          <RefreshCw className="w-8 h-8 mx-auto opacity-40 text-gray-400 mb-1" />
          <p className="font-bold">No refill requests found in this view.</p>
          <p className="text-[11px]">Select any eligible completed order above to submit a free refill guarantee.</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-stone-200 dark:border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 dark:bg-slate-800/80 text-gray-500 font-mono text-[11px] border-b border-stone-200 dark:border-slate-800 uppercase">
              <tr>
                <th className="py-3 px-4">Refill ID</th>
                <th className="py-3 px-4">Order ID</th>
                <th className="py-3 px-4">Service Name</th>
                <th className="py-3 px-4">Target Link</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Requested At</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filteredRequests.map((r) => {
                const statusColor =
                  r.status === 'completed'
                    ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
                    : r.status === 'rejected'
                    ? 'bg-rose-500/10 text-rose-600 border-rose-500/20'
                    : 'bg-amber-500/10 text-amber-600 border-amber-500/20';

                return (
                  <tr key={r.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-gray-400">#{r.id}</td>
                    <td className="py-3 px-4 font-mono font-bold text-amber-600 dark:text-amber-400">
                      #{r.orderId}
                    </td>
                    <td className="py-3 px-4 font-bold max-w-xs truncate">
                      {r.serviceName || `Service for Order #${r.orderId}`}
                    </td>
                    <td className="py-3 px-4 font-mono text-gray-500 max-w-xs truncate">
                      <a
                        href={r.link?.startsWith('http') ? r.link : `https://${r.link}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-red-500 hover:underline flex items-center gap-1"
                      >
                        <span className="truncate">{r.link}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border inline-block ${statusColor}`}>
                        {r.status || 'pending'}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-gray-500 text-[11px] text-right">
                      {r.createdAt ? new Date(r.createdAt).toLocaleString() : 'Recent'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
