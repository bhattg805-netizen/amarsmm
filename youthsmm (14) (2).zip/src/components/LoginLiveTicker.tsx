import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, Clock, Check } from 'lucide-react';
import {
  SpotifyIcon,
  InstagramIcon,
  YouTubeIcon,
  TikTokColorIcon,
  TelegramIcon,
  FacebookIcon,
  TwitterXIcon,
} from './BrandIcons';

export interface LiveFeedOrder {
  orderId: number;
  platform: 'spotify' | 'instagram' | 'youtube' | 'tiktok' | 'telegram' | 'facebook' | 'twitter';
  platformName: string;
  quantity: string;
  serviceName: string;
  speed: string;
  createdAt: number; // timestamp in ms
}

const BASE_ORDERS_DATA: Omit<LiveFeedOrder, 'orderId' | 'createdAt'>[] = [
  {
    platform: 'spotify',
    platformName: 'Spotify',
    quantity: '+10,000',
    serviceName: 'Spotify Premium Track Streams [Royalty Eligible]',
    speed: 'Safe Pace',
  },
  {
    platform: 'instagram',
    platformName: 'Instagram',
    quantity: '+2,500',
    serviceName: 'Instagram Followers [High Quality + Real] [30 Days Refill]',
    speed: 'Instant',
  },
  {
    platform: 'youtube',
    platformName: 'YouTube',
    quantity: '+5,000',
    serviceName: 'YouTube Monetizable Video Views [High Retention]',
    speed: '2,000/hr',
  },
  {
    platform: 'telegram',
    platformName: 'Telegram',
    quantity: '+1,500',
    serviceName: 'Telegram Channel Members [Non-Drop + Real]',
    speed: 'Instant',
  },
  {
    platform: 'tiktok',
    platformName: 'TikTok',
    quantity: '+25,000',
    serviceName: 'TikTok Viral FYP Video Views & High Retention',
    speed: 'High Speed',
  },
  {
    platform: 'instagram',
    platformName: 'Instagram',
    quantity: '+1,000',
    serviceName: 'Instagram Real Likes + Impressions [Explore Page]',
    speed: 'Instant',
  },
  {
    platform: 'youtube',
    platformName: 'YouTube',
    quantity: '+500',
    serviceName: 'YouTube Subscribers [Non-Drop + Monetizable]',
    speed: 'Gradual',
  },
  {
    platform: 'facebook',
    platformName: 'Facebook',
    quantity: '+2,000',
    serviceName: 'Facebook Page Likes & Real Followers',
    speed: 'Safe Pace',
  },
  {
    platform: 'spotify',
    platformName: 'Spotify',
    quantity: '+5,000',
    serviceName: 'Spotify Playlist Followers & Monthly Listeners',
    speed: 'Safe Pace',
  },
  {
    platform: 'twitter',
    platformName: 'Twitter (𝕏)',
    quantity: '+1,200',
    serviceName: 'Twitter (𝕏) Followers [Real Active Profiles]',
    speed: 'Instant',
  },
  {
    platform: 'tiktok',
    platformName: 'TikTok',
    quantity: '+50,000',
    serviceName: 'TikTok Video Views [Global Discovery]',
    speed: 'High Speed',
  },
  {
    platform: 'instagram',
    platformName: 'Instagram',
    quantity: '+10,000',
    serviceName: 'Instagram Reel Views + Reach [Algorithm Boost]',
    speed: 'Instant',
  },
];

interface LoginLiveTickerProps {
  onSelectCategory?: (category: string) => void;
}

export const LoginLiveTicker: React.FC<LoginLiveTickerProps> = ({ onSelectCategory }) => {
  // Base counter initialized to match #98426
  const [dataIndex, setDataIndex] = useState(0);
  const [orderNumber, setOrderNumber] = useState(98426);
  const [orderCreatedAt, setOrderCreatedAt] = useState<number>(() => Date.now() - 4000);
  const [timeText, setTimeText] = useState('just now');
  const [isPaused, setIsPaused] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<string | null>(null);

  // Filtered orders list based on selected network pill
  const activeOrders = selectedFilter
    ? BASE_ORDERS_DATA.filter((o) =>
        o.platformName.toLowerCase().includes(selectedFilter.toLowerCase()) ||
        o.platform.toLowerCase().includes(selectedFilter.toLowerCase())
      )
    : BASE_ORDERS_DATA;

  const effectiveOrders = activeOrders.length > 0 ? activeOrders : BASE_ORDERS_DATA;

  // Auto-advance orders every ~3.6s
  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setDataIndex((prev) => (prev + 1) % effectiveOrders.length);
      setOrderNumber((prev) => prev + 1);
      setOrderCreatedAt(Date.now());
      setTimeText('just now');
    }, 3600);

    return () => clearInterval(interval);
  }, [isPaused, effectiveOrders.length]);

  // Update elapsed time string every 1s
  useEffect(() => {
    const timeInterval = setInterval(() => {
      const diffSec = Math.floor((Date.now() - orderCreatedAt) / 1000);
      if (diffSec < 6) {
        setTimeText('just now');
      } else if (diffSec < 60) {
        setTimeText(`${diffSec}s ago`);
      } else {
        const diffMin = Math.floor(diffSec / 60);
        setTimeText(`${diffMin}m ago`);
      }
    }, 1000);

    return () => clearInterval(timeInterval);
  }, [orderCreatedAt]);

  const currentOrder = effectiveOrders[dataIndex % effectiveOrders.length] || BASE_ORDERS_DATA[0];

  // Helper to render platform badge matching screenshot styling
  const renderPlatformBadge = (platform: LiveFeedOrder['platform'], name: string) => {
    switch (platform) {
      case 'spotify':
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#1DB954]/10 text-[#1DB954] border border-[#1DB954]/20 flex items-center space-x-1 select-none">
            <SpotifyIcon className="w-3 h-3 shrink-0" />
            <span>Spotify</span>
          </span>
        );
      case 'instagram':
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#E1306C]/10 text-[#E1306C] border border-[#E1306C]/20 flex items-center space-x-1 select-none">
            <InstagramIcon className="w-3 h-3 shrink-0" />
            <span>Instagram</span>
          </span>
        );
      case 'youtube':
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#FF0000]/10 text-[#FF0000] border border-[#FF0000]/20 flex items-center space-x-1 select-none">
            <YouTubeIcon className="w-3 h-3 shrink-0" />
            <span>YouTube</span>
          </span>
        );
      case 'tiktok':
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-black/10 text-stone-900 border border-black/20 flex items-center space-x-1 select-none">
            <TikTokColorIcon className="w-3 h-3 shrink-0" />
            <span>TikTok</span>
          </span>
        );
      case 'telegram':
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#229ED9]/10 text-[#229ED9] border border-[#229ED9]/20 flex items-center space-x-1 select-none">
            <TelegramIcon className="w-3 h-3 shrink-0" />
            <span>Telegram</span>
          </span>
        );
      case 'facebook':
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#1877F2]/10 text-[#1877F2] border border-[#1877F2]/20 flex items-center space-x-1 select-none">
            <FacebookIcon className="w-3 h-3 shrink-0" />
            <span>Facebook</span>
          </span>
        );
      case 'twitter':
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-stone-900/10 text-stone-900 border border-stone-900/20 flex items-center space-x-1 select-none">
            <TwitterXIcon className="w-3 h-3 shrink-0" />
            <span>Twitter (𝕏)</span>
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-stone-100 text-stone-800">
            {name}
          </span>
        );
    }
  };

  return (
    <div
      className="bg-[#FFFDF8] border border-[#EAE3D2] rounded-3xl p-5 sm:p-6 shadow-[0_4px_25px_-6px_rgba(150,130,90,0.08)] space-y-4"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* 1. Header with live pulsing dot & 'Server Automated' badge */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="text-[11px] font-black uppercase tracking-wider text-gray-800 select-none">
            LIVE ORDER FEED
          </span>
        </div>
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center space-x-1 select-none">
          <Check className="w-3 h-3 text-emerald-500" />
          <span>Server Automated</span>
        </span>
      </div>

      {/* 2. Animated Ticker Box matching user's uploaded image exactly */}
      <div className="p-3.5 rounded-2xl bg-[#F4EFE3]/80 border border-[#E5DAC4] relative overflow-hidden min-h-[96px] sm:min-h-[82px] flex items-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={orderNumber}
            initial={{ opacity: 0, y: 8, scale: 0.99 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.99 }}
            transition={{ duration: 0.28, ease: 'easeOut' }}
            className="w-full flex flex-col sm:flex-row sm:items-center justify-between gap-3"
          >
            {/* Left: Red Zap in rounded square + order info */}
            <div className="flex items-start sm:items-center space-x-3 min-w-0">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-red-500/10 text-red-600 flex items-center justify-center shrink-0 mt-0.5 sm:mt-0 shadow-2xs">
                <Zap className="w-4 h-4 sm:w-5 sm:h-5 fill-red-600" />
              </div>
              <div className="min-w-0 flex-1 space-y-1">
                {/* Top line: #ID  Platform  +Quantity */}
                <div className="flex items-center flex-wrap gap-1.5 sm:gap-2">
                  <span className="font-mono font-bold text-xs text-stone-900">
                    #{orderNumber}
                  </span>
                  {renderPlatformBadge(currentOrder.platform, currentOrder.platformName)}
                  <span className="font-mono font-black text-xs text-[#DC2626]">
                    {currentOrder.quantity}
                  </span>
                </div>
                {/* Service description */}
                <p className="text-xs font-semibold text-stone-700 leading-snug line-clamp-1 sm:line-clamp-none">
                  {currentOrder.serviceName}
                </p>
              </div>
            </div>

            {/* Right: Time ago + Speed badge */}
            <div className="flex items-center space-x-2 self-start sm:self-auto text-stone-400 text-[11px] shrink-0 pl-12 sm:pl-0">
              <div className="flex items-center space-x-1 font-medium">
                <Clock className="w-3 h-3 text-stone-400 shrink-0" />
                <span className="font-mono text-stone-500">{timeText}</span>
              </div>
              <span className="px-2 py-0.5 rounded-md bg-[#EDE6D6] text-stone-700 text-[10px] font-bold select-none border border-[#E0D7C4]/50">
                {currentOrder.speed}
              </span>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* 3. TOP NETWORKS ROW */}
      <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
        <span className="font-black text-[10px] uppercase tracking-wider text-stone-400 mr-1 select-none">
          TOP NETWORKS:
        </span>
        {['Instagram', 'YouTube', 'TikTok', 'Telegram', 'Facebook'].map((net) => {
          const isSelected = selectedFilter === net;
          return (
            <button
              key={net}
              type="button"
              onClick={() => {
                if (selectedFilter === net) {
                  setSelectedFilter(null);
                } else {
                  setSelectedFilter(net);
                }
                setDataIndex(0);
                setOrderCreatedAt(Date.now());
                setTimeText('just now');
                if (onSelectCategory) {
                  onSelectCategory(net);
                }
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer select-none active:scale-[0.98] ${
                isSelected
                  ? 'bg-[#DC2626] text-white shadow-xs font-bold'
                  : 'bg-[#EDE6D6] hover:bg-[#E3D9C3] text-stone-800'
              }`}
            >
              {net}
            </button>
          );
        })}
        {selectedFilter && (
          <button
            type="button"
            onClick={() => {
              setSelectedFilter(null);
              setDataIndex(0);
              setOrderCreatedAt(Date.now());
              setTimeText('just now');
            }}
            className="text-[11px] font-bold text-stone-400 hover:text-stone-700 underline cursor-pointer ml-1 select-none"
          >
            Show All
          </button>
        )}
      </div>
    </div>
  );
};
