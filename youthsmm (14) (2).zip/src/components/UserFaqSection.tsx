import React, { useState } from 'react';
import {
  HelpCircle,
  Search,
  ChevronDown,
  ChevronUp,
  MessageSquare,
  Send,
  Zap,
  ShieldCheck,
  Wallet,
  Globe,
} from 'lucide-react';

interface UserFaqSectionProps {
  isDarkMode: boolean;
  publicSettings: any;
  onSwitchToTickets: () => void;
}

export const UserFaqSection: React.FC<UserFaqSectionProps> = ({
  isDarkMode,
  publicSettings,
  onSwitchToTickets,
}) => {
  const [search, setSearch] = useState('');
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const defaultFaqs = [
    {
      q: 'What is an SMM Panel and how does YouthSMM work?',
      a: 'An SMM (Social Media Marketing) panel is an online wholesale marketplace where you can purchase social media marketing services like followers, likes, comments, watch time, and views at factory prices. When you place an order with your link, our automated high-speed servers dispatch it directly to upstream API providers within seconds.',
      tag: 'General',
    },
    {
      q: 'How do I add funds using BharatPe UPI, PhonePe, or Google Pay?',
      a: 'Go to the "Add Funds" tab, select BharatPe / All UPI. Scan the dynamic QR code using your UPI app (PhonePe, GPay, Paytm, BHIM), pay the desired amount, and copy the 12-digit UTR / Reference Number from your bank transaction screen. Paste the UTR into the verification box and click "Verify & Credit". Your wallet balance is automatically credited in under 5 seconds with zero transaction fees.',
      tag: 'Payments',
    },
    {
      q: 'How long does it take for my order to start delivering?',
      a: 'Most high-speed services (Instagram Likes, Telegram Members, YouTube Views) start instantly within 0 to 5 minutes after submission. Larger packages or non-drop refill guaranteed services gradually deliver over several hours to simulate natural organic growth and protect your profile integrity.',
      tag: 'Orders',
    },
    {
      q: 'What is a Non-Drop Refill Guarantee and how do I request it?',
      a: 'Services marked with "Refill" come with an automated 30 to 60-day replacement warranty. If followers or views drop below your initial start count, head over to the "Refill History" tab or click "Request Refill" on your completed order. Our system will automatically top up the missing quantity back to 100% free of charge.',
      tag: 'Refills',
    },
    {
      q: 'Can I rent a Child Panel to sell services under my own brand?',
      a: 'Yes! Open the "Child Panels" tab to order your white-label reseller panel. You can connect your own custom domain (e.g. yourbrand.com), set your own retail prices, and keep 100% of the profits. All orders placed on your child panel route through our wholesale API automatically.',
      tag: 'Child Panels',
    },
    {
      q: 'Can I connect my own website or Telegram bot via API?',
      a: 'Absolutely. We support the industry-standard SMM Reseller API v2. Go to the "Api" tab to copy your unique API key and view documentation with copy-paste code snippets for cURL, Python, PHP, and Node.js.',
      tag: 'API',
    },
    {
      q: 'Can I cancel or modify an order after placing it?',
      a: 'Once an order is submitted to the automated delivery pipeline, it cannot be edited. However, if you accidentally provided a broken or private link, the order will automatically cancel or fail, and the charged funds will immediately return to your account balance.',
      tag: 'Orders',
    },
  ];

  const adminFaqContent = publicSettings?.faqContent;
  let parsedAdminFaqs: { q: string; a: string; tag: string }[] = [];

  if (adminFaqContent && typeof adminFaqContent === 'string' && adminFaqContent.trim().length > 0) {
    try {
      const parts = adminFaqContent.split(/\n\n+/);
      parsedAdminFaqs = parts
        .map((p) => {
          const lines = p.split('\n');
          const qLine = lines[0]?.replace(/^Q:\s*/i, '').replace(/^\d+[\.\)]\s*/, '').trim();
          const aLine = lines.slice(1).join('\n').replace(/^A:\s*/i, '').trim();
          if (qLine && aLine) {
            return { q: qLine, a: aLine, tag: 'Official FAQ' };
          }
          return null;
        })
        .filter(Boolean) as any[];
    } catch (_) {}
  }

  const allFaqs = parsedAdminFaqs.length > 0 ? [...parsedAdminFaqs, ...defaultFaqs] : defaultFaqs;

  const filteredFaqs = allFaqs.filter(
    (f) =>
      !search.trim() ||
      f.q.toLowerCase().includes(search.toLowerCase()) ||
      f.a.toLowerCase().includes(search.toLowerCase()) ||
      f.tag.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div
      className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-7 transition-colors ${
        isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
      }`}
    >
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#2196F3] flex items-center justify-center text-white shadow-xs">
              <HelpCircle className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span>Frequently Asked Questions</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-blue-500/10 text-blue-600 border border-blue-500/20">
              Help Center
            </span>
          </h2>
          <p className="text-xs text-stone-500 dark:text-gray-400 mt-1">
            Instant answers to the most common questions about orders, payments, speed, refills, and reseller tools.
          </p>
        </div>

        <div className="relative w-full sm:w-64 self-start sm:self-auto">
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
          <input
            type="text"
            placeholder="Search questions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] dark:bg-slate-900 text-stone-900 dark:text-white placeholder-stone-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Accordion List */}
      <div className="space-y-3">
        {filteredFaqs.map((faq, index) => {
          const isOpen = openIndex === index;
          return (
            <div
              key={index}
              className={`rounded-2xl border transition-all ${
                isOpen
                  ? 'border-blue-500/40 bg-blue-500/5 shadow-xs'
                  : isDarkMode
                  ? 'bg-slate-800/40 border-slate-800'
                  : 'bg-[#F4EFE3]/50 border-[#DDD3BC] hover:bg-[#F4EFE3]'
              }`}
            >
              <button
                type="button"
                onClick={() => setOpenIndex(isOpen ? null : index)}
                className="w-full p-4 sm:p-5 flex items-center justify-between text-left cursor-pointer gap-3"
              >
                <div className="flex items-center gap-3">
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-black/5 dark:bg-white/10 text-stone-500 shrink-0">
                    {faq.tag}
                  </span>
                  <span className="text-sm font-bold text-stone-900 dark:text-white leading-snug">
                    {faq.q}
                  </span>
                </div>
                <div className="text-stone-400 shrink-0">
                  {isOpen ? <ChevronUp className="w-4 h-4 text-blue-500" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </button>

              {isOpen && (
                <div className="px-4 pb-4 sm:px-5 sm:pb-5 text-xs text-stone-600 dark:text-gray-300 leading-relaxed border-t border-blue-500/10 pt-3 animate-in fade-in">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Still need help callout */}
      <div className="p-5 sm:p-6 rounded-2xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3]/60 dark:bg-slate-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h4 className="text-sm font-black text-stone-900 dark:text-white">Still have questions or need custom assistance?</h4>
          <p className="text-xs text-stone-500 dark:text-gray-400 mt-0.5">
            Our 24x7 customer support team is available to assist you with any questions.
          </p>
        </div>

        <button
          type="button"
          onClick={onSwitchToTickets}
          className="px-5 py-2.5 rounded-xl bg-[#DC2626] hover:bg-red-700 text-white text-xs font-black shadow-md shadow-red-500/20 cursor-pointer self-start sm:self-auto flex items-center gap-1.5 transition-all"
        >
          <MessageSquare className="w-4 h-4" />
          <span>Open Support Ticket</span>
        </button>
      </div>
    </div>
  );
};
