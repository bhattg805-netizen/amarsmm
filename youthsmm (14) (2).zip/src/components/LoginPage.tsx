import React, { useState, useEffect } from 'react';
import {
  Eye,
  EyeOff,
  Lock,
  Mail,
  User as UserIcon,
  ArrowRight,
  Zap,
  Check,
  Star,
  Send,
  Headphones,
  Menu,
  X,
  Search,
  ExternalLink,
  ChevronDown,
  AlertCircle,
  CheckCircle2,
  Clock,
  Sparkles,
  Shield,
  Layers,
  HelpCircle,
  FileText
} from 'lucide-react';
import { User, Service } from '../types.ts';
import { LoginStatsSection } from './LoginStatsSection.tsx';
import { LoginPlatformMarquee } from './LoginPlatformMarquee.tsx';
import { LoginLiveTicker } from './LoginLiveTicker.tsx';
import { LoginFaqSection } from './LoginFaqSection.tsx';
import { LoginFooter } from './LoginFooter.tsx';
import { LoginModals } from './LoginModals.tsx';
import { AnimatedLogo } from './AnimatedLogo.tsx';
import {
  SpotifyIcon,
  InstagramIcon,
  YouTubeIcon,
  TikTokColorIcon,
  TelegramIcon,
  FacebookIcon,
  TwitterXIcon,
  WhatsAppIcon,
  SnapchatIcon,
  DiscordIcon,
  LinkedInIcon,
  TwitchIcon,
} from './BrandIcons.tsx';

interface LoginPageProps {
  onLoginSuccess: (token: string, user: User) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  // Auth Form State
  const [authMode, setAuthMode] = useState<'signin' | 'register'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Modals state
  const [showServicesModal, setShowServicesModal] = useState(false);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const [showBlogModal, setShowBlogModal] = useState(false);
  const [showApiModal, setShowApiModal] = useState(false);
  const [showChildPanelsModal, setShowChildPanelsModal] = useState(false);
  const [showAffiliatesModal, setShowAffiliatesModal] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [showForgotPasswordModal, setShowForgotPasswordModal] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Services catalog preview state
  const [servicesList, setServicesList] = useState<Service[]>([]);
  const [servicesSearch, setServicesSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Load public services
  useEffect(() => {
    fetch('/api/services/public')
      .then((r) => r.ok && r.json())
      .then((d) => Array.isArray(d) && setServicesList(d))
      .catch(() => {});
  }, []);

  // Form submit handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const isRegister = authMode === 'register';
    const endpoint = isRegister ? '/api/auth/register' : '/api/auth/login';
    const payload = isRegister ? { email, password, name } : { email, password };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (res.ok && data.token) {
        localStorage.setItem('youthsmm_token', data.token);
        onLoginSuccess(data.token, data.user);
      } else {
        setError(data.error || 'Authentication failed. Please check your credentials.');
      }
    } catch (err: any) {
      setError(err.message || 'Network connection failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Quick Instant Demo Login
  const handleQuickLogin = (token: string) => {
    localStorage.setItem('youthsmm_token', token);
    fetch('/api/auth/me', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.user) {
          onLoginSuccess(token, data.user);
        }
      })
      .catch((err) => console.error('Quick login error:', err));
  };

  // Google OAuth redirect
  const handleGoogleSignIn = () => {
    window.location.href = '/api/auth/google';
  };

  // Scroll to FAQ
  const handleScrollToFaq = () => {
    const el = document.getElementById('faq-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#F8F4EA] text-stone-900 font-sans flex flex-col selection:bg-red-500 selection:text-white relative overflow-x-hidden">
      {/* ===================== FLOATING NAVBAR (SCREENSHOT 1) ===================== */}
      <header className="w-full max-w-7xl mx-auto px-5 sm:px-6 lg:px-8 pt-3 sm:pt-6 pb-2 z-40">
        <div className="bg-[#FFFDF8]/95 backdrop-blur-md border border-[#EAE3D2] rounded-2xl sm:rounded-3xl px-3.5 sm:px-7 py-2.5 sm:py-3 shadow-[0_4px_20px_-4px_rgba(150,130,90,0.08)] flex items-center justify-between gap-2">
          {/* Animated Logo (Matching custom emblem & branding) */}
          <AnimatedLogo
            size="md"
            showText={true}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          />

          {/* Right Action Buttons: Services Pill, Telegram Pill, Hamburger Menu */}
          <div className="flex items-center space-x-1.5 sm:space-x-2.5 shrink-0">
            {/* Services Button with Red Eye Icon */}
            <button
              type="button"
              onClick={() => setShowServicesModal(true)}
              className="px-3 sm:px-4 py-1.5 sm:py-2 rounded-full border border-[#E5DAC4] bg-[#F7F2E7] hover:bg-[#EFE8D8] text-xs font-bold text-stone-800 flex items-center space-x-1.5 shadow-xs transition-all cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5 text-red-600 shrink-0" />
              <span>Services</span>
            </button>

            {/* Telegram Button with Cyan Paper Airplane */}
            <a
              href="https://t.me/securesmmtursted"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-full border border-[#E5DAC4] bg-[#F7F2E7] hover:bg-[#EFE8D8] text-xs font-bold text-stone-800 flex items-center space-x-1.5 shadow-xs transition-all cursor-pointer hidden sm:flex"
            >
              <Send className="w-3.5 h-3.5 text-[#0088CC]" />
              <span>Telegram</span>
            </a>

            {/* Hamburger Menu Button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl border border-[#E5DAC4] bg-[#F7F2E7] hover:bg-[#EFE8D8] flex items-center justify-center text-stone-700 transition-all cursor-pointer"
              aria-label="Navigation Menu"
            >
              <Menu className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu if hamburger opened */}
        {mobileMenuOpen && (
          <div className="mt-2 p-4 rounded-2xl bg-[#FFFDF8] border border-[#EAE3D2] shadow-xl space-y-2 animate-in fade-in slide-in-from-top-2 sm:hidden">
            <button
              type="button"
              onClick={() => { setShowServicesModal(true); setMobileMenuOpen(false); }}
              className="w-full text-left py-2 px-3 rounded-xl hover:bg-[#F4EFE3] text-xs font-bold text-stone-800 flex items-center justify-between"
            >
              <span>Browse All Services</span>
              <ArrowRight className="w-3.5 h-3.5 text-stone-400" />
            </button>
            <button
              type="button"
              onClick={() => { handleScrollToFaq(); setMobileMenuOpen(false); }}
              className="w-full text-left py-2 px-3 rounded-xl hover:bg-[#F4EFE3] text-xs font-bold text-stone-800 flex items-center justify-between"
            >
              <span>Frequently Asked Questions</span>
              <ArrowRight className="w-3.5 h-3.5 text-stone-400" />
            </button>
            <button
              type="button"
              onClick={() => { setShowApiModal(true); setMobileMenuOpen(false); }}
              className="w-full text-left py-2 px-3 rounded-xl hover:bg-[#F4EFE3] text-xs font-bold text-stone-800 flex items-center justify-between"
            >
              <span>API Documentation</span>
              <ArrowRight className="w-3.5 h-3.5 text-stone-400" />
            </button>
            <button
              type="button"
              onClick={() => { setShowChildPanelsModal(true); setMobileMenuOpen(false); }}
              className="w-full text-left py-2 px-3 rounded-xl hover:bg-[#F4EFE3] text-xs font-bold text-stone-800 flex items-center justify-between"
            >
              <span>Rent a Child Panel</span>
              <ArrowRight className="w-3.5 h-3.5 text-stone-400" />
            </button>
          </div>
        )}
      </header>

      {/* ===================== HERO & AUTH SECTION ===================== */}
      <main className="w-full max-w-7xl mx-auto px-5 sm:px-6 lg:px-8 py-5 sm:py-8 lg:py-12 flex-1 box-border">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* ===================== 1. HERO CONTENT (ABOVE LOGIN CARD ON MOBILE) ===================== */}
          <div className="order-1 lg:order-none lg:col-span-7 lg:row-start-1 space-y-4 sm:space-y-6 pt-1 sm:pt-2">
            {/* 1. MAIN SMM PROVIDER badge at the top */}
            <div>
              <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-red-500/10 text-red-600 border border-red-500/20 text-xs font-black tracking-wider uppercase select-none">
                <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></span>
                <span>MAIN SMM PROVIDER</span>
              </div>
            </div>

            {/* 2 & 3. "Grow Smarter With YouthSMM" heading & "Powerful Social Media Solutions" red heading */}
            <div className="space-y-1 sm:space-y-2">
              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-gray-900 leading-[1.12] break-words">
                Grow Smarter With YouthSMM
              </h1>
              <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-[#DC2626] leading-[1.12] break-words">
                Powerful Social Media Solutions
              </h2>
            </div>

            {/* 4. Existing description text */}
            <p className="text-sm sm:text-base text-gray-600 leading-relaxed max-w-xl">
              Access fast, affordable and easy-to-use social media marketing services for Instagram, YouTube, Facebook, TikTok and more — all from one powerful dashboard.
            </p>

            {/* 5. Create Account and Browse All Services buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-3.5 pt-1 sm:pt-2">
              <button
                type="button"
                onClick={() => {
                  setAuthMode('register');
                  const authCard = document.getElementById('auth-card');
                  if (authCard) {
                    authCard.scrollIntoView({ behavior: 'smooth' });
                  } else {
                    window.scrollTo({ top: 120, behavior: 'smooth' });
                  }
                }}
                className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-[#DC2626] hover:bg-[#B91C1C] text-white font-black text-sm flex items-center justify-center space-x-2 shadow-lg shadow-red-600/30 transition-all cursor-pointer select-none active:scale-[0.98]"
              >
                <UserIcon className="w-4 h-4" />
                <span>Create Account</span>
              </button>

              <button
                type="button"
                onClick={() => setShowServicesModal(true)}
                className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-[#FFFDF8] hover:bg-[#F3EDE0] border border-[#EAE3D2] text-gray-800 font-bold text-sm flex items-center justify-center space-x-2 shadow-xs transition-all cursor-pointer select-none active:scale-[0.98]"
              >
                <span>Browse all services</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* ===================== 2. LOGIN / REGISTER CARD (BELOW HERO SECTION ON MOBILE) ===================== */}
          <div
            id="auth-card"
            className="order-2 lg:order-none lg:col-span-5 lg:col-start-8 lg:row-start-1 lg:row-span-2 space-y-4 w-full max-w-md sm:max-w-lg lg:max-w-none mx-auto box-border"
          >
            <div className="bg-[#FFFDF8] border border-[#EAE3D2] rounded-3xl p-5 sm:p-7 md:p-8 shadow-[0_12px_40px_-10px_rgba(150,130,90,0.12)] space-y-4 sm:space-y-5 w-full box-border">
              {/* Segmented Switcher Tabs: [Sign in] vs [Register] */}
              <div className="p-1.5 rounded-2xl bg-[#F2EBDC] border border-[#E5DAC4] flex items-center w-full box-border">
                <button
                  type="button"
                  onClick={() => { setAuthMode('signin'); setError(null); }}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer select-none ${
                    authMode === 'signin'
                      ? 'bg-[#DC2626] text-white shadow-md shadow-red-600/25'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Sign in
                </button>
                <button
                  type="button"
                  onClick={() => { setAuthMode('register'); setError(null); }}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer select-none ${
                    authMode === 'register'
                      ? 'bg-[#DC2626] text-white shadow-md shadow-red-600/25'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Register
                </button>
              </div>

              {/* Title & Subtitle */}
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">
                  {authMode === 'signin' ? 'Welcome back' : 'Create your account'}
                </h3>
                <p className="text-xs text-stone-500 mt-1">
                  {authMode === 'signin'
                    ? 'Sign in to manage your orders'
                    : 'Get started in 30 seconds to access wholesale rates'}
                </p>
              </div>

              {error && (
                <div className="p-3.5 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-600 text-xs font-bold flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                {authMode === 'register' && (
                  <div>
                    <label className="block text-[11px] font-black uppercase tracking-wider text-stone-600 mb-1.5">
                      FULL NAME
                    </label>
                    <div className="relative">
                      <UserIcon className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                      <input
                        type="text"
                        required
                        placeholder="John Doe"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 rounded-2xl bg-[#F5F0E4] border border-[#DDD3BC] text-xs font-semibold text-stone-900 placeholder-stone-400 focus:bg-[#FFFDF9] focus:outline-hidden focus:ring-2 focus:ring-[#DC2626]/20 focus:border-[#C4B79B] transition-all box-border"
                      />
                    </div>
                  </div>
                )}

                {/* USERNAME OR EMAIL INPUT WITH CREAM BG */}
                <div>
                  <label className="block text-[11px] font-black uppercase tracking-wider text-stone-600 mb-1.5">
                    USERNAME OR EMAIL
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      required
                      placeholder="Enter username or email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 rounded-2xl bg-[#F5F0E4] border border-[#DDD3BC] text-xs font-semibold text-stone-900 placeholder-stone-400 focus:bg-[#FFFDF9] focus:outline-hidden focus:ring-2 focus:ring-[#DC2626]/20 focus:border-[#C4B79B] transition-all font-sans box-border"
                    />
                  </div>
                </div>

                {/* PASSWORD INPUT WITH CREAM BG & EYE TOGGLE */}
                <div>
                  <label className="block text-[11px] font-black uppercase tracking-wider text-stone-600 mb-1.5">
                    PASSWORD
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="••••••••••••••••••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-10 py-3 rounded-2xl bg-[#F5F0E4] border border-[#DDD3BC] text-xs font-semibold text-stone-900 placeholder-stone-400 focus:bg-[#FFFDF9] focus:outline-hidden focus:ring-2 focus:ring-[#DC2626]/20 focus:border-[#C4B79B] transition-all box-border"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-stone-700 cursor-pointer"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Remember me Checkbox */}
                <div className="flex items-center space-x-2 pt-0.5">
                  <input
                    type="checkbox"
                    id="rememberMeCheckbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded text-red-600 focus:ring-red-500 cursor-pointer"
                  />
                  <label htmlFor="rememberMeCheckbox" className="text-xs text-stone-600 font-medium cursor-pointer select-none">
                    Remember me
                  </label>
                </div>

                {/* Submit Button: Solid Red [→] Sign in] (Screenshot 1) */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 px-4 rounded-2xl bg-[#DC2626] hover:bg-[#B91C1C] text-white font-black text-sm shadow-md shadow-red-600/25 transition-all cursor-pointer flex items-center justify-center space-x-2 select-none active:scale-[0.99] disabled:opacity-70"
                >
                  <ArrowRight className="w-4 h-4" />
                  <span>{loading ? 'Please wait...' : authMode === 'signin' ? 'Sign in' : 'Create Account'}</span>
                </button>
              </form>

              {/* Divider 'or' */}
              <div className="relative flex items-center justify-center pt-1">
                <div className="border-t border-[#EAE3D2] w-full"></div>
                <span className="bg-[#FFFDF8] px-3 text-xs text-stone-400 font-semibold uppercase absolute select-none">
                  or
                </span>
              </div>

              {/* Google OAuth Button */}
              <button
                type="button"
                onClick={handleGoogleSignIn}
                className="w-full py-3 px-4 rounded-2xl bg-[#FFFDF8] hover:bg-[#F5F0E4] border border-[#DDD3BC] text-stone-800 font-bold text-xs flex items-center justify-center space-x-2 shadow-xs transition-all cursor-pointer select-none active:scale-[0.99]"
              >
                {/* Colorful Google SVG */}
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>

              {/* Links: Forgot password? · Create account */}
              <div className="text-center text-xs font-semibold text-stone-500 pt-1 flex items-center justify-center flex-wrap gap-x-2 gap-y-1">
                <button
                  type="button"
                  onClick={() => setShowForgotPasswordModal(true)}
                  className="text-red-600 hover:text-red-700 underline cursor-pointer"
                >
                  Forgot password?
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => setAuthMode(authMode === 'signin' ? 'register' : 'signin')}
                  className="text-red-600 hover:text-red-700 underline cursor-pointer"
                >
                  {authMode === 'signin' ? 'Create account' : 'Already have an account?'}
                </button>
              </div>

              {/* Quick Demo Login (Helpful for fast admin / test access) */}
              <div className="pt-2 border-t border-[#EAE3D2] flex items-center justify-center flex-wrap gap-2 text-[11px] text-stone-400">
                <span>Instant Demo:</span>
                <button
                  type="button"
                  onClick={() => handleQuickLogin('sandbox-admin-token')}
                  className="text-red-600 font-bold hover:underline cursor-pointer"
                >
                  Admin Panel
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => handleQuickLogin('sandbox-user-token')}
                  className="text-stone-700 font-bold hover:underline cursor-pointer"
                >
                  User Panel
                </button>
              </div>
            </div>

            {/* ===================== TRUSTPILOT RATING BAR (SCREENSHOT 2) ===================== */}
            <div className="text-center space-y-1.5 pt-2">
              <div className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full bg-[#FFFDF8] border border-[#EAE3D2] shadow-xs text-xs font-bold select-none">
                <div className="flex text-emerald-500">
                  {'★★★★★'.split('').map((s, i) => (
                    <span key={i} className="text-emerald-500 text-sm leading-none">★</span>
                  ))}
                </div>
                <span className="text-stone-900 font-black">4.8</span>
                <span className="text-emerald-600 font-bold">★ Trustpilot</span>
              </div>
              <p className="text-xs text-stone-500">
                Trusted by <strong className="text-stone-800">thousands of resellers</strong> · <strong className="text-stone-800">2,487</strong> services · <strong className="text-stone-800">24/7</strong> support
              </p>
            </div>
          </div>

          {/* ===================== 3. LIVE ORDER FEED CARD ===================== */}
          <div className="order-3 lg:order-none lg:col-span-7 lg:col-start-1 lg:row-start-2 w-full pt-1 sm:pt-4">
            <LoginLiveTicker
              onSelectCategory={(net) => {
                setSelectedCategory(net);
              }}
            />
          </div>

        </div>

        {/* ===================== STATS COUNTER CARD (SCREENSHOT 2) ===================== */}
        <div className="mt-12 sm:mt-16">
          <LoginStatsSection />
        </div>

        {/* ===================== PLATFORM CHIPS MARQUEE (SCREENSHOT 2) ===================== */}
        <div className="mt-8 sm:mt-12">
          <LoginPlatformMarquee />
        </div>

        {/* ===================== FAQ ACCORDION SECTION (SCREENSHOT 3) ===================== */}
        <div className="mt-16 sm:mt-24">
          <LoginFaqSection />
        </div>
      </main>

      {/* ===================== FOOTER (SCREENSHOT 4) ===================== */}
      <LoginFooter
        websiteName="YouthSMM"
        onOpenCategory={(cat) => {
          setSelectedCategory(cat);
        }}
        onOpenAboutUs={() => setShowAboutModal(true)}
        onOpenBlog={() => setShowBlogModal(true)}
        onOpenApi={() => setShowApiModal(true)}
        onOpenChildPanels={() => setShowChildPanelsModal(true)}
        onOpenAffiliates={() => setShowAffiliatesModal(true)}
        onOpenTerms={() => setShowTermsModal(true)}
        onOpenPrivacy={() => setShowPrivacyModal(true)}
        onOpenSupport={() => setShowSupportModal(true)}
        onOpenContact={() => setShowContactModal(true)}
        onScrollToFaq={handleScrollToFaq}
      />

      {/* ===================== LOGIN MODALS (SERVICES, ABOUT, API, ETC.) ===================== */}
      <LoginModals
        showAboutModal={showAboutModal}
        setShowAboutModal={setShowAboutModal}
        showBlogModal={showBlogModal}
        setShowBlogModal={setShowBlogModal}
        showApiModal={showApiModal}
        setShowApiModal={setShowApiModal}
        showChildPanelsModal={showChildPanelsModal}
        setShowChildPanelsModal={setShowChildPanelsModal}
        showAffiliatesModal={showAffiliatesModal}
        setShowAffiliatesModal={setShowAffiliatesModal}
        showTermsModal={showTermsModal}
        setShowTermsModal={setShowTermsModal}
        showPrivacyModal={showPrivacyModal}
        setShowPrivacyModal={setShowPrivacyModal}
        showContactModal={showContactModal}
        setShowContactModal={setShowContactModal}
        showSupportModal={showSupportModal}
        setShowSupportModal={setShowSupportModal}
        websiteName="YouthSMM"
        onSelectAuthMode={(m) => {
          setAuthMode(m);
          window.scrollTo({ top: 120, behavior: 'smooth' });
        }}
      />

      {/* ===================== PUBLIC SERVICES BROWSER MODAL ===================== */}
      {showServicesModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
          <div className="w-full max-w-5xl max-h-[90vh] rounded-3xl bg-[#FFFDF8] border border-[#EAE3D2] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
            <div className="p-5 sm:p-6 border-b border-[#EAE3D2] flex items-center justify-between">
              <div>
                <h3 className="text-xl font-black text-stone-900">Services Catalog</h3>
                <p className="text-xs text-stone-500">Live wholesale social media marketing services</p>
              </div>
              <button
                type="button"
                onClick={() => setShowServicesModal(false)}
                className="w-8 h-8 rounded-full bg-[#F4EFE3] flex items-center justify-center text-stone-500 hover:text-stone-900 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 border-b border-[#EAE3D2] bg-[#FAF6EE] flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search service by name or ID..."
                  value={servicesSearch}
                  onChange={(e) => setServicesSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-[#DDD3BC] text-xs bg-[#FFFDF8] text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-red-500"
                />
              </div>

              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 py-2 rounded-xl border border-[#DDD3BC] text-xs font-bold bg-[#FFFDF8] text-stone-900"
              >
                <option value="All">All Platforms</option>
                <option value="Instagram">Instagram</option>
                <option value="YouTube">YouTube</option>
                <option value="TikTok">TikTok</option>
                <option value="Telegram">Telegram</option>
                <option value="Facebook">Facebook</option>
                <option value="Spotify">Spotify</option>
                <option value="Twitter">Twitter (X)</option>
              </select>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6">
              <div className="overflow-x-auto rounded-2xl border border-[#EAE3D2]">
                <table className="w-full text-left text-xs whitespace-nowrap">
                  <thead className="font-mono text-[11px] font-bold bg-[#F4EFE3] text-stone-500 sticky top-0">
                    <tr>
                      <th className="py-2.5 px-3">ID</th>
                      <th className="py-2.5 px-4">Service Name</th>
                      <th className="py-2.5 px-3">Rate / 1K</th>
                      <th className="py-2.5 px-3">Min / Max</th>
                      <th className="py-2.5 px-3">Speed</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EAE3D2]">
                    {servicesList
                      .filter((s) => {
                        const matchQ = !servicesSearch || s.name.toLowerCase().includes(servicesSearch.toLowerCase()) || String(s.id).includes(servicesSearch);
                        const matchC = selectedCategory === 'All' || (s.categoryName && s.categoryName.toLowerCase().includes(selectedCategory.toLowerCase()));
                        return matchQ && matchC;
                      })
                      .slice(0, 100)
                      .map((s) => (
                        <tr key={s.id} className="hover:bg-[#FAF6EE]">
                          <td className="py-2.5 px-3 font-mono font-bold text-stone-400">#{s.id}</td>
                          <td className="py-2.5 px-4 font-semibold text-stone-800 max-w-[320px] truncate">{s.name}</td>
                          <td className="py-2.5 px-3 font-mono font-black text-emerald-600">₹{Number(s.pricePerThousand).toFixed(2)}</td>
                          <td className="py-2.5 px-3 font-mono text-stone-500">{s.minAmount.toLocaleString()} - {s.maxAmount.toLocaleString()}</td>
                          <td className="py-2.5 px-3 font-semibold text-stone-600">Instant Automated</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Forgot Password Modal */}
      {showForgotPasswordModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#FFFDF8] border border-[#EAE3D2] p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-black text-stone-900">Reset Password</h3>
              <button
                type="button"
                onClick={() => setShowForgotPasswordModal(false)}
                className="w-8 h-8 rounded-full bg-[#F4EFE3] flex items-center justify-center text-stone-500 hover:text-stone-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-stone-500 leading-relaxed">
              Enter your registered email address and we'll send you an instant password reset link.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                alert('Password reset link sent to your registered email address!');
                setShowForgotPasswordModal(false);
              }}
              className="space-y-3"
            >
              <input
                type="email"
                required
                placeholder="name@example.com"
                className="w-full px-4 py-2.5 rounded-xl border border-[#DDD3BC] bg-[#F5F0E4] text-xs font-semibold text-stone-900 focus:outline-hidden focus:ring-2 focus:ring-red-500"
              />
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs shadow-md shadow-red-600/20"
              >
                Send Reset Link
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
