import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Calendar,
  User,
  ArrowRight,
  Search,
  Sparkles,
  Bell,
  RefreshCw,
  X,
  Tag,
} from 'lucide-react';

interface UserBlogsSectionProps {
  isDarkMode: boolean;
  announcementsList: any[];
  publicSettings: any;
}

export const UserBlogsSection: React.FC<UserBlogsSectionProps> = ({
  isDarkMode,
  announcementsList,
  publicSettings,
}) => {
  const [blogs, setBlogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedArticle, setSelectedArticle] = useState<any | null>(null);

  const defaultArticles = [
    {
      id: 'news-1',
      title: 'Instagram Algorithm 2026: Why High-Retention Views & Reels Saves Matter',
      content:
        'Instagram has revamped its Explore recommendation engine to heavily prioritize initial engagement velocity within the first 30 minutes of publishing. Buying high-retention views combined with genuine saves triggers the AI algorithm to feature your post across trending hashtags and explore pages.\n\nOur specialized Instagram Reels VIP services guarantee authentic-paced delivery that perfectly matches organic discovery curves without triggering spam flags.',
      category: 'Instagram Guide',
      createdAt: new Date().toISOString(),
      authorName: 'YouthSMM Tech Team',
    },
    {
      id: 'news-2',
      title: 'YouTube Subscribers & Watch Hours Speed Boost: Instant Monetization Readiness',
      content:
        'Reaching 1,000 subscribers and 4,000 watch hours has never been easier. We have upgraded all YouTube Watchtime servers to stream from tier-1 residential networks with zero drop guarantees.\n\nEnjoy automated refill protection for 60 full days. Start turning your passion into passive income with YouTube Partner Program monetization.',
      category: 'YouTube Growth',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
      authorName: 'Admin Desk',
    },
    {
      id: 'news-3',
      title: 'Automated BharatPe UPI Settlements Now Live 24/7 with Zero Transaction Fees',
      content:
        'We have fully integrated instant automated BharatPe UPI QR code settlements. Simply scan the dynamic QR with PhonePe, Google Pay, or Paytm, enter the 12-digit UTR transaction reference number, and your panel balance will credit in under 3 seconds.\n\nNo manual screenshot verification required, round-the-clock deposits enabled.',
      category: 'Platform Update',
      createdAt: new Date(Date.now() - 172800000).toISOString(),
      authorName: 'Operations',
    },
  ];

  const fetchBlogs = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/blogs?_t=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          setBlogs(data);
          return;
        }
      }
      setBlogs(defaultArticles);
    } catch (err) {
      setBlogs(defaultArticles);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  const combinedItems = [
    ...(announcementsList || []).map((a) => ({
      id: `ann-${a.id}`,
      title: a.title || 'Platform Announcement',
      content: a.message || a.content,
      category: 'Official Notice',
      createdAt: a.createdAt,
      authorName: 'Admin',
      isPinned: true,
    })),
    ...blogs,
  ];

  const filteredItems = combinedItems.filter(
    (item) =>
      !search.trim() ||
      item.title?.toLowerCase().includes(search.toLowerCase()) ||
      item.content?.toLowerCase().includes(search.toLowerCase()) ||
      item.category?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div
      className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-7 transition-colors ${
        isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
      }`}
    >
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#E91E63] flex items-center justify-center text-white shadow-xs">
              <BookOpen className="w-5 h-5" />
            </div>
            <span>Blogs & News</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-pink-500/10 text-pink-600 border border-pink-500/20">
              Latest Updates
            </span>
          </h2>
          <p className="text-xs text-stone-500 dark:text-gray-400 mt-1">
            Stay informed with platform notices, SMM growth marketing strategies, algorithm news, and exclusive promotional offers.
          </p>
        </div>

        <div className="relative w-full sm:w-64 self-start sm:self-auto">
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
          <input
            type="text"
            placeholder="Search news & guides..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3] dark:bg-slate-900 text-stone-900 dark:text-white placeholder-stone-400 focus:outline-hidden focus:ring-2 focus:ring-pink-500"
          />
        </div>
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredItems.map((article) => {
          const isAnnouncement = article.isPinned;
          return (
            <div
              key={article.id}
              className={`p-5 rounded-2xl border transition-all flex flex-col justify-between space-y-4 hover:shadow-md ${
                isAnnouncement
                  ? 'border-amber-500/30 bg-amber-500/5'
                  : isDarkMode
                  ? 'bg-slate-800/40 border-slate-800 hover:border-slate-700'
                  : 'bg-stone-50/70 border-stone-200/80 hover:border-stone-300'
              }`}
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      isAnnouncement
                        ? 'bg-amber-500 text-white'
                        : 'bg-pink-500/10 text-pink-600 border border-pink-500/20'
                    }`}
                  >
                    {isAnnouncement ? '★ Notice' : article.category || 'Article'}
                  </span>

                  <span className="text-[10px] font-mono text-gray-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    <span>{article.createdAt ? new Date(article.createdAt).toLocaleDateString() : 'Today'}</span>
                  </span>
                </div>

                <h3 className="font-black text-sm text-gray-900 dark:text-white line-clamp-2 leading-snug">
                  {article.title}
                </h3>

                <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-3 leading-relaxed">
                  {article.content}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedArticle(article)}
                className="pt-2 border-t border-gray-200/60 dark:border-slate-800/80 flex items-center justify-between text-xs font-black text-[#E91E63] hover:underline cursor-pointer"
              >
                <span>Read Full Article</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Reader Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-xl rounded-3xl p-6 sm:p-7 shadow-2xl border space-y-4 animate-in fade-in zoom-in-95 max-h-[85vh] overflow-y-auto ${
              isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-[#FFFDF8] border-[#EAE3D2] text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-gray-100 dark:border-slate-800">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-pink-500/10 text-pink-600 border border-pink-500/20">
                {selectedArticle.category || 'News Article'}
              </span>
              <button
                type="button"
                onClick={() => setSelectedArticle(null)}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1">
              <h3 className="text-lg font-black tracking-tight leading-snug">{selectedArticle.title}</h3>
              <div className="text-[11px] font-mono text-gray-400 flex items-center gap-3">
                <span>By {selectedArticle.authorName || 'YouthSMM Editorial'}</span>
                <span>•</span>
                <span>{selectedArticle.createdAt ? new Date(selectedArticle.createdAt).toLocaleDateString() : 'Recent'}</span>
              </div>
            </div>

            <div className="pt-2 text-xs leading-relaxed text-gray-600 dark:text-gray-300 space-y-3 whitespace-pre-line border-t border-gray-100 dark:border-slate-800">
              {selectedArticle.content}
            </div>

            <button
              type="button"
              onClick={() => setSelectedArticle(null)}
              className="w-full py-2.5 rounded-xl bg-stone-100 dark:bg-slate-800 hover:bg-stone-200 dark:hover:bg-slate-700 text-xs font-bold cursor-pointer transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
