import React, { useState, useRef, useEffect, useId } from 'react';
import { ChevronDown, Check, Layers } from 'lucide-react';
import { ServiceCategoryIcon } from './ServiceCategoryIcon';
import type { Category } from '../types';

interface CategoryDropdownProps {
  categories: Category[];
  allCategories?: Category[];
  selectedCategory: number | 'all';
  onSelectCategory: (categoryId: number | 'all') => void;
  isDarkMode?: boolean;
  disabled?: boolean;
}

export const CategoryDropdown: React.FC<CategoryDropdownProps> = ({
  categories,
  allCategories,
  selectedCategory,
  onSelectCategory,
  isDarkMode = false,
  disabled = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState<number>(-1);

  const containerRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const listboxId = useId();

  // Find currently selected category object
  const lookupCategories = allCategories && allCategories.length > 0 ? allCategories : categories;
  const currentCategory =
    selectedCategory === 'all'
      ? null
      : lookupCategories.find((c) => c.id === selectedCategory) || null;

  // Close dropdown when clicking outside
  useEffect(() => {
    if (!isOpen) return;

    const handlePointerDownOutside = (e: MouseEvent | TouchEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handlePointerDownOutside);
    document.addEventListener('touchstart', handlePointerDownOutside);

    return () => {
      document.removeEventListener('mousedown', handlePointerDownOutside);
      document.removeEventListener('touchstart', handlePointerDownOutside);
    };
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) {
      setHighlightedIndex(-1);
    }
  }, [isOpen]);

  // Handle keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (disabled) return;

    if (!isOpen) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        setIsOpen(true);
      }
      return;
    }

    // Dropdown is open:
    if (e.key === 'Escape') {
      e.preventDefault();
      setIsOpen(false);
      triggerRef.current?.focus();
      return;
    }

    if (e.key === 'Tab') {
      setIsOpen(false);
      return;
    }

    // Number of navigable rows: "All Categories" option (index 0) + categories items
    const totalItems = 1 + categories.length;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightedIndex((prev) => {
        const next = prev < totalItems - 1 ? prev + 1 : 0;
        scrollIndexIntoView(next);
        return next;
      });
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightedIndex((prev) => {
        const next = prev > 0 ? prev - 1 : totalItems - 1;
        scrollIndexIntoView(next);
        return next;
      });
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (highlightedIndex === 0) {
        onSelectCategory('all');
        setIsOpen(false);
        triggerRef.current?.focus();
      } else if (highlightedIndex > 0 && highlightedIndex - 1 < categories.length) {
        onSelectCategory(categories[highlightedIndex - 1].id);
        setIsOpen(false);
        triggerRef.current?.focus();
      }
    }
  };

  const scrollIndexIntoView = (index: number) => {
    if (!listRef.current) return;
    const items = listRef.current.querySelectorAll('[data-category-item]');
    const target = items[index] as HTMLElement;
    if (target) {
      target.scrollIntoView({ block: 'nearest' });
    }
  };

  const handleSelect = (categoryId: number | 'all') => {
    onSelectCategory(categoryId);
    setIsOpen(false);
    triggerRef.current?.focus();
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full max-w-full"
      onKeyDown={handleKeyDown}
    >
      {/* TRIGGER BUTTON (ROUNDED CORNERS, HIGHLIGHTED BORDER WHEN ACTIVE, RED/BLUE ACCENTS) */}
      <button
        ref={triggerRef}
        type="button"
        disabled={disabled}
        onClick={() => !disabled && setIsOpen((prev) => !prev)}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        aria-controls={listboxId}
        className={`w-full box-border rounded-2xl px-4 py-3 sm:py-3.5 min-h-[44px] flex items-center justify-between gap-2.5 text-left transition-all duration-150 select-none cursor-pointer outline-none ${
          disabled ? 'opacity-50 cursor-not-allowed' : ''
        } ${
          isOpen
            ? 'ring-2 ring-red-500/30 border-[#DC2626] shadow-sm'
            : isDarkMode
            ? 'hover:border-slate-600 focus:ring-2 focus:ring-red-500/30'
            : 'hover:border-[#DDD3BC] focus:ring-2 focus:ring-red-500/30'
        } ${
          isDarkMode
            ? 'bg-slate-800/90 border-slate-700 text-white'
            : 'bg-[#F4EFE3] border-[#DDD3BC] text-stone-900'
        }`}
      >
        {/* Left: Selected Category Icon + Label */}
        <div className="flex items-center gap-3 min-w-0 pr-1 flex-1">
          <div className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0">
            {currentCategory ? (
              <ServiceCategoryIcon
                name={currentCategory.name}
                icon={currentCategory.icon}
                size="sm"
                animated={true}
              />
            ) : (
              <Layers className="w-3.5 h-3.5 text-stone-600 dark:text-stone-300" />
            )}
          </div>

          <span
            className={`truncate block ${
              currentCategory
                ? 'font-bold text-stone-900 dark:text-white'
                : 'text-stone-600 dark:text-stone-400 font-semibold'
            }`}
          >
            {currentCategory ? (
              currentCategory.name
            ) : (
              <span>Select a Category ({categories.length} available)</span>
            )}
          </span>
        </div>

        {/* Right: Sleek Indicator Button */}
        <div className="flex items-center gap-1.5 shrink-0 ml-1">
          <div
            className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all ${
              isOpen
                ? 'bg-[#DC2626] text-white rotate-180 shadow-xs'
                : 'bg-blue-600 text-white'
            }`}
          >
            <ChevronDown className="w-4 h-4 stroke-[2.5]" />
          </div>
        </div>
      </button>

      {/* DROPDOWN PANEL (ANCHORED, INTERNAL SCROLL, COMPACT VIEWPORT-AWARE MAX HEIGHT - NO SEARCH BOX) */}
      {isOpen && (
        <div
          id={listboxId}
          role="listbox"
          aria-label="Categories"
          className={`absolute left-0 right-0 top-full mt-1.5 z-50 w-full max-w-full box-border rounded-2xl border shadow-xl flex flex-col overflow-hidden transition-all duration-150 max-h-[min(280px,40vh)] sm:max-h-[min(360px,45vh)] ${
            isDarkMode
              ? 'bg-slate-900 border-slate-700/90 text-white shadow-black/50'
              : 'bg-[#FFFDF8] border-[#DDD3BC] text-stone-900 shadow-stone-900/10'
          }`}
        >
          {/* INTERNAL SCROLLABLE LIST (TOUCH-FRIENDLY ROWS, INDEPENDENT SCROLL) */}
          <div
            ref={listRef}
            className="overflow-y-auto overscroll-contain flex-1 divide-y divide-stone-100 dark:divide-slate-800/60 p-1"
            style={{
              WebkitOverflowScrolling: 'touch',
            }}
          >
            {/* OPTION 0: ALL CATEGORIES / RESET */}
            <div
              data-category-item
              role="option"
              aria-selected={selectedCategory === 'all'}
              onClick={() => handleSelect('all')}
              className={`min-h-[44px] px-3.5 py-2.5 rounded-xl flex items-center justify-between gap-3 text-xs font-semibold cursor-pointer transition-colors select-none ${
                selectedCategory === 'all'
                  ? 'bg-red-500/10 text-[#DC2626] font-bold border-l-4 border-l-[#DC2626] pl-2.5'
                  : isDarkMode
                  ? 'hover:bg-slate-800/80 text-gray-300'
                  : 'hover:bg-[#F4EFE3]/80 text-stone-700'
              } ${
                highlightedIndex === 0
                  ? isDarkMode
                    ? 'bg-slate-800'
                    : 'bg-[#F4EFE3]'
                  : ''
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-6 h-6 rounded-lg bg-stone-200/50 dark:bg-slate-800 flex items-center justify-center shrink-0 pointer-events-none"
                  aria-hidden="true"
                >
                  <Layers className="w-3.5 h-3.5 text-stone-500 dark:text-stone-400" />
                </div>
                <span className="truncate">
                  Select a Category ({categories.length} available)
                </span>
              </div>
              {selectedCategory === 'all' && (
                <Check className="w-4 h-4 text-[#DC2626] shrink-0" />
              )}
            </div>

            {/* CATEGORY ROWS WITH BRAND PLATFORM ICONS */}
            {categories.map((cat, idx) => {
              const isSelected = selectedCategory === cat.id;
              const isHighlighted = highlightedIndex === idx + 1;

              return (
                <div
                  key={cat.id}
                  data-category-item
                  role="option"
                  aria-selected={isSelected}
                  title={cat.name}
                  onClick={() => handleSelect(cat.id)}
                  onMouseEnter={() => setHighlightedIndex(idx + 1)}
                  className={`min-h-[44px] px-3.5 py-2.5 rounded-xl flex items-center justify-between gap-3 text-xs cursor-pointer transition-colors select-none ${
                    isSelected
                      ? 'bg-red-500/10 text-[#DC2626] dark:text-red-400 font-bold border-l-4 border-l-[#DC2626] pl-2.5'
                      : isDarkMode
                      ? 'text-gray-200 hover:bg-slate-800/90 font-medium'
                      : 'text-stone-800 hover:bg-[#F4EFE3]/80 font-medium'
                  } ${
                    isHighlighted
                      ? isDarkMode
                        ? 'bg-slate-800'
                        : 'bg-[#F4EFE3]'
                      : ''
                  }`}
                >
                  {/* Platform Icon & Category Name */}
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {/* Consistent Platform Icon Container */}
                    <div
                      className="w-6 h-6 rounded-lg bg-stone-200/50 dark:bg-slate-800 flex items-center justify-center shrink-0 pointer-events-none"
                      aria-hidden="true"
                    >
                      <ServiceCategoryIcon
                        name={cat.name}
                        icon={cat.icon}
                        size="sm"
                        animated={false}
                      />
                    </div>

                    {/* Category Title - Truncated cleanly to prevent row bulging */}
                    <span className="truncate leading-normal">{cat.name}</span>
                  </div>

                  {/* Selected Checkmark Indicator */}
                  {isSelected && (
                    <Check className="w-4 h-4 text-[#DC2626] shrink-0" />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
