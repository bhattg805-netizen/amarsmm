import React from 'react';
import {
  Headphones,
  MessageCircle,
  Send,
  Mail,
  Clock,
  Sparkles,
  Ticket,
  ExternalLink,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';
import { TelegramIcon } from './BrandIcons.tsx';

interface UserSupportChannelsSectionProps {
  isDarkMode: boolean;
  publicSettings: any;
  onOpenAiChat: () => void;
  onOpenTickets: () => void;
}

export const UserSupportChannelsSection: React.FC<UserSupportChannelsSectionProps> = ({
  isDarkMode,
  publicSettings,
  onOpenAiChat,
  onOpenTickets,
}) => {
  const whatsappNumber = publicSettings?.whatsappNumber || publicSettings?.bharatpePhone || '8795005604';
  const cleanPhone = whatsappNumber.replace(/[^0-9]/g, '');
  const telegramUsername = publicSettings?.telegramUsername || '@securesmmtursted';
  const cleanTelegram = telegramUsername.replace(/^@/, '');
  const telegramChannel = publicSettings?.telegramChannel || 'https://t.me/securesmmtursted';
  const supportEmail = publicSettings?.supportEmail || 'support@youthsmm.com';
  const workingHours = publicSettings?.supportWorkingHours || '24/7 Live Automated Support';

  return (
    <div
      className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-7 transition-colors ${
        isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-[#FFFDF8] border-[#EAE3D2]'
      }`}
    >
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-[#00897B] flex items-center justify-center text-white shadow-xs">
              <Headphones className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span>Support Channels</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
              Verified Direct Desk
            </span>
          </h2>
          <p className="text-xs text-stone-500 dark:text-gray-400 mt-1">
            Connect with our certified support representatives directly via WhatsApp, Telegram, Ticket Desk, or Email.
          </p>
        </div>

        <div className="px-3.5 py-1.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-xs font-mono font-bold flex items-center gap-1.5 self-start sm:self-auto">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping inline-block" />
          <span>{workingHours}</span>
        </div>
      </div>

      {/* Grid of Verified Support Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* 1. WHATSAPP SUPPORT */}
        <div className="p-5 rounded-2xl border border-emerald-500/30 bg-emerald-500/5 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-md shadow-emerald-500/25">
                <MessageCircle className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 px-2.5 py-0.5 rounded-full">
                Instant Chat
              </span>
            </div>

            <h3 className="text-base font-black text-gray-900 dark:text-white">
              WhatsApp VIP Helpdesk
            </h3>
            <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
              Fastest channel for payment verification, urgent speed boosts, and custom reseller bulk pricing.
            </p>
            <div className="font-mono text-xs font-bold text-emerald-700 dark:text-emerald-400 pt-1">
              +91 {cleanPhone}
            </div>
          </div>

          <a
            href={`https://wa.me/91${cleanPhone}?text=${encodeURIComponent(
              `Hello YouthSMM Support! I need assistance with my account.`
            )}`}
            target="_blank"
            rel="noreferrer"
            className="w-full py-3 rounded-xl bg-[#25D366] hover:bg-emerald-600 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
          >
            <span>Message on WhatsApp</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* 2. TELEGRAM CHANNEL & DM */}
        <div className="p-5 rounded-2xl border border-sky-500/30 bg-sky-500/5 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-2xl bg-[#0088cc] text-white flex items-center justify-center shadow-md shadow-sky-500/25">
                <TelegramIcon className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-wider bg-sky-500/20 text-sky-700 dark:text-sky-300 px-2.5 py-0.5 rounded-full">
                Channel & DM
              </span>
            </div>

            <h3 className="text-base font-black text-gray-900 dark:text-white">
              Official Telegram Desk
            </h3>
            <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
              Join our Telegram channel for live service discount codes, server maintenance updates, and direct admin DM.
            </p>
            <div className="font-mono text-xs font-bold text-sky-600 dark:text-sky-400 pt-1">
              @{cleanTelegram}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <a
              href={telegramChannel}
              target="_blank"
              rel="noreferrer"
              className="py-3 px-2 rounded-xl bg-[#0088cc] hover:bg-sky-600 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-sky-500/20 transition-all cursor-pointer text-center truncate"
            >
              <span>Join Channel</span>
              <ExternalLink className="w-3 h-3 shrink-0" />
            </a>

            <a
              href={`https://t.me/${cleanTelegram}`}
              target="_blank"
              rel="noreferrer"
              className="py-3 px-2 rounded-xl border border-sky-500/30 bg-[#FFFDF8] dark:bg-slate-900 hover:bg-sky-50 dark:hover:bg-slate-800 text-sky-600 dark:text-sky-400 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer text-center truncate"
            >
              <span>Direct Chat</span>
              <ExternalLink className="w-3 h-3 shrink-0" />
            </a>
          </div>
        </div>

        {/* 3. TICKET DESK */}
        <div className="p-5 rounded-2xl border border-rose-500/30 bg-rose-500/5 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-2xl bg-[#FF5376] text-white flex items-center justify-center shadow-md shadow-rose-500/25">
                <Ticket className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-700 dark:text-rose-300 px-2.5 py-0.5 rounded-full">
                Ticket Desk
              </span>
            </div>

            <h3 className="text-base font-black text-gray-900 dark:text-white">
              Official In-Panel Tickets
            </h3>
            <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
              Track issues with full audit history. Receive notifications when an admin replies to your order or payment dispute.
            </p>
            <div className="text-[11px] text-gray-400 font-medium pt-1">
              Guaranteed resolution under 15 minutes
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenTickets}
            className="w-full py-3 rounded-xl bg-[#DC2626] hover:bg-red-700 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md shadow-red-500/20 transition-all cursor-pointer"
          >
            <Ticket className="w-3.5 h-3.5" />
            <span>Open / View Tickets</span>
          </button>
        </div>

        {/* 4. EMAIL SUPPORT */}
        <div className="p-5 rounded-2xl border border-[#DDD3BC] dark:border-slate-800 bg-[#F4EFE3]/60 dark:bg-slate-800/40 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-2xl bg-slate-700 text-white flex items-center justify-center shadow-md">
                <Mail className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-wider bg-gray-200 dark:bg-slate-700 text-gray-700 dark:text-gray-300 px-2.5 py-0.5 rounded-full">
                Email
              </span>
            </div>

            <h3 className="text-base font-black text-stone-900 dark:text-white">
              Enterprise Email Support
            </h3>
            <p className="text-xs text-stone-600 dark:text-gray-300 leading-relaxed">
              For corporate invoice inquiries, custom API contracts, or high-volume enterprise reseller partnerships.
            </p>
            <div className="font-mono text-xs font-bold text-stone-800 dark:text-gray-200 pt-1">
              {supportEmail}
            </div>
          </div>

          <a
            href={`mailto:${supportEmail}`}
            className="w-full py-3 rounded-xl border border-[#DDD3BC] dark:border-slate-700 bg-[#FFFDF8] dark:bg-slate-900 hover:bg-[#F4EFE3] dark:hover:bg-slate-800 text-stone-800 dark:text-gray-200 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Send Email</span>
          </a>
        </div>
      </div>
    </div>
  );
};
