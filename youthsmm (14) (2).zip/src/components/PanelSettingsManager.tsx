import React, { useState } from 'react';
import {
  Settings,
  Save,
  Globe,
  Radio,
  Share2,
  DollarSign,
  Sparkles,
  Award,
  Layers,
  Bookmark,
  Wallet,
  FileText,
  TrendingUp,
  CreditCard,
  Clock,
  Shield,
  Copy,
  Check,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  ChevronDown,
  RefreshCw,
  Plus,
  Trash2,
  Edit2,
  Gift,
  HelpCircle,
  Code
} from 'lucide-react';
import { broadcastAdminChange } from '../lib/api';

interface PanelSettingsManagerProps {
  token: string;
  panelSettings: any;
  setPanelSettings: React.Dispatch<React.SetStateAction<any>>;
  onNavigateToPayments?: () => void;
  showSuccess: (msg: string) => void;
  showError: (msg: string) => void;
  isLight: boolean;
  cardBgClasses: string;
  subCardBg: string;
}

export const PanelSettingsManager: React.FC<PanelSettingsManagerProps> = ({
  token,
  panelSettings,
  setPanelSettings,
  onNavigateToPayments,
  showSuccess,
  showError,
  isLight,
  cardBgClasses,
  subCardBg,
}) => {
  // Local form state cloned from panelSettings
  const [formData, setFormData] = useState<Record<string, string>>({
    websiteName: panelSettings?.websiteName || 'YouthSMM',
    defaultLanguage: panelSettings?.defaultLanguage || 'en',
    whatsappNumber: panelSettings?.whatsappNumber || '8795005604',
    telegramUsername: panelSettings?.telegramUsername || '@youthsmm',
    supportEmail: panelSettings?.supportEmail || 'support@youthsmm.com',
    supportWorkingHours: panelSettings?.supportWorkingHours || '24x7 Customer Helpdesk',
    websiteLogo: panelSettings?.websiteLogo || '',
    favicon: panelSettings?.favicon || '',
    homepageYoutubeId: panelSettings?.homepageYoutubeId || '',

    // Currency rates
    inrToUsdRate: panelSettings?.inrToUsdRate || '0.012',
    inrToEurRate: panelSettings?.inrToEurRate || '0.011',
    inrToPkrRate: panelSettings?.inrToPkrRate || '3.32',

    // Dashboard Greeting & Gamification
    greetingNotice:
      panelSettings?.greetingNotice ||
      'Place a new order in a few taps — orders delivered on YouthSMM | Main SMM Provider.',
    sidebarAddFundsBtnText: panelSettings?.sidebarAddFundsBtnText || '+ Add funds',
    sidebarLevelNum: panelSettings?.sidebarLevelNum || 'Level 3',
    sidebarLevelName: panelSettings?.sidebarLevelName || 'BRONZE',
    sidebarXpText: panelSettings?.sidebarXpText || '66 / 120 XP',
    sidebarNextXp: panelSettings?.sidebarNextXp || 'Next: 54 XP',
    sidebarRewardsLinkText: panelSettings?.sidebarRewardsLinkText || '🏆 VIEW REWARDS & LEVELS',
    footerCopyright: panelSettings?.footerCopyright || '© YouthSMM | Main SMM Provider',

    // Child panels
    childPanelTitle: panelSettings?.childPanelTitle || 'Rent a Child Panel',
    childPanelPrice: panelSettings?.childPanelPrice || '₹ 1,500 / month',
    childPanelDescription:
      panelSettings?.childPanelDescription || 'Start your own automated SMM',
    childPanelNameservers:
      panelSettings?.childPanelNameservers || 'ns1.youthsmm.com & ns2.youthsmm.com',

    // Affiliate & Perks
    affiliateTitle: panelSettings?.affiliateTitle || 'Affiliate Referral Program',
    affiliateSubtitle:
      panelSettings?.affiliateSubtitle ||
      'Earn 5% lifetime commission on every deposit by referred users',
    level1PerkText: panelSettings?.level1PerkText || 'Standard Rates',
    level2PerkText: panelSettings?.level2PerkText || '300 XP · 2% Lifetime Discount',
    level3PerkText: panelSettings?.level3PerkText || '1000 XP · 5% Lifetime Discount',

    // Add Funds Page & Bank Details
    allUpiQrUrl: panelSettings?.allUpiQrUrl || '/phonepe-qr.png',
    allUpiMerchantName: panelSettings?.allUpiMerchantName || 'MUKUL BHATT',
    allUpiVpa: panelSettings?.allUpiVpa || '8795005604@ybl',
    manualBankDetails:
      panelSettings?.manualBankDetails ||
      'Bank: HDFC Bank\nA/C: 50100234567890\nIFSC: HDFC0001234\nHolder: Youth SMM Services',
    addFundPageNotice:
      panelSettings?.addFundPageNotice ||
      '⚠️ Please make sure to enter correct 12-digit UTR number for automatic credit.',

    // Terms, Policy & FAQ
    termsOfService: panelSettings?.termsOfService || '',
    privacyPolicy: panelSettings?.privacyPolicy || '',
    faqContent: panelSettings?.faqContent || '',

    // SEO
    seoKeywords:
      panelSettings?.seoKeywords ||
      'smm panel, social followers, automatic likes, cheapest smm panel',
    seoDescription:
      panelSettings?.seoDescription ||
      'Access high-speed automated social growth services with instant dispatch protocols.',

    // BharatPe Gateway Account Linking
    bharatpeStatus: panelSettings?.bharatpeStatus || 'linked',
    bharatpeMerchantId: panelSettings?.bharatpeMerchantId || '64225077',
    bharatpeToken: panelSettings?.bharatpeToken || '87bc04ed970a476cb113dd7dd6108bc0',
    bharatpeMerchantName: panelSettings?.bharatpeMerchantName || 'MUKUL BHATT',
    bharatpePhone: panelSettings?.bharatpePhone || '8795005604',
    bharatpeVpa: panelSettings?.bharatpeVpa || '8795005604@ybl',
    instantUtrAutoCredit: panelSettings?.instantUtrAutoCredit || 'enabled',

    // Advanced Operations Tuning
    orderIdSkip: panelSettings?.orderIdSkip || '0',
    addFundPageContent:
      panelSettings?.addFundPageContent ||
      'To pay manually:\n1. Scan the UPI QR Code above\n2. Send the desired INR amount\n3. Submit a manual support ticket with the transaction reference ID.',

    // Google OAuth
    googleLoginStatus: panelSettings?.googleLoginStatus || 'enabled',
    adminEmail: panelSettings?.adminEmail || 'bhattg805@gmail.com',
    googleClientId:
      panelSettings?.googleClientId ||
      '636019039384-4f20a2l5pk1qs4qn5ui038ivfv9gobog.apps.googleusercontent.com',
    googleClientSecret: panelSettings?.googleClientSecret || '',

    // Code Injections
    headerCode: panelSettings?.headerCode || '',
    footerCode: panelSettings?.footerCode || '',
    headerCodeAfterLogin: panelSettings?.headerCodeAfterLogin || '',
  });

  const [isSaving, setIsSaving] = useState(false);
  const [copiedCallback, setCopiedCallback] = useState(false);

  // Parse Promo Banners
  const banners = React.useMemo(() => {
    if (panelSettings?.dashboardBanners) {
      try {
        const parsed =
          typeof panelSettings.dashboardBanners === 'string'
            ? JSON.parse(panelSettings.dashboardBanners)
            : panelSettings.dashboardBanners;
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [
      {
        id: 'default-1',
        title: 'Earn up to ₹ 200 in free credit',
        subtitle: 'Leave a review for ₹ 25 · make a promo video for ₹ 200',
        badge: 'FREE WALLET CREDIT',
        btnText: 'Earn now →',
        btnLink: 'affiliate',
        active: true,
      },
    ];
  }, [panelSettings?.dashboardBanners]);

  const handleChange = (key: string, value: string) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const handleSaveAll = async () => {
    setIsSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        showSuccess('Settings customizations persisted and deployed globally!');
        setPanelSettings((prev: any) => ({ ...prev, ...formData }));
        broadcastAdminChange();
      } else {
        const d = await res.json();
        showError(d.error || 'Failed to save settings.');
      }
    } catch (err: any) {
      showError(`Save failed: ${err.message || err}`);
    } finally {
      setIsSaving(false);
    }
  };

  const copyCallbackUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedCallback(true);
    setTimeout(() => setCopiedCallback(false), 2000);
  };

  const callbackUrl = 'https://www.youthsmm.com/api/auth/google/callback';

  return (
    <div className="space-y-7">
      {/* ===================== TOP ACTION BAR (SCREENSHOT 1) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs ${cardBgClasses}`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-gray-900 dark:text-white">
              Save Changes
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">
              Submit parameters to synchronize branding and script modifications globally.
            </p>
          </div>

          <button
            type="button"
            onClick={handleSaveAll}
            disabled={isSaving}
            className="px-6 py-3 rounded-2xl bg-[#7C3AED] hover:bg-[#6D28D9] text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-purple-600/30 transition-all cursor-pointer flex items-center justify-center space-x-2 shrink-0"
          >
            {isSaving ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>SAVING...</span>
              </>
            ) : (
              <span>PERSIST CUSTOMIZATIONS</span>
            )}
          </button>
        </div>
      </div>

      {/* ===================== PAYMENT GATEWAY & UPI QR BANNER (SCREENSHOT 1) ===================== */}
      <div className={`rounded-3xl p-5 sm:p-6 border shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3.5">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0">
            <Wallet className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-black text-base text-gray-900 dark:text-white">
                Payment Gateway & UPI QR Management
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
                Dedicated Hub
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-0.5">
              Configure BharatPe, PhonePe, Paytm, Google Pay, Mobile Phone OTP, and Instant 12-digit UTR Auto-Credit.
            </p>
          </div>
        </div>

        {onNavigateToPayments && (
          <button
            type="button"
            onClick={onNavigateToPayments}
            className="px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center space-x-2 shadow-md shadow-emerald-600/20 transition-all cursor-pointer shrink-0"
          >
            <span>Manage Payment Settings</span>
            <span className="text-sm">›</span>
          </button>
        )}
      </div>

      {/* ===================== ROW 1: BRAND IDENTITY + VISUAL MEDIA ASSETS (SCREENSHOT 1) ===================== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Brand Identity & Multi-Channel Support */}
        <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base text-gray-900 dark:text-white">
                Brand Identity & Multi-Channel Support
              </h3>
              <p className="text-xs text-gray-400">
                Control panel brand name, language, and customer care channels.
              </p>
            </div>
          </div>

          <div className="space-y-4 pt-1">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                WEBSITE / BRAND NAME
              </label>
              <input
                type="text"
                placeholder="YouthSMM"
                value={formData.websiteName}
                onChange={(e) => handleChange('websiteName', e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-xs font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                DEFAULT LANGUAGE
              </label>
              <select
                value={formData.defaultLanguage}
                onChange={(e) => handleChange('defaultLanguage', e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-xs font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              >
                <option value="en">English (Default)</option>
                <option value="hi">Hindi (हिंदी)</option>
                <option value="es">Spanish</option>
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  WHATSAPP CONTACT NUMBER
                </label>
                <input
                  type="text"
                  placeholder="919999999999"
                  value={formData.whatsappNumber}
                  onChange={(e) => handleChange('whatsappNumber', e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                    isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                  TELEGRAM USERNAME / LINK
                </label>
                <input
                  type="text"
                  placeholder="@youthsmm"
                  value={formData.telegramUsername}
                  onChange={(e) => handleChange('telegramUsername', e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                    isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                SUPPORT HELPDESK EMAIL
              </label>
              <input
                type="email"
                placeholder="support@youthsmm.com"
                value={formData.supportEmail}
                onChange={(e) => handleChange('supportEmail', e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                SUPPORT WORKING HOURS BADGE
              </label>
              <input
                type="text"
                placeholder="24x7 Customer Helpdesk"
                value={formData.supportWorkingHours}
                onChange={(e) => handleChange('supportWorkingHours', e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>
          </div>
        </div>

        {/* Visual Media Assets */}
        <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-pink-500/10 text-pink-600 flex items-center justify-center">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base text-gray-900 dark:text-white">
                Visual Media Assets
              </h3>
              <p className="text-xs text-gray-400">
                Customize logotypes, dynamic web icons, and explainers.
              </p>
            </div>
          </div>

          <div className="space-y-4 pt-1">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                WEBSITE LOGO URL
              </label>
              <input
                type="text"
                placeholder="https://example.com/logo.png"
                value={formData.websiteLogo}
                onChange={(e) => handleChange('websiteLogo', e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                FAVICON ICON URL
              </label>
              <input
                type="text"
                placeholder="https://example.com/favicon.ico"
                value={formData.favicon}
                onChange={(e) => handleChange('favicon', e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                HOME PAGE YOUTUBE VIDEO ID
              </label>
              <input
                type="text"
                placeholder="dQw4w9WgXcQ"
                value={formData.homepageYoutubeId}
                onChange={(e) => handleChange('homepageYoutubeId', e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
              <span className="text-[10px] text-gray-400 mt-1.5 block leading-relaxed">
                Enter the 11-character video key (e.g. <strong>dQw4w9WgXcQ</strong>) to embed an interactive platform explainer tutorial directly inside the public guest portal.
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ===================== ROW 2: CURRENCY CONVERSION RATES (SCREENSHOT 2) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              Currency Conversion Rates (INR Base)
            </h3>
            <p className="text-xs text-gray-400">
              Control live user currency switcher calculations against Indian Rupee.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              1 INR TO USD RATE ($)
            </label>
            <input
              type="text"
              value={formData.inrToUsdRate}
              onChange={(e) => handleChange('inrToUsdRate', e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-xs font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              e.g. 0.012 means ₹100 = $1.20 USD
            </span>
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              1 INR TO EUR RATE (€)
            </label>
            <input
              type="text"
              value={formData.inrToEurRate}
              onChange={(e) => handleChange('inrToEurRate', e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-xs font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              e.g. 0.011 means ₹100 = €1.10 EUR
            </span>
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              1 INR TO PKR RATE (Rs)
            </label>
            <input
              type="text"
              value={formData.inrToPkrRate}
              onChange={(e) => handleChange('inrToPkrRate', e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-xs font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              e.g. 3.32 means ₹100 = Rs 332 PKR
            </span>
          </div>
        </div>
      </div>

      {/* ===================== DASHBOARD PROMO BANNERS PREVIEW (SCREENSHOT 2) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-4 ${cardBgClasses}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="font-black text-base text-gray-900 dark:text-white">
                  Dashboard Promo Banners
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-500/10 text-purple-600">
                  {banners.length} Active
                </span>
              </div>
              <p className="text-xs text-gray-400">
                Add new promotional banners or edit existing ones. Active banners rotate automatically on the user panel carousel.
              </p>
            </div>
          </div>
        </div>

        {/* Active Banner Showcase Box */}
        {(() => {
          const currentBanner = banners[0] || {};
          const bTitle = currentBanner.title || panelSettings?.bannerTitle || formData.bannerTitle || 'Earn up to ₹ 200 in free credit';
          const bBadge = currentBanner.badge || panelSettings?.bannerBadge || formData.bannerBadge || 'FREE WALLET CREDIT';
          const bSub = currentBanner.subtitle || panelSettings?.bannerSubtitle || formData.bannerSubtitle || 'Add funds & receive instant bonus';
          const bBtn = currentBanner.btnText || panelSettings?.bannerBtnText || formData.bannerBtnText || 'Earn now →';
          const bLink = currentBanner.btnLink || panelSettings?.bannerBtnLink || formData.bannerBtnLink || 'affiliate';
          const isEnabled = (panelSettings?.bannerStatus !== 'disabled') && (currentBanner.status !== 'disabled');

          return (
            <div className="p-4 sm:p-5 rounded-2xl bg-[#0F172A] text-white border border-slate-800 space-y-3">
              <div className="p-4 rounded-xl bg-gradient-to-r from-purple-800 via-indigo-700 to-purple-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center shrink-0">
                    <Gift className="w-5 h-5 text-amber-300" />
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-amber-300 block">
                      {bBadge}
                    </span>
                    <h4 className="font-black text-sm sm:text-base">{bTitle}</h4>
                    <p className="text-xs text-purple-200">
                      {bSub}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2 self-start sm:self-auto">
                  <button
                    type="button"
                    className="px-3 py-1.5 rounded-lg bg-white text-gray-900 font-black text-xs shrink-0 cursor-pointer"
                  >
                    {bBtn}
                  </button>
                  <span className={`px-2 py-1 rounded-lg text-xs font-bold flex items-center space-x-1 ${isEnabled ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${isEnabled ? 'bg-emerald-400' : 'bg-red-400'}`}></span>
                    <span>{isEnabled ? 'Active' : 'Disabled'}</span>
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between text-[11px] text-gray-400 pt-1">
                <span>Target: {bLink}</span>
                <span>Active Banners: {banners.length}</span>
              </div>
            </div>
          );
        })()}
      </div>

      {/* ===================== ROW 3: USER DASHBOARD GREETING & SIDEBAR (SCREENSHOT 3) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-600 flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              User Dashboard Greeting, Sidebar & XP Gamification
            </h3>
            <p className="text-xs text-gray-400">
              Customize greeting notices, sidebar tier labels, reward texts, and copyright messages.
            </p>
          </div>
        </div>

        <div className="space-y-4 pt-1">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              DASHBOARD TOP GREETING NOTICE
            </label>
            <input
              type="text"
              value={formData.greetingNotice}
              onChange={(e) => handleChange('greetingNotice', e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                SIDEBAR "+ ADD FUNDS" BUTTON
              </label>
              <input
                type="text"
                value={formData.sidebarAddFundsBtnText}
                onChange={(e) => handleChange('sidebarAddFundsBtnText', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                SIDEBAR LEVEL BADGE
              </label>
              <input
                type="text"
                value={formData.sidebarLevelNum}
                onChange={(e) => handleChange('sidebarLevelNum', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                SIDEBAR TIER NAME
              </label>
              <input
                type="text"
                value={formData.sidebarLevelName}
                onChange={(e) => handleChange('sidebarLevelName', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                SIDEBAR XP COUNTER
              </label>
              <input
                type="text"
                value={formData.sidebarXpText}
                onChange={(e) => handleChange('sidebarXpText', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                SIDEBAR NEXT TARGET
              </label>
              <input
                type="text"
                value={formData.sidebarNextXp}
                onChange={(e) => handleChange('sidebarNextXp', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                SIDEBAR REWARDS LINK LABEL
              </label>
              <input
                type="text"
                value={formData.sidebarRewardsLinkText}
                onChange={(e) => handleChange('sidebarRewardsLinkText', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                GLOBAL FOOTER COPYRIGHT LINE
              </label>
              <input
                type="text"
                value={formData.footerCopyright}
                onChange={(e) => handleChange('footerCopyright', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>
          </div>
        </div>
      </div>

      {/* ===================== ROW 4: CHILD PANELS RESELLER PACKAGE (SCREENSHOT 3) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              Child Panels Reseller Package
            </h3>
            <p className="text-xs text-gray-400">
              Control title, pricing, features, and nameserver instructions shown to users under the "Child Panels" tab.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-1">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              PRODUCT HEADING
            </label>
            <input
              type="text"
              value={formData.childPanelTitle}
              onChange={(e) => handleChange('childPanelTitle', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              PRICE TAG
            </label>
            <input
              type="text"
              value={formData.childPanelPrice}
              onChange={(e) => handleChange('childPanelPrice', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              TAGLINE / SUBTITLE
            </label>
            <input
              type="text"
              value={formData.childPanelDescription}
              onChange={(e) => handleChange('childPanelDescription', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              NAMESERVERS TEXT
            </label>
            <input
              type="text"
              value={formData.childPanelNameservers}
              onChange={(e) => handleChange('childPanelNameservers', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>
        </div>
      </div>

      {/* ===================== ROW 5: AFFILIATE & REWARDS PERKS (SCREENSHOT 4) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-600 flex items-center justify-center">
            <Bookmark className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              Affiliate & Rewards Modal Tier Perks
            </h3>
            <p className="text-xs text-gray-400">
              Customize texts shown in Affiliate Program tab and the Rewards & Levels popup modal.
            </p>
          </div>
        </div>

        <div className="space-y-4 pt-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                AFFILIATE HEADING
              </label>
              <input
                type="text"
                value={formData.affiliateTitle}
                onChange={(e) => handleChange('affiliateTitle', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                AFFILIATE DESCRIPTION / RATE SUBTITLE
              </label>
              <input
                type="text"
                value={formData.affiliateSubtitle}
                onChange={(e) => handleChange('affiliateSubtitle', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                LEVEL 1 (BRONZE) PERK TEXT
              </label>
              <input
                type="text"
                value={formData.level1PerkText}
                onChange={(e) => handleChange('level1PerkText', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                LEVEL 2 (SILVER) PERK TEXT
              </label>
              <input
                type="text"
                value={formData.level2PerkText}
                onChange={(e) => handleChange('level2PerkText', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                LEVEL 3 (GOLD) PERK TEXT
              </label>
              <input
                type="text"
                value={formData.level3PerkText}
                onChange={(e) => handleChange('level3PerkText', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>
          </div>
        </div>
      </div>

      {/* ===================== ROW 6: ADD FUNDS PAGE, QR CODE & BANK DETAILS (SCREENSHOT 4) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-teal-500/10 text-teal-600 flex items-center justify-center">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              Add Funds Page, QR Code & Bank Details
            </h3>
            <p className="text-xs text-gray-400">
              Customize payment QR image, UPI ID, manual bank transfer instructions, and helper text for deposits.
            </p>
          </div>
        </div>

        <div className="space-y-4 pt-1">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                UPI / PAYMENT QR CODE IMAGE (PHONEPE / ALL UPI)
              </label>
              <input
                type="text"
                placeholder="/phonepe-qr.png or https://example.com/qr-code.png"
                value={formData.allUpiQrUrl}
                onChange={(e) => {
                  const val = e.target.value;
                  handleChange('allUpiQrUrl', val);
                  handleChange('phonepeQrUrl', val);
                  handleChange('bharatpeQrUrl', val);
                }}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                MERCHANT NAME
              </label>
              <input
                type="text"
                placeholder="MUKUL BHATT"
                value={formData.allUpiMerchantName}
                onChange={(e) => handleChange('allUpiMerchantName', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                UPI VPA / ID
              </label>
              <input
                type="text"
                placeholder="8795005604@ybl"
                value={formData.allUpiVpa}
                onChange={(e) => handleChange('allUpiVpa', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                MANUAL BANK TRANSFER DETAILS / INSTRUCTIONS
              </label>
              <textarea
                rows={4}
                value={formData.manualBankDetails}
                onChange={(e) => handleChange('manualBankDetails', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div>
              <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
                ADD FUNDS PAGE NOTE / NOTICE
              </label>
              <textarea
                rows={4}
                value={formData.addFundPageNotice}
                onChange={(e) => handleChange('addFundPageNotice', e.target.value)}
                className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                  isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>
          </div>
        </div>
      </div>

      {/* ===================== ROW 7: POLICIES, TERMS & FAQ (SCREENSHOT 5) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-teal-500/10 text-teal-600 flex items-center justify-center">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              Policies, Terms & FAQ Management
            </h3>
            <p className="text-xs text-gray-400">
              Customize complete text for Terms of Service, Privacy Policy, and Frequently Asked Questions tabs.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              TERMS & CONDITIONS (CUSTOM CONTENT)
            </label>
            <textarea
              rows={4}
              placeholder="Enter custom terms and rules..."
              value={formData.termsOfService}
              onChange={(e) => handleChange('termsOfService', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              Leave empty to use automatic standard terms.
            </span>
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              PRIVACY POLICY (CUSTOM CONTENT)
            </label>
            <textarea
              rows={4}
              placeholder="Enter custom privacy policy..."
              value={formData.privacyPolicy}
              onChange={(e) => handleChange('privacyPolicy', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              Leave empty to use automatic standard privacy policy.
            </span>
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              FAQ / HELP KNOWLEDGEBASE (CUSTOM CONTENT)
            </label>
            <textarea
              rows={4}
              placeholder="Q: How long do orders take?&#10;A: Usually 1-5 minutes."
              value={formData.faqContent}
              onChange={(e) => handleChange('faqContent', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              Leave empty to use built-in rich FAQ accordion.
            </span>
          </div>
        </div>
      </div>

      {/* ===================== ROW 8: SEO (SCREENSHOT 5) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              Search Engine Optimization (SEO)
            </h3>
            <p className="text-xs text-gray-400">
              Control indexing keywords, crawler tags, and search result snippets.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              SEO KEYWORDS (COMMA SEPARATED)
            </label>
            <textarea
              rows={3}
              value={formData.seoKeywords}
              onChange={(e) => handleChange('seoKeywords', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              SEO DESCRIPTION META TAG
            </label>
            <textarea
              rows={3}
              value={formData.seoDescription}
              onChange={(e) => handleChange('seoDescription', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>
        </div>
      </div>

      {/* ===================== ROW 9: BHARATPE DYNAMIC QR ACCOUNT LINKING (SCREENSHOT 6 & 7) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-pink-500/10 text-pink-600 flex items-center justify-center">
            <CreditCard className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              BharatPe UPI Dynamic QR Account Linking
            </h3>
            <p className="text-xs text-gray-400">
              Link your BharatPe merchant account via registered mobile number and OTP verification, or configure manually.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start pt-1">
          {/* Form Side */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-gray-800">
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-xs font-mono font-black text-emerald-600">
                  GATEWAY ACTIVE & LINKED
                </span>
              </div>
              <select
                value={formData.bharatpeStatus}
                onChange={(e) => handleChange('bharatpeStatus', e.target.value)}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold ${
                  isLight ? 'bg-white border-stone-200' : 'bg-slate-800 border-slate-700'
                }`}
              >
                <option value="linked">Enabled (Active)</option>
                <option value="disabled">Disabled</option>
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-black uppercase text-gray-500">
                    BHARATPE MERCHANT ID
                  </label>
                  <span className="text-[9px] font-black text-emerald-600 bg-emerald-500/10 px-1 rounded">
                    Active
                  </span>
                </div>
                <input
                  type="text"
                  value={formData.bharatpeMerchantId}
                  onChange={(e) => handleChange('bharatpeMerchantId', e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono ${
                    isLight ? 'bg-white border-stone-200' : 'bg-slate-800 border-slate-700'
                  }`}
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-black uppercase text-gray-500">
                    BHARATPE API TOKEN
                  </label>
                  <span className="text-[9px] font-black text-blue-600 bg-blue-500/10 px-1 rounded">
                    Authenticated
                  </span>
                </div>
                <input
                  type="password"
                  value={formData.bharatpeToken}
                  onChange={(e) => handleChange('bharatpeToken', e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono ${
                    isLight ? 'bg-white border-stone-200' : 'bg-slate-800 border-slate-700'
                  }`}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-black uppercase text-gray-500 mb-1">
                  MERCHANT DISPLAY NAME
                </label>
                <input
                  type="text"
                  value={formData.bharatpeMerchantName}
                  onChange={(e) => handleChange('bharatpeMerchantName', e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold ${
                    isLight ? 'bg-white border-stone-200' : 'bg-slate-800 border-slate-700'
                  }`}
                />
              </div>

              <div>
                <label className="block text-[11px] font-black uppercase text-gray-500 mb-1">
                  REGISTERED MOBILE (+91)
                </label>
                <input
                  type="text"
                  value={formData.bharatpePhone}
                  onChange={(e) => handleChange('bharatpePhone', e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono ${
                    isLight ? 'bg-white border-stone-200' : 'bg-slate-800 border-slate-700'
                  }`}
                />
              </div>
            </div>

            {/* Instant Credit Mode */}
            <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-between">
              <div>
                <span className="text-xs font-black text-purple-700 dark:text-purple-300 block">
                  Instant UTR Auto-Credit Mode
                </span>
                <p className="text-[11px] text-purple-600/80 dark:text-purple-400/80">
                  When enabled, user wallet is credited instantly upon entering a valid 12-digit UTR with anti-fraud duplicate checks.
                </p>
              </div>
              <select
                value={formData.instantUtrAutoCredit}
                onChange={(e) => handleChange('instantUtrAutoCredit', e.target.value)}
                className="px-3 py-1.5 rounded-xl border text-xs font-bold bg-white text-gray-900 shrink-0"
              >
                <option value="enabled">Instant Credit (Active)</option>
                <option value="disabled">Manual Review</option>
              </select>
            </div>

            <div className="pt-2 flex items-center space-x-2.5">
              <button
                type="button"
                onClick={handleSaveAll}
                className="px-4 py-2 rounded-xl bg-pink-600 hover:bg-pink-700 text-white font-black text-xs cursor-pointer shadow-md shadow-pink-600/20"
              >
                Save QR Customizations
              </button>
              <button
                type="button"
                onClick={() => handleChange('bharatpeStatus', 'disabled')}
                className="px-4 py-2 rounded-xl border border-red-500/20 bg-red-500/10 text-red-600 font-bold text-xs cursor-pointer hover:bg-red-500/20"
              >
                Disconnect Account
              </button>
            </div>
          </div>

          {/* Phone Standee Mockup Side (Screenshot 6 & 7) */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center p-4">
            <div className="w-[230px] rounded-3xl p-4 bg-gradient-to-b from-[#FE2C55] via-teal-800 to-teal-950 text-white shadow-2xl space-y-3 text-center border-4 border-white/20">
              <span className="text-[10px] font-black uppercase tracking-wider opacity-80 block">
                HAI YAKEEN
              </span>
              <div className="text-sm font-black flex items-center justify-center space-x-1">
                <span>BharatPe</span>
              </div>
              <div className="font-bold text-xs">{formData.bharatpeMerchantName || 'PRIYA'}</div>
              <div className="p-3 bg-white rounded-2xl mx-auto shadow-inner flex items-center justify-center">
                <img
                  src={formData.allUpiQrUrl || '/phonepe-qr.png'}
                  alt="QR"
                  className="w-36 h-36 object-contain rounded-lg"
                  onError={(e) => {
                    (e.target as any).src = '/phonepe-qr.png';
                  }}
                />
              </div>
              <div className="text-[10px] opacity-80">
                BHIM &gt; UPI
                <br />
                Pay with any UPI app (PhonePe, GPay, Paytm)
              </div>
            </div>
            <span className="text-[10px] text-gray-400 mt-2 block text-center">
              Live dynamic QR payload is generated per transaction on Checkout.
            </span>
          </div>
        </div>
      </div>

      {/* ===================== ROW 10: ADVANCED OPERATIONS TUNING (SCREENSHOT 8 & 9) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              Advanced Operations Tuning
            </h3>
            <p className="text-xs text-gray-400">
              Regulate payment flow displays and offset database identity pipelines.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 pt-1">
          <div className="sm:col-span-4">
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              ORDER ID SKIP OFFSET
            </label>
            <input
              type="text"
              value={formData.orderIdSkip}
              onChange={(e) => handleChange('orderIdSkip', e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-xs font-mono font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1.5 block leading-relaxed">
              Offsets user-facing order IDs globally. e.g. setting to 10000 makes Order #5 display as #10005, making the system look more established.
            </span>
          </div>

          <div className="sm:col-span-8">
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              ADD FUNDS INSTRUCTIONS CONTENT
            </label>
            <textarea
              rows={4}
              value={formData.addFundPageContent}
              onChange={(e) => handleChange('addFundPageContent', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-sans focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              Configure custom guidelines, bank details, QR details, or manual transfer rules. Displays in a prominent alert box inside the user's "Deposit Wallet" page.
            </span>
          </div>
        </div>
      </div>

      {/* ===================== ROW 11: GOOGLE AUTHENTICATION SETTINGS (SCREENSHOT 10) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-red-500/10 text-red-600 flex items-center justify-center">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              Google Authentication (OAuth) Settings
            </h3>
            <p className="text-xs text-gray-400">
              Configure status, dynamic administrator email mapping, and Google Sign-In credentials.
            </p>
          </div>
        </div>

        {/* Callback box */}
        <div className="p-4 rounded-2xl bg-rose-50/70 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 space-y-2.5">
          <span className="text-xs font-black text-rose-600 block">
            Authorized Redirect URIs (Required for Google Cloud Console)
          </span>
          <p className="text-[11px] text-rose-700/90 dark:text-rose-300/90 leading-relaxed">
            Copy and paste the exact URL below into the <strong>Authorized redirect URIs</strong> section of your OAuth 2.0 Client in Google Cloud Console:
          </p>

          <div className="space-y-3 pt-1">
            <div className="space-y-1">
              <div className="text-[11px] font-bold text-gray-500">
                Production Callback (www.youthsmm.com):
              </div>
              <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-slate-800 flex items-center justify-between gap-2 text-xs font-mono text-emerald-600">
                <span className="truncate">https://www.youthsmm.com/api/auth/google/callback</span>
                <button
                  type="button"
                  onClick={() => copyCallbackUrl('https://www.youthsmm.com/api/auth/google/callback')}
                  className="px-2.5 py-1 rounded-lg bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-200 text-[10px] font-black cursor-pointer hover:bg-gray-200"
                >
                  {copiedCallback ? 'COPIED!' : 'COPY'}
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <div className="text-[11px] font-bold text-gray-500">
                Current Origin Callback (www.youthsmm.com):
              </div>
              <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-slate-800 flex items-center justify-between gap-2 text-xs font-mono text-rose-600 dark:text-rose-400">
                <span className="truncate">https://www.youthsmm.com/api/auth/google/callback</span>
                <button
                  type="button"
                  onClick={() => copyCallbackUrl('https://www.youthsmm.com/api/auth/google/callback')}
                  className="px-2.5 py-1 rounded-lg bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-200 text-[10px] font-black cursor-pointer hover:bg-gray-200"
                >
                  COPY
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              GOOGLE LOGIN STATUS
            </label>
            <select
              value={formData.googleLoginStatus}
              onChange={(e) => handleChange('googleLoginStatus', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-bold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            >
              <option value="enabled">Enabled</option>
              <option value="disabled">Disabled</option>
            </select>
            <span className="text-[10px] text-gray-400 mt-1 block">
              Toggle Google Sign-In button visibility on the login portal.
            </span>
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              PRIMARY ADMINISTRATOR EMAIL ADDRESS
            </label>
            <input
              type="email"
              value={formData.adminEmail}
              onChange={(e) => handleChange('adminEmail', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              Matches the Gmail address of the owner. Grants administrator dashboard access to this email dynamically.
            </span>
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              GOOGLE OAUTH CLIENT ID
            </label>
            <input
              type="text"
              placeholder="220010257054-pv05rshg..."
              value={formData.googleClientId}
              onChange={(e) => handleChange('googleClientId', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              Optional override. Google Client ID from Google Cloud credentials console.
            </span>
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              GOOGLE OAUTH CLIENT SECRET
            </label>
            <input
              type="password"
              placeholder="••••••••••••••••••••••••"
              value={formData.googleClientSecret}
              onChange={(e) => handleChange('googleClientSecret', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
            <span className="text-[10px] text-gray-400 mt-1 block">
              Optional override. Google Client Secret key from Google Cloud credentials console.
            </span>
          </div>
        </div>
      </div>

      {/* ===================== ROW 12: DYNAMIC HEADER & FOOTER CODE INJECTIONS (SCREENSHOT 11) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs space-y-5 ${cardBgClasses}`}>
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-600 flex items-center justify-center">
            <Code className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-black text-base text-gray-900 dark:text-white">
              Dynamic Header & Footer Code Injections
            </h3>
            <p className="text-xs text-gray-400">
              Inject dynamic script protocols, analytics trackers, CSS overrides, or widgets safely.
            </p>
          </div>
        </div>

        <div className="space-y-4 pt-1">
          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              ADDITIONAL HEADER CODE (INJECTED INTO &lt;HEAD&gt; GLOBALLY)
            </label>
            <textarea
              rows={3}
              placeholder="<!-- Google Tag Manager / Analytics / Custom Global CSS -->&#10;<script>console.log('Global script loaded');</script>"
              value={formData.headerCode}
              onChange={(e) => handleChange('headerCode', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              ADDITIONAL FOOTER CODE (INJECTED INTO &lt;BODY&gt; GLOBALLY)
            </label>
            <textarea
              rows={3}
              placeholder="<!-- Custom Chat Widget or analytics timers -->"
              value={formData.footerCode}
              onChange={(e) => handleChange('footerCode', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>

          <div>
            <label className="block text-[11px] font-black uppercase tracking-wider text-gray-500 mb-1">
              ADDITIONAL HEADER CODE - AFTER LOGIN PAGES (ONLY ON AUTHENTICATED VIEWS)
            </label>
            <textarea
              rows={3}
              placeholder="<!-- Injected exclusively for registered panels -->"
              value={formData.headerCodeAfterLogin}
              onChange={(e) => handleChange('headerCodeAfterLogin', e.target.value)}
              className={`w-full px-3.5 py-2.5 rounded-xl border text-xs font-mono focus:outline-hidden focus:ring-2 focus:ring-purple-500 ${
                isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-800 border-slate-700 text-white'
              }`}
            />
          </div>
        </div>
      </div>

      {/* ===================== BOTTOM STICKY PERSIST BUTTON (SCREENSHOT 11) ===================== */}
      <div className={`rounded-3xl p-6 sm:p-7 border shadow-xs flex items-center justify-end ${cardBgClasses}`}>
        <button
          type="button"
          onClick={handleSaveAll}
          disabled={isSaving}
          className="px-8 py-3.5 rounded-2xl bg-[#7C3AED] hover:bg-[#6D28D9] text-white font-black text-xs uppercase tracking-wider shadow-lg shadow-purple-600/30 transition-all cursor-pointer flex items-center space-x-2"
        >
          {isSaving ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>SAVING...</span>
            </>
          ) : (
            <span>PERSIST CUSTOMIZATIONS</span>
          )}
        </button>
      </div>
    </div>
  );
};
