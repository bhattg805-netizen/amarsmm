import React, { useState, useEffect } from 'react';
import {
  Shield,
  Users,
  ListOrdered,
  Layers,
  Wallet,
  Settings,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Clock,
  ArrowRight,
  LogOut,
  Send,
  Eye,
  Edit2,
  Trash2,
  Check,
  X,
  Play,
  Search,
  ExternalLink,
  ChevronRight,
  CreditCard,
  TrendingUp,
  Globe,
  Activity,
  Percent,
  Calendar,
  MessageSquare,
  Megaphone,
  BookOpen,
  FileText,
  Sun,
  Moon,
  Coffee,
  Sparkles,
  Plus,
  ChevronDown,
  UserCheck,
  DollarSign,
  Link as LinkIcon,
  RotateCcw,
  Zap,
  Menu,
} from 'lucide-react';
import { User, Service, Order, Category, Payment } from '../types';
import { BharatPePaymentsLedger } from './BharatPePaymentsLedger.tsx';
import { PaymentSettingsManager } from './PaymentSettingsManager.tsx';
import { PromoBannerManager } from './PromoBannerManager.tsx';
import { ApiProvidersManager } from './ApiProvidersManager.tsx';
import { CatalogManager } from './CatalogManager.tsx';
import { ManualSellerSync } from './ManualSellerSync.tsx';
import { PanelSettingsManager } from './PanelSettingsManager.tsx';
import { AnimatedLogo } from './AnimatedLogo.tsx';
import { broadcastAdminChange } from '../lib/api';

interface AdminDashboardProps {
  user: User;
  token: string;
  onLogout: () => void;
  onSwitchToUser: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  user,
  token,
  onLogout,
  onSwitchToUser,
}) => {
  // Theme state: 'light' | 'dark' | 'espresso' (default: 'light' matching user screenshot)
  const [adminTheme, setAdminTheme] = useState<'light' | 'dark' | 'espresso'>(() => {
    return (localStorage.getItem('youthsmm_admin_theme') as any) || 'light';
  });
  const [adminMobileDrawerOpen, setAdminMobileDrawerOpen] = useState(false);

  // Active Navigation Tab matching screenshots
  const [activeTab, setActiveTab] = useState<
    | 'analytics'
    | 'payments'
    | 'payment_settings'
    | 'users'
    | 'orders'
    | 'child_panels'
    | 'refills'
    | 'providers'
    | 'services'
    | 'seller_sync'
    | 'promos'
    | 'appointments'
    | 'support'
    | 'broadcasts'
    | 'blogs'
    | 'logs'
    | 'settings'
  >('analytics');

  // Stats & Data states
  const [stats, setStats] = useState<any>({
    usersCount: 0,
    ordersCount: 0,
    totalRevenue: 0,
    totalDeposited: 0,
    todayRevenue: 0,
    todayDeposited: 0,
    todayDepositsCount: 0,
    pendingDepositsCount: 0,
    pendingDepositsAmount: 0,
  });

  const [orders, setOrders] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [servicesList, setServicesList] = useState<Service[]>([]);
  const [categoriesList, setCategoriesList] = useState<Category[]>([]);
  const [paymentsList, setPaymentsList] = useState<any[]>([]);
  const [providersList, setProvidersList] = useState<any[]>([]);
  const [panelSettings, setPanelSettings] = useState<any>({});
  const [childPanels, setChildPanels] = useState<any[]>([]);
  const [refillsList, setRefillsList] = useState<any[]>([]);
  const [ticketsList, setTicketsList] = useState<any[]>([]);
  const [logsList, setLogsList] = useState<any[]>([]);
  const [blogsList, setBlogsList] = useState<any[]>([]);

  const [loading, setLoading] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [lastSyncTime, setLastSyncTime] = useState<string>('11:02:45 PM');

  // User editing modal/balance state
  const [editingUserId, setEditingUserId] = useState<number | null>(null);
  const [newBalanceInput, setNewBalanceInput] = useState<string>('');

  // User Ledger Action Modals States
  const [selectedUserForOrders, setSelectedUserForOrders] = useState<any | null>(null);
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'user' | 'admin'>('all');
  const [userOrdersList, setUserOrdersList] = useState<any[]>([]);
  const [loadingUserOrders, setLoadingUserOrders] = useState(false);

  const [selectedUserForFunds, setSelectedUserForFunds] = useState<any | null>(null);
  const [fundAmountInput, setFundAmountInput] = useState<string>('');
  const [fundActionType, setFundActionType] = useState<'add' | 'deduct' | 'set'>('add');
  const [fundNoteInput, setFundNoteInput] = useState<string>('Admin manual credit');

  // Searches & Filters
  const [userSearch, setUserSearch] = useState('');
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState('all');
  const [serviceSearch, setServiceSearch] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  // Child panels and support tickets management state
  const [selectedTicket, setSelectedTicket] = useState<any | null>(null);
  const [ticketMessages, setTicketMessages] = useState<any[]>([]);
  const [adminTicketReply, setAdminTicketReply] = useState('');
  const [loadingTicketMessages, setLoadingTicketMessages] = useState(false);
  const [sendingTicketReply, setSendingTicketReply] = useState(false);
  const [ticketFilterStatus, setTicketFilterStatus] = useState<string>('all');

  // Notification helper
  const showSuccess = (msg: string) => {
    setActionSuccess(msg);
    setTimeout(() => setActionSuccess(null), 4000);
  };

  const showError = (msg: string) => {
    setActionError(msg);
    setTimeout(() => setActionError(null), 5000);
  };

  // Switch Theme
  const handleThemeChange = (newTheme: 'light' | 'dark' | 'espresso') => {
    setAdminTheme(newTheme);
    localStorage.setItem('youthsmm_admin_theme', newTheme);
  };

  // Fetch all admin data
  const fetchAdminData = async () => {
    setLoading(true);
    const now = new Date();
    setLastSyncTime(now.toLocaleTimeString());
    try {
      const [stRes, ordRes, usrRes, srvRes, catRes, payRes, provRes, setRes] =
        await Promise.all([
          fetch('/api/admin/stats', { headers: { Authorization: `Bearer ${token}` } }).catch(() => null),
          fetch('/api/admin/orders', { headers: { Authorization: `Bearer ${token}` } }).catch(() => null),
          fetch('/api/admin/users', { headers: { Authorization: `Bearer ${token}` } }).catch(() => null),
          fetch('/api/admin/services', { headers: { Authorization: `Bearer ${token}` } }).catch(() => null),
          fetch('/api/admin/categories', { headers: { Authorization: `Bearer ${token}` } }).catch(() => null),
          fetch('/api/admin/payments', { headers: { Authorization: `Bearer ${token}` } }).catch(() => null),
          fetch('/api/admin/providers', { headers: { Authorization: `Bearer ${token}` } }).catch(() => null),
          fetch('/api/admin/settings', { headers: { Authorization: `Bearer ${token}` } }).catch(() => null),
        ]);

      if (stRes && stRes.ok) {
        try { setStats(await stRes.json()); } catch (_) {}
      }
      if (ordRes && ordRes.ok) {
        try { setOrders(await ordRes.json()); } catch (_) {}
      }
      if (usrRes && usrRes.ok) {
        try { setUsersList(await usrRes.json()); } catch (_) {}
      }
      if (srvRes && srvRes.ok) {
        try { setServicesList(await srvRes.json()); } catch (_) {}
      }
      if (catRes && catRes.ok) {
        try { setCategoriesList(await catRes.json()); } catch (_) {}
      }
      if (payRes && payRes.ok) {
        try { setPaymentsList(await payRes.json()); } catch (_) {}
      }
      if (provRes && provRes.ok) {
        try { setProvidersList(await provRes.json()); } catch (_) {}
      }
      if (setRes && setRes.ok) {
        try { setPanelSettings(await setRes.json()); } catch (_) {}
      }

      // Fetch optional resources
      fetch('/api/admin/child-panels', { headers: { Authorization: `Bearer ${token}` } })
        .then((r) => r.ok && r.json())
        .then((d) => d && setChildPanels(d))
        .catch(() => {});
      fetch('/api/admin/refill-requests', { headers: { Authorization: `Bearer ${token}` } })
        .then((r) => r.ok && r.json())
        .then((d) => d && setRefillsList(d))
        .catch(() => {});
      fetch('/api/admin/tickets', { headers: { Authorization: `Bearer ${token}` } })
        .then((r) => r.ok && r.json())
        .then((d) => d && setTicketsList(d))
        .catch(() => {});
      fetch('/api/admin/logs', { headers: { Authorization: `Bearer ${token}` } })
        .then((r) => r.ok && r.json())
        .then((d) => d && setLogsList(d))
        .catch(() => {});
      fetch('/api/admin/blogs', { headers: { Authorization: `Bearer ${token}` } })
        .then((r) => r.ok && r.json())
        .then((d) => d && setBlogsList(d))
        .catch(() => {});
    } catch (err) {
      console.error('Failed to load admin dashboard:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, [token]);

  // Handle update balance
  const handleUpdateBalance = async (userId: number) => {
    if (!newBalanceInput) return;
    try {
      const res = await fetch(`/api/admin/users/${userId}/balance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ amount: Number(newBalanceInput), action: 'set' }),
      });
      const data = await res.json();
      if (res.ok) {
        showSuccess(`User #${userId} balance updated to ₹${newBalanceInput}`);
        setEditingUserId(null);
        setNewBalanceInput('');
        fetchAdminData();
        broadcastAdminChange();
      } else {
        showError(data.error || 'Failed to update balance.');
      }
    } catch (e: any) {
      showError(e.message || 'Balance update failed.');
    }
  };

  // Login As User (Impersonation)
  const handleLoginAsUser = async (userObj: any) => {
    try {
      const res = await fetch(`/api/admin/users/${userObj.id}/login-as`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok && data.success && data.token) {
        showSuccess(`Switched to user account: ${userObj.email}`);
        localStorage.setItem('youthsmm_token', data.token);
        localStorage.setItem('youthsmm_last_view', 'user');
        window.location.reload();
      } else {
        showError(data.error || 'Failed to login as user.');
      }
    } catch (e: any) {
      showError(e.message || 'Login-as request failed.');
    }
  };

  // Toggle User Status (Suspend / Activate)
  const handleToggleSuspendUser = async (userObj: any) => {
    const nextStatus = userObj.status === 'suspended' ? 'active' : 'suspended';
    if (nextStatus === 'suspended' && !confirm(`Are you sure you want to suspend user ${userObj.email}?`)) {
      return;
    }
    try {
      const res = await fetch(`/api/admin/users/${userObj.id}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: nextStatus }),
      });
      const data = await res.json();
      if (res.ok) {
        showSuccess(`User #${userObj.id} is now ${nextStatus}!`);
        fetchAdminData();
        broadcastAdminChange();
      } else {
        showError(data.error || 'Failed to update status.');
      }
    } catch (e: any) {
      showError(e.message || 'Status update failed.');
    }
  };

  // View User Orders
  const handleViewUserOrders = async (userObj: any) => {
    setSelectedUserForOrders(userObj);
    setLoadingUserOrders(true);
    try {
      const res = await fetch(`/api/admin/users/${userObj.id}/orders`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const d = await res.json();
        setUserOrdersList(Array.isArray(d) ? d : []);
      } else {
        setUserOrdersList([]);
      }
    } catch (e) {
      setUserOrdersList([]);
    } finally {
      setLoadingUserOrders(false);
    }
  };

  // Add Funds Modal Submit
  const handleAddFundsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserForFunds || !fundAmountInput) return;
    try {
      const res = await fetch(`/api/admin/users/${selectedUserForFunds.id}/balance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          amount: Number(fundAmountInput),
          action: fundActionType,
          note: fundNoteInput,
        }),
      });
      const d = await res.json();
      if (res.ok) {
        showSuccess(`Balance updated for ${selectedUserForFunds.email}!`);
        setSelectedUserForFunds(null);
        setFundAmountInput('');
        fetchAdminData();
        broadcastAdminChange();
      } else {
        showError(d.error || 'Failed to update balance.');
      }
    } catch (e: any) {
      showError(e.message || 'Failed to update funds.');
    }
  };

  // Handle order status change
  const handleUpdateOrderStatus = async (orderId: number, status: string) => {
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        showSuccess(`Order #${orderId} marked as ${status}`);
        fetchAdminData();
        broadcastAdminChange();
      }
    } catch (e) {
      showError('Failed to change status.');
    }
  };

  // Handle dispatch order to provider
  const handleDispatchOrder = async (orderId: number) => {
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/dispatch`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showSuccess(data.message || `Order #${orderId} dispatched to provider.`);
        fetchAdminData();
        broadcastAdminChange();
      } else {
        showError(data.error || 'Provider dispatch failed.');
      }
    } catch (e) {
      showError('Network error during dispatch.');
    }
  };

  // Trigger sync all
  const handleSyncAll = async () => {
    setLoading(true);
    try {
      await fetch('/api/admin/cron/trigger', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      showSuccess('Full sync triggered across all SMM providers!');
      await fetchAdminData();
      broadcastAdminChange();
    } catch (e) {
      showError('Sync failed.');
      setLoading(false);
    }
  };

  // Child panel status update
  const handleUpdateChildPanelStatus = async (panelId: number, status: string) => {
    try {
      const res = await fetch(`/api/admin/child-panels/${panelId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        showSuccess(`Child panel #${panelId} status updated to ${status}`);
        setChildPanels((prev) =>
          prev.map((p) => (p.id === panelId ? { ...p, status } : p))
        );
        broadcastAdminChange();
      } else {
        const d = await res.json();
        showError(d.error || 'Failed to update child panel status');
      }
    } catch (e: any) {
      showError(e.message || 'Status update failed');
    }
  };

  // Support ticket selection
  const handleSelectTicket = async (ticket: any) => {
    setSelectedTicket(ticket);
    setLoadingTicketMessages(true);
    try {
      const res = await fetch(`/api/tickets/${ticket.id}/messages`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setTicketMessages(data.messages || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingTicketMessages(false);
    }
  };

  // Send reply to support ticket
  const handleSendTicketReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !adminTicketReply.trim()) return;
    setSendingTicketReply(true);
    try {
      const res = await fetch(`/api/tickets/${selectedTicket.id}/reply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ message: adminTicketReply.trim() }),
      });
      if (res.ok) {
        showSuccess('Reply sent to user successfully!');
        setTicketMessages((prev) => [
          ...prev,
          {
            id: Date.now(),
            message: adminTicketReply.trim(),
            createdAt: new Date().toISOString(),
            senderName: user.name || 'Support Team',
            senderRole: 'admin',
          },
        ]);
        setAdminTicketReply('');
        broadcastAdminChange();
        fetchAdminData();
      } else {
        const d = await res.json();
        showError(d.error || 'Failed to send reply');
      }
    } catch (e: any) {
      showError(e.message || 'Reply failed');
    } finally {
      setSendingTicketReply(false);
    }
  };

  // Update ticket status
  const handleUpdateTicketStatus = async (ticketId: number, status: string) => {
    try {
      const res = await fetch(`/api/tickets/${ticketId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        showSuccess(`Ticket #${ticketId} status marked as ${status}`);
        setTicketsList((prev) =>
          prev.map((t) => (t.id === ticketId ? { ...t, status } : t))
        );
        if (selectedTicket && selectedTicket.id === ticketId) {
          setSelectedTicket((prev: any) => ({ ...prev, status }));
        }
        broadcastAdminChange();
      }
    } catch (e: any) {
      showError('Failed to change ticket status');
    }
  };

  // Theme container classes
  const isEspresso = adminTheme === 'espresso';
  const isDark = adminTheme === 'dark';
  const isLight = adminTheme === 'light';

  const bgClasses = isEspresso
    ? 'bg-[#181411] text-[#EFEBE8]'
    : isDark
    ? 'bg-[#0B0F19] text-gray-100'
    : 'bg-[#F9F7F2] text-gray-900';

  const cardBgClasses = isEspresso
    ? 'bg-[#211C18] border-[#362D26]'
    : isDark
    ? 'bg-[#111827] border-slate-800'
    : 'bg-white border-[#EFECE6]';

  const subCardBg = isEspresso
    ? 'bg-[#1C1713] border-[#362D26]'
    : isDark
    ? 'bg-slate-800/50 border-slate-700/60'
    : 'bg-[#FAF8F5] border-[#EFECE6]';

  const clientMembersCount = usersList.filter((u) => u.role !== 'admin').length;
  const adminUsersCount = usersList.filter((u) => u.role === 'admin').length;
  const totalUsersCount = usersList.length > 0 ? usersList.length : Number(stats.usersCount || 0);

  const pendingCount = Number(stats.pendingDepositsCount ?? 0);
  const pendingAmount = Number(stats.pendingDepositsAmount ?? 0).toFixed(2);

  const adminNavMenuItems = [
    { id: 'analytics', label: 'Analytics Dashboard', icon: TrendingUp, iconColor: 'text-red-500' },
    { id: 'payments', label: 'BharatPe Payments', icon: CreditCard, iconColor: 'text-teal-400', badge: pendingCount > 0 ? pendingCount : null },
    { id: 'payment_settings', label: 'Payment Settings (UPI / QR)', icon: Wallet, iconColor: 'text-emerald-400' },
    { id: 'users', label: `User Ledger (${usersList.length})`, icon: Users, iconColor: 'text-blue-400' },
    { id: 'orders', label: `Order Pipeline (${orders.length})`, icon: LinkIcon, iconColor: 'text-orange-400' },
    { id: 'child_panels', label: 'Reseller Child Panels', icon: Globe, iconColor: 'text-cyan-400' },
    { id: 'refills', label: 'Refill Requests', icon: RotateCcw, iconColor: 'text-teal-400' },
    { id: 'providers', label: 'API Providers', icon: RefreshCw, iconColor: 'text-rose-400' },
    { id: 'services', label: 'Catalog Manager', icon: ListOrdered, iconColor: 'text-blue-400' },
    { id: 'seller_sync', label: 'Manual Seller Sync', icon: Activity, iconColor: 'text-amber-400' },
    { id: 'promos', label: 'Promos & Coupons', icon: Percent, iconColor: 'text-purple-400' },
    { id: 'appointments', label: 'Appointments', icon: Calendar, iconColor: 'text-blue-400' },
    { id: 'support', label: 'Support Desk', icon: MessageSquare, iconColor: 'text-sky-400' },
    { id: 'broadcasts', label: 'System Broadcasts', icon: Megaphone, iconColor: 'text-amber-400' },
    { id: 'blogs', label: 'Blogs Manager', icon: BookOpen, iconColor: 'text-pink-400' },
    { id: 'logs', label: 'Platform Logs', icon: FileText, iconColor: 'text-slate-400' },
    { id: 'settings', label: 'Panel Settings', icon: Settings, iconColor: 'text-purple-400' },
  ];

  const renderSidebarItem = (item: typeof adminNavMenuItems[0], isMobile = false) => {
    const Icon = item.icon;
    const isActive = activeTab === item.id;
    return (
      <button
        key={item.id}
        type="button"
        onClick={() => {
          setActiveTab(item.id as any);
          if (isMobile) setAdminMobileDrawerOpen(false);
        }}
        className={`w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl transition-all cursor-pointer select-none text-[13.5px] ${
          isActive
            ? 'bg-red-500/20 dark:bg-red-950/60 border-l-4 border-red-500 shadow-xs'
            : 'hover:bg-black/5 dark:hover:bg-white/10'
        }`}
      >
        <Icon
          className={`w-4 h-4 shrink-0 transition-colors ${
            isActive ? 'text-red-500 dark:text-red-400' : item.iconColor
          }`}
        />
        <span
          className={`flex-1 text-left truncate transition-colors ${
            isActive
              ? 'font-black text-red-600 dark:text-white'
              : 'font-semibold text-stone-800 dark:text-slate-100'
          }`}
        >
          {item.label}
        </span>
        {item.badge && (
          <span className="ml-auto bg-[#F59E0B] text-amber-950 font-black text-xs px-2 py-0.5 rounded-full shrink-0 shadow-xs">
            {item.badge}
          </span>
        )}
      </button>
    );
  };

  return (
    <div className={`min-h-screen transition-colors duration-200 font-sans ${bgClasses} flex flex-col`}>
      {/* ===================== NOTIFICATIONS POPUP ===================== */}
      {actionSuccess && (
        <div className="fixed top-5 right-5 z-50 bg-emerald-600 text-white font-bold text-xs px-4 py-3 rounded-2xl shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-top-3">
          <CheckCircle className="w-4 h-4" />
          <span>{actionSuccess}</span>
        </div>
      )}
      {actionError && (
        <div className="fixed top-5 right-5 z-50 bg-red-600 text-white font-bold text-xs px-4 py-3 rounded-2xl shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-top-3">
          <AlertCircle className="w-4 h-4" />
          <span>{actionError}</span>
        </div>
      )}

      {/* ===================== ADMIN MOBILE TOP BAR (VISIBLE ON < lg) ===================== */}
      <header className={`lg:hidden sticky top-0 z-40 border-b px-3.5 py-2.5 backdrop-blur-md shadow-xs select-none transition-colors ${
        isEspresso
          ? 'bg-[#181411]/95 border-[#362D26]'
          : isDark
          ? 'bg-[#0B0F19]/95 border-slate-800'
          : 'bg-white/95 border-stone-200'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => setAdminMobileDrawerOpen(true)}
              className="p-2 rounded-xl border border-stone-200 dark:border-slate-700 bg-stone-50 dark:bg-slate-800 text-gray-700 dark:text-gray-200 hover:bg-stone-100 flex items-center justify-center cursor-pointer shadow-xs"
              aria-label="Admin Navigation Menu"
            >
              <Menu className="w-4 h-4" />
            </button>
            <AnimatedLogo size="xs" showText={true} theme={isLight ? 'light' : 'dark'} onClick={() => setActiveTab('analytics')} />
            <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-red-500/10 text-red-500 border border-red-500/20">
              ADMIN
            </span>
          </div>

          <div className="flex items-center space-x-1.5">
            {/* Quick theme toggles */}
            <button
              type="button"
              onClick={() => handleThemeChange(adminTheme === 'light' ? 'dark' : adminTheme === 'dark' ? 'espresso' : 'light')}
              className="p-2 rounded-xl border border-stone-200 dark:border-slate-700 bg-stone-50 dark:bg-slate-800 text-gray-700 dark:text-gray-300 cursor-pointer"
              title="Toggle Admin Theme"
            >
              {isEspresso ? <span>☕</span> : isDark ? <Moon className="w-3.5 h-3.5 text-blue-400" /> : <Sun className="w-3.5 h-3.5 text-amber-500" />}
            </button>

            {/* Switch to User view */}
            <button
              type="button"
              onClick={onSwitchToUser}
              className="px-2.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-[11px] shadow-xs flex items-center space-x-1 cursor-pointer"
            >
              <UserCheck className="w-3 h-3" />
              <span>User</span>
            </button>
          </div>
        </div>

        {/* Quick Horizontal Tab Bar for Mobile (< lg) */}
        <div className="flex items-center space-x-1.5 overflow-x-auto touch-scroll-x no-scrollbar pt-2 pb-0.5">
          {[
            { id: 'analytics', label: 'Overview', icon: <TrendingUp className="w-3 h-3" /> },
            { id: 'payments', label: `Payments (${pendingCount})`, icon: <CreditCard className="w-3 h-3" />, alert: pendingCount > 0 },
            { id: 'payment_settings', label: 'UPI / QR', icon: <Wallet className="w-3 h-3" /> },
            { id: 'users', label: 'Users', icon: <Users className="w-3 h-3" /> },
            { id: 'orders', label: 'Orders', icon: <ListOrdered className="w-3 h-3" /> },
            { id: 'services', label: 'Catalog', icon: <Layers className="w-3 h-3" /> },
            { id: 'seller_sync', label: 'Seller Sync', icon: <RefreshCw className="w-3 h-3" /> },
            { id: 'settings', label: 'Settings', icon: <Settings className="w-3 h-3" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setActiveTab(tab.id as any);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`px-2.5 py-1 rounded-xl text-[11px] font-bold shrink-0 flex items-center space-x-1 transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-red-600 text-white shadow-xs font-black'
                  : tab.alert
                  ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800'
                  : 'bg-stone-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300 hover:bg-stone-200 dark:hover:bg-slate-700'
              }`}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
          <button
            type="button"
            onClick={() => setAdminMobileDrawerOpen(true)}
            className="px-2.5 py-1 rounded-xl text-[11px] font-bold shrink-0 bg-stone-200/80 dark:bg-slate-700 text-gray-800 dark:text-gray-200 hover:bg-stone-300 cursor-pointer"
          >
            + All Menus
          </button>
        </div>
      </header>

      {/* ===================== MAIN LAYOUT ===================== */}
      <div className="max-w-[1600px] mx-auto px-3.5 sm:px-6 py-4 sm:py-6 w-full flex-1 flex flex-col lg:flex-row gap-6 sm:gap-8 items-start">
        {/* ===================== LEFT SIDEBAR (EXACT MATCHING SCREENSHOTS - DESKTOP) ===================== */}
        <aside className="hidden lg:block w-72 shrink-0 space-y-4 select-none">
          {/* Logo & Brand Header */}
          <div className="flex flex-col items-start px-2 pt-1 pb-2">
            {/* Animated Logo (Matching custom emblem & branding) */}
            <AnimatedLogo
              size="md"
              showText={true}
              theme={isLight ? 'light' : 'dark'}
              onClick={() => setActiveTab('analytics')}
            />

            {/* ADMIN SUITE BADGE (MATCHING SCREENSHOT 1) */}
            <div className="mt-2.5">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black tracking-wider uppercase bg-red-500/10 text-red-500 border border-red-500/25">
                ADMIN SUITE
              </span>
            </div>
          </div>

          {/* Navigation Items (17 Menu Items from Screenshots 1, 2, 3) */}
          <nav className="space-y-1 pt-1 text-[13.5px]">
            {adminNavMenuItems.map((item) => renderSidebarItem(item, false))}
          </nav>

          {/* Divider */}
          <div className="pt-3 border-t border-gray-200 dark:border-gray-800" />

          {/* BOTTOM BUTTONS (MATCHING SCREENSHOT 1) */}
          <div className="space-y-2 pt-1">
            <button
              type="button"
              onClick={onSwitchToUser}
              className="w-full py-3 px-4 rounded-xl bg-[#2563EB] hover:bg-blue-700 text-white font-extrabold text-xs shadow-sm flex items-center justify-center space-x-2 transition-all cursor-pointer"
            >
              <span>User Dashboard View</span>
            </button>

            <button
              type="button"
              onClick={onSwitchToUser}
              className={`w-full py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                isLight
                  ? 'bg-[#EAE7DF] hover:bg-[#DDD9CE] text-gray-800'
                  : 'bg-slate-800 hover:bg-slate-700 text-gray-300'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Switch Role to User</span>
            </button>

            <button
              type="button"
              onClick={onLogout}
              className="w-full py-2 px-4 rounded-xl text-xs font-semibold text-gray-400 hover:text-red-500 transition-colors flex items-center justify-center space-x-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </aside>

        {/* ===================== MAIN CONTENT WRAPPER ===================== */}
        <main className="flex-1 w-full min-w-0 space-y-6">
          {/* ===================== TOP HEADER CARD (MATCHING SCREENSHOT 1) ===================== */}
          <div
            className={`rounded-3xl p-4 sm:p-7 border shadow-xs transition-colors flex flex-col md:flex-row items-start md:items-center justify-between gap-4 sm:gap-6 ${cardBgClasses}`}
          >
            {/* Left Header Title */}
            <div>
              <div className="flex items-center space-x-2 text-[10px] font-black uppercase tracking-wider text-gray-400">
                <div className="w-4 h-4 rounded bg-red-500/10 text-red-600 flex items-center justify-center">
                  <Shield className="w-3 h-3" />
                </div>
                <span>SECURE TERMINAL PANEL</span>
              </div>
              <h1 className="text-xl sm:text-3xl font-black tracking-tight mt-1">
                {activeTab === 'analytics'
                  ? 'Analytics & Overview'
                  : activeTab === 'payments'
                  ? 'BharatPe Payments'
                  : activeTab === 'payment_settings'
                  ? 'Payment Settings'
                  : activeTab === 'users'
                  ? 'User Ledger'
                  : activeTab === 'orders'
                  ? 'Order Pipeline'
                  : activeTab === 'providers'
                  ? 'API Providers'
                  : activeTab === 'services'
                  ? 'Catalog Manager'
                  : activeTab === 'promos'
                  ? 'Promos & Coupons'
                  : 'Panel Settings'}
              </h1>
              <p className="text-xs text-gray-500 font-medium mt-1">
                Real-time financial velocity, status ratios, and account metrics.
              </p>
            </div>

            {/* Right Top Controls & Theme Switcher */}
            <div className="flex flex-col items-start sm:items-end space-y-2.5 self-stretch md:self-auto">
              {/* Top row pills: API status, UTC year, Sync All */}
              <div className="flex flex-wrap items-center gap-2">
                <div
                  className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold flex items-center space-x-2 select-none ${
                    isLight ? 'bg-[#FAF8F5] border-stone-200 text-gray-800' : 'bg-slate-800/60 border-slate-700 text-gray-300'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>API Status: Operational</span>
                </div>

                <div
                  className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold flex items-center space-x-1.5 select-none ${
                    isLight ? 'bg-[#FAF8F5] border-stone-200 text-gray-800' : 'bg-slate-800/60 border-slate-700 text-gray-300'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5 text-red-500" />
                  <span>UTC Year: 2026</span>
                </div>

                <button
                  type="button"
                  onClick={handleSyncAll}
                  disabled={loading}
                  className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                    isLight
                      ? 'bg-[#FAF8F5] hover:bg-stone-100 border-stone-200 text-gray-900'
                      : 'bg-slate-800/80 hover:bg-slate-700 border-slate-700 text-gray-200'
                  }`}
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-blue-600' : ''}`} />
                  <span>Sync All</span>
                </button>
              </div>

              {/* Bottom row pills: Espresso, Dark, Light theme pills (MATCHING SCREENSHOT 1) */}
              <div
                className={`p-1 rounded-2xl border flex items-center space-x-1 ${
                  isLight ? 'bg-[#FAF8F5] border-stone-200' : 'bg-slate-800/80 border-slate-700'
                }`}
              >
                <button
                  type="button"
                  onClick={() => handleThemeChange('espresso')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                    isEspresso
                      ? 'bg-amber-900 text-white shadow-xs font-black'
                      : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <span>☕</span>
                  <span>Espresso</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleThemeChange('dark')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                    isDark
                      ? 'bg-slate-900 text-white shadow-xs font-black'
                      : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5" />
                  <span>Dark</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleThemeChange('light')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                    isLight
                      ? 'bg-white border border-stone-200 text-gray-900 shadow-xs font-black'
                      : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                  <span>Light</span>
                </button>
              </div>
            </div>
          </div>

          {/* ===================== TAB: ANALYTICS DASHBOARD (SCREENSHOT 1) ===================== */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              {/* Subheader bar with IST time & Refresh Stats */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none">
                <div>
                  <div className="flex items-center space-x-2">
                    <h2 className="text-lg font-black tracking-tight">
                      Platform Analytics & Financial Velocity
                    </h2>
                    <span className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-extrabold text-[10px] px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                      IST (UTC+5:30) Live
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 font-medium mt-0.5">
                    Real-time metrics for Today's Revenue and Funds Added (Indian Standard Time). (Synced at{' '}
                    {lastSyncTime})
                  </p>
                </div>

                <button
                  type="button"
                  onClick={fetchAdminData}
                  disabled={loading}
                  className="px-4 py-2 rounded-xl bg-[#E9D5FF] hover:bg-purple-200 text-purple-900 font-black text-xs flex items-center space-x-1.5 transition-all shadow-xs cursor-pointer self-start sm:self-auto"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span>Refresh Stats</span>
                </button>
              </div>

              {/* AMBER ALERT BANNER: ACTION REQUIRED (MATCHING SCREENSHOT 1) */}
              <div className="rounded-2xl bg-[#FEF3C7] border border-[#FDE68A] p-4.5 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs">
                <div className="flex items-start space-x-3.5">
                  <div className="w-9 h-9 rounded-full bg-amber-500/20 text-amber-800 flex items-center justify-center shrink-0 mt-0.5">
                    <Clock className="w-5 h-5 text-amber-700" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-black text-sm text-amber-950">
                        {pendingCount} Payments Awaiting Admin Approval!
                      </span>
                      <span className="bg-[#F59E0B] text-black font-black text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                        ACTION REQUIRED
                      </span>
                    </div>
                    <p className="text-xs text-amber-800 font-medium mt-0.5">
                      Users have submitted UPI UTR numbers totaling ₹{pendingAmount}. Verify and approve to add funds to
                      user wallets.
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTab('payments')}
                  className="px-5 py-2.5 rounded-xl bg-[#F59E0B] hover:bg-amber-600 text-black font-black text-xs shadow-xs transition-all cursor-pointer shrink-0 flex items-center space-x-1.5"
                >
                  <span>Review & Approve Now</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              {/* 7 METRIC CARDS IN A ROW (EXACT MATCHING SCREENSHOT 1) */}
              <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3 sm:gap-4 select-none">
                {/* 1. Total Accounts / Registered Members */}
                <div className={`p-4 rounded-2xl border transition-colors ${cardBgClasses}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-gray-500">
                      Total Accounts
                    </span>
                    <div className="w-7 h-7 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center">
                      <Users className="w-3.5 h-3.5" />
                    </div>
                  </div>
                  <div className="text-2xl font-black tracking-tight">{totalUsersCount}</div>
                  <span className="text-[10px] text-gray-400 font-semibold mt-1 block">
                    {clientMembersCount} Members · {adminUsersCount} Admins
                  </span>
                </div>

                {/* 2. Orders Processed */}
                <div className={`p-4 rounded-2xl border transition-colors ${cardBgClasses}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-gray-500">
                      Orders Processed
                    </span>
                    <div className="w-7 h-7 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
                      <LinkIcon className="w-3.5 h-3.5" />
                    </div>
                  </div>
                  <div className="text-2xl font-black tracking-tight">{orders.length > 0 ? orders.length : (stats.ordersCount ?? 0)}</div>
                  <span className="text-[10px] text-gray-400 font-semibold mt-1 block">Lifetime Orders</span>
                </div>

                {/* 3. Platform Revenue */}
                <div className={`p-4 rounded-2xl border transition-colors ${cardBgClasses}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-gray-500">
                      Platform Revenue
                    </span>
                    <div className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
                      <TrendingUp className="w-3.5 h-3.5" />
                    </div>
                  </div>
                  <div className="text-2xl font-black tracking-tight">
                    ₹{Number(stats.totalRevenue ?? 0).toFixed(2)}
                  </div>
                  <span className="text-[10px] text-gray-400 font-semibold mt-1 block">Total Net Flow</span>
                </div>

                {/* 4. Wallet Deposits */}
                <div className={`p-4 rounded-2xl border transition-colors ${cardBgClasses}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-gray-500">
                      Wallet Deposits
                    </span>
                    <div className="w-7 h-7 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center">
                      <CreditCard className="w-3.5 h-3.5" />
                    </div>
                  </div>
                  <div className="text-2xl font-black tracking-tight">
                    ₹{Number(stats.totalDeposited ?? 0).toFixed(2)}
                  </div>
                  <span className="text-[10px] text-gray-400 font-semibold mt-1 block">Total Added Funds</span>
                </div>

                {/* 5. Today's Revenue */}
                <div className={`p-4 rounded-2xl border transition-colors ${cardBgClasses}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-gray-500">
                      Today's Revenue
                    </span>
                    <span className="bg-emerald-500/10 text-emerald-600 font-black text-[9px] px-1.5 py-0.5 rounded uppercase">
                      TODAY
                    </span>
                  </div>
                  <div className="text-2xl font-black tracking-tight text-emerald-600 dark:text-emerald-400">
                    ₹{Number(stats.todayRevenue ?? 0).toFixed(2)}
                  </div>
                  <span className="text-[10px] text-gray-400 font-semibold mt-1 block">Confirmed today</span>
                </div>

                {/* 6. Today's Fund Added */}
                <div className={`p-4 rounded-2xl border transition-colors ${cardBgClasses}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-gray-500">
                      Today's Fund Added
                    </span>
                    <span className="bg-cyan-500/10 text-cyan-600 font-black text-[9px] px-1.5 py-0.5 rounded uppercase">
                      TODAY
                    </span>
                  </div>
                  <div className="text-2xl font-black tracking-tight">
                    ₹{Number(stats.todayDeposited ?? 0).toFixed(2)}
                  </div>
                  <span className="text-[10px] text-gray-400 font-semibold mt-1 block">
                    {stats.todayDepositsCount ?? 0} deposits today
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm("Revert today's calculated fund totals?")) {
                        showSuccess("Today's calculated funds ledger refreshed.");
                      }
                    }}
                    className="mt-2.5 w-full py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-800 dark:text-amber-300 text-[10px] font-bold border border-amber-500/20 cursor-pointer"
                  >
                    🗑️ Revert Today's Funds
                  </button>
                </div>

                {/* 7. Pending Approvals */}
                <div className={`p-4 rounded-2xl border transition-colors ${cardBgClasses}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-gray-500">
                      Pending Approvals
                    </span>
                    <span className="bg-amber-500/10 text-amber-700 font-black text-[9px] px-1.5 py-0.5 rounded uppercase">
                      WAITING
                    </span>
                  </div>
                  <div className="text-2xl font-black tracking-tight text-amber-600">{pendingCount}</div>
                  <span className="text-[10px] text-gray-400 font-semibold mt-1 block truncate">
                    ₹{pendingAmount} awaiting review
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveTab('payments')}
                    className="mt-2.5 w-full py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-900 dark:text-amber-200 text-[10px] font-black border border-amber-500/30 cursor-pointer"
                  >
                    View Queue →
                  </button>
                </div>
              </div>

              {/* RECENT ORDERS & RECENT PAYMENTS IN SPLIT PREVIEW */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 items-start">
                {/* Recent Orders Overview */}
                <div className={`rounded-3xl p-6 border shadow-xs ${cardBgClasses} space-y-4`}>
                  <div className="flex items-center justify-between">
                    <h3 className="font-black text-base flex items-center space-x-2">
                      <LinkIcon className="w-4 h-4 text-orange-500" />
                      <span>Recent Orders Pipeline</span>
                    </h3>
                    <button
                      onClick={() => setActiveTab('orders')}
                      className="text-xs font-bold text-red-600 hover:underline"
                    >
                      View All Orders ({orders.length}) →
                    </button>
                  </div>

                  <div className="overflow-x-auto rounded-2xl border border-gray-100 dark:border-gray-800">
                    <table className="w-full text-left text-xs">
                      <thead className={`font-mono text-[11px] ${subCardBg} text-gray-400`}>
                        <tr>
                          <th className="py-2.5 px-3">ID</th>
                          <th className="py-2.5 px-3">Service</th>
                          <th className="py-2.5 px-3">Qty</th>
                          <th className="py-2.5 px-3">Status</th>
                          <th className="py-2.5 px-3">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                        {orders.slice(0, 5).map((o) => (
                          <tr key={o.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/40">
                            <td className="py-2.5 px-3 font-mono font-bold">#{o.id}</td>
                            <td className="py-2.5 px-3 truncate max-w-[140px]">{o.serviceName || `Service #${o.serviceId}`}</td>
                            <td className="py-2.5 px-3 font-mono">{o.quantity}</td>
                            <td className="py-2.5 px-3">
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/10 text-blue-600 uppercase">
                                {o.status}
                              </span>
                            </td>
                            <td className="py-2.5 px-3">
                              <button
                                onClick={() => handleDispatchOrder(o.id)}
                                className="px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg text-[10px] font-black cursor-pointer"
                              >
                                Dispatch
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Pending Payments Overview */}
                <div className={`rounded-3xl p-6 border shadow-xs ${cardBgClasses} space-y-4`}>
                  <div className="flex items-center justify-between">
                    <h3 className="font-black text-base flex items-center space-x-2">
                      <CreditCard className="w-4 h-4 text-teal-600" />
                      <span>Pending UPI UTR Approvals</span>
                    </h3>
                    <button
                      onClick={() => setActiveTab('payments')}
                      className="text-xs font-bold text-amber-600 hover:underline"
                    >
                      Open Full Ledger ({pendingCount}) →
                    </button>
                  </div>

                  <div className="overflow-x-auto rounded-2xl border border-gray-100 dark:border-gray-800">
                    <table className="w-full text-left text-xs">
                      <thead className={`font-mono text-[11px] ${subCardBg} text-gray-400`}>
                        <tr>
                          <th className="py-2.5 px-3">UTR / ID</th>
                          <th className="py-2.5 px-3">User</th>
                          <th className="py-2.5 px-3">Amount</th>
                          <th className="py-2.5 px-3">Method</th>
                          <th className="py-2.5 px-3">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                        {paymentsList
                          .filter((p) => p.status === 'pending')
                          .slice(0, 5)
                          .map((p) => (
                            <tr key={p.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/40">
                              <td className="py-2.5 px-3 font-mono font-bold text-amber-600">
                                {p.transactionId || `#${p.id}`}
                              </td>
                              <td className="py-2.5 px-3">User #{p.userId}</td>
                              <td className="py-2.5 px-3 font-mono font-bold text-emerald-600">
                                ₹{Number(p.amount).toFixed(2)}
                              </td>
                              <td className="py-2.5 px-3">{p.paymentMethod || 'BharatPe'}</td>
                              <td className="py-2.5 px-3">
                                <button
                                  onClick={() => setActiveTab('payments')}
                                  className="px-2.5 py-1 bg-[#F59E0B] text-black font-black text-[10px] rounded-lg cursor-pointer"
                                >
                                  Verify
                                </button>
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ===================== TAB: BHARATPE PAYMENTS ===================== */}
          {activeTab === 'payments' && (
            <BharatPePaymentsLedger
              token={token}
              adminTheme={adminTheme}
              formatCurrency={(v) => `₹${Number(v).toFixed(2)}`}
              showSuccess={showSuccess}
              showError={showError}
              onRefreshStats={fetchAdminData}
              onOpenPaymentSettings={() => setActiveTab('payment_settings')}
            />
          )}

          {/* ===================== TAB: PAYMENT SETTINGS (UPI / QR) ===================== */}
          {activeTab === 'payment_settings' && (
            <PaymentSettingsManager
              token={token}
              adminTheme={adminTheme}
              panelSettings={panelSettings}
              setPanelSettings={setPanelSettings}
              showSuccess={showSuccess}
              showError={showError}
              onRefreshStats={fetchAdminData}
            />
          )}

          {/* ===================== TAB: USER LEDGER ===================== */}
          {activeTab === 'users' && (
            <div className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5 ${cardBgClasses}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black flex items-center gap-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    <span>User Ledger & Members ({usersList.length})</span>
                  </h2>
                  <p className="text-xs text-gray-500">
                    {clientMembersCount} Client Members · {adminUsersCount} Administrators ({usersList.length} Total Accounts)
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2.5">
                  {/* Role filter buttons */}
                  <div className={`p-1 rounded-xl border flex items-center space-x-1 ${
                    isDark ? 'bg-slate-800 border-slate-700' : 'bg-stone-100 border-stone-200'
                  }`}>
                    <button
                      type="button"
                      onClick={() => setUserRoleFilter('all')}
                      className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                        userRoleFilter === 'all'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'text-stone-500 hover:text-stone-900 dark:text-gray-400 dark:hover:text-white'
                      }`}
                    >
                      All ({usersList.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setUserRoleFilter('user')}
                      className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                        userRoleFilter === 'user'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'text-stone-500 hover:text-stone-900 dark:text-gray-400 dark:hover:text-white'
                      }`}
                    >
                      Members ({clientMembersCount})
                    </button>
                    <button
                      type="button"
                      onClick={() => setUserRoleFilter('admin')}
                      className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                        userRoleFilter === 'admin'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'text-stone-500 hover:text-stone-900 dark:text-gray-400 dark:hover:text-white'
                      }`}
                    >
                      Admins ({adminUsersCount})
                    </button>
                  </div>

                  <div className="relative">
                    <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search user name, email, or ID..."
                      value={userSearch}
                      onChange={(e) => setUserSearch(e.target.value)}
                      className={`pl-9 pr-4 py-2 rounded-xl text-xs border focus:outline-none focus:border-red-500 ${subCardBg}`}
                    />
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-gray-100 dark:border-gray-800">
                <table className="w-full text-left text-xs whitespace-nowrap">
                  <thead className={`font-mono text-[11px] font-black uppercase tracking-wider ${subCardBg} text-gray-600 dark:text-gray-300 border-b border-gray-200 dark:border-gray-800`}>
                    <tr>
                      <th className="py-3.5 px-4">ID</th>
                      <th className="py-3.5 px-4">USER</th>
                      <th className="py-3.5 px-4">ROLE</th>
                      <th className="py-3.5 px-4">TOTAL SPENT</th>
                      <th className="py-3.5 px-4">SAVED (BALANCE)</th>
                      <th className="py-3.5 px-4">LAST LOGIN TIME</th>
                      <th className="py-3.5 px-4">STATUS</th>
                      <th className="py-3.5 px-4 text-center">ACTIONS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-800 font-sans">
                    {usersList
                      .filter((u) => {
                        if (userRoleFilter !== 'all' && u.role !== userRoleFilter) return false;
                        if (!userSearch) return true;
                        const s = userSearch.toLowerCase();
                        return (
                          String(u.id).includes(s) ||
                          (u.name || '').toLowerCase().includes(s) ||
                          (u.email || '').toLowerCase().includes(s)
                        );
                      })
                      .map((u: any) => {
                        const totalSpentVal = Number(u.spent || u.totalSpent || 0).toFixed(2);
                        const savedBalanceVal = Number(u.saved !== undefined ? u.saved : u.balance || 0).toFixed(2);
                        const isSuspended = u.status === 'suspended';

                        // Format last login time
                        const formatLastLogin = (ts: any) => {
                          if (!ts) return 'Never';
                          try {
                            const d = new Date(ts);
                            return d.toLocaleString([], {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            });
                          } catch (e) {
                            return 'Never';
                          }
                        };

                        return (
                          <tr key={u.id} className="hover:bg-gray-50/70 dark:hover:bg-slate-800/40 transition-colors">
                            {/* 1. ID */}
                            <td className="py-3.5 px-4 font-mono font-black text-gray-900 dark:text-white">
                              #{u.id}
                            </td>

                            {/* 2. USER */}
                            <td className="py-3.5 px-4">
                              <span className="font-bold text-gray-900 dark:text-white block max-w-[160px] truncate">
                                {u.name || u.email?.split('@')[0] || `User #${u.id}`}
                              </span>
                              <span className="text-[10px] text-gray-400 font-mono block max-w-[160px] truncate">
                                {u.email}
                              </span>
                            </td>

                            {/* 3. ROLE */}
                            <td className="py-3.5 px-4">
                              <span
                                className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                                  u.role === 'admin'
                                    ? 'bg-red-500/10 text-red-600 border-red-500/25'
                                    : 'bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-gray-400 border-gray-200 dark:border-slate-700'
                                }`}
                              >
                                {u.role || 'USER'}
                              </span>
                            </td>

                            {/* 4. TOTAL SPENT */}
                            <td className="py-3.5 px-4 font-mono font-bold text-gray-900 dark:text-white">
                              ₹{totalSpentVal}
                            </td>

                            {/* 5. SAVED (BALANCE) */}
                            <td className="py-3.5 px-4 font-mono font-black text-emerald-600 dark:text-emerald-400">
                              ₹{savedBalanceVal}
                            </td>

                            {/* 6. LAST LOGIN TIME */}
                            <td className="py-3.5 px-4 font-mono text-[11px] text-gray-500 dark:text-gray-400">
                              {formatLastLogin(u.lastLoginAt || u.last_login_at)}
                            </td>

                            {/* 7. STATUS */}
                            <td className="py-3.5 px-4">
                              <span
                                className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${
                                  isSuspended
                                    ? 'bg-red-500/15 text-red-700 dark:text-red-400 border-red-500/30'
                                    : 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30'
                                }`}
                              >
                                {isSuspended ? 'Suspended' : 'Active'}
                              </span>
                            </td>

                            {/* 8. ACTIONS (4 BUTTONS EXACT MATCHING SCREENSHOT 2) */}
                            <td className="py-3.5 px-4 text-center">
                              <div className="flex items-center justify-center space-x-1.5">
                                {/* Button 1: Orders (x) */}
                                <button
                                  type="button"
                                  onClick={() => handleViewUserOrders(u)}
                                  className="bg-[#FEF3C7] hover:bg-[#FDE68A] text-[#92400E] border border-[#FCD34D] px-3 py-1.5 rounded-xl font-bold text-xs flex items-center space-x-1 transition-all cursor-pointer shadow-2xs"
                                  title="View orders for this user"
                                >
                                  <span>📦</span>
                                  <span>Orders ({u.ordersCount || 0})</span>
                                </button>

                                {/* Button 2: Login (Impersonation) */}
                                <button
                                  type="button"
                                  onClick={() => handleLoginAsUser(u)}
                                  className="bg-[#DBEAFE] hover:bg-[#BFDBFE] text-[#1D4ED8] border border-[#93C5FD] px-3 py-1.5 rounded-xl font-bold text-xs flex items-center space-x-1 transition-all cursor-pointer shadow-2xs"
                                  title="Direct Login as this user"
                                >
                                  <span>↪]</span>
                                  <span>Login</span>
                                </button>

                                {/* Button 3: Add Funds */}
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSelectedUserForFunds(u);
                                    setFundAmountInput('');
                                    setFundActionType('add');
                                    setFundNoteInput('Admin manual credit');
                                  }}
                                  className="bg-[#F3E8FF] hover:bg-[#E9D5FF] text-[#7E22CE] border border-[#D8B4FE] px-3 py-1.5 rounded-xl font-bold text-xs flex items-center space-x-1 transition-all cursor-pointer shadow-2xs"
                                  title="Add or adjust wallet balance"
                                >
                                  <span>Add Funds</span>
                                </button>

                                {/* Button 4: Suspend / Activate */}
                                <button
                                  type="button"
                                  onClick={() => handleToggleSuspendUser(u)}
                                  className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center space-x-1 transition-all cursor-pointer shadow-2xs ${
                                    isSuspended
                                      ? 'bg-[#DCFCE7] hover:bg-[#BBF7D0] text-[#166534] border border-[#86EFAC]'
                                      : 'bg-[#FEE2E2] hover:bg-[#FECACA] text-[#991B1B] border border-[#FCA5A5]'
                                  }`}
                                  title={isSuspended ? 'Activate account' : 'Suspend account'}
                                >
                                  <span>{isSuspended ? 'Activate' : 'Suspend'}</span>
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ===================== TAB: ORDER PIPELINE ===================== */}
          {activeTab === 'orders' && (
            <div className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5 ${cardBgClasses}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black flex items-center gap-2">
                    <LinkIcon className="w-5 h-5 text-orange-500" />
                    <span>Order Pipeline ({orders.length} Orders)</span>
                  </h2>
                  <p className="text-xs text-gray-500">Live order progression, seller upstream IDs, counts, remains, and pipeline status.</p>
                </div>

                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={async () => {
                      setLoading(true);
                      try {
                        const res = await fetch('/api/admin/orders?sync=true', {
                          headers: { Authorization: `Bearer ${token}` }
                        });
                        if (res.ok) {
                          const data = await res.json();
                          setOrders(data);
                          showSuccess('Orders synced with upstream Seller APIs!');
                        }
                      } catch (e) {
                        showError('Sync failed.');
                      } finally {
                        setLoading(false);
                      }
                    }}
                    disabled={loading}
                    className="px-3.5 py-2 rounded-xl bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 dark:text-orange-400 font-bold text-xs flex items-center space-x-1.5 transition-all cursor-pointer border border-orange-500/20"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                    <span>Sync Provider Statuses</span>
                  </button>

                  <div className="relative">
                    <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search ID, user, seller ID, link..."
                      value={orderSearch}
                      onChange={(e) => setOrderSearch(e.target.value)}
                      className={`pl-9 pr-4 py-2 rounded-xl text-xs border focus:outline-none focus:border-red-500 ${subCardBg}`}
                    />
                  </div>
                </div>
              </div>

              {/* Status Filters */}
              <div className="flex flex-wrap gap-1.5 border-b border-gray-100 dark:border-gray-800 pb-3">
                {['all', 'pending', 'in_progress', 'processing', 'completed', 'partial', 'cancelled'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setOrderStatusFilter(st)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                      orderStatusFilter === st
                        ? 'bg-[#DC2626] text-white shadow-xs'
                        : 'bg-stone-100 dark:bg-slate-800 text-gray-600 dark:text-gray-400 hover:text-gray-900'
                    }`}
                  >
                    {st === 'in_progress' ? 'In Progress' : st}
                  </button>
                ))}
              </div>

              {/* EXACT COLUMNS MATCHING USER'S SCREENSHOTS */}
              <div className="overflow-x-auto rounded-2xl border border-gray-100 dark:border-gray-800">
                <table className="w-full text-left text-xs whitespace-nowrap">
                  <thead className={`font-mono text-[11px] font-black uppercase tracking-wider ${subCardBg} text-gray-600 dark:text-gray-300 border-b border-gray-200 dark:border-gray-800`}>
                    <tr>
                      <th className="py-3.5 px-4">ID</th>
                      <th className="py-3.5 px-4">USER</th>
                      <th className="py-3.5 px-4">SERVICE</th>
                      <th className="py-3.5 px-4">SELLER / API ID</th>
                      <th className="py-3.5 px-4">LINK</th>
                      <th className="py-3.5 px-4 text-center">QTY</th>
                      <th className="py-3.5 px-4 text-center">START COUNT</th>
                      <th className="py-3.5 px-4 text-center">REMAINS</th>
                      <th className="py-3.5 px-4">CHARGE</th>
                      <th className="py-3.5 px-4">PIPELINE STATE</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-800 font-sans">
                    {orders
                      .filter((o) => {
                        const matchesFilter =
                          orderStatusFilter === 'all' ||
                          (orderStatusFilter === 'in_progress' && (o.status === 'in_progress' || o.status === 'processing')) ||
                          o.status === orderStatusFilter;
                        const matchesSearch =
                          !orderSearch ||
                          String(o.id).includes(orderSearch) ||
                          String(o.providerOrderId || '').includes(orderSearch) ||
                          (o.link || '').toLowerCase().includes(orderSearch.toLowerCase()) ||
                          (o.serviceName || '').toLowerCase().includes(orderSearch.toLowerCase()) ||
                          (o.userName || '').toLowerCase().includes(orderSearch.toLowerCase()) ||
                          (o.userEmail || '').toLowerCase().includes(orderSearch.toLowerCase());
                        return matchesFilter && matchesSearch;
                      })
                      .map((o) => {
                        const statusColors: Record<string, string> = {
                          completed: 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30',
                          in_progress: 'bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30',
                          processing: 'bg-blue-500/15 text-blue-700 dark:text-blue-400 border-blue-500/30',
                          pending: 'bg-amber-500/15 text-amber-800 dark:text-amber-400 border-amber-500/30',
                          partial: 'bg-purple-500/15 text-purple-700 dark:text-purple-400 border-purple-500/30',
                          cancelled: 'bg-red-500/15 text-red-700 dark:text-red-400 border-red-500/30',
                        };

                        const currentBadgeColor = statusColors[o.status] || 'bg-gray-100 text-gray-700 border-gray-300';

                        return (
                          <tr key={o.id} className="hover:bg-gray-50/70 dark:hover:bg-slate-800/40 transition-colors">
                            {/* 1. ID */}
                            <td className="py-3.5 px-4 font-mono font-black text-gray-900 dark:text-white">
                              #{o.id}
                            </td>

                            {/* 2. USER */}
                            <td className="py-3.5 px-4">
                              <span className="font-bold text-gray-900 dark:text-white block max-w-[140px] truncate">
                                {o.userName || o.userEmail?.split('@')[0] || `User #${o.userId}`}
                              </span>
                              <span className="text-[10px] text-gray-400 font-mono block max-w-[140px] truncate">
                                {o.userEmail || `ID #${o.userId}`}
                              </span>
                            </td>

                            {/* 3. SERVICE */}
                            <td className="py-3.5 px-4">
                              <span className="font-semibold block max-w-[200px] truncate" title={o.serviceName}>
                                {o.serviceName || `Service #${o.serviceId}`}
                              </span>
                              <span className="text-[10px] font-mono text-gray-400">
                                Srv #{o.serviceId}
                              </span>
                            </td>

                            {/* 4. SELLER / API ID */}
                            <td className="py-3.5 px-4 font-mono">
                              {o.providerOrderId ? (
                                <div className="space-y-0.5">
                                  <span className="font-bold text-indigo-600 dark:text-indigo-400 block">
                                    #{o.providerOrderId}
                                  </span>
                                  {o.providerName && (
                                    <span className="text-[10px] text-gray-400 block font-sans">
                                      {o.providerName}
                                    </span>
                                  )}
                                </div>
                              ) : (
                                <span className="text-amber-600 dark:text-amber-400 font-bold text-[11px] bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                                  Unassigned
                                </span>
                              )}
                            </td>

                            {/* 5. LINK */}
                            <td className="py-3.5 px-4 font-mono">
                              <a
                                href={o.link.startsWith('http') ? o.link : `https://${o.link}`}
                                target="_blank"
                                rel="noreferrer"
                                className="text-red-600 hover:text-red-700 hover:underline inline-flex items-center gap-1.5 max-w-[180px] truncate font-medium"
                              >
                                <span className="truncate">{o.link}</span>
                                <ExternalLink className="w-3 h-3 shrink-0" />
                              </a>
                            </td>

                            {/* 6. QTY */}
                            <td className="py-3.5 px-4 font-mono font-bold text-center text-gray-800 dark:text-gray-200">
                              {Number(o.quantity).toLocaleString()}
                            </td>

                            {/* 7. START COUNT */}
                            <td className="py-3.5 px-4 font-mono text-center text-gray-600 dark:text-gray-400">
                              {Number(o.startCount || 0).toLocaleString()}
                            </td>

                            {/* 8. REMAINS */}
                            <td className="py-3.5 px-4 font-mono font-bold text-center text-amber-600 dark:text-amber-400">
                              {Number(o.remains !== undefined && o.remains !== null ? o.remains : (o.status === 'completed' ? 0 : o.quantity)).toLocaleString()}
                            </td>

                            {/* 9. CHARGE */}
                            <td className="py-3.5 px-4 font-mono font-black text-emerald-600 dark:text-emerald-400">
                              ₹{Number(o.charge).toFixed(2)}
                            </td>

                            {/* 10. PIPELINE STATE */}
                            <td className="py-3.5 px-4">
                              <div className="flex items-center space-x-2">
                                <span
                                  className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${currentBadgeColor}`}
                                >
                                  {o.status.replace('_', ' ')}
                                </span>

                                <select
                                  value={o.status}
                                  onChange={(e) => handleUpdateOrderStatus(o.id, e.target.value)}
                                  className="px-2 py-1 rounded-lg text-[10px] font-bold bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 focus:outline-none"
                                >
                                  <option value="pending">Pending</option>
                                  <option value="in_progress">In Progress</option>
                                  <option value="completed">Completed</option>
                                  <option value="partial">Partial</option>
                                  <option value="cancelled">Cancelled</option>
                                </select>

                                {!o.providerOrderId && (
                                  <button
                                    onClick={() => handleDispatchOrder(o.id)}
                                    className="px-2.5 py-1 bg-[#DC2626] hover:bg-red-700 text-white font-black text-[10px] rounded-lg cursor-pointer shadow-xs transition-colors"
                                    title="Dispatch to upstream SMM API"
                                  >
                                    Dispatch
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ===================== TAB: CATALOG MANAGER (SERVICES & CATEGORIES) ===================== */}
          {activeTab === 'services' && (
            <CatalogManager
              token={token}
              categoriesList={categoriesList}
              servicesList={servicesList}
              providersList={providersList}
              onRefresh={fetchAdminData}
              showSuccess={showSuccess}
              showError={showError}
              isLight={isLight}
              cardBgClasses={cardBgClasses}
              subCardBg={subCardBg}
            />
          )}

          {/* ===================== TAB: PROMOS & COUPONS ===================== */}
          {activeTab === 'promos' && (
            <PromoBannerManager
              panelSettings={panelSettings}
              setPanelSettings={setPanelSettings}
              token={token}
              showSuccess={showSuccess}
              showError={showError}
            />
          )}

          {/* ===================== TAB: API PROVIDERS ===================== */}
          {activeTab === 'providers' && (
            <ApiProvidersManager
              token={token}
              providers={providersList}
              servicesList={servicesList}
              onRefreshProviders={fetchAdminData}
              showSuccess={showSuccess}
              showError={showError}
              isLight={isLight}
              cardBgClasses={cardBgClasses}
              subCardBg={subCardBg}
            />
          )}

          {/* ===================== TAB: MANUAL SELLER SYNC ===================== */}
          {activeTab === 'seller_sync' && (
            <ManualSellerSync
              token={token}
              providersList={providersList}
              servicesList={servicesList}
              onRefresh={fetchAdminData}
              showSuccess={showSuccess}
              showError={showError}
              isLight={isLight}
              cardBgClasses={cardBgClasses}
              subCardBg={subCardBg}
            />
          )}

          {/* ===================== TAB: PANEL SETTINGS ===================== */}
          {activeTab === 'settings' && (
            <PanelSettingsManager
              token={token}
              panelSettings={panelSettings}
              setPanelSettings={setPanelSettings}
              onNavigateToPayments={() => setActiveTab('payment_settings')}
              showSuccess={showSuccess}
              showError={showError}
              isLight={isLight}
              cardBgClasses={cardBgClasses}
              subCardBg={subCardBg}
            />
          )}

          {/* ===================== TAB: CHILD PANELS MANAGER ===================== */}
          {activeTab === 'child_panels' && (
            <div className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-6 ${cardBgClasses}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
                    <span>Child Panels Manager</span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-indigo-500/10 text-indigo-600 border border-indigo-500/20">
                      {childPanels.length} Registered
                    </span>
                  </h2>
                  <p className="text-xs text-gray-400 mt-0.5">
                    Manage client white-label reseller child panels, approve domains, and control operational status.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={fetchAdminData}
                  className="px-3.5 py-2 rounded-xl border text-xs font-bold flex items-center space-x-1.5 cursor-pointer self-start sm:self-auto hover:bg-stone-50 dark:hover:bg-slate-800"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh Panels</span>
                </button>
              </div>

              {/* Child Panels Table */}
              <div className="overflow-x-auto rounded-2xl border border-stone-200 dark:border-slate-800">
                <table className="w-full text-left text-xs">
                  <thead className={`border-b border-stone-200 dark:border-slate-800 text-gray-400 font-mono text-[11px] uppercase ${subCardBg}`}>
                    <tr>
                      <th className="py-3.5 px-4 font-bold">ID / Domain</th>
                      <th className="py-3.5 px-4 font-bold">User</th>
                      <th className="py-3.5 px-4 font-bold">Admin Creds</th>
                      <th className="py-3.5 px-4 font-bold">Price / Mo</th>
                      <th className="py-3.5 px-4 font-bold">Status</th>
                      <th className="py-3.5 px-4 font-bold">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 dark:divide-slate-800/80">
                    {childPanels.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-gray-400 text-xs">
                          No child panel requests yet. Users can order child panels directly from their User Dashboard.
                        </td>
                      </tr>
                    ) : (
                      childPanels.map((cp) => (
                        <tr key={cp.id} className="hover:bg-stone-50/50 dark:hover:bg-slate-800/30 transition-colors">
                          <td className="py-3.5 px-4">
                            <span className="font-mono text-gray-400 block text-[10px]">#{cp.id}</span>
                            <span className="font-black text-sm text-indigo-600 dark:text-indigo-400 block">
                              {cp.domain}
                            </span>
                            <span className="text-[10px] text-gray-400">
                              {new Date(cp.createdAt).toLocaleDateString()}
                            </span>
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="font-bold block">{cp.userName || `User #${cp.userId}`}</span>
                            <span className="font-mono text-[11px] text-gray-400">{cp.userEmail}</span>
                          </td>
                          <td className="py-3.5 px-4 font-mono text-[11px]">
                            <div>User: <strong className="text-gray-700 dark:text-gray-300">{cp.adminUsername}</strong></div>
                            <div className="text-gray-400">Pass: ••••••••</div>
                          </td>
                          <td className="py-3.5 px-4 font-mono font-bold text-emerald-600">
                            ₹{Number(cp.price || 1500).toFixed(2)}
                          </td>
                          <td className="py-3.5 px-4">
                            <span
                              className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider inline-block ${
                                cp.status === 'active'
                                  ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                                  : cp.status === 'terminated'
                                  ? 'bg-rose-500/10 text-rose-600 border border-rose-500/20'
                                  : 'bg-amber-500/10 text-amber-600 border border-amber-500/20'
                              }`}
                            >
                              {cp.status || 'pending'}
                            </span>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="flex items-center space-x-1.5">
                              {cp.status !== 'active' && (
                                <button
                                  type="button"
                                  onClick={() => handleUpdateChildPanelStatus(cp.id, 'active')}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-black transition-all cursor-pointer shadow-xs"
                                >
                                  Activate
                                </button>
                              )}
                              {cp.status !== 'terminated' && (
                                <button
                                  type="button"
                                  onClick={() => handleUpdateChildPanelStatus(cp.id, 'terminated')}
                                  className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[10px] font-black transition-all cursor-pointer shadow-xs"
                                >
                                  Terminate
                                </button>
                              )}
                              {cp.status !== 'pending' && (
                                <button
                                  type="button"
                                  onClick={() => handleUpdateChildPanelStatus(cp.id, 'pending')}
                                  className="px-2 py-1 bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 text-gray-800 dark:text-gray-200 rounded-lg text-[10px] font-bold transition-all cursor-pointer"
                                >
                                  Pending
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ===================== TAB: SUPPORT TICKETS DESK ===================== */}
          {activeTab === 'support' && (
            <div className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-6 ${cardBgClasses}`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
                    <span>Customer Support Helpdesk</span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-blue-500/10 text-blue-600 border border-blue-500/20">
                      {ticketsList.length} Tickets
                    </span>
                  </h2>
                  <p className="text-xs text-gray-400 mt-0.5">
                    Resolve user disputes, payment UTR verifications, refill requests, and general questions.
                  </p>
                </div>

                {/* Status Filter Buttons */}
                <div className="flex items-center space-x-1.5 self-start sm:self-auto bg-stone-100 dark:bg-slate-800 p-1 rounded-xl">
                  {['all', 'open', 'answered', 'closed'].map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setTicketFilterStatus(st)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                        ticketFilterStatus === st
                          ? 'bg-red-600 text-white shadow-xs'
                          : 'text-gray-500 hover:text-gray-900 dark:hover:text-white'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Grid: Tickets List on Left, Active Conversation Thread on Right */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                {/* Tickets Master List */}
                <div className="lg:col-span-5 space-y-2.5">
                  {ticketsList
                    .filter((t) => (ticketFilterStatus === 'all' ? true : t.status === ticketFilterStatus))
                    .map((t) => {
                      const isSelected = selectedTicket?.id === t.id;
                      return (
                        <div
                          key={t.id}
                          onClick={() => handleSelectTicket(t)}
                          className={`p-4 rounded-2xl border transition-all cursor-pointer select-none ${
                            isSelected
                              ? 'border-red-500 bg-red-500/5 shadow-xs ring-1 ring-red-500/40'
                              : 'border-stone-200 dark:border-slate-800 hover:bg-stone-50 dark:hover:bg-slate-800/40'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-mono text-gray-400 text-[10px] font-bold">Ticket #{t.id}</span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                                t.status === 'open'
                                  ? 'bg-amber-500/10 text-amber-600 border border-amber-500/20'
                                  : t.status === 'answered'
                                  ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                                  : 'bg-gray-500/10 text-gray-500 border border-gray-500/20'
                              }`}
                            >
                              {t.status || 'open'}
                            </span>
                          </div>
                          <h4 className="font-extrabold text-xs text-gray-900 dark:text-white mt-1 leading-snug line-clamp-1">
                            {t.subject}
                          </h4>
                          <div className="flex items-center justify-between text-[11px] text-gray-400 mt-2">
                            <span className="truncate max-w-[150px]">{t.userName || t.userEmail}</span>
                            <span className="font-mono text-[10px]">{new Date(t.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      );
                    })}

                  {ticketsList.length === 0 && (
                    <div className="p-8 rounded-2xl border text-center text-gray-400 text-xs">
                      No support tickets recorded yet.
                    </div>
                  )}
                </div>

                {/* Conversation Thread & Reply Panel */}
                <div className="lg:col-span-7">
                  {selectedTicket ? (
                    <div className={`rounded-2xl border border-stone-200 dark:border-slate-800 p-5 space-y-4 ${subCardBg}`}>
                      {/* Ticket Header & Status switcher */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-stone-200 dark:border-slate-800">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-mono text-xs text-gray-400 font-bold">#{selectedTicket.id}</span>
                            <h3 className="font-black text-sm">{selectedTicket.subject}</h3>
                          </div>
                          <span className="text-xs text-gray-400 block mt-0.5">
                            From: {selectedTicket.userName || selectedTicket.userEmail}
                          </span>
                        </div>

                        <div className="flex items-center space-x-1.5">
                          <button
                            type="button"
                            onClick={() => handleUpdateTicketStatus(selectedTicket.id, 'open')}
                            className="px-2.5 py-1 rounded-lg text-[10px] font-bold border border-amber-500/30 text-amber-600 hover:bg-amber-500/10 cursor-pointer"
                          >
                            Mark Open
                          </button>
                          <button
                            type="button"
                            onClick={() => handleUpdateTicketStatus(selectedTicket.id, 'answered')}
                            className="px-2.5 py-1 rounded-lg text-[10px] font-bold border border-emerald-500/30 text-emerald-600 hover:bg-emerald-500/10 cursor-pointer"
                          >
                            Mark Answered
                          </button>
                          <button
                            type="button"
                            onClick={() => handleUpdateTicketStatus(selectedTicket.id, 'closed')}
                            className="px-2.5 py-1 rounded-lg text-[10px] font-bold border border-gray-400/30 text-gray-500 hover:bg-gray-500/10 cursor-pointer"
                          >
                            Close Ticket
                          </button>
                        </div>
                      </div>

                      {/* Messages Thread */}
                      <div className="space-y-3 max-h-[360px] overflow-y-auto p-1">
                        {loadingTicketMessages ? (
                          <div className="py-8 text-center text-xs text-gray-400">Loading conversation...</div>
                        ) : ticketMessages.length === 0 ? (
                          <div className="py-8 text-center text-xs text-gray-400">No message history.</div>
                        ) : (
                          ticketMessages.map((m) => {
                            const isAdminMsg = m.senderRole === 'admin';
                            return (
                              <div
                                key={m.id}
                                className={`flex flex-col ${isAdminMsg ? 'items-end' : 'items-start'}`}
                              >
                                <div className="flex items-center space-x-1.5 mb-1 text-[10px] text-gray-400">
                                  <span>{isAdminMsg ? 'Support Agent (Admin)' : m.senderName || 'Client'}</span>
                                  <span>·</span>
                                  <span>{new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                </div>
                                <div
                                  className={`p-3.5 rounded-2xl max-w-[85%] text-xs leading-relaxed ${
                                    isAdminMsg
                                      ? 'bg-red-600 text-white rounded-tr-xs'
                                      : 'bg-white dark:bg-slate-800 border border-stone-200 dark:border-slate-700 text-gray-800 dark:text-gray-200 rounded-tl-xs'
                                  }`}
                                >
                                  {m.message}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>

                      {/* Reply Form */}
                      <form onSubmit={handleSendTicketReply} className="pt-2 border-t border-stone-200 dark:border-slate-800 space-y-2.5">
                        <textarea
                          rows={3}
                          required
                          placeholder="Type an official resolution or reply to the user..."
                          value={adminTicketReply}
                          onChange={(e) => setAdminTicketReply(e.target.value)}
                          className="w-full p-3 rounded-xl border border-stone-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-red-500"
                        />
                        <div className="flex items-center justify-end">
                          <button
                            type="submit"
                            disabled={sendingTicketReply || !adminTicketReply.trim()}
                            className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs shadow-md transition-all cursor-pointer disabled:opacity-50"
                          >
                            {sendingTicketReply ? 'Sending Reply...' : 'Send Reply as Support'}
                          </button>
                        </div>
                      </form>
                    </div>
                  ) : (
                    <div className="p-12 rounded-2xl border border-dashed border-stone-300 dark:border-slate-800 text-center text-gray-400 text-xs space-y-1">
                      <MessageSquare className="w-8 h-8 mx-auto text-gray-300 dark:text-slate-700 mb-2" />
                      <p className="font-bold">Select a ticket from the left column</p>
                      <p className="text-[11px]">Click any ticket to read messages and post support replies.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ===================== TAB: OTHER SECTIONS (PLACEHOLDERS) ===================== */}
          {[
            'refills',
            'appointments',
            'broadcasts',
            'blogs',
            'logs',
          ].includes(activeTab) && (
            <div className={`rounded-3xl p-6 sm:p-8 border shadow-xs space-y-5 ${cardBgClasses}`}>
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-black capitalize">
                    {activeTab.replace('_', ' ')} Manager
                  </h2>
                  <p className="text-xs text-gray-500">
                    Live production controls for {activeTab.replace('_', ' ')}.
                  </p>
                </div>
                <button
                  onClick={fetchAdminData}
                  className="px-3.5 py-1.5 rounded-xl border text-xs font-bold flex items-center space-x-1 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Refresh</span>
                </button>
              </div>

              <div className={`p-8 rounded-2xl border text-center ${subCardBg} space-y-3`}>
                <div className="w-12 h-12 rounded-2xl bg-red-500/10 text-red-600 mx-auto flex items-center justify-center font-bold">
                  <Shield className="w-6 h-6" />
                </div>
                <h3 className="font-black text-base capitalize">
                  {activeTab.replace('_', ' ')} Operational
                </h3>
                <p className="text-xs text-gray-400 max-w-md mx-auto">
                  All systems active and connected to live database. Use sidebar tabs to manage BharatPe Payments,
                  Payment Settings, Users, Orders, and Promos.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => setActiveTab('analytics')}
                    className="px-4 py-2 rounded-xl bg-red-600 text-white font-bold text-xs"
                  >
                    Back to Analytics Dashboard
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* ===================== MODAL: USER ORDERS LIST ===================== */}
      {selectedUserForOrders && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-3xl rounded-3xl p-6 sm:p-7 border shadow-2xl space-y-5 animate-in fade-in zoom-in-95 ${
              isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-4">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-lg font-black">
                    Orders by {selectedUserForOrders.name || selectedUserForOrders.email}
                  </span>
                  <span className="bg-[#FEF3C7] text-[#92400E] text-[10px] font-black px-2.5 py-0.5 rounded-full border border-[#FCD34D]">
                    User #{selectedUserForOrders.id}
                  </span>
                </div>
                <span className="text-xs text-gray-400 block mt-0.5">
                  Total Spent: ₹{Number(selectedUserForOrders.spent || 0).toFixed(2)} · Balance: ₹{Number(selectedUserForOrders.balance || 0).toFixed(2)}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedUserForOrders(null)}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-gray-500 hover:text-gray-900 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {loadingUserOrders ? (
              <div className="py-12 text-center text-xs text-gray-400 flex items-center justify-center space-x-2">
                <RefreshCw className="w-4 h-4 animate-spin text-red-600" />
                <span>Loading orders...</span>
              </div>
            ) : userOrdersList.length === 0 ? (
              <div className="py-12 text-center text-xs text-gray-400">
                <span>No orders placed yet by this user.</span>
              </div>
            ) : (
              <div className="overflow-x-auto max-h-[380px] rounded-2xl border border-gray-100 dark:border-gray-800">
                <table className="w-full text-left text-xs whitespace-nowrap">
                  <thead className={`font-mono text-[11px] font-bold ${subCardBg} text-gray-400 sticky top-0`}>
                    <tr>
                      <th className="py-2.5 px-3">Order ID</th>
                      <th className="py-2.5 px-3">Service</th>
                      <th className="py-2.5 px-3">Qty</th>
                      <th className="py-2.5 px-3">Charge</th>
                      <th className="py-2.5 px-3">Status</th>
                      <th className="py-2.5 px-3">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-800 font-sans">
                    {userOrdersList.map((ord: any) => (
                      <tr key={ord.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/40">
                        <td className="py-2.5 px-3 font-mono font-bold">#{ord.id}</td>
                        <td className="py-2.5 px-3 truncate max-w-[200px]">{ord.serviceName || `Service #${ord.serviceId}`}</td>
                        <td className="py-2.5 px-3 font-mono">{Number(ord.quantity).toLocaleString()}</td>
                        <td className="py-2.5 px-3 font-mono font-bold text-emerald-600">₹{Number(ord.charge).toFixed(2)}</td>
                        <td className="py-2.5 px-3">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-blue-500/10 text-blue-600">
                            {ord.status}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-gray-400 text-[11px]">
                          {new Date(ord.createdAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ===================== MODAL: ADD / ADJUST USER FUNDS ===================== */}
      {selectedUserForFunds && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-3xl p-6 sm:p-7 border shadow-2xl space-y-5 animate-in fade-in zoom-in-95 ${
              isLight ? 'bg-white border-stone-200 text-gray-900' : 'bg-slate-900 border-slate-800 text-white'
            }`}
          >
            <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3">
              <div>
                <h3 className="text-lg font-black">Manage User Funds</h3>
                <span className="text-xs text-gray-400 font-mono">
                  {selectedUserForFunds.email} (Current: ₹{Number(selectedUserForFunds.balance || 0).toFixed(2)})
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedUserForFunds(null)}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-slate-800 flex items-center justify-center text-gray-500 hover:text-gray-900 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddFundsSubmit} className="space-y-4">
              {/* Action type buttons */}
              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 mb-1.5">Action Type</label>
                <div className="grid grid-cols-3 gap-2 text-xs font-bold">
                  <button
                    type="button"
                    onClick={() => setFundActionType('add')}
                    className={`py-2 px-3 rounded-xl border text-center transition-all ${
                      fundActionType === 'add'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-stone-50 dark:bg-slate-800 border-stone-200 dark:border-slate-700 text-gray-600'
                    }`}
                  >
                    + Add Funds
                  </button>
                  <button
                    type="button"
                    onClick={() => setFundActionType('deduct')}
                    className={`py-2 px-3 rounded-xl border text-center transition-all ${
                      fundActionType === 'deduct'
                        ? 'bg-red-600 text-white border-red-600 shadow-xs'
                        : 'bg-stone-50 dark:bg-slate-800 border-stone-200 dark:border-slate-700 text-gray-600'
                    }`}
                  >
                    - Deduct
                  </button>
                  <button
                    type="button"
                    onClick={() => setFundActionType('set')}
                    className={`py-2 px-3 rounded-xl border text-center transition-all ${
                      fundActionType === 'set'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-stone-50 dark:bg-slate-800 border-stone-200 dark:border-slate-700 text-gray-600'
                    }`}
                  >
                    = Set Exact
                  </button>
                </div>
              </div>

              {/* Amount input */}
              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 mb-1.5">Amount (INR ₹)</label>
                <input
                  type="number"
                  step="any"
                  required
                  placeholder="e.g. 500"
                  value={fundAmountInput}
                  onChange={(e) => setFundAmountInput(e.target.value)}
                  className={`w-full px-4 py-3 rounded-2xl text-xs font-mono font-bold border focus:outline-none focus:ring-2 focus:ring-red-500/30 ${
                    isLight ? 'bg-stone-50 border-stone-200' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              {/* Reason / Note input */}
              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 mb-1.5">Note / Reason</label>
                <input
                  type="text"
                  placeholder="e.g. Bank transfer UTR verified"
                  value={fundNoteInput}
                  onChange={(e) => setFundNoteInput(e.target.value)}
                  className={`w-full px-4 py-2.5 rounded-2xl text-xs border focus:outline-none ${
                    isLight ? 'bg-stone-50 border-stone-200' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              <div className="pt-2 flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => setSelectedUserForFunds(null)}
                  className="flex-1 py-3 rounded-2xl border text-xs font-bold text-gray-600 hover:bg-stone-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-2xl bg-[#DC2626] hover:bg-red-700 text-white font-black text-xs shadow-md transition-all cursor-pointer"
                >
                  Apply Balance
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================== ADMIN MOBILE FULL NAVIGATION DRAWER ===================== */}
      {adminMobileDrawerOpen && (
        <div className="fixed inset-0 z-50 flex justify-start animate-in fade-in lg:hidden select-none">
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => setAdminMobileDrawerOpen(false)}
          />

          {/* Drawer Sheet */}
          <div
            className={`relative w-[85vw] max-w-sm h-full shadow-2xl p-5 flex flex-col justify-between overflow-y-auto z-10 ${
              isEspresso
                ? 'bg-[#181411] text-[#EFEBE8] border-r border-[#362D26]'
                : isDark
                ? 'bg-[#0B0F19] text-white border-r border-slate-800'
                : 'bg-[#FBF9F5] text-gray-900 border-r border-stone-200'
            }`}
          >
            <div className="space-y-4">
              {/* Header */}
              <div className="flex items-center justify-between border-b pb-3 border-gray-200 dark:border-slate-800">
                <div className="flex items-center space-x-2">
                  <AnimatedLogo size="xs" showText={true} theme={isLight ? 'light' : 'dark'} />
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-red-500/10 text-red-500 border border-red-500/25">
                    ADMIN
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setAdminMobileDrawerOpen(false)}
                  className="w-8 h-8 rounded-full bg-black/5 dark:bg-white/10 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* 17 Navigation Items */}
              <nav className="space-y-1 text-[13.5px]">
                {adminNavMenuItems.map((item) => renderSidebarItem(item, true))}
              </nav>
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-gray-200 dark:border-slate-800 space-y-2">
              <button
                type="button"
                onClick={() => {
                  setAdminMobileDrawerOpen(false);
                  onSwitchToUser();
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-[#2563EB] hover:bg-blue-700 text-white font-extrabold text-xs shadow-sm flex items-center justify-center space-x-2 transition-all cursor-pointer"
              >
                <span>User Dashboard View</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setAdminMobileDrawerOpen(false);
                  onLogout();
                }}
                className="w-full py-2 px-4 rounded-xl text-xs font-bold text-stone-700 dark:text-gray-300 hover:text-red-600 dark:hover:text-red-400 transition-colors flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
