import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";

const { Pool } = pg;

export function sanitizeDbErrorMessage(messageOrError: any): string {
  if (!messageOrError) return "Unknown database error";
  const raw = typeof messageOrError === "string" ? messageOrError : messageOrError.message || String(messageOrError);
  return raw
    .replace(/(postgres(?:ql)?:\/\/[^:]+:)([^@]+)(@)/gi, "$1***$3")
    .replace(/(password=)[^&;\s]+/gi, "$1***")
    .replace(/(token=)[^&;\s]+/gi, "$1***")
    .replace(/(key=)[a-zA-Z0-9_\-\.]+/gi, "$1***");
}

export function normalizeDatabaseUrl(raw?: string): string | undefined {
  if (!raw) return undefined;
  let url = raw.trim();
  url = url.replace(/:\[([^\]]+)\]@/, (m, p) => ":" + encodeURIComponent(p) + "@");
  const match = url.match(/^(postgres(?:ql)?:\/\/[^:]+):([^@]+)@(.+)$/);
  if (match) {
    const [, protocolAndUser, rawPassword, rest] = match;
    if (
      rawPassword.includes("@") ||
      rawPassword.includes("#") ||
      rawPassword.includes("[") ||
      rawPassword.includes("]")
    ) {
      const decoded = decodeURIComponent(rawPassword);
      url = `${protocolAndUser}:${encodeURIComponent(decoded)}@${rest}`;
    }
  }
  if (url.includes("db.ixhkffzlxawrbvchfcta.supabase.co")) {
    url = url
      .replace("postgresql://postgres:", "postgresql://postgres.ixhkffzlxawrbvchfcta:")
      .replace("postgres://postgres:", "postgres://postgres.ixhkffzlxawrbvchfcta:")
      .replace("db.ixhkffzlxawrbvchfcta.supabase.co:5432", "aws-0-ap-northeast-2.pooler.supabase.com:6543")
      .replace("db.ixhkffzlxawrbvchfcta.supabase.co", "aws-0-ap-northeast-2.pooler.supabase.com:6543");
  }
  return url;
}

const isServerless = Boolean(
  process.env.VERCEL ||
  process.env.AWS_LAMBDA_FUNCTION_NAME ||
  process.env.NETLIFY ||
  process.env.SERVERLESS
);

export const getPoolMax = (isSupabase = false): number => {
  if (process.env.DB_POOL_MAX) {
    const parsed = parseInt(process.env.DB_POOL_MAX, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  // Conservative serverless pool size: Supabase session pool limit is strictly 15 clients.
  // Using max: 1 per instance prevents multiple warm lambdas from exhausting pool_size: 15.
  return isServerless || isSupabase ? 1 : 2;
};

export const getIdleTimeoutMillis = (): number => {
  if (process.env.DB_POOL_IDLE_TIMEOUT) {
    const parsed = parseInt(process.env.DB_POOL_IDLE_TIMEOUT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  // 5 seconds idle timeout ensures idle connections are returned promptly
  return 5000;
};

export const getConnectionTimeoutMillis = (): number => {
  if (process.env.DB_POOL_CONN_TIMEOUT) {
    const parsed = parseInt(process.env.DB_POOL_CONN_TIMEOUT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  return 8000;
};

export const createPool = () => {
  const idleTimeout = getIdleTimeoutMillis();
  const connTimeout = getConnectionTimeoutMillis();

  if (
    process.env.SQL_HOST &&
    (process.env.SQL_USER || process.env.SQL_ADMIN_USER) &&
    (process.env.SQL_PASSWORD || process.env.SQL_ADMIN_PASSWORD)
  ) {
    const user = process.env.SQL_USER || process.env.SQL_ADMIN_USER || "ai_studio_app_user";
    const password = process.env.SQL_PASSWORD || process.env.SQL_ADMIN_PASSWORD || "";
    const host = process.env.SQL_HOST;
    const database = process.env.SQL_DB_NAME || "cloud_sql_development_database";
    const isSocket = host.startsWith("/");
    const max = getPoolMax(false);

    return new Pool({
      host,
      port: parseInt(process.env.SQL_PORT || "5432", 10),
      user,
      password,
      database,
      ssl: isSocket || process.env.SQL_SSL === "false" ? false : process.env.SQL_SSL === "true" ? { rejectUnauthorized: false } : false,
      connectionTimeoutMillis: connTimeout,
      max,
      idleTimeoutMillis: idleTimeout,
      allowExitOnIdle: true,
      keepAlive: true,
      keepAliveInitialDelayMillis: 10000,
    });
  }

  const rawUrl = process.env.DATABASE_URL || process.env.POSTGRES_URL;
  const connectionString = normalizeDatabaseUrl(rawUrl);
  if (connectionString) {
    const isLocalhost = connectionString.includes("localhost") || connectionString.includes("127.0.0.1");
    const isSupabase = connectionString.includes("supabase.co") || connectionString.includes("supabase.com");
    const max = getPoolMax(isSupabase);

    return new Pool({
      connectionString,
      ssl: isLocalhost ? false : { rejectUnauthorized: false },
      connectionTimeoutMillis: connTimeout,
      max,
      idleTimeoutMillis: idleTimeout,
      allowExitOnIdle: true,
      keepAlive: true,
      keepAliveInitialDelayMillis: 10000,
    });
  }

  return new Pool({
    host: process.env.SQL_HOST || "localhost",
    port: parseInt(process.env.SQL_PORT || "5432", 10),
    user: process.env.SQL_USER || process.env.SQL_ADMIN_USER || "postgres",
    password: process.env.SQL_PASSWORD || process.env.SQL_ADMIN_PASSWORD || "",
    database: process.env.SQL_DB_NAME || "youthsmm",
    ssl: process.env.SQL_SSL === "true" ? { rejectUnauthorized: false } : false,
    connectionTimeoutMillis: connTimeout,
    max: getPoolMax(false),
    idleTimeoutMillis: idleTimeout,
    allowExitOnIdle: true,
    keepAlive: true,
    keepAliveInitialDelayMillis: 10000,
  });
};

function setupPoolErrorHandling(p: pg.Pool) {
  // Handle idle connection errors gracefully without crashing the serverless instance
  p.on("error", (err: any) => {
    const isExpectedDisconnect =
      err?.message?.includes("Connection terminated unexpectedly") ||
      err?.message?.includes("Client has encountered a connection error") ||
      err?.message?.includes("terminating connection due to administrator command") ||
      err?.message?.includes("read ECONNRESET") ||
      err?.code === "57P01" ||
      err?.code === "57P02" ||
      err?.code === "57P03" ||
      err?.code === "08006" ||
      err?.code === "08001" ||
      err?.code === "08004" ||
      err?.code === "ECONNRESET";

    if (!isExpectedDisconnect) {
      console.warn("[DB Pool Safe Notice]:", {
        code: err?.code,
        message: sanitizeDbErrorMessage(err),
      });
    }
  });

  const originalQuery = p.query;
  (p as any).query = async function (...args: any[]) {
    let attempts = 0;
    const maxAttempts = 3;
    while (true) {
      try {
        attempts++;
        return await originalQuery.apply(this, args as any);
      } catch (err: any) {
        const isTransientError =
          err?.message?.includes("Connection terminated unexpectedly") ||
          err?.message?.includes("Client has encountered a connection error") ||
          err?.message?.includes("terminating connection due to administrator command") ||
          err?.message?.includes("read ECONNRESET") ||
          err?.message?.includes("EMAXCONNSESSION") ||
          err?.message?.includes("max clients reached in session mode") ||
          err?.message?.includes("pool_size: 15") ||
          err?.code === "57P01" ||
          err?.code === "57P02" ||
          err?.code === "57P03" ||
          err?.code === "08006" ||
          err?.code === "08001" ||
          err?.code === "08004" ||
          err?.code === "ECONNRESET";

        if (isTransientError && attempts < maxAttempts) {
          console.log(
            `[DB Pool Safe Notice] Transient connection issue, retrying (attempt ${attempts}/${maxAttempts})...`
          );
          await new Promise((resolve) => setTimeout(resolve, 200 * attempts));
          continue;
        }
        throw err;
      }
    }
  };

  const originalConnect = p.connect;
  (p as any).connect = async function (...args: any[]) {
    let attempts = 0;
    const maxAttempts = 3;
    while (true) {
      try {
        attempts++;
        return await originalConnect.apply(this, args as any);
      } catch (err: any) {
        const isTransientError =
          err?.message?.includes("Connection terminated unexpectedly") ||
          err?.message?.includes("Client has encountered a connection error") ||
          err?.message?.includes("terminating connection due to administrator command") ||
          err?.message?.includes("read ECONNRESET") ||
          err?.message?.includes("EMAXCONNSESSION") ||
          err?.message?.includes("max clients reached in session mode") ||
          err?.message?.includes("pool_size: 15") ||
          err?.code === "57P01" ||
          err?.code === "57P02" ||
          err?.code === "57P03" ||
          err?.code === "08006" ||
          err?.code === "08001" ||
          err?.code === "08004" ||
          err?.code === "ECONNRESET";

        if (isTransientError && attempts < maxAttempts) {
          console.log(
            `[DB Pool Safe Notice] Transient socket connection issue, retrying (attempt ${attempts}/${maxAttempts})...`
          );
          await new Promise((resolve) => setTimeout(resolve, 200 * attempts));
          continue;
        }
        throw err;
      }
    }
  };
}

// Global singleton cache across warm serverless lambdas / Node.js module reloads
const globalForDb = globalThis as unknown as {
  __dbPool?: pg.Pool;
  __dbInstance?: ReturnType<typeof drizzle>;
};

export const getPool = (): pg.Pool => {
  if (!globalForDb.__dbPool) {
    globalForDb.__dbPool = createPool();
    setupPoolErrorHandling(globalForDb.__dbPool);
  }
  return globalForDb.__dbPool;
};

export const pool = getPool();
export const db =
  globalForDb.__dbInstance ||
  (globalForDb.__dbInstance = drizzle(pool, { schema }));

