export interface User {
  id: number;
  uid: string;
  email: string;
  name: string | null;
  role: string;
  balance: number;
  status: string;
  customRate: number;
  customProviderUrl?: string | null;
  customProviderKey?: string | null;
  apiKey?: string | null;
  lastLoginAt?: string | null;
  createdAt: string;
}

export interface Service {
  id: number;
  categoryId: number;
  name: string;
  description: string | null;
  pricePerThousand: number;
  minAmount: number;
  maxAmount: number;
  status: string;
  providerId: number | null;
  providerServiceId: string | null;
  icon?: string | null;
}

export interface Order {
  id: number;
  userId: number;
  serviceId: number | null;
  serviceName: string | null;
  link: string;
  quantity: number;
  charge: number;
  status: string;
  startCount: number;
  remains: number;
  providerOrderId?: string | null;
  providerName?: string | null;
  refillStatus: string;
  createdAt: string;
}

export interface Category {
  id: number;
  name: string;
  status: string;
  sortOrder: number;
  icon?: string | null;
}

export interface Payment {
  id: number;
  userId: number;
  amount: number;
  paymentMethod: string;
  transactionId?: string | null;
  status: string;
  createdAt: string;
}
