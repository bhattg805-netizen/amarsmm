import { GoogleGenAI } from '@google/genai';
import { db } from '../db/index';
import {
  orders,
  services,
  categories,
  settings,
  users,
  tickets,
  ticketMessages,
  refillRequests,
  activityLogs,
} from '../db/schema';
import { eq, desc, sql } from 'drizzle-orm';

let genAIClient: GoogleGenAI | null = null;

function getGenAI(): GoogleGenAI | null {
  if (!genAIClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      genAIClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });
    }
  }
  return genAIClient;
}

interface ChatHistoryItem {
  role: 'user' | 'model';
  content: string;
}

interface HandleAiChatParams {
  message: string;
  history?: ChatHistoryItem[];
  userId?: number;
}

export async function handleAiChat({ message, history = [], userId }: HandleAiChatParams) {
  const trimmed = message.trim();
  const lower = trimmed.toLowerCase();

  // 1. Check if user typed an order ID (e.g., #1024, 1024, order 1024)
  const orderIdMatch = trimmed.match(/(?:#|order\s*(?:id)?\s*:?\s*|id\s*:?\s*)?(\b\d{1,8}\b)/i);
  let candidateId: number | null = null;
  if (orderIdMatch && orderIdMatch[1]) {
    const parsed = parseInt(orderIdMatch[1], 10);
    if (!isNaN(parsed) && parsed > 0) {
      candidateId = parsed;
    }
  }

  // Detect specific action intent
  const isShowsCompleted =
    /shows?\s*completed|completed\s*without\s*complete|not\s*received|fake\s*complete|mila\s*nahi|aaya\s*nahi|deliver\s*nahi|complete\s*dikha\s*raha/i.test(
      trimmed
    );
  const isCancel = /\b(cancel|stop|rok|abort|cancel\s*order|refund\s*karo)\b/i.test(trimmed);
  const isRefill = /\b(refill|drop|restore|kam\s*ho\s*gaye|refill\s*request|ghat\s*gaye)\b/i.test(trimmed);
  const isSpeed = /\b(speed(?:\s*up)?|fast|jaldi|expedite|boost|speedup|slow\s*hai)\b/i.test(trimmed);
  const isStatus = /\b(status|check|progress|kaha\s*tak|track|kaisa\s*hai|kab\s*aayega)\b/i.test(trimmed);

  // Fetch specific order if ID given
  let specificOrder: any = null;
  if (candidateId) {
    try {
      const found = await db
        .select({
          id: orders.id,
          userId: orders.userId,
          serviceId: orders.serviceId,
          link: orders.link,
          quantity: orders.quantity,
          charge: orders.charge,
          status: orders.status,
          startCount: orders.startCount,
          remains: orders.remains,
          refillStatus: orders.refillStatus,
          createdAt: orders.createdAt,
          serviceName: services.name,
        })
        .from(orders)
        .leftJoin(services, eq(orders.serviceId, services.id))
        .where(eq(orders.id, candidateId))
        .limit(1);

      if (found.length > 0) {
        specificOrder = found[0];
      }
    } catch (e) {
      console.error('Error fetching specific order in AI chatbot:', e);
    }
  }

  // Fetch user recent orders
  let recentOrders: any[] = [];
  if (userId) {
    try {
      recentOrders = await db
        .select({
          id: orders.id,
          serviceId: orders.serviceId,
          link: orders.link,
          quantity: orders.quantity,
          charge: orders.charge,
          status: orders.status,
          startCount: orders.startCount,
          remains: orders.remains,
          createdAt: orders.createdAt,
          serviceName: services.name,
        })
        .from(orders)
        .leftJoin(services, eq(orders.serviceId, services.id))
        .where(eq(orders.userId, userId))
        .orderBy(desc(orders.createdAt))
        .limit(5);
    } catch (e) {
      console.error('Error fetching recent orders for AI chatbot:', e);
    }
  }

  // Fetch website settings & active services
  let settingsList: Record<string, string> = {};
  let popularServices: any[] = [];
  let allActiveCategories: any[] = [];
  try {
    const sRows = await db.select().from(settings);
    sRows.forEach((r) => {
      settingsList[r.key] = r.value;
    });

    allActiveCategories = await db.select().from(categories).limit(15);

    popularServices = await db
      .select({
        id: services.id,
        name: services.name,
        pricePerThousand: services.pricePerThousand,
        categoryName: categories.name,
      })
      .from(services)
      .leftJoin(categories, eq(services.categoryId, categories.id))
      .where(eq(services.status, 'active'))
      .limit(12);
  } catch (e) {
    console.error('Error fetching settings/services for AI context:', e);
  }

  const websiteName = settingsList.websiteName || 'YouthSMM';
  const rawTg = settingsList.telegramUsername || '@securesmmtursted';
  const telegramUsername = rawTg.startsWith('@') ? rawTg : `@${rawTg}`;
  const whatsappNumber = settingsList.whatsappNumber || '8795005604';
  const cleanPhone = whatsappNumber.replace(/[^0-9]/g, '') || '8795005604';

  // ===================== SPECIFIC ORDER COMMAND HANDLERS =====================
  let directCommandResponse: string | null = null;

  if (specificOrder) {
    const s = specificOrder;
    // Security check: if userId is provided and order belongs to another user, restrict access
    if (userId && s.userId && s.userId !== userId) {
      directCommandResponse = `🔒 **Access Denied to Order #${s.id}**\n\nYeh order aapke account ke saath associated nahi hai. Security reasons ki wajah se aap sirf apne orders manage kar sakte hain. Kripya apna sahi Order ID verify karein (Orders tab me check karein).`;
      specificOrder = null;
    } else {
      const orderStatus = (s.status || '').toLowerCase();
      const refillSt = (s.refillStatus || '').toLowerCase();

      // 1. SHOWS COMPLETED
      if (isShowsCompleted) {
      let ticketId = 0;
      try {
        const [createdTicket] = await db
          .insert(tickets)
          .values({
            userId: s.userId || userId || 1,
            subject: `⚠️ Order #${s.id} - Showing Completed Without Complete`,
            status: 'open',
          })
          .returning();

        if (createdTicket) {
          ticketId = createdTicket.id;
          await db.insert(ticketMessages).values({
            ticketId: createdTicket.id,
            senderId: s.userId || userId || 1,
            message: `User reported via AI Support Chatbot: Order #${s.id} (${s.serviceName || 'SMM Service'}, Link: ${s.link}, Quantity: ${s.quantity}) is marked as COMPLETED, but the service was NOT received. Urgent technical audit requested.`,
          });
        }

        await db.insert(activityLogs).values({
          userId: s.userId || userId || null,
          action: 'Report Completed Without Complete',
          details: `Urgent audit ticket #${ticketId} created for Order #${s.id}`,
        });
      } catch (err) {
        console.error('Failed to log audit ticket:', err);
      }

      directCommandResponse = `⚠️ **Investigation Ticket Created for Order #${s.id}!**

• **Command:** \`${s.id} shows completed\`
• **Issue:** Showing Completed Without Complete
• **Service:** ${s.serviceName || 'SMM Service #' + s.serviceId}
• **Target Link:** \`${s.link}\`
• **Quantity Ordered:** ${s.quantity?.toLocaleString()}
• **Urgent Ticket ID:** #TCK-${ticketId || s.id}

📋 **Action Taken:**
1️⃣ Provider audit node par re-check request forward kar di gayi hai.
2️⃣ Link delivery status ko technical team review karegi. Agar premature completion hua hoga toh order re-deliver hoga ya full refund wallet me credit ho jayega.
3️⃣ Updates aap **Tickets** tab me check kar sakte hain.`;
    }

    // 2. REFILL
    else if (isRefill) {
      if (orderStatus === 'cancelled' || orderStatus === 'refunded') {
        directCommandResponse = `❌ **Order #${s.id} is Cancelled.**
Refill is not applicable on cancelled orders.`;
      } else if (orderStatus === 'pending') {
        directCommandResponse = `⏳ **Order #${s.id} is Pending.**
Refill completed orders par count drop hone par submit hota hai. Agar order start karwana hai toh reply karein: \`${s.id} speed\`.`;
      } else if (refillSt === 'requested') {
        directCommandResponse = `🔄 **Refill Already Active for Order #${s.id}!**

• **Status:** Refill In-Progress
• **Service:** ${s.serviceName || 'SMM Service'}
• **Link:** \`${s.link}\`

Aapka refill request already server par process ho raha hai (restoration usually takes 1-24 hours). Live updates Orders tab me milenge.`;
      } else {
        try {
          await db.update(orders).set({ refillStatus: 'requested' }).where(eq(orders.id, s.id));
          await db.insert(refillRequests).values({
            userId: s.userId || userId || 1,
            orderId: s.id,
            status: 'pending',
          });
          const [t] = await db
            .insert(tickets)
            .values({
              userId: s.userId || userId || 1,
              subject: `Refill Request: Order #${s.id}`,
              status: 'open',
            })
            .returning();
          if (t) {
            await db.insert(ticketMessages).values({
              ticketId: t.id,
              senderId: s.userId || userId || 1,
              message: `Automated refill request initiated via Chatbot for Order #${s.id} (${s.serviceName}, Link: ${s.link}).`,
            });
          }
          await db.insert(activityLogs).values({
            userId: s.userId || userId || null,
            action: 'Chatbot Refill Request',
            details: `Refill requested for Order #${s.id} via AI Chatbot`,
          });
          s.refillStatus = 'requested';
        } catch (err) {
          console.error('Refill request error:', err);
        }

        directCommandResponse = `🔄 **Refill Request Submitted for Order #${s.id}!**

• **Command:** \`${s.id} refill\`
• **Service:** ${s.serviceName || 'SMM Service #' + s.serviceId}
• **Link:** \`${s.link}\`
• **Refill Status:** \`REQUESTED\` ⚡
• **Tracking ID:** #RF-${s.id}

✅ Server ne refill command provider network ko dispatch kar di hai. Dropped counts restore hona 1-24 hours me complete ho jata hai. Live updates aap Orders tab me dekh sakte hain.`;
      }
    }

    // 3. SPEED UP
    else if (isSpeed) {
      if (orderStatus === 'completed') {
        directCommandResponse = `✅ **Order #${s.id} Already Completed!**

• **Status:** \`COMPLETED\`
Speed-up ki zaroorat nahi hai kyunki order deliver ho chuka hai.
• Agar count drop hua ho, reply karein: \`${s.id} refill\`
• Agar service nahi aayi ho, reply karein: \`${s.id} shows completed\``;
      } else if (orderStatus === 'cancelled' || orderStatus === 'refunded') {
        directCommandResponse = `❌ **Order #${s.id} is Cancelled.** Speed-up cannot be applied.`;
      } else {
        let ticketId = 0;
        try {
          const [t] = await db
            .insert(tickets)
            .values({
              userId: s.userId || userId || 1,
              subject: `⚡ Speed-Up Request: Order #${s.id}`,
              status: 'open',
            })
            .returning();
          if (t) {
            ticketId = t.id;
            await db.insert(ticketMessages).values({
              ticketId: t.id,
              senderId: s.userId || userId || 1,
              message: `Priority speed-up requested for Order #${s.id} (${s.serviceName}, Link: ${s.link}, Status: ${s.status}, Remains: ${s.remains}). Expediting dispatch.`,
            });
          }
          await db.insert(activityLogs).values({
            userId: s.userId || userId || null,
            action: 'Chatbot Speed-Up Request',
            details: `Speed-up accelerated for Order #${s.id}`,
          });
        } catch (err) {
          console.error('Speed up error:', err);
        }

        directCommandResponse = `🚀 **Speed-Up Accelerated for Order #${s.id}!**

• **Command:** \`${s.id} speed\`
• **Service:** ${s.serviceName || 'SMM Service'}
• **Current Status:** \`${orderStatus.toUpperCase()}\`
• **Remains:** ${s.remains ?? 0} / ${s.quantity}
• **Priority Node:** ⚡ HIGH PRIORITY DISPATCHED

✅ Server delivery queue me aapke order ki priority elevate kar di gayi hai. Delivery node ko acceleration signal send ho chuka hai, aapko link par speed boost jald dikhega!`;
      }
    }

    // 4. CANCEL
    else if (isCancel) {
      if (orderStatus === 'completed') {
        directCommandResponse = `⚠️ **Order #${s.id} Cannot Be Cancelled.**

• **Status:** \`COMPLETED\`
• **Service:** ${s.serviceName || 'SMM Service'}
• **Link:** \`${s.link}\`

Yeh order server par deliver ho chuka hai.
• Agar count drop ho gaya hai, reply karein: \`${s.id} refill\`
• Agar count receive nahi hua, reply karein: \`${s.id} shows completed\``;
      } else if (orderStatus === 'cancelled' || orderStatus === 'refunded') {
        directCommandResponse = `ℹ️ **Order #${s.id} Already Cancelled.**

• **Status:** \`${orderStatus.toUpperCase()}\`
Aapka order pehle se hi cancelled hai aur refund balance me credit ho chuka hai.`;
      } else if (orderStatus === 'pending') {
        try {
          await db.update(orders).set({ status: 'cancelled', remains: s.quantity }).where(eq(orders.id, s.id));
          if (s.userId && s.charge > 0) {
            await db.update(users).set({ balance: sql`${users.balance} + ${s.charge}` }).where(eq(users.id, s.userId));
          }
          await db.insert(activityLogs).values({
            userId: s.userId || userId || null,
            action: 'Chatbot Order Cancelled',
            details: `Order #${s.id} cancelled via Chatbot. Refunded ₹${s.charge} to user #${s.userId}.`,
          });
          s.status = 'cancelled';
        } catch (err) {
          console.error('Cancel order error:', err);
        }

        directCommandResponse = `❌ **Order #${s.id} Successfully Cancelled!**

• **Command:** \`${s.id} cancel\`
• **Service:** ${s.serviceName || 'SMM Service'}
• **Status:** \`CANCELLED\`
• **Refund Credited:** ₹${Number(s.charge).toFixed(2)}
• **Wallet Balance:** Updated instantly!

Order start hone se pehle hi cancel kar diya gaya hai aur full refund aapke wallet me add ho chuka hai. Aap New Order tab se naya order laga sakte hain.`;
      } else {
        let ticketId = 0;
        try {
          const [t] = await db
            .insert(tickets)
            .values({
              userId: s.userId || userId || 1,
              subject: `Cancellation Request: Order #${s.id}`,
              status: 'open',
            })
            .returning();
          if (t) {
            ticketId = t.id;
            await db.insert(ticketMessages).values({
              ticketId: t.id,
              senderId: s.userId || userId || 1,
              message: `User requested cancellation for in-progress Order #${s.id} (${s.serviceName}, Link: ${s.link}, Remains: ${s.remains}). Halting provider dispatch.`,
            });
          }
          await db.insert(activityLogs).values({
            userId: s.userId || userId || null,
            action: 'Chatbot Cancel Request',
            details: `Cancellation ticket #${ticketId} submitted for active Order #${s.id}`,
          });
        } catch (err) {
          console.error('Cancel ticket error:', err);
        }

        directCommandResponse = `⏳ **Cancellation Request Submitted for Order #${s.id}!**

• **Command:** \`${s.id} cancel\`
• **Status:** \`${orderStatus.toUpperCase()}\` (Active on Provider Node)
• **Remains:** ${s.remains ?? 0}
• **Priority Ticket:** #CAN-${ticketId || s.id}

⚠️ Order currently provider server par process ho raha hai. Agar provider cancel approve karta hai, toh remaining balance automatically aapke wallet me refund ho jayega.`;
      }
    }

    // 5. STATUS
    else if (isStatus) {
      const statusEmoji =
        s.status === 'completed'
          ? '✅'
          : s.status === 'processing'
          ? '⚡'
          : s.status === 'pending'
          ? '⏳'
          : s.status === 'cancelled'
          ? '❌'
          : '⚠️';
      const total = s.quantity || 1;
      const remains = s.remains ?? 0;
      const delivered = Math.max(0, total - remains);
      const percent = Math.min(100, Math.round((delivered / total) * 100));

      directCommandResponse = `📦 **Order Status for #${s.id}**

${statusEmoji} **Status:** \`${(s.status || '').toUpperCase()}\`
🛠️ **Service:** ${s.serviceName || 'SMM Service #' + s.serviceId}
🔗 **Link:** \`${s.link}\`
📊 **Quantity:** ${s.quantity?.toLocaleString()}
🔢 **Start Count:** ${s.startCount ?? 0} | **Remains:** ${remains}
📈 **Progress:** ${percent}% delivered
🕒 **Date Placed:** ${new Date(s.createdAt).toLocaleString()}

To manage this order, reply with your Order ID followed by a command:

\`${s.id} status\` — check progress
\`${s.id} refill\` — request a refill
\`${s.id} speed\` — request a speed-up
\`${s.id} cancel\` — request cancellation
\`${s.id} shows completed\` — Showing Completed Without Complete`;
    }

    // Default info for specific order
    else if (!isShowsCompleted && !isCancel && !isRefill && !isSpeed && !isStatus) {
      directCommandResponse = `👋 **Order #${s.id} Details Found!**

• **Service:** ${s.serviceName || 'SMM Service #' + s.serviceId}
• **Status:** \`${(s.status || '').toUpperCase()}\`
• **Link:** \`${s.link}\`
• **Quantity:** ${s.quantity?.toLocaleString()} | **Remains:** ${s.remains ?? 0}

To manage this order, reply with:
\`${s.id} status\` — check progress
\`${s.id} refill\` — request a refill
\`${s.id} speed\` — request a speed-up
\`${s.id} cancel\` — request cancellation
\`${s.id} shows completed\` — Showing Completed Without Complete`;
    }
    }
  } else if (candidateId && !specificOrder) {
    directCommandResponse = `❌ **Order #${candidateId} Not Found.**

Database me Order #${candidateId} nahi mila. Kripya apna sahi Order ID verify karein (Orders tab me check karein).

Agar order ID yaad hai toh reply karein:
\`${candidateId} status\` — check progress
\`${candidateId} refill\` — request a refill
\`${candidateId} speed\` — request a speed-up
\`${candidateId} cancel\` — request cancellation
\`${candidateId} shows completed\` — Showing Completed Without Complete`;
  } else if (!candidateId && (isShowsCompleted || isCancel || isRefill || isSpeed || isStatus)) {
    const cmdName = isShowsCompleted
      ? 'shows completed'
      : isCancel
      ? 'cancel'
      : isRefill
      ? 'refill'
      : isSpeed
      ? 'speed'
      : 'status';
    if (recentOrders.length > 0) {
      const recentId = recentOrders[0].id;
      directCommandResponse = `🔍 Aapka recent order **#${recentId}** (${recentOrders[0].serviceName || 'Service'}) hai.

To manage this order, reply with:
• \`${recentId} ${cmdName}\`

Ya phir apna specific Order ID likhein:
• \`[OrderID] ${cmdName}\` (jaise \`12345 ${cmdName}\`)

---
**All Available Commands:**
\`${recentId} status\` — check progress
\`${recentId} refill\` — request a refill
\`${recentId} speed\` — request a speed-up
\`${recentId} cancel\` — request cancellation
\`${recentId} shows completed\` — Showing Completed Without Complete`;
    } else {
      directCommandResponse = `To manage an order, reply with your Order ID followed by a command:

\`12345 status\` — check progress
\`12345 refill\` — request a refill
\`12345 speed\` — request a speed-up
\`12345 cancel\` — request cancellation
\`12345 shows completed\` — Showing Completed Without Complete`;
    }
  }

  if (directCommandResponse) {
    return {
      success: true,
      response: directCommandResponse,
      order: specificOrder,
    };
  }

  // ===================== GEMINI AI ENGINE GENERATION =====================
  const servicesContext = popularServices.map((s) => `- #${s.id} ${s.name}: ₹${s.pricePerThousand}/1K (${s.categoryName})`).join('\n');

  const systemInstruction = `You are the official 24/7 AI Smart Assistant for "${websiteName}" SMM Panel.
You help users with ALL questions regarding social media growth (Instagram, YouTube, Telegram, Facebook, Twitter/X, TikTok, Spotify), SMM services, pricing, order placing, fund deposits, API integrations, and account safety.

Always be polite, enthusiastic, helpful, and concise. You understand Hindi, Hinglish, and English seamlessly. Answer in the same language the user asks.

PRIMARY POLICIES & KNOWLEDGE:
1. WEBSITE & CONTACT:
- Website: ${websiteName}
- Official WhatsApp Support: +91 ${cleanPhone} (Direct fast resolution)
- Official Telegram: ${telegramUsername}
- 24/7 Live Automated Dispatch

2. HOW TO ADD FUNDS (PAYMENTS):
- Go to "Add Funds" page in the dashboard.
- Enter amount (Minimum deposit is only ₹10 - ₹50!).
- Scan the BharatPe / PhonePe UPI QR code using any UPI app (GPay, PhonePe, Paytm, etc.).
- After payment, copy the 12-digit UTR / Ref Number from your UPI app.
- Paste UTR in the "Transaction ID / UTR" box and click "Verify & Add Funds".
- Balance is credited instantly to your wallet.

3. HOW TO PLACE A NEW ORDER:
- Click "New Order" tab.
- Choose your Category (e.g. Instagram Followers, YouTube Views, Telegram Members).
- Select the specific Service from wholesale list.
- Paste your target public link (post URL, profile URL, or channel link).
- Enter quantity and click "Submit Order".
- Note: Never enter private accounts. Keep profiles public during delivery.

4. ORDER MANAGEMENT 5 CORE COMMANDS:
Whenever users mention an order ID or ask to manage an order, inform them of these 5 commands:
- "[OrderID] status" — check live delivery progress
- "[OrderID] refill" — request a refill if counts dropped
- "[OrderID] speed" — request a speed-up for pending/slow orders
- "[OrderID] cancel" — cancel order & get instant wallet refund
- "[OrderID] shows completed" — report if marked completed without complete (creates priority technical audit ticket)

5. POPULAR SERVICES & PRICING CONTEXT:
${servicesContext || 'Instagram Followers from ₹35/1K, Likes from ₹8/1K, YouTube Views from ₹75/1K, Telegram Members from ₹85/1K'}

6. SAFETY & PRIVACY:
- 100% Safe. No passwords are ever required! Only public profile or post links.
- High retention non-drop algorithms protect accounts from bans.

7. DEVELOPER API:
- We provide high-speed SMM API v2 for developers and resellers.
- Find your API Secret Key in Profile / API Docs tab.

${recentOrders.length > 0 ? `CURRENT USER RECENT ORDERS:\n${recentOrders.map((o) => `- #${o.id}: ${o.serviceName || 'Service'} | Status: ${o.status.toUpperCase()} | Qty: ${o.quantity} | Remains: ${o.remains}`).join('\n')}` : ''}

CRITICAL: Give direct, accurate, and actionable answers to whatever the user is asking!`;

  const ai = getGenAI();
  let aiResponseText = '';

  if (ai) {
    const formattedContents: any[] = [];
    for (const h of history.slice(-6)) {
      formattedContents.push({
        role: h.role === 'user' ? 'user' : 'model',
        parts: [{ text: h.content }],
      });
    }
    formattedContents.push({
      role: 'user',
      parts: [{ text: trimmed }],
    });

    // Primary recommended model is gemini-3.8-flash
    try {
      const timeoutPromise = new Promise<null>((_, reject) =>
        setTimeout(() => reject(new Error('AI generation timeout')), 2000)
      );

      const genPromise = ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: formattedContents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const response: any = await Promise.race([genPromise, timeoutPromise]);
      if (response && response.text) {
        aiResponseText = response.text;
      }
    } catch (err: any) {
      console.warn('Gemini 3.8 Flash model notice:', err?.message || err);
    }
  }

  // ===================== ULTRA-SMART FALLBACK NLP ENGINE =====================
  // If Gemini is not configured, rate limited, or network fails, provide rich, helpful answers
  if (!aiResponseText) {
    aiResponseText = generateSmartFallbackResponse(lower, trimmed, websiteName, cleanPhone, telegramUsername, recentOrders, popularServices);
  }

  return {
    success: true,
    response: aiResponseText,
    order: specificOrder,
  };
}

/**
 * Robust, highly intelligent conversational fallback engine
 * Handles Hindi, Hinglish, and English queries covering every aspect of YouthSMM
 */
function generateSmartFallbackResponse(
  lower: string,
  raw: string,
  siteName: string,
  phone: string,
  telegram: string,
  recentOrders: any[],
  servicesList: any[]
): string {
  const sampleId = recentOrders.length > 0 ? recentOrders[0].id : 12345;

  // 1. GREETINGS
  if (/^(hi|hello|hey|namaste|pranam|kaise ho|kya haal|good morning|good evening|good afternoon|sup|yo)\b/i.test(lower)) {
    return `👋 **Namaste! Welcome to ${siteName} 24/7 AI Support!**

Main aapka personal AI assistant hoon. Main aapki in cheezon me madad kar sakta hoon:

⚡ **1. Order Management:** Kisi bhi order ka status, refill, speedup ya cancel karein (\`${sampleId} status\`, \`${sampleId} refill\`, \`${sampleId} speed\`, etc.)
💳 **2. Payment & Funds:** BharatPe UPI QR se paise add karna aur UTR verification.
🚀 **3. Services & Rates:** Instagram, YouTube, Telegram, Facebook, TikTok wholesale pricing.
🔑 **4. API & Integration:** API Secret Key aur Developer documentation.

Aap mujhse koi bhi sawaal pooch sakte hain! Aaj aapko kis cheez me help chahiye?`;
  }

  // 2. PAYMENT / ADD FUNDS / UTR / UPI
  if (
    /payment|add\s*funds?|paise|fund|recharge|balance|wallet|utr|bharatpe|phonepe|paytm|gpay|google\s*pay|deposit|scanner|qr/i.test(
      lower
    )
  ) {
    return `💳 **Payment & Wallet Add Funds Guide:**

1️⃣ **Add Funds** tab par jayein.
2️⃣ Amount enter karein (Minimum sirf ₹10 - ₹50 se start kar sakte hain!).
3️⃣ Screen par dikh rahe **BharatPe / PhonePe UPI QR** ko apne kisi bhi UPI app (Paytm, GPay, PhonePe) se scan karke payment karein.
4️⃣ Payment complete hone ke baad UPI app me se **12-digit UTR / Ref Number** copy karein.
5️⃣ UTR box me paste karein aur **"Verify & Add Funds"** par click karein.

⚡ Balance instant 5 seconds me aapke wallet me add ho jata hai!
⚠️ Agar koi UTR issue aaye toh seedhe WhatsApp Support par UTR screenshot bhejein: **+91 ${phone}**`;
  }

  // 3. HOW TO ORDER / NEW ORDER
  if (/how\s*to\s*order|order\s*kaise|new\s*order|kaise\s*lagaye|order\s*place|kaise\s*kare/i.test(lower)) {
    return `🚀 **How to Place an Order on ${siteName}:**

1️⃣ Dashboard ke **New Order** tab par click karein.
2️⃣ **Platform & Category** select karein (e.g. *Instagram Followers*, *YouTube Views*, *Telegram Members*).
3️⃣ Apni pasand ki **Service** choose karein (rates per 1000 dikhenge).
4️⃣ **Link** box me apna public link paste karein:
   • Profile ke liye: \`https://instagram.com/username\`
   • Post ya Reel ke liye: \`https://instagram.com/p/.../reels/...\`
5️⃣ **Quantity** daalein aur **"Submit Order"** par click karein!

✅ Order automatic dispatch ho jayega aur live status aap Orders tab me dekh sakte hain.`;
  }

  // 4. INSTAGRAM SERVICES (Followers, Likes, Views, Non-drop)
  if (/insta|instagram|ig|follower|followers|reels?|views?|likes?|story|comments?/i.test(lower)) {
    return `📸 **Instagram Services & Wholesale Rates:**

• **Instagram Followers (Non-Drop):** Starting ~₹35 - ₹90 / 1K (Refill Guarantee available)
• **Instagram Real Likes:** Starting ~₹8 - ₹20 / 1K (Instant High Speed)
• **Instagram Reels Views:** Starting ~₹1.50 - ₹5 / 1K (Instant Viral Booster)
• **Instagram Custom Comments:** Starting ~₹45 / 1K

💡 **Pro Tips:**
1. Account hamesha **PUBLIC** hona chahiye (Private profile par delivery nahi hoti).
2. Non-Drop services me refill button enable rehta hai. Agar count drop ho toh reply karein: \`${sampleId} refill\`!
3. Order lagane ke liye **New Order** tab me Instagram category select karein.`;
  }

  // 5. YOUTUBE SERVICES (Subscribers, 4K Watch time, Views)
  if (/youtube|yt|subscriber|subscribers|watch\s*time|monetiz|views/i.test(lower)) {
    return `🔴 **YouTube Monetization & Growth Services:**

• **YouTube Real Views:** ~₹75 - ₹140 / 1K (High Retention, Suggested views)
• **YouTube Non-Drop Subscribers:** ~₹350 - ₹850 / 1K (Lifetime Refill Guarantee)
• **4000 Hours Watch Time Pack:** Fast channel monetization packages available!
• **YouTube Likes & Comments:** Instant speed delivery.

💡 **Tips for YouTube:**
• Views ke liye video public honi chahiye (No unlisted/private).
• Watch time ke liye 15+ minutes ya 60+ minutes ki lambi video ka link submit karein.`;
  }

  // 6. TELEGRAM SERVICES
  if (/telegram|tg|channel|group|members?|tg\s*views|reaction/i.test(lower)) {
    return `✈️ **Telegram Channel & Group Growth:**

• **Telegram Channel Members:** ~₹85 - ₹160 / 1K (0% Drop, Instant Activation)
• **Telegram Group Members:** High retention active members.
• **Telegram Post Views:** ~₹0.80 - ₹3 / 1K (Last 5-10 posts autoview available).
• **Telegram Custom Reactions:** Heart ❤️, Fire 🔥, Thumbs-up 👍.

Public channel link: \`https://t.me/yourchannel\` paste karein aur New Order lagayein!`;
  }

  // 7. FACEBOOK / TWITTER / TIKTOK / SPOTIFY / OTHER
  if (/facebook|fb|twitter|tweet|x\s*followers|tiktok|spotify|threads|linkedin|snapchat/i.test(lower)) {
    return `🌐 **Facebook, Twitter/𝕏, TikTok & Spotify Services:**

• **Facebook:** Page Likes, Profile Followers, Post Reactions & Video Views.
• **Twitter / 𝕏:** Followers, Retweets, Likes, Impressions & Poll Votes.
• **TikTok:** Global Followers, Video Views & Shares.
• **Spotify:** Monthly Listeners, Playlist Followers & Track Streams.

Sabhi services wholesale wholesale pricing ke saath **New Order** tab me available hain!`;
  }

  // 8. SAFETY / BAN RISK / PASSWORD
  if (/safe|ban|password|hack|risk|account\s*ud|secure/i.test(lower)) {
    return `🛡️ **100% Safe & Secure Guarantee:**

• **No Password Required:** Hum aapse kabhi bhi account ka password ya OTP nahi maangte. Sirf public link ya username chahiye hota hai!
• **Zero Ban Risk:** Hamare automated delivery servers natural drip-feed rate use karte hain, jisse aapka account bilkul safe rehta hai.
• **Privacy Protected:** Aapka data aur order details encrypted rehti hain.`;
  }

  // 9. API / DEVELOPER / RESELLER
  if (/api|reseller|child\s*panel|connect|developer|webhook/i.test(lower)) {
    return `🔌 **API & Reseller Features:**

• **API v2 Supported:** Standard SMM Rental / SmartPanel API endpoints support available.
• **API Docs:** Dashboard me **API** tab par jayein. Wahan aapko aapka unique **API Secret Key**, endpoints aur code examples (cURL, Python, PHP, Node.js) milenge.
• **Regenerate Key:** Ek click me instant new secure API key generate kar sakte hain without page reload!
• **Child Panels:** Aap apna khud ka SMM panel bhi hamare server se connect kar sakte hain.`;
  }

  // 10. SUPPORT / CONTACT / WHATSAPP / TELEGRAM
  if (/support|contact|helpline|number|whatsapp|telegram|admin|call|help/i.test(lower)) {
    return `📞 **Official Support Channels (24/7 Available):**

• **WhatsApp Direct Support:** [+91 ${phone}](https://wa.me/91${phone})
• **Official Telegram Channel & Support:** [${telegram}](https://t.me/${telegram.replace('@', '')})
• **Website Tickets:** Dashboard ke **Tickets** tab me jaakar ticket create karein.

Kisi bhi payment, order ya service issue ke liye WhatsApp par message karein for instant human response!`;
  }

  // 11. GENERAL / COMPREHENSIVE HELPFUL ANSWER
  return `✨ **${siteName} AI Support:**

Maine aapki query ko note kar liya hai: *"${raw}"*

Aap in options ke zariye aage badh sakte hain:
1️⃣ **Order Check / Action:** Apna Order ID aur command likhein:
   • \`${sampleId} status\` — Check progress
   • \`${sampleId} refill\` — Request refill
   • \`${sampleId} speed\` — Speed up delivery
   • \`${sampleId} cancel\` — Cancel & refund
   • \`${sampleId} shows completed\` — Urgent investigation ticket
2️⃣ **Services & Pricing:** New Order tab me sabhi platforms ke live wholesale rates check karein.
3️⃣ **Wallet Recharge:** Add Funds tab me BharatPe QR scan karke UTR verify karein.
4️⃣ **Human Support:** WhatsApp **+91 ${phone}** ya Telegram **${telegram}** par direct chat karein.

Mujhe batayein aapko aur kya jankari chahiye!`;
}
