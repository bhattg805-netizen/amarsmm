import express from "express";
import path from "path";
import fs from "fs";
import cors from "cors";
import cookieParser from "cookie-parser";
import compression from "compression";
import * as dotenv from "dotenv";

dotenv.config();

import apiRouter from "./src/server/api";
import { sitemapHandler, robotsHandler } from "./src/server/sitemap";

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(
    compression({
      level: 6,
      threshold: 1024,
      filter: (req, res) => {
        if (req.headers["x-no-compression"]) return false;
        if (req.headers["upgrade"] === "websocket") return false;
        if (
          process.env.NODE_ENV !== "production" &&
          (req.path.startsWith("/@") ||
            req.path.startsWith("/node_modules") ||
            req.path.startsWith("/src/"))
        ) {
          return false;
        }
        return compression.filter(req, res);
      },
    })
  );

  app.use(
    cors({
      origin: true,
      credentials: true,
      methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
      allowedHeaders: [
        "Content-Type",
        "Authorization",
        "X-Requested-With",
        "Accept",
      ],
    })
  );

  app.use(cookieParser());
  app.use(express.json({ limit: "20mb" }));
  app.use(express.urlencoded({ extended: true, limit: "20mb" }));

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.setHeader("Content-Type", "application/json");
    res.json({ status: "ok", time: new Date() });
  });

  // API router (both standard /api and direct /v1, /v2 SMM endpoints)
  app.use("/api", apiRouter);
  app.use("/v1", (req, res, next) => {
    req.url = "/v1" + (req.url === "/" ? "" : req.url);
    apiRouter(req, res, next);
  });
  app.use("/v2", (req, res, next) => {
    req.url = "/v2" + (req.url === "/" ? "" : req.url);
    apiRouter(req, res, next);
  });

  // Catch-all for undefined API routes
  app.all("/api/*", (req, res) => {
    res.status(404).json({ error: `API route ${req.method} ${req.path} not found.` });
  });

  // API error handler
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (req.path.startsWith("/api")) {
      console.error("[API Handler Error]", err);
      res
        .status(err.status || 500)
        .json({ error: err.message || "Internal Server Error" });
      return;
    }
    next(err);
  });

  // Sitemap & Robots
  app.get("/sitemap.xml", sitemapHandler);
  app.get("/robots.txt", robotsHandler);

  const publicPath = path.join(process.cwd(), "public");
  if (fs.existsSync(publicPath)) {
    app.use(
      express.static(publicPath, {
        maxAge: "1d",
        setHeaders: (res, filePath) => {
          if (filePath.endsWith(".ico")) {
            res.setHeader("Content-Type", "image/x-icon");
            res.setHeader("Cache-Control", "public, max-age=86400");
          } else if (filePath.endsWith(".svg")) {
            res.setHeader("Content-Type", "image/svg+xml");
            res.setHeader("Cache-Control", "public, max-age=86400");
          } else if (filePath.endsWith(".png")) {
            res.setHeader("Content-Type", "image/png");
            res.setHeader("Cache-Control", "public, max-age=86400");
          } else if (filePath.endsWith(".webmanifest")) {
            res.setHeader("Content-Type", "application/manifest+json");
            res.setHeader("Cache-Control", "public, max-age=86400");
          }
        },
      })
    );
  }

  const distPath = path.join(process.cwd(), "dist");
  const hasDist = fs.existsSync(distPath);
  const hasSrcMain = fs.existsSync(path.join(process.cwd(), "src/main.tsx"));

  if (hasDist) {
    app.use(
      express.static(distPath, {
        maxAge: "1y",
        immutable: true,
        setHeaders: (res, filePath) => {
          if (filePath.endsWith(".html")) {
            res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
          }
        },
      })
    );
  }

  if (process.env.NODE_ENV !== "production" && hasSrcMain) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Fallback SPA serving
    const indexPath = hasDist
      ? path.join(distPath, "index.html")
      : path.join(process.cwd(), "index.html");

    app.get("*", (req, res) => {
      res.setHeader("Cache-Control", "public, max-age=0, must-revalidate");
      res.sendFile(indexPath);
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Full-Stack SMM Panel Server running on port ${PORT}`);
  });
}

startServer();
