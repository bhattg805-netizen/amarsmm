var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/server/vercel.ts
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import * as dotenv from "dotenv";

// src/server/api.ts
import { Router } from "express";
import crypto from "crypto";
import bcrypt from "bcryptjs";

// src/db/index.ts
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";

// src/db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  activityLogs: () => activityLogs,
  affiliates: () => affiliates,
  affiliatesRelations: () => affiliatesRelations,
  announcements: () => announcements,
  appointments: () => appointments,
  appointmentsRelations: () => appointmentsRelations,
  blogs: () => blogs,
  blogsRelations: () => blogsRelations,
  categories: () => categories,
  categoriesRelations: () => categoriesRelations,
  childPanels: () => childPanels,
  coupons: () => coupons,
  favoriteServices: () => favoriteServices,
  favoriteServicesRelations: () => favoriteServicesRelations,
  orders: () => orders,
  ordersRelations: () => ordersRelations,
  payments: () => payments,
  paymentsRelations: () => paymentsRelations,
  providers: () => providers,
  referrals: () => referrals,
  referralsRelations: () => referralsRelations,
  refillRequests: () => refillRequests,
  services: () => services,
  servicesRelations: () => servicesRelations,
  settings: () => settings,
  ticketMessages: () => ticketMessages,
  ticketMessagesRelations: () => ticketMessagesRelations,
  tickets: () => tickets,
  ticketsRelations: () => ticketsRelations,
  users: () => users,
  usersRelations: () => usersRelations
});
import { relations } from "drizzle-orm";
import { integer, pgTable, serial, text, timestamp, doublePrecision } from "drizzle-orm/pg-core";
var users = pgTable("users", { id: serial("id").primaryKey(), uid: text("uid").notNull().unique(), email: text("email").notNull().unique(), name: text("name"), role: text("role").default("user").notNull(), balance: doublePrecision("balance").default(0).notNull(), status: text("status").default("active").notNull(), customRate: doublePrecision("custom_rate").default(1).notNull(), customProviderUrl: text("custom_provider_url"), customProviderKey: text("custom_provider_key"), apiKey: text("api_key"), password: text("password"), lastLoginAt: timestamp("last_login_at"), lastIp: text("last_ip"), createdAt: timestamp("created_at").defaultNow().notNull() });
var providers = pgTable("providers", { id: serial("id").primaryKey(), name: text("name").notNull(), apiUrl: text("api_url").notNull(), apiKey: text("api_key").notNull(), status: text("status").default("active").notNull(), balance: doublePrecision("balance").default(0).notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var categories = pgTable("categories", { id: serial("id").primaryKey(), name: text("name").notNull(), status: text("status").default("active").notNull(), sortOrder: integer("sort_order").default(0).notNull(), icon: text("icon"), createdAt: timestamp("created_at").defaultNow().notNull() });
var services = pgTable("services", { id: serial("id").primaryKey(), categoryId: integer("category_id").references(() => categories.id, { onDelete: "cascade" }).notNull(), name: text("name").notNull(), description: text("description"), pricePerThousand: doublePrecision("price_per_thousand").notNull(), minAmount: integer("min_amount").default(10).notNull(), maxAmount: integer("max_amount").default(1e4).notNull(), status: text("status").default("active").notNull(), providerId: integer("provider_id").references(() => providers.id, { onDelete: "set null" }), providerServiceId: text("provider_service_id"), icon: text("icon"), createdAt: timestamp("created_at").defaultNow().notNull() });
var orders = pgTable("orders", { id: serial("id").primaryKey(), userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(), serviceId: integer("service_id").references(() => services.id, { onDelete: "set null" }), link: text("link").notNull(), quantity: integer("quantity").notNull(), charge: doublePrecision("charge").notNull(), status: text("status").default("pending").notNull(), startCount: integer("start_count").default(0).notNull(), remains: integer("remains").default(0).notNull(), providerOrderId: text("provider_order_id"), refillStatus: text("refill_status").default("none").notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var payments = pgTable("payments", { id: serial("id").primaryKey(), userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(), amount: doublePrecision("amount").notNull(), paymentMethod: text("payment_method").notNull(), transactionId: text("transaction_id").unique(), status: text("status").default("pending").notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var coupons = pgTable("coupons", { id: serial("id").primaryKey(), code: text("code").notNull().unique(), discountPercent: integer("discount_percent").notNull(), maxUsage: integer("max_usage"), usageCount: integer("usage_count").default(0).notNull(), status: text("status").default("active").notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var tickets = pgTable("tickets", { id: serial("id").primaryKey(), userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(), subject: text("subject").notNull(), status: text("status").default("open").notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var ticketMessages = pgTable("ticket_messages", { id: serial("id").primaryKey(), ticketId: integer("ticket_id").references(() => tickets.id, { onDelete: "cascade" }).notNull(), senderId: integer("sender_id").references(() => users.id, { onDelete: "cascade" }).notNull(), message: text("message").notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var announcements = pgTable("announcements", { id: serial("id").primaryKey(), title: text("title").notNull(), content: text("content").notNull(), type: text("type").default("info").notNull(), status: text("status").default("active").notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var activityLogs = pgTable("activity_logs", { id: serial("id").primaryKey(), userId: integer("user_id").references(() => users.id, { onDelete: "set null" }), action: text("action").notNull(), details: text("details"), ipAddress: text("ip_address"), createdAt: timestamp("created_at").defaultNow().notNull() });
var affiliates = pgTable("affiliates", { id: serial("id").primaryKey(), userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull().unique(), referralCode: text("referral_code").notNull().unique(), earnings: doublePrecision("earnings").default(0).notNull(), visits: integer("visits").default(0).notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var referrals = pgTable("referrals", { id: serial("id").primaryKey(), affiliateId: integer("affiliate_id").references(() => affiliates.id, { onDelete: "cascade" }).notNull(), referredUserId: integer("referred_user_id").references(() => users.id, { onDelete: "cascade" }).notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var favoriteServices = pgTable("favorite_services", { id: serial("id").primaryKey(), userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(), serviceId: integer("service_id").references(() => services.id, { onDelete: "cascade" }).notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var childPanels = pgTable("child_panels", { id: serial("id").primaryKey(), userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(), domain: text("domain").notNull(), currency: text("currency").default("USD").notNull(), adminUsername: text("admin_username").notNull(), adminPassword: text("admin_password").notNull(), price: doublePrecision("price").default(10).notNull(), status: text("status").default("pending").notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var refillRequests = pgTable("refill_requests", { id: serial("id").primaryKey(), userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(), orderId: integer("order_id").references(() => orders.id, { onDelete: "cascade" }).notNull(), status: text("status").default("pending").notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var usersRelations = relations(users, ({ many, one }) => ({ orders: many(orders), payments: many(payments), tickets: many(tickets), ticketMessages: many(ticketMessages), activityLogs: many(activityLogs), affiliate: one(affiliates, { fields: [users.id], references: [affiliates.userId] }), referrals: many(referrals), favorites: many(favoriteServices) }));
var categoriesRelations = relations(categories, ({ many }) => ({ services: many(services) }));
var servicesRelations = relations(services, ({ one, many }) => ({ category: one(categories, { fields: [services.categoryId], references: [categories.id] }), provider: one(providers, { fields: [services.providerId], references: [providers.id] }), orders: many(orders), favorites: many(favoriteServices) }));
var ordersRelations = relations(orders, ({ one }) => ({ user: one(users, { fields: [orders.userId], references: [users.id] }), service: one(services, { fields: [orders.serviceId], references: [services.id] }) }));
var paymentsRelations = relations(payments, ({ one }) => ({ user: one(users, { fields: [payments.userId], references: [users.id] }) }));
var ticketsRelations = relations(tickets, ({ one, many }) => ({ user: one(users, { fields: [tickets.userId], references: [users.id] }), messages: many(ticketMessages) }));
var ticketMessagesRelations = relations(ticketMessages, ({ one }) => ({ ticket: one(tickets, { fields: [ticketMessages.ticketId], references: [tickets.id] }), sender: one(users, { fields: [ticketMessages.senderId], references: [users.id] }) }));
var affiliatesRelations = relations(affiliates, ({ one, many }) => ({ user: one(users, { fields: [affiliates.userId], references: [users.id] }), referrals: many(referrals) }));
var referralsRelations = relations(referrals, ({ one }) => ({ affiliate: one(affiliates, { fields: [referrals.affiliateId], references: [affiliates.id] }), referredUser: one(users, { fields: [referrals.referredUserId], references: [users.id] }) }));
var favoriteServicesRelations = relations(favoriteServices, ({ one }) => ({ user: one(users, { fields: [favoriteServices.userId], references: [users.id] }), service: one(services, { fields: [favoriteServices.serviceId], references: [services.id] }) }));
var settings = pgTable("settings", { id: serial("id").primaryKey(), key: text("key").notNull().unique(), value: text("value").notNull(), createdAt: timestamp("created_at").defaultNow().notNull(), updatedAt: timestamp("updated_at").defaultNow().notNull() });
var blogs = pgTable("blogs", { id: serial("id").primaryKey(), title: text("title").notNull(), slug: text("slug").notNull(), content: text("content").notNull(), authorId: integer("author_id").references(() => users.id, { onDelete: "set null" }), status: text("status").default("published").notNull(), coverImage: text("cover_image"), createdAt: timestamp("created_at").defaultNow().notNull(), updatedAt: timestamp("updated_at").defaultNow().notNull() });
var blogsRelations = relations(blogs, ({ one }) => ({ author: one(users, { fields: [blogs.authorId], references: [users.id] }) }));
var appointments = pgTable("appointments", { id: serial("id").primaryKey(), userId: integer("user_id").references(() => users.id, { onDelete: "set null" }), name: text("name").notNull(), email: text("email").notNull(), phone: text("phone"), date: text("date").notNull(), timeSlot: text("time_slot").notNull(), serviceType: text("service_type").default("General Consultation"), message: text("message"), status: text("status").default("pending").notNull(), createdAt: timestamp("created_at").defaultNow().notNull() });
var appointmentsRelations = relations(appointments, ({ one }) => ({ user: one(users, { fields: [appointments.userId], references: [users.id] }) }));

// src/db/index.ts
var { Pool } = pg;
function sanitizeDbErrorMessage(messageOrError) {
  if (!messageOrError) return "Unknown database error";
  const raw = typeof messageOrError === "string" ? messageOrError : messageOrError.message || String(messageOrError);
  return raw.replace(/(postgres(?:ql)?:\/\/[^:]+:)([^@]+)(@)/gi, "$1***$3").replace(/(password=)[^&;\s]+/gi, "$1***").replace(/(token=)[^&;\s]+/gi, "$1***").replace(/(key=)[a-zA-Z0-9_\-\.]+/gi, "$1***");
}
function normalizeDatabaseUrl(raw) {
  if (!raw) return void 0;
  let url = raw.trim();
  url = url.replace(/:\[([^\]]+)\]@/, (m, p) => ":" + encodeURIComponent(p) + "@");
  const match = url.match(/^(postgres(?:ql)?:\/\/[^:]+):([^@]+)@(.+)$/);
  if (match) {
    const [, protocolAndUser, rawPassword, rest] = match;
    if (rawPassword.includes("@") || rawPassword.includes("#") || rawPassword.includes("[") || rawPassword.includes("]")) {
      const decoded = decodeURIComponent(rawPassword);
      url = `${protocolAndUser}:${encodeURIComponent(decoded)}@${rest}`;
    }
  }
  if (url.includes("db.ixhkffzlxawrbvchfcta.supabase.co")) {
    url = url.replace("postgresql://postgres:", "postgresql://postgres.ixhkffzlxawrbvchfcta:").replace("postgres://postgres:", "postgres://postgres.ixhkffzlxawrbvchfcta:").replace("db.ixhkffzlxawrbvchfcta.supabase.co:5432", "aws-0-ap-northeast-2.pooler.supabase.com:6543").replace("db.ixhkffzlxawrbvchfcta.supabase.co", "aws-0-ap-northeast-2.pooler.supabase.com:6543");
  }
  return url;
}
var isServerless = Boolean(
  process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME || process.env.NETLIFY || process.env.SERVERLESS
);
var getPoolMax = (isSupabase = false) => {
  if (process.env.DB_POOL_MAX) {
    const parsed = parseInt(process.env.DB_POOL_MAX, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  return isServerless || isSupabase ? 1 : 2;
};
var getIdleTimeoutMillis = () => {
  if (process.env.DB_POOL_IDLE_TIMEOUT) {
    const parsed = parseInt(process.env.DB_POOL_IDLE_TIMEOUT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  return 5e3;
};
var getConnectionTimeoutMillis = () => {
  if (process.env.DB_POOL_CONN_TIMEOUT) {
    const parsed = parseInt(process.env.DB_POOL_CONN_TIMEOUT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  return 8e3;
};
var createPool = () => {
  const idleTimeout = getIdleTimeoutMillis();
  const connTimeout = getConnectionTimeoutMillis();
  if (process.env.SQL_HOST && (process.env.SQL_USER || process.env.SQL_ADMIN_USER) && (process.env.SQL_PASSWORD || process.env.SQL_ADMIN_PASSWORD)) {
    const user = process.env.SQL_USER || process.env.SQL_ADMIN_USER || "ai_studio_app_user";
    const password = process.env.SQL_PASSWORD || process.env.SQL_ADMIN_PASSWORD || "";
    const host = process.env.SQL_HOST;
    const database = process.env.SQL_DB_NAME || "cloud_sql_development_database";
    const isSocket = host.startsWith("/");
    const max = getPoolMax(false);
    return new Pool({
      host,
      port: parseInt(process.env.SQL_PORT || "5432", 10),
      user,
      password,
      database,
      ssl: isSocket || process.env.SQL_SSL === "false" ? false : process.env.SQL_SSL === "true" ? { rejectUnauthorized: false } : false,
      connectionTimeoutMillis: connTimeout,
      max,
      idleTimeoutMillis: idleTimeout,
      allowExitOnIdle: true,
      keepAlive: true,
      keepAliveInitialDelayMillis: 1e4
    });
  }
  const rawUrl = process.env.DATABASE_URL || process.env.POSTGRES_URL;
  const connectionString = normalizeDatabaseUrl(rawUrl);
  if (connectionString) {
    const isLocalhost = connectionString.includes("localhost") || connectionString.includes("127.0.0.1");
    const isSupabase = connectionString.includes("supabase.co") || connectionString.includes("supabase.com");
    const max = getPoolMax(isSupabase);
    return new Pool({
      connectionString,
      ssl: isLocalhost ? false : { rejectUnauthorized: false },
      connectionTimeoutMillis: connTimeout,
      max,
      idleTimeoutMillis: idleTimeout,
      allowExitOnIdle: true,
      keepAlive: true,
      keepAliveInitialDelayMillis: 1e4
    });
  }
  return new Pool({
    host: process.env.SQL_HOST || "localhost",
    port: parseInt(process.env.SQL_PORT || "5432", 10),
    user: process.env.SQL_USER || process.env.SQL_ADMIN_USER || "postgres",
    password: process.env.SQL_PASSWORD || process.env.SQL_ADMIN_PASSWORD || "",
    database: process.env.SQL_DB_NAME || "youthsmm",
    ssl: process.env.SQL_SSL === "true" ? { rejectUnauthorized: false } : false,
    connectionTimeoutMillis: connTimeout,
    max: getPoolMax(false),
    idleTimeoutMillis: idleTimeout,
    allowExitOnIdle: true,
    keepAlive: true,
    keepAliveInitialDelayMillis: 1e4
  });
};
function setupPoolErrorHandling(p) {
  p.on("error", (err) => {
    const isExpectedDisconnect = err?.message?.includes("Connection terminated unexpectedly") || err?.message?.includes("Client has encountered a connection error") || err?.message?.includes("terminating connection due to administrator command") || err?.message?.includes("read ECONNRESET") || err?.code === "57P01" || err?.code === "57P02" || err?.code === "57P03" || err?.code === "08006" || err?.code === "08001" || err?.code === "08004" || err?.code === "ECONNRESET";
    if (!isExpectedDisconnect) {
      console.warn("[DB Pool Safe Notice]:", {
        code: err?.code,
        message: sanitizeDbErrorMessage(err)
      });
    }
  });
  const originalQuery = p.query;
  p.query = async function(...args) {
    let attempts = 0;
    const maxAttempts = 3;
    while (true) {
      try {
        attempts++;
        return await originalQuery.apply(this, args);
      } catch (err) {
        const isTransientError = err?.message?.includes("Connection terminated unexpectedly") || err?.message?.includes("Client has encountered a connection error") || err?.message?.includes("terminating connection due to administrator command") || err?.message?.includes("read ECONNRESET") || err?.message?.includes("EMAXCONNSESSION") || err?.message?.includes("max clients reached in session mode") || err?.message?.includes("pool_size: 15") || err?.code === "57P01" || err?.code === "57P02" || err?.code === "57P03" || err?.code === "08006" || err?.code === "08001" || err?.code === "08004" || err?.code === "ECONNRESET";
        if (isTransientError && attempts < maxAttempts) {
          console.log(
            `[DB Pool Safe Notice] Transient connection issue, retrying (attempt ${attempts}/${maxAttempts})...`
          );
          await new Promise((resolve) => setTimeout(resolve, 200 * attempts));
          continue;
        }
        throw err;
      }
    }
  };
  const originalConnect = p.connect;
  p.connect = async function(...args) {
    let attempts = 0;
    const maxAttempts = 3;
    while (true) {
      try {
        attempts++;
        return await originalConnect.apply(this, args);
      } catch (err) {
        const isTransientError = err?.message?.includes("Connection terminated unexpectedly") || err?.message?.includes("Client has encountered a connection error") || err?.message?.includes("terminating connection due to administrator command") || err?.message?.includes("read ECONNRESET") || err?.message?.includes("EMAXCONNSESSION") || err?.message?.includes("max clients reached in session mode") || err?.message?.includes("pool_size: 15") || err?.code === "57P01" || err?.code === "57P02" || err?.code === "57P03" || err?.code === "08006" || err?.code === "08001" || err?.code === "08004" || err?.code === "ECONNRESET";
        if (isTransientError && attempts < maxAttempts) {
          console.log(
            `[DB Pool Safe Notice] Transient socket connection issue, retrying (attempt ${attempts}/${maxAttempts})...`
          );
          await new Promise((resolve) => setTimeout(resolve, 200 * attempts));
          continue;
        }
        throw err;
      }
    }
  };
}
var globalForDb = globalThis;
var getPool = () => {
  if (!globalForDb.__dbPool) {
    globalForDb.__dbPool = createPool();
    setupPoolErrorHandling(globalForDb.__dbPool);
  }
  return globalForDb.__dbPool;
};
var pool = getPool();
var db = globalForDb.__dbInstance || (globalForDb.__dbInstance = drizzle(pool, { schema: schema_exports }));

// src/server/supabase.ts
import { createClient } from "@supabase/supabase-js";
var __defProp2 = Object.defineProperty;
var __name = (target, value) => __defProp2(target, "name", { value, configurable: true });
var SUPABASE_URL = process.env.SUPABASE_URL || "https://ixhkffzlxawrbvchfcta.supabase.co";
var SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_KEY || "sb_publishable_T8nX5ILyvXp5LbFySzLaLA_kzitU05X";
var supabaseServerClient = null;
function getSupabaseServer() {
  if (!supabaseServerClient) {
    supabaseServerClient = createClient(SUPABASE_URL, SUPABASE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
  }
  return supabaseServerClient;
}
__name(getSupabaseServer, "getSupabaseServer");
async function syncPaymentToSupabase(payment) {
  const client = getSupabaseServer();
  try {
    const { data, error } = await client.from("payments").upsert([{ user_id: payment.userId, amount: payment.amount, payment_method: payment.paymentMethod, transaction_id: payment.transactionId, status: payment.status, created_at: (payment.createdAt || /* @__PURE__ */ new Date()).toISOString() }], { onConflict: "transaction_id" }).select();
    if (error) {
      console.warn("Supabase payments sync warning:", error.message);
    }
    return data;
  } catch (err) {
    console.warn("Supabase payments sync error:", err.message);
  }
}
__name(syncPaymentToSupabase, "syncPaymentToSupabase");
async function syncUserBalanceToSupabase(userId, newBalance) {
  const client = getSupabaseServer();
  try {
    const { error } = await client.from("users").update({ balance: newBalance }).eq("id", userId);
    if (error) {
      console.warn("Supabase user balance sync warning:", error.message);
    }
  } catch (err) {
    console.warn("Supabase user balance sync error:", err.message);
  }
}
__name(syncUserBalanceToSupabase, "syncUserBalanceToSupabase");

// src/server/paymentVerification.ts
var __defProp3 = Object.defineProperty;
var __name2 = (target, value) => __defProp3(target, "name", { value, configurable: true });
function resolveBharatPeCredentials(customMerchantId, customToken) {
  const envMerchantId = (process.env.BHARATPE_MERCHANT_ID || process.env.MERCHANT_ID || process.env.BHARATPE_MID || process.env.MID || process.env.BHARAT_PE_MERCHANT_ID || "").trim();
  const envToken = (process.env.BHARATPE_TOKEN || process.env.TOKEN || process.env.BHARATPE_API_KEY || process.env.API_KEY || process.env.BHARATPE_AUTH_TOKEN || process.env.AUTH_TOKEN || process.env.BHARAT_PE_TOKEN || "").trim();
  const envCookie = (process.env.BHARATPE_COOKIE || process.env.COOKIE || "").trim();
  const sanitizeCustom = __name2((val) => {
    if (!val) return "";
    return String(val).trim();
  }, "sanitizeCustom");
  const merchantId = envMerchantId || sanitizeCustom(customMerchantId);
  const token = envToken || sanitizeCustom(customToken);
  return { merchantId, token, cookie: envCookie, isEnvMerchantId: Boolean(envMerchantId), isEnvToken: Boolean(envToken), isEnvCookie: Boolean(envCookie) };
}
__name2(resolveBharatPeCredentials, "resolveBharatPeCredentials");
async function verifyPaymentWithOfficialProvider(params) {
  const cleanUtr = String(params.utr || "").trim().replace(/\D/g, "");
  const expectedAmount = Number(params.expectedAmount) || 0;
  if (!cleanUtr || cleanUtr.length !== 12) {
    return { verified: false, status: "failed", error: "Invalid 12-digit UTR/Bank Reference Number. Please enter the genuine 12-digit reference from your payment receipt." };
  }
  const isRepeated = /^(\d)\1{11}$/.test(cleanUtr);
  const isSequential = "01234567890123456789".includes(cleanUtr) || "98765432109876543210".includes(cleanUtr);
  if (isRepeated || isSequential) {
    return { verified: false, status: "failed", error: "Fake or placeholder UTR detected. Real UPI transactions have a genuine 12-digit bank reference number." };
  }
  const creds = resolveBharatPeCredentials(params.customMerchantId, params.customToken);
  console.log("[BharatPe Server Verification Diagnostics]:", { merchantIdConfigured: Boolean(creds.merchantId), merchantIdLength: creds.merchantId ? creds.merchantId.length : 0, merchantIdSource: creds.isEnvMerchantId ? "process.env" : creds.merchantId ? "database/settings" : "none", tokenConfigured: Boolean(creds.token), tokenLength: creds.token ? creds.token.length : 0, tokenSource: creds.isEnvToken ? "process.env" : creds.token ? "database/settings" : "none", cookieConfigured: creds.isEnvCookie, nodeEnv: process.env.NODE_ENV || "development", vercelEnv: process.env.VERCEL_ENV || "local" });
  if (!creds.merchantId || !creds.token) {
    const missing = [];
    if (!creds.merchantId) missing.push("BHARATPE_MERCHANT_ID (or MERCHANT_ID / MID)");
    if (!creds.token) missing.push("BHARATPE_TOKEN (or TOKEN)");
    console.warn(`[BharatPe Verification] Direct cloud API verification unconfigured: Missing: ${missing.join(", ")}`);
    return { verified: false, status: "pending", error: `Automated gateway verification is not configured on cloud server. Transaction has been queued for admin verification.`, missingCredentials: missing };
  }
  const endpointUrl = `https://payments-tesseract.bharatpe.in/api/v1/merchant/transactions?module=PAYMENT_QR&merchantId=${encodeURIComponent(creds.merchantId)}`;
  const requestHeaders = { "Content-Type": "application/json", "token": creds.token, "Authorization": `Bearer ${creds.token}`, "Accept": "application/json, text/plain, */*", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36", "Origin": "https://merchant.bharatpe.com", "Referer": "https://merchant.bharatpe.com/" };
  if (creds.cookie) {
    requestHeaders["Cookie"] = creds.cookie;
  }
  let rawMatchedTxn = null;
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12e3);
    const response = await fetch(endpointUrl, { method: "GET", headers: requestHeaders, signal: controller.signal });
    clearTimeout(timeoutId);
    if (response.ok) {
      const data = await response.json();
      const transactionList = Array.isArray(data.data?.transactions) && data.data.transactions || Array.isArray(data.transactions) && data.transactions || Array.isArray(data.data) && data.data || Array.isArray(data.transactionList) && data.transactionList || [];
      console.log(`[BharatPe API] Successfully fetched ${transactionList.length} transactions from merchant account.`);
      const matched = transactionList.find((tx) => {
        const bankRef = String(tx.bankReferenceNo || tx.utr || tx.rrn || tx.transactionId || tx.orderId || tx.externalTransactionId || "").trim();
        return bankRef === cleanUtr;
      });
      if (matched) {
        rawMatchedTxn = matched;
      }
    } else {
      const statusCode = response.status;
      let errorBody = "";
      try {
        errorBody = await response.text();
      } catch {
        errorBody = "Unable to read response body";
      }
      console.error(`[BharatPe API Error] HTTP ${statusCode}:`, errorBody.slice(0, 200));
      if (statusCode === 401) {
        return { verified: false, status: "pending", error: "BharatPe merchant session token is expired or unauthorized. Your transaction has been recorded and queued for manual admin verification." };
      }
      if (statusCode === 403) {
        return { verified: false, status: "pending", error: "BharatPe Cloudflare WAF restricted direct cloud server calls. Your transaction has been recorded and queued for manual admin verification." };
      }
      if (statusCode === 429) {
        return { verified: false, status: "pending", error: "BharatPe API rate limit reached. Your transaction has been recorded and queued for admin verification." };
      }
      return { verified: false, status: "pending", error: `BharatPe service returned HTTP ${statusCode}. Your transaction has been recorded and queued for admin verification.` };
    }
  } catch (err) {
    console.error("[BharatPe API Connection Error]:", err.message || err);
    if (err.name === "AbortError") {
      return { verified: false, status: "pending", error: "BharatPe verification timed out. Your transaction has been recorded and queued for admin verification." };
    }
    return { verified: false, status: "pending", error: `Connection to verification gateway was interrupted. Your transaction has been recorded and queued for admin verification.` };
  }
  if (rawMatchedTxn) {
    const rawStatus = String(rawMatchedTxn.status || rawMatchedTxn.paymentStatus || rawMatchedTxn.transactionStatus || "").toUpperCase();
    const txnAmount = Number(rawMatchedTxn.amount || rawMatchedTxn.paymentAmount || rawMatchedTxn.netAmount || 0);
    if (rawStatus === "PENDING") {
      return { verified: false, status: "pending", error: "Payment status is currently PENDING on BharatPe. Please allow 1-2 minutes for bank settlement and submit again.", rawResponse: rawMatchedTxn };
    }
    if (rawStatus === "CANCELLED" || rawStatus === "EXPIRED" || rawStatus === "FAILED") {
      return { verified: false, status: "failed", error: `Payment status is ${rawStatus.toLowerCase()} on BharatPe. Funds were not credited.`, rawResponse: rawMatchedTxn };
    }
    if (rawStatus !== "SUCCESS" && rawStatus !== "COMPLETED" && rawStatus !== "SETTLED") {
      return { verified: false, status: "failed", error: `BharatPe returned unconfirmed payment status: ${rawStatus || "UNKNOWN"}.`, rawResponse: rawMatchedTxn };
    }
    const verifiedCreditAmount = txnAmount > 0 ? txnAmount : expectedAmount > 0 ? expectedAmount : 10;
    return { verified: true, status: "completed", providerTransactionId: cleanUtr, verifiedAmount: verifiedCreditAmount, gateway: "BharatPe Official Merchant API", rawResponse: rawMatchedTxn };
  }
  return { verified: false, status: "failed", error: `Transaction with UTR ${cleanUtr} was not found in your BharatPe merchant transactions. Please ensure the payment was sent to your merchant QR and check the 12-digit UTR number on your receipt.` };
}
__name2(verifyPaymentWithOfficialProvider, "verifyPaymentWithOfficialProvider");

// src/server/smsService.ts
var __defProp4 = Object.defineProperty;
var __name3 = (target, value) => __defProp4(target, "name", { value, configurable: true });
async function sendOtpSms(params) {
  const cleanPhone = String(params.phone || "").replace(/\D/g, "").slice(-10);
  const otp = String(params.otp || "").trim();
  const senderName = params.senderName || "YouthSMM";
  if (!cleanPhone || cleanPhone.length !== 10) {
    return { success: false, provider: "none", message: "Invalid 10-digit mobile number." };
  }
  let fast2smsKey = (process.env.FAST2SMS_API_KEY || params.customApiKey || "").trim();
  let twoFactorKey = (process.env.TWO_FACTOR_API_KEY || "").trim();
  let msg91Key = (process.env.MSG91_AUTH_KEY || "").trim();
  let twilioSid = (process.env.TWILIO_ACCOUNT_SID || "").trim();
  let twilioAuthToken = (process.env.TWILIO_AUTH_TOKEN || "").trim();
  let twilioFrom = (process.env.TWILIO_PHONE_NUMBER || "").trim();
  let customSmsUrl = (process.env.SMS_GATEWAY_URL || "").trim();
  try {
    const dbSettings = await db.select().from(settings);
    const map = Object.fromEntries(dbSettings.map((s) => [s.key, s.value]));
    if (!fast2smsKey && map["fast2smsApiKey"]) fast2smsKey = map["fast2smsApiKey"].trim();
    if (!twoFactorKey && map["twoFactorApiKey"]) twoFactorKey = map["twoFactorApiKey"].trim();
    if (!msg91Key && map["msg91AuthKey"]) msg91Key = map["msg91AuthKey"].trim();
    if (!twilioSid && map["twilioSid"]) twilioSid = map["twilioSid"].trim();
    if (!twilioAuthToken && map["twilioAuthToken"]) twilioAuthToken = map["twilioAuthToken"].trim();
    if (!twilioFrom && map["twilioFrom"]) twilioFrom = map["twilioFrom"].trim();
    if (!customSmsUrl && map["smsGatewayUrl"]) customSmsUrl = map["smsGatewayUrl"].trim();
  } catch (dbErr) {
    console.warn("[SMS Gateway] Notice: Could not read DB settings, using env vars only:", dbErr);
  }
  const smsText = `Your ${senderName} BharatPe verification code is ${otp}. Valid for 10 minutes. Do not share it with anyone.`;
  const errors = [];
  if (fast2smsKey) {
    try {
      console.log(`[SMS Gateway] Attempting Fast2SMS dispatch to +91 ${cleanPhone}...`);
      const f2sRes = await fetch("https://www.fast2sms.com/dev/bulkV2", { method: "POST", headers: { authorization: fast2smsKey, "Content-Type": "application/json" }, body: JSON.stringify({ route: "otp", variables_values: otp, numbers: cleanPhone }) });
      const f2sData = await f2sRes.json().catch(() => ({}));
      if (f2sData?.return === true || f2sRes.ok && f2sData?.status_code === 200) {
        console.log(`[SMS Gateway] Fast2SMS dispatched successfully to +91 ${cleanPhone}`);
        return { success: true, provider: "Fast2SMS", message: `SMS successfully delivered to +91 ${cleanPhone} via Fast2SMS.`, messageId: f2sData.request_id || void 0 };
      }
      const quickUrl = `https://www.fast2sms.com/dev/bulkV2?authorization=${encodeURIComponent(fast2smsKey)}&route=q&message=${encodeURIComponent(`Your ${senderName} verification code is ${otp}. Valid for 10 mins.`)}&language=english&flash=0&numbers=${cleanPhone}`;
      const qRes = await fetch(quickUrl, { method: "GET" });
      const qData = await qRes.json().catch(() => ({}));
      if (qData?.return === true || qRes.ok) {
        console.log(`[SMS Gateway] Fast2SMS Quick Route dispatched successfully to +91 ${cleanPhone}`);
        return { success: true, provider: "Fast2SMS", message: `SMS successfully delivered to +91 ${cleanPhone} via Fast2SMS.`, messageId: qData.request_id || void 0 };
      }
      errors.push(`Fast2SMS: ${f2sData?.message || qData?.message || "Dispatch failed"}`);
    } catch (err) {
      console.error("[SMS Gateway] Fast2SMS fetch failed:", err.message);
      errors.push(`Fast2SMS Error: ${err.message}`);
    }
  }
  if (twoFactorKey) {
    try {
      console.log(`[SMS Gateway] Attempting 2Factor dispatch to +91 ${cleanPhone}...`);
      const url = `https://2factor.in/v1/API/V1/${encodeURIComponent(twoFactorKey)}/SMS/${cleanPhone}/${otp}/OTP1`;
      const tfRes = await fetch(url);
      const tfData = await tfRes.json().catch(() => ({}));
      if (tfData?.Status === "Success") {
        console.log(`[SMS Gateway] 2Factor dispatched successfully to +91 ${cleanPhone}`);
        return { success: true, provider: "2Factor", message: `SMS successfully delivered to +91 ${cleanPhone} via 2Factor.`, messageId: tfData.Details };
      }
      const fallbackUrl = `https://2factor.in/v1/API/V1/${encodeURIComponent(twoFactorKey)}/SMS/${cleanPhone}/${otp}`;
      const tfFallbackRes = await fetch(fallbackUrl);
      const tfFallbackData = await tfFallbackRes.json().catch(() => ({}));
      if (tfFallbackData?.Status === "Success") {
        console.log(`[SMS Gateway] 2Factor fallback dispatched successfully to +91 ${cleanPhone}`);
        return { success: true, provider: "2Factor", message: `SMS successfully delivered to +91 ${cleanPhone} via 2Factor.`, messageId: tfFallbackData.Details };
      }
      errors.push(`2Factor: ${tfData?.Details || tfFallbackData?.Details || "Failed"}`);
    } catch (err) {
      console.error("[SMS Gateway] 2Factor fetch failed:", err.message);
      errors.push(`2Factor Error: ${err.message}`);
    }
  }
  if (msg91Key) {
    try {
      console.log(`[SMS Gateway] Attempting MSG91 dispatch to +91 ${cleanPhone}...`);
      const msg91Url = `https://control.msg91.com/api/v5/otp?template_id=default&mobile=91${cleanPhone}&authkey=${encodeURIComponent(msg91Key)}&otp=${otp}`;
      const msgRes = await fetch(msg91Url, { method: "POST" });
      const msgData = await msgRes.json().catch(() => ({}));
      if (msgData?.type === "success" || msgRes.ok) {
        console.log(`[SMS Gateway] MSG91 dispatched successfully to +91 ${cleanPhone}`);
        return { success: true, provider: "MSG91", message: `SMS successfully delivered to +91 ${cleanPhone} via MSG91.`, messageId: msgData?.message };
      }
      errors.push(`MSG91: ${msgData?.message || "Failed"}`);
    } catch (err) {
      console.error("[SMS Gateway] MSG91 fetch failed:", err.message);
      errors.push(`MSG91 Error: ${err.message}`);
    }
  }
  if (twilioSid && twilioAuthToken && twilioFrom) {
    try {
      console.log(`[SMS Gateway] Attempting Twilio dispatch to +91 ${cleanPhone}...`);
      const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioSid}/Messages.json`;
      const authHeader = Buffer.from(`${twilioSid}:${twilioAuthToken}`).toString("base64");
      const body = new URLSearchParams({ To: `+91${cleanPhone}`, From: twilioFrom, Body: smsText });
      const twilioRes = await fetch(twilioUrl, { method: "POST", headers: { Authorization: `Basic ${authHeader}`, "Content-Type": "application/x-www-form-urlencoded" }, body: body.toString() });
      const twilioData = await twilioRes.json().catch(() => ({}));
      if (twilioRes.ok && twilioData?.sid) {
        console.log(`[SMS Gateway] Twilio dispatched successfully to +91 ${cleanPhone}`);
        return { success: true, provider: "Twilio", message: `SMS successfully delivered to +91 ${cleanPhone} via Twilio.`, messageId: twilioData.sid };
      }
      errors.push(`Twilio: ${twilioData?.message || "Failed"}`);
    } catch (err) {
      console.error("[SMS Gateway] Twilio fetch failed:", err.message);
      errors.push(`Twilio Error: ${err.message}`);
    }
  }
  if (customSmsUrl) {
    try {
      console.log(`[SMS Gateway] Attempting Custom Gateway dispatch to +91 ${cleanPhone}...`);
      const targetUrl = customSmsUrl.replace("{phone}", cleanPhone).replace("{otp}", otp).replace("{message}", encodeURIComponent(smsText));
      const custRes = await fetch(targetUrl, { method: "GET" });
      if (custRes.ok) {
        console.log(`[SMS Gateway] Custom SMS Gateway dispatched to +91 ${cleanPhone}`);
        return { success: true, provider: "CustomGateway", message: `SMS successfully dispatched to +91 ${cleanPhone} via Custom Gateway.` };
      }
      errors.push(`Custom Gateway: HTTP ${custRes.status}`);
    } catch (err) {
      console.error("[SMS Gateway] Custom Gateway failed:", err.message);
      errors.push(`Custom Gateway Error: ${err.message}`);
    }
  }
  const noGatewaysConfigured = !fast2smsKey && !twoFactorKey && !msg91Key && (!twilioSid || !twilioAuthToken) && !customSmsUrl;
  if (noGatewaysConfigured) {
    console.warn(`[SMS Gateway] Notice: No active SMS gateway configured in Vercel environment variables or Admin Settings.`);
    return { success: false, provider: "none", message: "SMS Gateway is not configured. Please enter your Fast2SMS or 2Factor API Key in Admin Settings or add FAST2SMS_API_KEY to your Vercel Environment Variables so the OTP SMS can reach your phone.", errorDetails: "Missing SMS provider credentials" };
  }
  return { success: false, provider: "failed", message: `SMS delivery failed across configured gateways. Details: ${errors.join("; ")}`, errorDetails: errors.join("; ") };
}
__name3(sendOtpSms, "sendOtpSms");

// src/middleware/auth.ts
import { eq, or } from "drizzle-orm";
import { verifyToken } from "@clerk/backend";
var __defProp5 = Object.defineProperty;
var __name4 = (target, value) => __defProp5(target, "name", { value, configurable: true });
function safeDecodeJwt(jwtString) {
  try {
    const parts = jwtString.split(".");
    if (parts.length < 2) return null;
    const base64Url = parts[1];
    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    const jsonPayload = Buffer.from(base64, "base64").toString("utf8");
    return JSON.parse(jsonPayload);
  } catch {
    return null;
  }
}
__name4(safeDecodeJwt, "safeDecodeJwt");
var requireAuth = __name4(async (req, res, next) => {
  const authHeader = req.headers.authorization;
  let token = "";
  if (authHeader && authHeader.startsWith("Bearer ")) {
    token = authHeader.split("Bearer ")[1].trim();
  } else if (req.headers.cookie) {
    const cookieHeader = req.headers.cookie;
    const match = cookieHeader.match(/(?:^|;\s*)(?:__session|auth_token|session_token|youthsmm_token)=([^;]+)/);
    if (match && match[1]) {
      token = decodeURIComponent(match[1]).trim();
    }
  }
  if (!token) {
    return res.status(401).json({ error: "Unauthorized: Missing token or session cookie" });
  }
  try {
    let uid;
    let email = "";
    let name = "";
    const clerkSecretKey = process.env.CLERK_SECRET_KEY;
    const decodedJwt = safeDecodeJwt(token);
    if (decodedJwt && (decodedJwt.sub || decodedJwt.iss?.includes("clerk") || decodedJwt.azp)) {
      if (clerkSecretKey) {
        try {
          const verified = await verifyToken(token, { secretKey: clerkSecretKey });
          if (verified) {
            uid = verified.sub;
            email = verified.email || verified.primary_email_address || decodedJwt.email || decodedJwt.email_address || "";
            name = verified.name || decodedJwt.name || "";
          } else {
            uid = decodedJwt.sub;
            email = decodedJwt.email || decodedJwt.email_address || "";
            name = decodedJwt.name || "";
          }
        } catch {
          uid = decodedJwt.sub;
          email = decodedJwt.email || decodedJwt.email_address || "";
          name = decodedJwt.name || "";
        }
      } else {
        uid = decodedJwt.sub;
        email = decodedJwt.email || decodedJwt.email_address || "";
        name = decodedJwt.name || "";
      }
      if (!email && uid) {
        email = `${uid}@clerk.user`;
      }
      if (!name) {
        name = email ? email.split("@")[0] : "User";
      }
    } else if (token === "sandbox-admin-token") {
      uid = "sandbox-admin-uid";
      email = "bhattg805@gmail.com";
      name = "Sandbox Admin";
    } else if (token === "sandbox-user-token") {
      uid = "sandbox-user-uid";
      email = "sandbox-user@example.com";
      name = "Sandbox User";
    } else if (decodedJwt && (decodedJwt.email || decodedJwt.id)) {
      email = (decodedJwt.email || "").toLowerCase().trim();
      uid = decodedJwt.sub || `local-${email || decodedJwt.id}`;
      name = decodedJwt.name || (email ? email.split("@")[0] : "User");
    } else if (token.startsWith("local-token-")) {
      email = token.replace("local-token-", "").toLowerCase().trim();
      uid = `local-${email}`;
      name = email.split("@")[0];
    } else if (token.startsWith("clerk-user-")) {
      const parts = token.split(":");
      uid = parts[0];
      email = parts[1] || `${uid}@clerk.user`;
      name = parts[2] || email.split("@")[0];
    } else {
      if (token.startsWith("eyJ")) {
        return res.status(401).json({ error: "Invalid or expired token payload" });
      }
      email = token.toLowerCase().trim();
      uid = `local-${email}`;
      name = email.split("@")[0];
    }
    email = email.toLowerCase().trim();
    const isAdminEmail = __name4((e) => {
      const norm = (e || "").toLowerCase().trim();
      return norm === "bhattg805@gmail.com" || norm === "bhattg805@gmai.com" || norm.includes("bhattg805");
    }, "isAdminEmail");
    const existing = await db.select().from(users).where(or(eq(users.email, email), eq(users.uid, uid))).limit(1);
    let dbUser;
    if (existing.length > 0) {
      dbUser = existing[0];
      const updates = {};
      if (dbUser.uid !== uid && uid.startsWith("user_")) {
        updates.uid = uid;
      }
      if (isAdminEmail(email) || isAdminEmail(dbUser.email)) {
        if (dbUser.role !== "admin" || dbUser.status !== "active") {
          updates.role = "admin";
          updates.status = "active";
        }
      }
      if (Object.keys(updates).length > 0) {
        const [updatedUser] = await db.update(users).set(updates).where(eq(users.id, dbUser.id)).returning();
        dbUser = updatedUser;
      }
    } else {
      const roleToSet = isAdminEmail(email) ? "admin" : "user";
      const result = await db.insert(users).values({ uid, email, name: name || email.split("@")[0], role: roleToSet, balance: 0, status: "active" }).returning();
      dbUser = result[0];
    }
    req.user = dbUser;
    const isUserAdmin = isAdminEmail(dbUser.email) || dbUser.role === "admin";
    if (dbUser.status === "suspended" && !isUserAdmin) {
      const currentPath = (req.baseUrl || "") + (req.path || "");
      const isAllowed = currentPath.includes("/user/profile") || currentPath.includes("/auth/me") || currentPath.includes("/auth/logout");
      if (!isAllowed) {
        return res.status(403).json({ error: "Your account has been suspended by the administrator. Please contact support.", isSuspended: true });
      }
    }
    next();
  } catch (error) {
    console.error("Error in auth verification / sync user:", error);
    return res.status(401).json({ error: "Unauthorized: Invalid token" });
  }
}, "requireAuth");
var requireAdmin = __name4(async (req, res, next) => {
  await requireAuth(req, res, async () => {
    const norm = (req.user?.email || "").toLowerCase().trim();
    const isAdmin = norm === "bhattg805@gmail.com" || norm === "bhattg805@gmai.com" || norm.includes("bhattg805") || req.user?.role === "admin";
    if (!isAdmin) {
      return res.status(403).json({ error: "Forbidden: Admin access required" });
    }
    next();
  });
}, "requireAdmin");

// src/server/api.ts
import { eq as eq4, and, desc as desc3, sql as sql2, or as or2, inArray, gte, lt, ne } from "drizzle-orm";

// src/server/sitemap.ts
import { eq as eq2, desc } from "drizzle-orm";
var __defProp6 = Object.defineProperty;
var __name5 = (target, value) => __defProp6(target, "name", { value, configurable: true });
var STATIC_PUBLIC_PAGES = [{ path: "", changefreq: "daily", priority: "1.0" }, { path: "/services", changefreq: "daily", priority: "0.9" }, { path: "/blog", changefreq: "daily", priority: "0.8" }, { path: "/faq", changefreq: "weekly", priority: "0.8" }, { path: "/api-docs", changefreq: "monthly", priority: "0.7" }, { path: "/child-panels", changefreq: "monthly", priority: "0.7" }, { path: "/affiliates", changefreq: "monthly", priority: "0.7" }, { path: "/about", changefreq: "monthly", priority: "0.6" }, { path: "/contact", changefreq: "monthly", priority: "0.6" }, { path: "/terms", changefreq: "monthly", priority: "0.5" }, { path: "/privacy", changefreq: "monthly", priority: "0.5" }];
var STATIC_EDITORIAL_ARTICLES = [{ slug: "how-to-maximize-organic-reach-with-smm-in-2026", updatedAt: "2026-08-15", priority: "0.7", changefreq: "weekly" }, { slug: "youtube-algorithm-essentials-watch-time-vs-click-through-rate", updatedAt: "2026-07-20", priority: "0.7", changefreq: "weekly" }, { slug: "how-to-launch-a-profitable-reseller-panel-with-youthsmm-child-panels", updatedAt: "2026-06-10", priority: "0.7", changefreq: "weekly" }];
function getCanonicalBaseUrl(req, customDomainSetting) {
  if (customDomainSetting && /^https?:\/\//i.test(customDomainSetting.trim())) {
    return customDomainSetting.trim().replace(/\/+$/, "");
  }
  if (req) {
    const rawProto = req.headers["x-forwarded-proto"] || req.protocol || "https";
    const proto = rawProto.split(",")[0].trim();
    const rawHost = req.headers["x-forwarded-host"] || req.get("host") || "";
    const host = rawHost.split(",")[0].trim();
    if (host && !host.includes("localhost") && !host.includes("127.0.0.1")) {
      if (host === "youthsmm.com" || host === "www.youthsmm.com") {
        return "https://www.youthsmm.com";
      }
      const safeProto = proto === "http" ? "https" : proto;
      return `${safeProto}://${host}`;
    }
  }
  const envUrl = (process.env.APP_URL || process.env.NEXT_PUBLIC_APP_URL || process.env.VITE_APP_URL || process.env.SITE_URL || process.env.DOMAIN || "").trim().replace(/\/+$/, "");
  if (envUrl && /^https?:\/\//i.test(envUrl)) {
    return envUrl;
  }
  if (req) {
    const rawHost = req.headers["x-forwarded-host"] || req.get("host") || "";
    if (rawHost) {
      return `http://${rawHost.split(",")[0].trim()}`;
    }
  }
  return "https://www.youthsmm.com";
}
__name5(getCanonicalBaseUrl, "getCanonicalBaseUrl");
async function generateSitemapXml(baseUrl) {
  const currentDate = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const cleanBase = baseUrl.replace(/\/+$/, "");
  const urls = [];
  for (const page of STATIC_PUBLIC_PAGES) {
    urls.push({ loc: page.path === "" ? `${cleanBase}/` : `${cleanBase}${page.path}`, lastmod: currentDate, changefreq: page.changefreq, priority: page.priority });
  }
  const seenSlugs = /* @__PURE__ */ new Set();
  try {
    const publishedBlogs = await db.select({ id: blogs.id, slug: blogs.slug, updatedAt: blogs.updatedAt, createdAt: blogs.createdAt }).from(blogs).where(eq2(blogs.status, "published")).orderBy(desc(blogs.createdAt));
    for (const blog of publishedBlogs) {
      const identifier = blog.slug || String(blog.id);
      if (identifier && !seenSlugs.has(identifier)) {
        seenSlugs.add(identifier);
        const lastmodDate = blog.updatedAt || blog.createdAt;
        const formattedDate = lastmodDate ? new Date(lastmodDate).toISOString().split("T")[0] : currentDate;
        urls.push({ loc: `${cleanBase}/blog/${encodeURIComponent(identifier)}`, lastmod: formattedDate, changefreq: "weekly", priority: "0.7" });
      }
    }
  } catch (err) {
    console.warn("[SITEMAP] Could not query dynamic blogs table:", err);
  }
  for (const article of STATIC_EDITORIAL_ARTICLES) {
    if (!seenSlugs.has(article.slug)) {
      seenSlugs.add(article.slug);
      urls.push({ loc: `${cleanBase}/blog/${article.slug}`, lastmod: article.updatedAt, changefreq: article.changefreq, priority: article.priority });
    }
  }
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
  for (const item of urls) {
    xml += "  <url>\n";
    xml += `    <loc>${item.loc}</loc>
`;
    xml += `    <lastmod>${item.lastmod}</lastmod>
`;
    xml += `    <changefreq>${item.changefreq}</changefreq>
`;
    xml += `    <priority>${item.priority}</priority>
`;
    xml += "  </url>\n";
  }
  xml += "</urlset>";
  return xml;
}
__name5(generateSitemapXml, "generateSitemapXml");
function generateRobotsTxt(baseUrl) {
  const cleanBase = baseUrl.replace(/\/+$/, "");
  return `# robots.txt for YouthSMM
# Generated automatically with dynamic canonical domain detection

User-agent: *
Allow: /
Allow: /favicon*
Allow: /apple-touch-icon*
Allow: /*.ico
Allow: /*.png
Allow: /*.svg
Allow: /site.webmanifest
Allow: /services
Allow: /blog
Allow: /blog/*
Allow: /api-docs
Allow: /about
Allow: /faq
Allow: /contact
Allow: /terms
Allow: /privacy
Allow: /child-panels
Allow: /affiliates

# Explicitly allow Google Search & Image crawlers to index favicon and brand assets
User-agent: Googlebot-Image
Allow: /

User-agent: Googlebot
Allow: /

# Disallow private user, admin, auth and API backend routes
Disallow: /admin
Disallow: /admin/
Disallow: /dashboard
Disallow: /dashboard/
Disallow: /api/
Disallow: /auth/
Disallow: /login
Disallow: /register
Disallow: /signin
Disallow: /signup

# Sitemap Location
Sitemap: ${cleanBase}/sitemap.xml
`;
}
__name5(generateRobotsTxt, "generateRobotsTxt");
async function sitemapHandler(req, res) {
  try {
    let customDomain;
    try {
      const rows = await db.select().from(settings).where(eq2(settings.key, "websiteUrl")).limit(1);
      if (rows.length > 0 && rows[0].value) {
        customDomain = rows[0].value;
      }
    } catch (_) {
    }
    const baseUrl = getCanonicalBaseUrl(req, customDomain);
    const xml = await generateSitemapXml(baseUrl);
    res.setHeader("Content-Type", "application/xml; charset=utf-8");
    res.setHeader("Cache-Control", "public, max-age=3600, s-maxage=3600");
    res.status(200).send(xml);
  } catch (error) {
    console.error("[SITEMAP ERROR]", error);
    res.status(500).setHeader("Content-Type", "text/plain").send("Failed to generate sitemap.");
  }
}
__name5(sitemapHandler, "sitemapHandler");
async function robotsHandler(req, res) {
  try {
    let customDomain;
    try {
      const rows = await db.select().from(settings).where(eq2(settings.key, "websiteUrl")).limit(1);
      if (rows.length > 0 && rows[0].value) {
        customDomain = rows[0].value;
      }
    } catch (_) {
    }
    const baseUrl = getCanonicalBaseUrl(req, customDomain);
    const text2 = generateRobotsTxt(baseUrl);
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Cache-Control", "public, max-age=3600, s-maxage=3600");
    res.status(200).send(text2);
  } catch (error) {
    console.error("[ROBOTS.TXT ERROR]", error);
    res.status(500).setHeader("Content-Type", "text/plain").send("User-agent: *\nAllow: /\n");
  }
}
__name5(robotsHandler, "robotsHandler");

// src/server/ai.ts
import { GoogleGenAI } from "@google/genai";
import { eq as eq3, desc as desc2, sql } from "drizzle-orm";
var __defProp7 = Object.defineProperty;
var __name6 = (target, value) => __defProp7(target, "name", { value, configurable: true });
var genAIClient = null;
function getGenAI() {
  if (!genAIClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      genAIClient = new GoogleGenAI({ apiKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
    }
  }
  return genAIClient;
}
__name6(getGenAI, "getGenAI");
async function handleAiChat({ message, history = [], userId }) {
  const trimmed = message.trim();
  const lower = trimmed.toLowerCase();
  const orderIdMatch = trimmed.match(/(?:#|order\s*(?:id)?\s*:?\s*|id\s*:?\s*)?(\b\d{1,8}\b)/i);
  let candidateId = null;
  if (orderIdMatch && orderIdMatch[1]) {
    const parsed = parseInt(orderIdMatch[1], 10);
    if (!isNaN(parsed) && parsed > 0) {
      candidateId = parsed;
    }
  }
  const isShowsCompleted = /shows?\s*completed|completed\s*without\s*complete|not\s*received|fake\s*complete|mila\s*nahi|aaya\s*nahi|deliver\s*nahi/i.test(trimmed);
  const isCancel = /\b(cancel|stop|rok|abort|cancel\s*order)\b/i.test(trimmed);
  const isRefill = /\b(refill|drop|restore|kam\s*ho\s*gaye|refill\s*request)\b/i.test(trimmed);
  const isSpeed = /\b(speed(?:\s*up)?|fast|jaldi|expedite|boost|speedup)\b/i.test(trimmed);
  const isStatus = /\b(status|check|progress|kaha\s*tak|track|kaisa\s*hai)\b/i.test(trimmed);
  let specificOrder = null;
  if (candidateId) {
    try {
      const found = await db.select({ id: orders.id, userId: orders.userId, serviceId: orders.serviceId, link: orders.link, quantity: orders.quantity, charge: orders.charge, status: orders.status, startCount: orders.startCount, remains: orders.remains, refillStatus: orders.refillStatus, createdAt: orders.createdAt, serviceName: services.name }).from(orders).leftJoin(services, eq3(orders.serviceId, services.id)).where(eq3(orders.id, candidateId)).limit(1);
      if (found.length > 0) {
        specificOrder = found[0];
      }
    } catch (e) {
      console.error("Error fetching specific order in AI chatbot:", e);
    }
  }
  let recentOrders = [];
  if (userId) {
    try {
      recentOrders = await db.select({ id: orders.id, serviceId: orders.serviceId, link: orders.link, quantity: orders.quantity, charge: orders.charge, status: orders.status, startCount: orders.startCount, remains: orders.remains, createdAt: orders.createdAt, serviceName: services.name }).from(orders).leftJoin(services, eq3(orders.serviceId, services.id)).where(eq3(orders.userId, userId)).orderBy(desc2(orders.createdAt)).limit(5);
    } catch (e) {
      console.error("Error fetching recent orders for AI chatbot:", e);
    }
  }
  let settingsList = {};
  let popularServices = [];
  try {
    const sRows = await db.select().from(settings);
    sRows.forEach((r) => {
      settingsList[r.key] = r.value;
    });
    popularServices = await db.select({ id: services.id, name: services.name, pricePerThousand: services.pricePerThousand, categoryName: categories.name }).from(services).leftJoin(categories, eq3(services.categoryId, categories.id)).where(eq3(services.status, "active")).limit(8);
  } catch (e) {
    console.error("Error fetching settings/services for AI context:", e);
  }
  const websiteName = settingsList.websiteName || "YouthSMM";
  const telegramUsername = settingsList.telegramUsername || "@securesmmtursted";
  const whatsappNumber = settingsList.whatsappNumber || "8795005604";
  let directCommandResponse = null;
  if (specificOrder) {
    const s = specificOrder;
    const orderStatus = (s.status || "").toLowerCase();
    const refillSt = (s.refillStatus || "").toLowerCase();
    if (isShowsCompleted) {
      let ticketId = 0;
      try {
        const [createdTicket] = await db.insert(tickets).values({ userId: s.userId || userId || 1, subject: `\u26A0\uFE0F Order #${s.id} - Showing Completed Without Complete`, status: "open" }).returning();
        if (createdTicket) {
          ticketId = createdTicket.id;
          await db.insert(ticketMessages).values({ ticketId: createdTicket.id, senderId: s.userId || userId || 1, message: `User reported via AI Support Chatbot: Order #${s.id} (${s.serviceName || "SMM Service"}, Link: ${s.link}, Quantity: ${s.quantity}) is marked as COMPLETED, but the service was NOT received. Urgent technical audit requested.` });
        }
        await db.insert(activityLogs).values({ userId: s.userId || userId || null, action: "Report Completed Without Complete", details: `Urgent audit ticket #${ticketId} created for Order #${s.id}` });
      } catch (err) {
        console.error("Failed to log audit ticket:", err);
      }
      directCommandResponse = `\u26A0\uFE0F **Investigation Ticket Created for Order #${s.id}!**

\u2022 **Command:** \`${s.id} shows completed\`
\u2022 **Issue:** Showing Completed Without Complete
\u2022 **Service:** ${s.serviceName || "SMM Service #" + s.serviceId}
\u2022 **Target Link:** \`${s.link}\`
\u2022 **Quantity Ordered:** ${s.quantity?.toLocaleString()}
\u2022 **Urgent Ticket ID:** #TCK-${ticketId || s.id}

\u{1F4CB} **Action Taken:**
1\uFE0F\u20E3 Provider audit node par re-check request forward kar di gayi hai.
2\uFE0F\u20E3 Link delivery status ko technical team review karegi. Agar fake/premature complete hua hoga toh order re-deliver kiya jayega ya poora amount aapke wallet me refund ho jayega.
3\uFE0F\u20E3 Ticket progress aap **Tickets** tab me check kar sakte hain.`;
    } else if (isRefill) {
      if (orderStatus === "cancelled" || orderStatus === "refunded") {
        directCommandResponse = `\u274C **Order #${s.id} is Cancelled.**
Refill is not applicable on cancelled orders.`;
      } else if (orderStatus === "pending") {
        directCommandResponse = `\u23F3 **Order #${s.id} is Pending.**
Refill completed orders par drop aane par submit hota hai. Agar order start karwana hai toh reply karein: \`${s.id} speed\`.`;
      } else if (refillSt === "requested") {
        directCommandResponse = `\u{1F504} **Refill Already Active for Order #${s.id}!**

\u2022 **Status:** Refill In-Progress
\u2022 **Service:** ${s.serviceName || "SMM Service"}
\u2022 **Link:** \`${s.link}\`

Aapka refill request already server par process ho raha hai (restoration usually takes 1-24 hours). Live updates Orders tab me milenge.`;
      } else {
        try {
          await db.update(orders).set({ refillStatus: "requested" }).where(eq3(orders.id, s.id));
          await db.insert(refillRequests).values({ userId: s.userId || userId || 1, orderId: s.id, status: "pending" });
          const [t] = await db.insert(tickets).values({ userId: s.userId || userId || 1, subject: `Refill Request: Order #${s.id}`, status: "open" }).returning();
          if (t) {
            await db.insert(ticketMessages).values({ ticketId: t.id, senderId: s.userId || userId || 1, message: `Automated refill request initiated via Chatbot for Order #${s.id} (${s.serviceName}, Link: ${s.link}).` });
          }
          await db.insert(activityLogs).values({ userId: s.userId || userId || null, action: "Chatbot Refill Request", details: `Refill requested for Order #${s.id} via AI Chatbot` });
          s.refillStatus = "requested";
        } catch (err) {
          console.error("Refill request error:", err);
        }
        directCommandResponse = `\u{1F504} **Refill Request Submitted for Order #${s.id}!**

\u2022 **Command:** \`${s.id} refill\`
\u2022 **Service:** ${s.serviceName || "SMM Service #" + s.serviceId}
\u2022 **Link:** \`${s.link}\`
\u2022 **Refill Status:** \`REQUESTED\` \u26A1
\u2022 **Tracking ID:** #RF-${s.id}

\u2705 Server ne refill command provider network ko dispatch kar di hai. Dropped counts restore hona 1-24 hours me complete ho jata hai. Live updates aap Orders tab me dekh sakte hain.`;
      }
    } else if (isSpeed) {
      if (orderStatus === "completed") {
        directCommandResponse = `\u2705 **Order #${s.id} Already Completed!**

\u2022 **Status:** \`COMPLETED\`
Speed-up ki zaroorat nahi hai kyunki order deliver ho chuka hai.
\u2022 Agar count drop hua ho, reply karein: \`${s.id} refill\`
\u2022 Agar service nahi aayi ho, reply karein: \`${s.id} shows completed\``;
      } else if (orderStatus === "cancelled" || orderStatus === "refunded") {
        directCommandResponse = `\u274C **Order #${s.id} is Cancelled.** Speed-up cannot be applied.`;
      } else {
        let ticketId = 0;
        try {
          const [t] = await db.insert(tickets).values({ userId: s.userId || userId || 1, subject: `\u26A1 Speed-Up Request: Order #${s.id}`, status: "open" }).returning();
          if (t) {
            ticketId = t.id;
            await db.insert(ticketMessages).values({ ticketId: t.id, senderId: s.userId || userId || 1, message: `Priority speed-up requested for Order #${s.id} (${s.serviceName}, Link: ${s.link}, Status: ${s.status}, Remains: ${s.remains}). Expediting dispatch.` });
          }
          await db.insert(activityLogs).values({ userId: s.userId || userId || null, action: "Chatbot Speed-Up Request", details: `Speed-up accelerated for Order #${s.id}` });
        } catch (err) {
          console.error("Speed up error:", err);
        }
        directCommandResponse = `\u{1F680} **Speed-Up Accelerated for Order #${s.id}!**

\u2022 **Command:** \`${s.id} speed\`
\u2022 **Service:** ${s.serviceName || "SMM Service"}
\u2022 **Current Status:** \`${orderStatus.toUpperCase()}\`
\u2022 **Remains:** ${s.remains ?? 0} / ${s.quantity}
\u2022 **Priority Node:** \u26A1 HIGH PRIORITY DISPATCHED

\u2705 Server delivery queue me aapke order ki priority elevate kar di gayi hai. Delivery node ko acceleration signal send ho chuka hai, aapko link par speed boost jald dikhega!`;
      }
    } else if (isCancel) {
      if (orderStatus === "completed") {
        directCommandResponse = `\u26A0\uFE0F **Order #${s.id} Cannot Be Cancelled.**

\u2022 **Status:** \`COMPLETED\`
\u2022 **Service:** ${s.serviceName || "SMM Service"}
\u2022 **Link:** \`${s.link}\`

Yeh order server par pehle hi deliver ho chuka hai.
\u2022 Agar count drop ho gaya hai, reply karein: \`${s.id} refill\`
\u2022 Agar count receive nahi hua, reply karein: \`${s.id} shows completed\``;
      } else if (orderStatus === "cancelled" || orderStatus === "refunded") {
        directCommandResponse = `\u2139\uFE0F **Order #${s.id} Already Cancelled.**

\u2022 **Status:** \`${orderStatus.toUpperCase()}\`
Aapka order pehle se hi cancelled hai aur refund balance me credit ho chuka hai.`;
      } else if (orderStatus === "pending") {
        try {
          await db.update(orders).set({ status: "cancelled", remains: s.quantity }).where(eq3(orders.id, s.id));
          if (s.userId && s.charge > 0) {
            await db.update(users).set({ balance: sql`${users.balance} + ${s.charge}` }).where(eq3(users.id, s.userId));
          }
          await db.insert(activityLogs).values({ userId: s.userId || userId || null, action: "Chatbot Order Cancelled", details: `Order #${s.id} cancelled via Chatbot. Refunded \u20B9${s.charge} to user #${s.userId}.` });
          s.status = "cancelled";
        } catch (err) {
          console.error("Cancel order error:", err);
        }
        directCommandResponse = `\u274C **Order #${s.id} Successfully Cancelled!**

\u2022 **Command:** \`${s.id} cancel\`
\u2022 **Service:** ${s.serviceName || "SMM Service"}
\u2022 **Status:** \`CANCELLED\`
\u2022 **Refund Credited:** \u20B9${Number(s.charge).toFixed(2)}
\u2022 **Wallet Balance:** Updated instantly!

Order start hone se pehle hi cancel kar diya gaya hai aur full refund aapke wallet me add ho chuka hai. Aap New Order tab se naya order laga sakte hain.`;
      } else {
        let ticketId = 0;
        try {
          const [t] = await db.insert(tickets).values({ userId: s.userId || userId || 1, subject: `Cancellation Request: Order #${s.id}`, status: "open" }).returning();
          if (t) {
            ticketId = t.id;
            await db.insert(ticketMessages).values({ ticketId: t.id, senderId: s.userId || userId || 1, message: `User requested cancellation for in-progress Order #${s.id} (${s.serviceName}, Link: ${s.link}, Remains: ${s.remains}). Halting provider dispatch.` });
          }
          await db.insert(activityLogs).values({ userId: s.userId || userId || null, action: "Chatbot Cancel Request", details: `Cancellation ticket #${ticketId} submitted for active Order #${s.id}` });
        } catch (err) {
          console.error("Cancel ticket error:", err);
        }
        directCommandResponse = `\u23F3 **Cancellation Request Submitted for Order #${s.id}!**

\u2022 **Command:** \`${s.id} cancel\`
\u2022 **Status:** \`${orderStatus.toUpperCase()}\` (Active on Provider Node)
\u2022 **Remains:** ${s.remains ?? 0}
\u2022 **Priority Ticket:** #CAN-${ticketId || s.id}

\u26A0\uFE0F Kyunki order currently server par process ho raha hai, provider node ko cancel hold command send kar di gayi hai. Agar provider cancel approve karta hai, toh remaining balance automatically aapke wallet me refund ho jayega.`;
      }
    } else if (isStatus) {
      const statusEmoji = s.status === "completed" ? "\u2705" : s.status === "processing" ? "\u26A1" : s.status === "pending" ? "\u23F3" : s.status === "cancelled" ? "\u274C" : "\u26A0\uFE0F";
      const total = s.quantity || 1;
      const remains = s.remains ?? 0;
      const delivered = Math.max(0, total - remains);
      const percent = Math.min(100, Math.round(delivered / total * 100));
      directCommandResponse = `\u{1F4E6} **Order Status for #${s.id}**

${statusEmoji} **Status:** \`${(s.status || "").toUpperCase()}\`
\u{1F6E0}\uFE0F **Service:** ${s.serviceName || "SMM Service #" + s.serviceId}
\u{1F517} **Link:** \`${s.link}\`
\u{1F4CA} **Quantity:** ${s.quantity?.toLocaleString()}
\u{1F522} **Start Count:** ${s.startCount ?? 0} | **Remains:** ${remains}
\u{1F4C8} **Progress:** ${percent}% delivered
\u{1F552} **Date Placed:** ${new Date(s.createdAt).toLocaleString()}

To manage this order, reply with your Order ID followed by a command:

\`${s.id} status\` \u2014 check progress

\`${s.id} refill\` \u2014 request a refill

\`${s.id} speed\` \u2014 request a speed-up

\`${s.id} cancel\` \u2014 request cancellation

\`${s.id} shows completed\` \u2014 Showing Completed Without Complete`;
    } else if (!isShowsCompleted && !isCancel && !isRefill && !isSpeed && !isStatus) {
      directCommandResponse = `\u{1F44B} **Order #${s.id} Found!**

\u2022 **Service:** ${s.serviceName || "SMM Service #" + s.serviceId}
\u2022 **Status:** \`${(s.status || "").toUpperCase()}\`
\u2022 **Link:** \`${s.link}\`
\u2022 **Quantity:** ${s.quantity?.toLocaleString()} | **Remains:** ${s.remains ?? 0}

To manage an order, reply with your Order ID followed by a command:

\`${s.id} status\` \u2014 check progress

\`${s.id} refill\` \u2014 request a refill

\`${s.id} speed\` \u2014 request a speed-up

\`${s.id} cancel\` \u2014 request cancellation

\`${s.id} shows completed\` \u2014 Showing Completed Without Complete`;
    }
  } else if (candidateId && !specificOrder) {
    directCommandResponse = `\u274C **Order #${candidateId} Not Found.**

Database me Order #${candidateId} nahi mila. Kripya apna sahi Order ID verify karein.

To manage an order, reply with your Order ID followed by a command:

\`${candidateId} status\` \u2014 check progress

\`${candidateId} refill\` \u2014 request a refill

\`${candidateId} speed\` \u2014 request a speed-up

\`${candidateId} cancel\` \u2014 request cancellation

\`${candidateId} shows completed\` \u2014 Showing Completed Without Complete`;
  } else if (!candidateId && (isShowsCompleted || isCancel || isRefill || isSpeed || isStatus)) {
    const cmdName = isShowsCompleted ? "shows completed" : isCancel ? "cancel" : isRefill ? "refill" : isSpeed ? "speed" : "status";
    if (recentOrders.length > 0) {
      const recentId = recentOrders[0].id;
      directCommandResponse = `\u{1F50D} Aapka recent order **#${recentId}** (${recentOrders[0].serviceName || "Service"}) hai.

To manage this order, reply with:
\u2022 \`${recentId} ${cmdName}\`

Ya phir apna specific Order ID likhein:
\u2022 \`[OrderID] ${cmdName}\` (jaise \`12345 ${cmdName}\`)

---
**All Available Commands:**
\`${recentId} status\` \u2014 check progress
\`${recentId} refill\` \u2014 request a refill
\`${recentId} speed\` \u2014 request a speed-up
\`${recentId} cancel\` \u2014 request cancellation
\`${recentId} shows completed\` \u2014 Showing Completed Without Complete`;
    } else {
      directCommandResponse = `To manage an order, reply with your Order ID followed by a command:

\`12345 status\` \u2014 check progress

\`12345 refill\` \u2014 request a refill

\`12345 speed\` \u2014 request a speed-up

\`12345 cancel\` \u2014 request cancellation

\`12345 shows completed\` \u2014 Showing Completed Without Complete`;
    }
  }
  if (directCommandResponse) {
    return { success: true, response: directCommandResponse, order: specificOrder };
  }
  const systemInstruction = `You are the official 24/7 AI Support Assistant for ${websiteName}.

The primary user interface command format is:
"To manage an order, reply with your Order ID followed by a command:
12345 status \u2014 check progress
12345 refill \u2014 request a refill
12345 speed \u2014 request a speed-up
12345 cancel \u2014 request cancellation
12345 shows completed \u2014 Showing Completed Without Complete"

Whenever users ask about their orders, always guide them using these exact 5 commands.
Always support English, Hindi, and Hinglish.

AVAILABLE DATA:
- Website: ${websiteName}
- WhatsApp Support: +91 ${whatsappNumber}
- Telegram Support: ${telegramUsername}
${recentOrders.length > 0 ? `
USER'S RECENT ORDERS:
${recentOrders.map((o) => `- #${o.id}: ${o.serviceName || "Service"} | Status: ${o.status.toUpperCase()} | Qty: ${o.quantity} | Remains: ${o.remains}`).join("\n")}
` : ""}
`;
  const ai = getGenAI();
  let aiResponseText = "";
  if (ai) {
    const formattedContents = [];
    for (const h of history.slice(-6)) {
      formattedContents.push({ role: h.role === "user" ? "user" : "model", parts: [{ text: h.content }] });
    }
    formattedContents.push({ role: "user", parts: [{ text: trimmed }] });
    const candidateModels = ["gemini-3.7-flash", "gemini-flash-latest", "gemini-3.1-flash-lite"];
    for (const modelName of candidateModels) {
      try {
        const response = await ai.models.generateContent({ model: modelName, contents: formattedContents, config: { systemInstruction, temperature: 0.7 } });
        if (response.text) {
          aiResponseText = response.text;
          break;
        }
      } catch (err) {
      }
    }
  }
  if (!aiResponseText) {
    if (qLowerIncludes("payment") || qLowerIncludes("pay") || qLowerIncludes("fund") || qLowerIncludes("paise")) {
      aiResponseText = `\u{1F4B3} **Payment & Add Funds Guide:**

1\uFE0F\u20E3 **Add Funds** tab par click karein.
2\uFE0F\u20E3 Amount enter karein (e.g. \u20B950, \u20B9100, \u20B9500).
3\uFE0F\u20E3 **BharatPe / PhonePe UPI QR** ko kisi bhi UPI app (GPay, PhonePe, Paytm) se scan karein.
4\uFE0F\u20E3 12-digit UTR copy karke paste karein aur **"Verify & Add Funds"** par click karein. Balance instant add ho jayega!`;
    } else if (qLowerIncludes("order kaise") || qLowerIncludes("how to order") || qLowerIncludes("place order")) {
      aiResponseText = `\u26A1 **New Order Guide:**

1\uFE0F\u20E3 **New Order** page par jayein.
2\uFE0F\u20E3 **Platform** aur **Service** select karein.
3\uFE0F\u20E3 Target post ya profile ka public link paste karein.
4\uFE0F\u20E3 Quantity enter karke **"Submit Order"** click karein!`;
    } else {
      const sampleId = recentOrders.length > 0 ? recentOrders[0].id : 12345;
      aiResponseText = `\u{1F44B} Welcome to **${websiteName} Support**!

To manage an order, reply with your Order ID followed by a command:

\`${sampleId} status\` \u2014 check progress

\`${sampleId} refill\` \u2014 request a refill

\`${sampleId} speed\` \u2014 request a speed-up

\`${sampleId} cancel\` \u2014 request cancellation

\`${sampleId} shows completed\` \u2014 Showing Completed Without Complete`;
    }
  }
  function qLowerIncludes(term) {
    return lower.includes(term);
  }
  __name6(qLowerIncludes, "qLowerIncludes");
  return { success: true, response: aiResponseText, order: specificOrder };
}
__name6(handleAiChat, "handleAiChat");

// src/server/api.ts
var router = Router();
router.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin) {
    res.setHeader("Access-Control-Allow-Origin", origin);
  } else {
    res.setHeader("Access-Control-Allow-Origin", "*");
  }
  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.setHeader("Access-Control-Allow-Methods", "GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With, Accept, Origin");
  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }
  next();
});
function sanitizeUser(user) {
  if (!user) return null;
  const { password, ...safeUser } = user;
  return safeUser;
}
var ADMIN_EMAILS = [
  "bhattg805@gmail.com"
];
function isSuperAdminEmail(email, customAdminEmail) {
  if (!email) return false;
  const norm = email.toLowerCase().trim();
  const custom = (customAdminEmail || "").toLowerCase().trim();
  return ADMIN_EMAILS.includes(norm) || norm === custom || norm === "bhattg805@gmai.com" || norm.includes("bhattg805");
}
router.get(["/health", "/health/"], (req, res) => {
  res.setHeader("Content-Type", "application/json");
  res.json({ status: "ok", time: /* @__PURE__ */ new Date() });
});
router.get(["/sitemap.xml", "/sitemap.xml/"], sitemapHandler);
router.get(["/robots.txt", "/robots.txt/"], robotsHandler);
router.post("/auth/register", async (req, res) => {
  const { email, name, password } = req.body;
  if (!email || !password || !name) {
    return res.status(400).json({ error: "Name, email, and password are required." });
  }
  try {
    const normalizedEmail = email.toLowerCase().trim();
    const existing = await db.select().from(users).where(eq4(users.email, normalizedEmail)).limit(1);
    if (existing.length > 0) {
      return res.status(400).json({ error: "An account with this email address already exists." });
    }
    const uid = `local-${normalizedEmail}`;
    const role = isSuperAdminEmail(normalizedEmail) ? "admin" : "user";
    const hashedPassword = await bcrypt.hash(password, 10);
    const [newUser] = await db.insert(users).values({
      uid,
      email: normalizedEmail,
      name,
      password: hashedPassword,
      role,
      balance: 0,
      lastLoginAt: /* @__PURE__ */ new Date(),
      lastIp: req.ip || req.headers["x-forwarded-for"] || "127.0.0.1"
    }).returning();
    await logActivity(newUser.id, "Register Local Account", `Registered local account ${normalizedEmail}`, req.ip || req.headers["x-forwarded-for"] || "127.0.0.1");
    const token = `local-token-${normalizedEmail}`;
    res.cookie("auth_token", token, {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1e3,
      path: "/"
    });
    res.json({
      success: true,
      token,
      user: sanitizeUser(newUser)
    });
  } catch (err) {
    console.error("Local registration failed:", err);
    res.status(500).json({ error: "Registration failed. Please try again." });
  }
});
router.post("/auth/clerk-sync", async (req, res) => {
  try {
    const { clerkId, email, name, avatarUrl, clerkSessionToken } = req.body;
    if (!clerkId && !email) {
      return res.status(400).json({ error: "Clerk ID or Email is required for authentication sync." });
    }
    const normalizedEmail = (email || `${clerkId}@clerk.user`).toLowerCase().trim();
    const uid = clerkId || `clerk-${normalizedEmail}`;
    const displayName = name || normalizedEmail.split("@")[0];
    const isUserAdmin = isSuperAdminEmail(normalizedEmail);
    const existing = await db.select().from(users).where(or2(eq4(users.email, normalizedEmail), eq4(users.uid, uid))).limit(1);
    let dbUser;
    if (existing.length > 0) {
      dbUser = existing[0];
      if (dbUser.status === "suspended" && !isUserAdmin) {
        return res.status(403).json({
          error: "Your account has been suspended by the administrator. Please contact support.",
          isSuspended: true
        });
      }
      const updates = {
        lastLoginAt: /* @__PURE__ */ new Date(),
        lastIp: req.ip || req.headers["x-forwarded-for"] || "127.0.0.1"
      };
      if (dbUser.uid !== uid) updates.uid = uid;
      if (name && (!dbUser.name || dbUser.name === normalizedEmail.split("@")[0])) updates.name = name;
      if (isUserAdmin && (dbUser.role !== "admin" || dbUser.status !== "active")) {
        updates.role = "admin";
        updates.status = "active";
      }
      const [updated] = await db.update(users).set(updates).where(eq4(users.id, dbUser.id)).returning();
      dbUser = updated;
    } else {
      const roleToSet = isUserAdmin ? "admin" : "user";
      const [newUser] = await db.insert(users).values({
        uid,
        email: normalizedEmail,
        name: displayName,
        role: roleToSet,
        balance: 0,
        status: "active",
        lastLoginAt: /* @__PURE__ */ new Date(),
        lastIp: req.ip || req.headers["x-forwarded-for"] || "127.0.0.1"
      }).returning();
      dbUser = newUser;
    }
    const authToken = clerkSessionToken || `clerk-user-${uid}:${normalizedEmail}:${encodeURIComponent(displayName)}`;
    res.cookie("auth_token", authToken, {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1e3,
      path: "/"
    });
    res.cookie("__session", authToken, {
      httpOnly: false,
      secure: true,
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1e3,
      path: "/"
    });
    res.json({
      success: true,
      token: authToken,
      user: sanitizeUser(dbUser)
    });
  } catch (error) {
    console.error("Error in /api/auth/clerk-sync:", error);
    res.status(500).json({ error: "Failed to synchronize Clerk account." });
  }
});
function getGoogleOAuthRedirectUri(req, settingsMap) {
  const explicitUri = (process.env.GOOGLE_REDIRECT_URI || settingsMap?.googleRedirectUri || "").trim();
  if (explicitUri && /^https?:\/\//i.test(explicitUri)) {
    return explicitUri;
  }
  const customAppUrl = (process.env.APP_URL || process.env.NEXT_PUBLIC_APP_URL || process.env.VITE_APP_URL || settingsMap?.websiteUrl || "").trim().replace(/\/+$/, "");
  if (customAppUrl && /^https?:\/\//i.test(customAppUrl)) {
    return `${customAppUrl}/api/auth/google/callback`;
  }
  const rawProto = req.headers["x-forwarded-proto"] || req.protocol || "https";
  const proto = rawProto.split(",")[0].trim();
  const rawHost = req.headers["x-forwarded-host"] || req.get("host") || "www.youthsmm.com";
  const host = rawHost.split(",")[0].trim();
  if (host.includes("localhost") || host.includes("127.0.0.1")) {
    return `http://${host}/api/auth/google/callback`;
  }
  if (host === "youthsmm.com" || host === "www.youthsmm.com") {
    return "https://www.youthsmm.com/api/auth/google/callback";
  }
  return `https://${host}/api/auth/google/callback`;
}
router.get(["/auth/google", "/auth/google/"], async (req, res) => {
  try {
    const settingsMap = await getSettingsMap();
    if (settingsMap.googleLoginStatus === "disabled") {
      return res.status(403).json({ error: "Google Login is currently disabled by administrator." });
    }
    const clientId = (settingsMap.googleClientId || process.env.GOOGLE_CLIENT_ID || "636019039384-4f20a2l5pk1qs4qn5ui038ivfv9gobog.apps.googleusercontent.com").trim();
    if (!clientId) {
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      return res.status(500).send(`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8" />
            <title>Google OAuth Not Configured</title>
            <style>
              body { background: #090d16; color: #f3f4f6; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
              .box { background: #111827; border: 1px solid #374151; padding: 28px; border-radius: 16px; max-width: 460px; text-align: center; }
              h3 { color: #ef4444; margin-top: 0; }
              p { color: #9ca3af; font-size: 14px; line-height: 1.6; }
              a { display: inline-block; margin-top: 16px; color: #3b82f6; text-decoration: none; font-weight: bold; }
            </style>
          </head>
          <body>
            <div class="box">
              <h3>Google OAuth Configuration Required</h3>
              <p>GOOGLE_CLIENT_ID is not configured in your environment variables. Please add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to your server environment or Admin Settings.</p>
              <a href="/">Back to Home</a>
            </div>
          </body>
        </html>
      `);
    }
    const redirectUri = getGoogleOAuthRedirectUri(req, settingsMap);
    const statePayload = {
      nonce: crypto.randomBytes(16).toString("hex"),
      redirectUri,
      ts: Date.now()
    };
    const state = Buffer.from(JSON.stringify(statePayload)).toString("base64url");
    res.cookie("oauth_state", state, {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      maxAge: 15 * 60 * 1e3
      // 15 mins
    });
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      response_type: "code",
      scope: "openid email profile",
      access_type: "offline",
      prompt: "select_account",
      state
    });
    const googleAuthUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
    if (req.query.format === "json" || req.query.json === "1" || req.headers.accept && req.headers.accept.includes("application/json") && !req.headers.accept.includes("text/html")) {
      res.setHeader("Content-Type", "application/json");
      return res.json({ url: googleAuthUrl, state, redirectUri });
    }
    res.redirect(googleAuthUrl);
  } catch (error) {
    console.error("Error initiating Google OAuth:", error);
    res.status(500).json({ error: "Failed to initiate Google OAuth login." });
  }
});
router.get(["/auth/google/url", "/auth/google/url/"], async (req, res) => {
  try {
    const settingsMap = await getSettingsMap();
    if (settingsMap.googleLoginStatus === "disabled") {
      return res.status(403).json({ error: "Google Login is currently disabled by administrator." });
    }
    const clientId = (settingsMap.googleClientId || process.env.GOOGLE_CLIENT_ID || "636019039384-4f20a2l5pk1qs4qn5ui038ivfv9gobog.apps.googleusercontent.com").trim();
    if (!clientId) {
      return res.status(500).json({ error: "GOOGLE_CLIENT_ID is not configured." });
    }
    const redirectUri = getGoogleOAuthRedirectUri(req, settingsMap);
    const statePayload = {
      nonce: crypto.randomBytes(16).toString("hex"),
      redirectUri,
      ts: Date.now()
    };
    const state = Buffer.from(JSON.stringify(statePayload)).toString("base64url");
    res.cookie("oauth_state", state, {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      maxAge: 15 * 60 * 1e3
    });
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      response_type: "code",
      scope: "openid email profile",
      access_type: "offline",
      prompt: "select_account",
      state
    });
    const googleAuthUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
    res.json({ url: googleAuthUrl, state, redirectUri });
  } catch (error) {
    console.error("Error creating Google auth URL:", error);
    res.status(500).json({ error: "Failed to construct Google OAuth URL." });
  }
});
router.get(["/auth/google/callback", "/auth/google/callback/"], async (req, res) => {
  try {
    const { code, error, error_description, state } = req.query;
    if (error) {
      const errMsg = String(error_description || error || "Access denied by user");
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      return res.status(200).send(`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
            <title>Authentication Error</title>
            <style>
              body { background: #090d16; color: #f3f4f6; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; padding: 20px; text-align: center; }
              .box { background: #111827; border: 1px solid #374151; padding: 24px; border-radius: 16px; max-width: 400px; width: 100%; box-sizing: border-box; }
              h3 { color: #ef4444; margin-top: 0; }
              a { color: #3b82f6; text-decoration: none; font-weight: bold; }
            </style>
          </head>
          <body>
            <div class="box">
              <h3>Google Login Canceled</h3>
              <p>${escapeHtml(errMsg)}</p>
              <p><a href="/">Return to Sign In</a></p>
            </div>
            <script>
              if (window.opener) {
                try {
                  window.opener.postMessage({ type: 'GOOGLE_AUTH_FAILURE', error: ${JSON.stringify(errMsg)} }, '*');
                } catch(e) {}
                setTimeout(() => window.close(), 1200);
              } else {
                setTimeout(() => { window.location.replace('/'); }, 2000);
              }
            </script>
          </body>
        </html>
      `);
    }
    if (!code || typeof code !== "string") {
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      return res.status(400).send(`
        <!DOCTYPE html>
        <html>
          <head><meta charset="utf-8" /><title>Missing Code</title></head>
          <body style="background:#090d16;color:#f3f4f6;font-family:sans-serif;text-align:center;padding:40px;">
            <p>Authorization code was not provided by Google.</p>
            <a href="/" style="color:#ef4444;">Return to Home</a>
          </body>
        </html>
      `);
    }
    const settingsMap = await getSettingsMap();
    const clientId = (settingsMap.googleClientId || process.env.GOOGLE_CLIENT_ID || "636019039384-4f20a2l5pk1qs4qn5ui038ivfv9gobog.apps.googleusercontent.com").trim();
    const clientSecret = (process.env.GOOGLE_CLIENT_SECRET || settingsMap.googleClientSecret || "").trim();
    if (!clientId || !clientSecret) {
      throw new Error("Google OAuth Client credentials (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET) are missing. Please configure them in environment variables.");
    }
    let redirectUri = getGoogleOAuthRedirectUri(req, settingsMap);
    if (state && typeof state === "string") {
      try {
        const decodedState = JSON.parse(Buffer.from(state, "base64url").toString("utf8"));
        if (decodedState && decodedState.redirectUri && /^https?:\/\//i.test(decodedState.redirectUri)) {
          redirectUri = decodedState.redirectUri;
        }
      } catch (_) {
      }
    }
    const tokenParams = new URLSearchParams({
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
      grant_type: "authorization_code"
    });
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: tokenParams.toString()
    });
    const tokenData = await tokenRes.json();
    if (!tokenRes.ok || !tokenData.access_token && !tokenData.id_token) {
      console.error("Google token exchange error:", tokenData);
      throw new Error(tokenData.error_description || tokenData.error || "Failed to exchange authorization code with Google.");
    }
    let email = "";
    let name = "";
    let sub = "";
    let picture = "";
    if (tokenData.access_token) {
      const userinfoRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
        headers: { Authorization: `Bearer ${tokenData.access_token}` }
      });
      if (userinfoRes.ok) {
        const uData = await userinfoRes.json();
        email = uData.email;
        name = uData.name;
        sub = uData.sub;
        picture = uData.picture;
      }
    }
    if (!email && tokenData.id_token) {
      const tokenInfoRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${tokenData.id_token}`);
      if (tokenInfoRes.ok) {
        const tInfo = await tokenInfoRes.json();
        email = tInfo.email;
        name = tInfo.name;
        sub = tInfo.sub;
        picture = tInfo.picture;
      }
    }
    if (!email) {
      throw new Error("Could not retrieve verified email address from Google.");
    }
    const normalizedEmail = email.toLowerCase().trim();
    const isAdmin = isSuperAdminEmail(normalizedEmail, settingsMap.adminEmail);
    const clientIp = req.headers["x-forwarded-for"] || req.ip || "127.0.0.1";
    const existing = await db.select().from(users).where(eq4(users.email, normalizedEmail)).limit(1);
    let userObj;
    if (existing.length > 0) {
      userObj = existing[0];
      if (userObj.status === "suspended" && !isAdmin) {
        return res.status(403).json({
          error: "Your account has been suspended by the administrator. Please contact support.",
          isSuspended: true
        });
      }
      const [updated] = await db.update(users).set({
        lastLoginAt: /* @__PURE__ */ new Date(),
        lastIp: clientIp,
        name: name || userObj.name || normalizedEmail.split("@")[0],
        ...isAdmin ? {
          role: "admin",
          status: "active"
        } : {}
      }).where(eq4(users.id, userObj.id)).returning();
      userObj = updated;
    } else {
      const [newUser] = await db.insert(users).values({
        uid: `google-${sub || Date.now()}`,
        email: normalizedEmail,
        name: name || normalizedEmail.split("@")[0],
        role: isAdmin ? "admin" : "user",
        balance: 0,
        status: "active",
        lastLoginAt: /* @__PURE__ */ new Date(),
        lastIp: clientIp
      }).returning();
      userObj = newUser;
    }
    await logActivity(userObj.id, "Google OAuth Login", `Logged in via Google OAuth (${normalizedEmail})`, clientIp);
    const token = `local-token-${normalizedEmail}`;
    const safeUser = {
      id: userObj.id,
      name: userObj.name,
      email: userObj.email,
      role: userObj.role,
      balance: userObj.balance,
      currency: userObj.currency || "INR",
      status: userObj.status,
      customDiscount: userObj.customDiscount || 0
    };
    res.cookie("auth_token", token, {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1e3,
      // 30 days
      path: "/"
    });
    res.cookie("youthsmm_token", token, {
      httpOnly: false,
      secure: true,
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1e3,
      path: "/"
    });
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.status(200).send(`
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>Authentication Successful</title>
          <style>
            body {
              background-color: #030712;
              color: #f3f4f6;
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              height: 100vh;
              margin: 0;
              padding: 20px;
              box-sizing: border-box;
              text-align: center;
            }
            .spinner {
              border: 3px solid rgba(255,255,255,0.1);
              border-top: 3px solid #ef4444;
              border-radius: 50%;
              width: 40px;
              height: 40px;
              animation: spin 0.8s linear infinite;
              margin-bottom: 20px;
            }
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
            .title {
              font-weight: 600;
              font-size: 17px;
              margin-bottom: 6px;
            }
            .sub {
              font-size: 13px;
              color: #9ca3af;
              margin-top: 0;
            }
          </style>
        </head>
        <body>
          <div class="spinner"></div>
          <div class="title">Welcome, ${escapeHtml(safeUser.name || safeUser.email)}!</div>
          <p class="sub">Redirecting you to the dashboard...</p>
          <script>
            const token = ${JSON.stringify(token)};
            const safeUser = ${JSON.stringify(safeUser)};
            
            try {
              localStorage.setItem('smm_auth_token', token);
              localStorage.setItem('youthsmm_token', token);
              localStorage.setItem('auth_token', token);
              localStorage.setItem('user', JSON.stringify(safeUser));
            } catch(e) {
              console.warn('LocalStorage save error:', e);
            }

            if (window.opener && !window.opener.closed) {
              try {
                window.opener.postMessage({ type: 'GOOGLE_AUTH_SUCCESS', token, user: safeUser }, '*');
              } catch (e) {}
              setTimeout(() => {
                window.close();
              }, 300);
            } else {
              window.location.replace('/');
            }
          </script>
        </body>
      </html>
    `);
  } catch (error) {
    console.error("Google callback error:", error);
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.status(500).send(`
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>Authentication Failed</title>
          <style>
            body { background: #030712; color: #f3f4f6; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }
            .card { background: #111827; border: 1px solid #1f2937; border-radius: 16px; padding: 28px; max-width: 450px; width: 100%; box-sizing: border-box; text-align: center; }
            h2 { color: #ef4444; margin-top: 0; font-size: 20px; }
            p { font-size: 14px; color: #9ca3af; line-height: 1.5; }
            a { display: inline-block; margin-top: 20px; padding: 10px 24px; background: #ef4444; color: #fff; text-decoration: none; border-radius: 12px; font-weight: bold; font-size: 14px; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>Authentication Failed</h2>
            <p>${escapeHtml(error.message || "An unexpected error occurred during Google Sign In.")}</p>
            <a href="/">Try Again</a>
          </div>
        </body>
      </html>
    `);
  }
});
function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
router.post("/auth/google", async (req, res) => {
  try {
    const { credential, idToken, accessToken, code, redirectUri } = req.body;
    const settingsMap = await getSettingsMap();
    if (settingsMap.googleLoginStatus === "disabled") {
      return res.status(403).json({ error: "Google Login is currently disabled by administrator." });
    }
    let email = "";
    let name = "";
    let sub = "";
    const { email: directEmail, name: directName } = req.body;
    if (directEmail) {
      email = directEmail;
      name = directName || directEmail.split("@")[0];
      sub = `google-${Date.now()}`;
    }
    if (!email && code) {
      const clientId = (settingsMap.googleClientId || process.env.GOOGLE_CLIENT_ID || "636019039384-4f20a2l5pk1qs4qn5ui038ivfv9gobog.apps.googleusercontent.com").trim();
      const clientSecret = (process.env.GOOGLE_CLIENT_SECRET || settingsMap.googleClientSecret || "").trim();
      if (!clientId || !clientSecret) {
        return res.status(400).json({ error: "Google OAuth Client credentials are not configured on server." });
      }
      const tokenParams = new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri || getGoogleOAuthRedirectUri(req, settingsMap),
        grant_type: "authorization_code"
      });
      const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: tokenParams.toString()
      });
      const tokenData = await tokenRes.json();
      if (tokenData.access_token) {
        const userinfoRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
          headers: { Authorization: `Bearer ${tokenData.access_token}` }
        });
        if (userinfoRes.ok) {
          const uData = await userinfoRes.json();
          email = uData.email;
          name = uData.name;
          sub = uData.sub;
        }
      }
      if (!email && tokenData.id_token) {
        const tokenInfoRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${tokenData.id_token}`);
        if (tokenInfoRes.ok) {
          const tInfo = await tokenInfoRes.json();
          email = tInfo.email;
          name = tInfo.name;
          sub = tInfo.sub;
        }
      }
    }
    if (!email && accessToken) {
      try {
        const userinfoRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
          headers: { Authorization: `Bearer ${accessToken}` }
        });
        if (userinfoRes.ok) {
          const uData = await userinfoRes.json();
          email = uData.email;
          name = uData.name;
          sub = uData.sub;
        }
      } catch (e) {
        console.error("Error verifying Google accessToken:", e);
      }
    }
    const rawJwt = idToken || credential;
    if (!email && rawJwt) {
      try {
        const tokenInfoRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${rawJwt}`);
        if (tokenInfoRes.ok) {
          const tInfo = await tokenInfoRes.json();
          email = tInfo.email;
          name = tInfo.name;
          sub = tInfo.sub;
        }
      } catch (e) {
        console.warn("Google tokeninfo fetch failed, attempting JWT payload parse:", e);
      }
      if (!email && typeof rawJwt === "string" && rawJwt.includes(".")) {
        try {
          const parts = rawJwt.split(".");
          if (parts.length >= 2) {
            const payload = JSON.parse(Buffer.from(parts[1], "base64").toString("utf-8"));
            if (payload.email) {
              email = payload.email;
              name = payload.name || payload.given_name || payload.email.split("@")[0];
              sub = payload.sub || payload.user_id;
            }
          }
        } catch (e) {
          console.error("Error decoding JWT payload:", e);
        }
      }
    }
    if (!email) {
      return res.status(400).json({ error: "Unable to retrieve verified email from Google." });
    }
    const normalizedEmail = email.toLowerCase().trim();
    const isAdmin = isSuperAdminEmail(normalizedEmail, settingsMap.adminEmail);
    const existing = await db.select().from(users).where(eq4(users.email, normalizedEmail)).limit(1);
    let userObj;
    const clientIp = req.ip || req.headers["x-forwarded-for"] || "127.0.0.1";
    if (existing.length > 0) {
      userObj = existing[0];
      if (userObj.status === "suspended" && !isAdmin) {
        return res.status(403).json({
          error: "Your account has been suspended by the administrator. Please contact support.",
          isSuspended: true
        });
      }
      const [updated] = await db.update(users).set({
        lastLoginAt: /* @__PURE__ */ new Date(),
        lastIp: clientIp,
        ...isAdmin ? {
          role: "admin",
          status: "active",
          name: name || userObj.name || "Bhatt Admin"
        } : {}
      }).where(eq4(users.id, userObj.id)).returning();
      userObj = updated;
    } else {
      const [newUser] = await db.insert(users).values({
        uid: `google-${sub || Date.now()}`,
        email: normalizedEmail,
        name: name || normalizedEmail.split("@")[0],
        role: isAdmin ? "admin" : "user",
        balance: 0,
        status: "active",
        lastLoginAt: /* @__PURE__ */ new Date(),
        lastIp: clientIp
      }).returning();
      userObj = newUser;
    }
    await logActivity(userObj.id, "Google Login", `Logged in with Google (${normalizedEmail})`, clientIp);
    const token = `local-token-${normalizedEmail}`;
    res.cookie("auth_token", token, {
      httpOnly: true,
      secure: true,
      sameSite: "none",
      maxAge: 30 * 24 * 60 * 60 * 1e3,
      path: "/"
    });
    res.json({
      success: true,
      token,
      user: userObj
    });
  } catch (error) {
    console.error("Google login route error:", error);
    res.status(500).json({ error: error.message || "Google authentication failed." });
  }
});
router.post("/auth/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email) {
    return res.status(400).json({ error: "Username or email is required." });
  }
  try {
    const rawIdentifier = email.trim();
    const normalizedEmail = rawIdentifier.toLowerCase();
    const isOwner = isSuperAdminEmail(normalizedEmail);
    const clientIp = req.ip || req.headers["x-forwarded-for"] || "127.0.0.1";
    let existing = await db.select().from(users).where(eq4(users.email, normalizedEmail)).limit(1);
    if (existing.length === 0) {
      existing = await db.select().from(users).where(sql2`LOWER(${users.name}) = ${normalizedEmail}`).limit(1);
    }
    let userObj;
    if (existing.length === 0) {
      if (isOwner) {
        const hashedPassword = await bcrypt.hash(password || "admin123", 10);
        const [newUser] = await db.insert(users).values({
          uid: `local-${normalizedEmail}`,
          email: normalizedEmail,
          name: "Admin",
          role: "admin",
          balance: 0,
          status: "active",
          password: hashedPassword,
          lastLoginAt: /* @__PURE__ */ new Date(),
          lastIp: clientIp
        }).returning();
        userObj = newUser;
      } else {
        return res.status(400).json({ error: 'No account found with this email or username. Please click "Create account" to sign up in seconds.' });
      }
    } else {
      userObj = existing[0];
      if (userObj.status === "suspended" && !isOwner) {
        return res.status(403).json({
          error: "Your account has been suspended by the administrator. Please contact support.",
          isSuspended: true
        });
      }
      if (userObj.password) {
        let passwordMatches = false;
        if (userObj.password.startsWith("$2a$") || userObj.password.startsWith("$2b$") || userObj.password.startsWith("$2y$")) {
          passwordMatches = await bcrypt.compare(password || "", userObj.password);
        } else {
          passwordMatches = userObj.password === password;
          if (passwordMatches && password) {
            const upgradedHash = await bcrypt.hash(password, 10);
            await db.update(users).set({ password: upgradedHash }).where(eq4(users.id, userObj.id));
          }
        }
        if (!passwordMatches && !isOwner) {
          return res.status(400).json({ error: "Incorrect password. Please verify and try again, or use Google Sign-In." });
        }
      }
      const [updated] = await db.update(users).set({
        lastLoginAt: /* @__PURE__ */ new Date(),
        lastIp: clientIp,
        ...isOwner ? { role: "admin", status: "active" } : {}
      }).where(eq4(users.id, userObj.id)).returning();
      userObj = updated;
    }
    await logActivity(userObj.id, "Login Local Account", `Logged in account ${userObj.email}`, clientIp);
    const token = `local-token-${userObj.email}`;
    res.cookie("auth_token", token, {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      maxAge: 30 * 24 * 60 * 60 * 1e3,
      path: "/"
    });
    res.json({
      success: true,
      token,
      user: sanitizeUser(userObj)
    });
  } catch (err) {
    console.error("Local login failed:", sanitizeDbErrorMessage(err));
    res.status(500).json({ error: "Login failed. Please check your credentials." });
  }
});
router.get("/auth/me", requireAuth, async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    res.json({
      success: true,
      user: sanitizeUser(req.user)
    });
  } catch (error) {
    console.error("Auth me endpoint error:", error);
    res.status(500).json({ error: "Failed to retrieve authenticated user profile." });
  }
});
router.post("/auth/logout", async (req, res) => {
  try {
    res.clearCookie("auth_token", { path: "/" });
    res.clearCookie("oauth_state", { path: "/" });
    res.clearCookie("youthsmm_token", { path: "/" });
    res.clearCookie("session_token", { path: "/" });
    res.json({ success: true, message: "Logged out successfully" });
  } catch (error) {
    console.error("Logout error:", error);
    res.status(500).json({ error: "Failed to logout." });
  }
});
async function logActivity(userId, action, details, ip) {
  try {
    await db.insert(activityLogs).values({
      userId,
      action,
      details,
      ipAddress: ip || "unknown"
    });
  } catch (err) {
    console.error("Failed to write activity log:", err);
  }
}
var DEFAULT_SETTINGS = {
  websiteLogo: "",
  favicon: "",
  websiteName: "youthsmm",
  defaultLanguage: "English",
  homepageYoutubeId: "",
  addFundPageContent: '<div class="space-y-4"><p class="text-gray-300">You can add funds via All UPI, PhonePe QR 1, PhonePe Bonus QR 2, Binance Pay, or Crypto.</p></div>',
  orderIdSkip: "0",
  seoKeywords: "",
  seoDescription: "YouthSMM is a reliable and affordable SMM panel for Instagram, Facebook and Telegram. Buy followers, likes, views, members and other social media services at affordable prices with fast delivery.",
  headerCode: "",
  footerCode: "",
  headerCodeAfterLogin: "",
  whatsappNumber: "8795005604",
  activeTheme: "default",
  bannerStatus: "enabled",
  bannerBadge: "FREE WALLET CREDIT",
  bannerTitle: "Earn up to \u20B9 200 in free credit",
  bannerSubtitle: "Leave a review for \u20B9 25 \xB7 make a promo video for \u20B9 200",
  bannerBtnText: "Earn now \u2192",
  bannerBtnLink: "affiliate",
  dashboardBanners: "",
  greetingNotice: "Place a new order in a few taps \u2014 orders delivered on YouthSMM | Main SMM Provider.",
  // 1. All UPI Payments (BharatPe / Multi-UPI Default)
  allUpiStatus: "enabled",
  allUpiTitle: "All UPI Payments",
  allUpiVpa: "BHARATPE2H0D0Q1Y4T29351@unitype",
  allUpiMerchantName: "PRIYA",
  allUpiQrUrl: "",
  allUpiInstructions: "Scan with PhonePe, Google Pay, Paytm, BharatPe, or any UPI app to complete payment.",
  // BharatPe Merchant Configuration
  bharatpeMerchantId: (process.env.BHARATPE_MERCHANT_ID || process.env.MERCHANT_ID || process.env.BHARATPE_MID || process.env.MID || "").trim(),
  bharatpeToken: (process.env.BHARATPE_TOKEN || process.env.TOKEN || process.env.BHARATPE_API_KEY || process.env.API_KEY || "").trim(),
  bharatpePhone: "8795005604",
  bharatpeMerchantName: "PRIYA",
  bharatpeVpa: "BHARATPE2H0D0Q1Y4T29351@unitype",
  bharatpeStatus: "linked",
  bharatpeQrUrl: "",
  instantUtrAutoCredit: "disabled",
  // 2. PhonePe Only (QR 1)
  phonepeStatus: "enabled",
  phonepeTitle: "PhonePe Only",
  phonepeVpa: "8795005604@ybl",
  phonepeMerchantName: "YouthSMM PhonePe",
  phonepeQrUrl: "",
  phonepeInstructions: "Scan using PhonePe App for fast settlement.",
  // 3. PhonePe Only (QR 2 - Bonus QR)
  phonepeBonusStatus: "enabled",
  phonepeBonusTitle: "PhonePe Only (QR 2)",
  phonepeBonusVpa: "8795005604@ibl",
  phonepeBonusMerchantName: "YouthSMM PhonePe QR 2",
  phonepeBonusQrUrl: "",
  phonepeBonusPercent: "2",
  phonepeBonusMinAmount: "1000",
  phonepeBonusInstructions: "Scan with PhonePe. Automatically receive a 2% bonus on deposits of \u20B91,000 or more.",
  // 4. Binance Pay (USDT / Crypto)
  binanceStatus: "enabled",
  binanceTitle: "Binance Pay",
  binancePayId: "912837465",
  binanceMerchantName: "YouthSMM Binance",
  binanceQrUrl: "",
  binanceCurrency: "USDT",
  binanceInstructions: "Pay via Binance Pay App to ID: 912837465 or scan the Binance QR code.",
  // 5. Heleket (Crypto - TRC20 / TRX / BTC)
  cryptoStatus: "enabled",
  cryptoTitle: "Heleket (Crypto)",
  cryptoWalletAddress: "TX9b57K8wX9q1mN4P2rS8tUvWxYzAbCdEf",
  cryptoNetwork: "USDT (TRC20) / TRX",
  cryptoMerchantName: "YouthSMM Crypto Treasury",
  cryptoQrUrl: "",
  cryptoInstructions: "Send USDT (TRC-20) or TRX to the official wallet address. Submit the 12-digit transaction ID or hash.",
  // 6. Paytm Direct (Optional Method)
  paytmStatus: "enabled",
  paytmTitle: "Paytm Only",
  paytmVpa: "8795005604@paytm",
  paytmMerchantName: "YouthSMM Paytm",
  paytmQrUrl: "",
  paytmInstructions: "Scan with Paytm App.",
  // 7. Google Pay Direct (Optional Method)
  gpayStatus: "enabled",
  gpayTitle: "Google Pay",
  gpayVpa: "8795005604@okaxis",
  gpayMerchantName: "YouthSMM Google Pay",
  gpayQrUrl: "",
  gpayInstructions: "Scan with Google Pay App.",
  // Global Gateways
  stripeStatus: "enabled",
  paypalStatus: "enabled",
  usdManualStatus: "enabled",
  stripePublishableKey: "",
  stripeSecretKey: "",
  paypalClientId: "",
  paypalSecretKey: "",
  razorpayStatus: "enabled",
  upiStatus: "enabled",
  inrStripeStatus: "enabled",
  inrManualStatus: "enabled",
  upiDirectVpa: "admin@upi",
  upiDirectMerchantName: "SMM QR Business",
  upiDirectQrUrl: "https://assets.gpay.com/images/default_upi_qr.png",
  phonepeMerchantId: "enabled",
  phonepeSaltKey: "enabled",
  phonepeSaltIndex: "1",
  razorpayKeyId: "",
  razorpayKeySecret: "",
  googleLoginStatus: "enabled",
  googleClientId: process.env.GOOGLE_CLIENT_ID || "636019039384-4f20a2l5pk1qs4qn5ui038ivfv9gobog.apps.googleusercontent.com",
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
  adminEmail: "bhattg805@gmail.com",
  inrToUsdRate: "0.012",
  inrToEurRate: "0.011",
  inrToPkrRate: "3.32"
};
var cachedSettingsMap = null;
var cachedSettingsTimestamp = 0;
var SETTINGS_CACHE_TTL = 3e4;
async function getSettingsMap(forceFresh = false) {
  const now = Date.now();
  if (!forceFresh && cachedSettingsMap && now - cachedSettingsTimestamp < SETTINGS_CACHE_TTL) {
    return cachedSettingsMap;
  }
  try {
    const rows = await db.select().from(settings);
    const map = { ...DEFAULT_SETTINGS };
    rows.forEach((r) => {
      map[r.key] = r.value;
    });
    cachedSettingsMap = map;
    cachedSettingsTimestamp = now;
    return map;
  } catch (err) {
    console.error("Error fetching settings map:", err);
    return cachedSettingsMap || { ...DEFAULT_SETTINGS };
  }
}
async function initBharatpeSettings() {
  try {
    const keysToVerify = {
      bharatpeMerchantName: "PRIYA",
      bharatpeVpa: "killee@ybl",
      bharatpeStatus: "linked",
      bharatpePhone: "8795005604"
    };
    for (const [key, value] of Object.entries(keysToVerify)) {
      const existing = await db.select().from(settings).where(eq4(settings.key, key)).limit(1);
      if (existing.length > 0) {
        if (existing[0].value === "" || existing[0].value === "unlinked" || existing[0].value === "9988776655@bharatpe" || existing[0].value === "BharatPe Merchant" || existing[0].value === "9988776655" || existing[0].value === "killee@ybl" || key === "bharatpeVpa") {
          await db.update(settings).set({ value, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(settings.key, key));
        }
      } else {
        await db.insert(settings).values({ key, value });
      }
    }
  } catch (error) {
    console.error("Error initializing BharatPe settings:", error);
  }
}
initBharatpeSettings();
async function initAdminUserAndUnblock() {
  try {
    const adminEmails = ["bhattg805@gmail.com"];
    for (const adminEmail of adminEmails) {
      const existing = await db.select().from(users).where(eq4(users.email, adminEmail)).limit(1);
      const name = "Admin";
      if (existing.length > 0) {
        await db.update(users).set({
          role: "admin",
          status: "active",
          name: existing[0].name || name
        }).where(eq4(users.id, existing[0].id));
        console.log(`[BOOTSTRAP] Admin user ${adminEmail} unblocked and verified with active super admin role.`);
      } else {
        await db.insert(users).values({
          uid: `admin-${adminEmail.split("@")[0]}`,
          email: adminEmail,
          name,
          role: "admin",
          balance: 1e3,
          status: "active",
          password: "admin"
        });
        console.log(`[BOOTSTRAP] Admin user ${adminEmail} created with active super admin role.`);
      }
    }
    const allUsers = await db.select().from(users);
    for (const u of allUsers) {
      if (u.email && isSuperAdminEmail(u.email)) {
        if (u.status !== "active" || u.role !== "admin") {
          await db.update(users).set({ status: "active", role: "admin" }).where(eq4(users.id, u.id));
        }
      }
    }
  } catch (error) {
    console.error("Error initializing and unblocking admin user:", error);
  }
}
initAdminUserAndUnblock();
async function getOrderIdOffset() {
  try {
    const row = await db.select().from(settings).where(eq4(settings.key, "orderIdSkip")).limit(1);
    if (row.length > 0) {
      const val = parseInt(row[0].value, 10);
      return isNaN(val) ? 0 : val;
    }
  } catch (err) {
    console.error("Error getting orderIdSkip offset:", err);
  }
  return 0;
}
async function executeSmmApiRequest(rawUrl, params, maxRetries = 3) {
  let targetUrl = (rawUrl || "").trim().replace(/^['"]+|['"]+$/g, "");
  if (!targetUrl) {
    throw new Error("Provider API URL is empty or invalid.");
  }
  if (!/^https?:\/\//i.test(targetUrl)) {
    targetUrl = `https://${targetUrl}`;
  }
  const formParams = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== void 0 && v !== null) {
      formParams.append(k, String(v));
    }
  }
  let lastError = null;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3e4);
    try {
      const response = await fetch(targetUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Accept": "application/json, text/plain, */*",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 YouthSMM-Engine/4.0",
          "Connection": "keep-alive"
        },
        body: formParams.toString(),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      const rawText = await response.text();
      const cleaned = (rawText || "").replace(/^\uFEFF/, "").trim();
      if (!response.ok && response.status >= 500 && attempt < maxRetries) {
        await new Promise((r) => setTimeout(r, 1200 * attempt));
        continue;
      }
      if (!cleaned) {
        throw new Error(`Empty response received from provider (HTTP ${response.status})`);
      }
      let data = null;
      try {
        data = JSON.parse(cleaned);
      } catch {
        if (/^\d+$/.test(cleaned)) {
          data = { order: cleaned };
        } else {
          if (cleaned.includes("<html") || cleaned.includes("<head>")) {
            throw new Error(`Provider returned HTML page (HTTP ${response.status}). Panel might be in maintenance or blocking IP.`);
          }
          throw new Error(`Invalid non-JSON response from provider: ${cleaned.substring(0, 150)}`);
        }
      }
      return data;
    } catch (err) {
      clearTimeout(timeoutId);
      lastError = err;
      const isAbort = err.name === "AbortError" || err.message?.includes("aborted");
      const errorMsg = isAbort ? "Connection timed out (30s limit reached)" : err.message || String(err);
      console.warn(`[SMM API ATTEMPT ${attempt}/${maxRetries} FAILED] Url: ${targetUrl} - ${errorMsg}`);
      if (attempt < maxRetries) {
        await new Promise((r) => setTimeout(r, 1500 * attempt));
      }
    }
  }
  throw lastError || new Error("Failed to connect to SMM API provider after all retry attempts.");
}
async function dispatchOrderToProvider(orderId, forceRetry = false) {
  try {
    const orderObj = await db.select({
      id: orders.id,
      link: orders.link,
      quantity: orders.quantity,
      serviceId: orders.serviceId,
      providerOrderId: orders.providerOrderId,
      userId: orders.userId
    }).from(orders).where(eq4(orders.id, orderId)).limit(1);
    if (orderObj.length === 0) {
      return { success: false, error: "Order not found in database." };
    }
    const ord = orderObj[0];
    if (ord.providerOrderId && !ord.providerOrderId.startsWith("FAILED:") && ord.providerOrderId.trim() !== "" && !forceRetry) {
      return { success: true, providerOrderId: ord.providerOrderId, providerName: "Already Dispatched" };
    }
    const srv = await db.select({
      id: services.id,
      name: services.name,
      description: services.description,
      providerId: services.providerId,
      providerServiceId: services.providerServiceId
    }).from(services).where(eq4(services.id, ord.serviceId)).limit(1);
    let apiUrl = "";
    let apiKey = "";
    let providerName = "";
    let providerServiceId = "";
    if (srv.length > 0 && srv[0].providerId) {
      const prov = await db.select().from(providers).where(eq4(providers.id, srv[0].providerId)).limit(1);
      if (prov.length > 0 && prov[0].apiUrl && prov[0].apiKey) {
        apiUrl = prov[0].apiUrl.trim();
        apiKey = prov[0].apiKey.trim();
        providerName = prov[0].name;
        providerServiceId = String(srv[0].providerServiceId || srv[0].id || ord.serviceId).trim();
      }
    }
    if (!apiUrl) {
      const allActiveProviders = await db.select().from(providers).orderBy(providers.id).limit(1);
      if (allActiveProviders.length > 0 && allActiveProviders[0].apiUrl && allActiveProviders[0].apiKey) {
        apiUrl = allActiveProviders[0].apiUrl.trim();
        apiKey = allActiveProviders[0].apiKey.trim();
        providerName = allActiveProviders[0].name;
        providerServiceId = String(srv[0]?.providerServiceId || srv[0]?.id || ord.serviceId).trim();
      }
    }
    if (!apiUrl && ord.userId) {
      const userResult = await db.select({
        customProviderUrl: users.customProviderUrl,
        customProviderKey: users.customProviderKey
      }).from(users).where(eq4(users.id, ord.userId)).limit(1);
      if (userResult.length > 0 && userResult[0].customProviderUrl && userResult[0].customProviderKey) {
        apiUrl = userResult[0].customProviderUrl.trim();
        apiKey = userResult[0].customProviderKey.trim();
        providerName = `User Custom Provider`;
        providerServiceId = String(srv[0]?.providerServiceId || srv[0]?.id || ord.serviceId).trim();
      }
    }
    if (!apiUrl || !apiKey) {
      console.log(`[PROVIDER DISPATCH SKIPPED] Order #${orderId} has no external SMM API provider available.`);
      return { success: false, error: "No active SMM API provider found in the system. Please configure an API provider in Admin > API Providers." };
    }
    if (!providerServiceId || providerServiceId === "0") {
      const descMatch = (srv[0]?.description || "").match(/SMM Provider Service ID:\s*(\d+)/i);
      if (descMatch && descMatch[1]) {
        providerServiceId = descMatch[1].trim();
        await db.update(services).set({ providerServiceId, providerId: srv[0].providerId || 9 }).where(eq4(services.id, srv[0].id));
      }
    }
    if (!providerServiceId || providerServiceId === "0") {
      const errMsg = `Service #${srv[0]?.id} ('${srv[0]?.name}') is not linked to any Provider Service ID. Please map it in Admin > Services or import from Provider.`;
      console.warn(`[PROVIDER DISPATCH BLOCKED] Order #${orderId}: ${errMsg}`);
      await db.update(orders).set({ providerOrderId: "FAILED: Missing Provider Service ID" }).where(eq4(orders.id, orderId));
      return { success: false, error: errMsg };
    }
    console.log(`[PROVIDER DISPATCH START] Dispatching Order #${orderId} to '${providerName}' (API URL: ${apiUrl}, Provider Service ID: ${providerServiceId}, Quantity: ${ord.quantity})`);
    const requestParams = {
      key: apiKey,
      action: "add",
      service: providerServiceId,
      link: ord.link.trim(),
      quantity: String(ord.quantity)
    };
    const data = await executeSmmApiRequest(apiUrl, requestParams, 2);
    console.log(`[PROVIDER DISPATCH RESPONSE] Order #${orderId} ->`, data);
    let pOrderId = null;
    if (typeof data === "number" || typeof data === "string" && /^\d+$/.test(data.trim())) {
      pOrderId = String(data).trim();
    } else if (data && typeof data === "object") {
      if (data.order !== void 0 && data.order !== null) pOrderId = String(data.order).trim();
      else if (data.order_id !== void 0 && data.order_id !== null) pOrderId = String(data.order_id).trim();
      else if (data.orderId !== void 0 && data.orderId !== null) pOrderId = String(data.orderId).trim();
      else if (data.id !== void 0 && data.id !== null && !isNaN(Number(data.id))) pOrderId = String(data.id).trim();
      else if (data.data?.order !== void 0 && data.data?.order !== null) pOrderId = String(data.data.order).trim();
      else if (data.data?.order_id !== void 0 && data.data?.order_id !== null) pOrderId = String(data.data.order_id).trim();
      else if (data.data?.id !== void 0 && data.data?.id !== null) pOrderId = String(data.data.id).trim();
      else if (data.result?.order !== void 0 && data.result?.order !== null) pOrderId = String(data.result.order).trim();
      else if (data.result?.order_id !== void 0 && data.result?.order_id !== null) pOrderId = String(data.result.order_id).trim();
    }
    if (pOrderId && pOrderId !== "undefined" && pOrderId !== "null" && pOrderId !== "") {
      await db.update(orders).set({
        providerOrderId: pOrderId,
        status: "processing"
      }).where(eq4(orders.id, orderId));
      await logActivity(
        null,
        "API Provider Dispatch",
        `Successfully dispatched Order #${orderId} to SMM Provider '${providerName}' (Provider Order ID: ${pOrderId})`,
        "system"
      );
      return {
        success: true,
        providerOrderId: pOrderId,
        providerName
      };
    } else if (data && data.error) {
      const errStr = typeof data.error === "string" ? data.error : JSON.stringify(data.error);
      console.warn(`[PROVIDER DISPATCH REJECTED] Order #${orderId}: Provider returned '${errStr}'. Service ID: ${providerServiceId}`);
      await db.update(orders).set({
        providerOrderId: `FAILED: ${errStr}`.substring(0, 255)
      }).where(eq4(orders.id, orderId));
      await logActivity(
        null,
        "API Provider Dispatch Error",
        `Provider '${providerName}' rejected Order #${orderId}. Reason: ${errStr}`,
        "system"
      );
      return {
        success: false,
        error: `Provider Error: ${errStr}`
      };
    } else {
      const errStr = `Invalid response from provider: ${JSON.stringify(data)}`;
      await db.update(orders).set({
        providerOrderId: `FAILED: ${errStr}`.substring(0, 255)
      }).where(eq4(orders.id, orderId));
      return {
        success: false,
        error: errStr
      };
    }
  } catch (err) {
    const errorMsg = err.message || String(err);
    console.error(`[PROVIDER DISPATCH FAILED] Order #${orderId}:`, errorMsg);
    await db.update(orders).set({
      providerOrderId: `FAILED: ${errorMsg}`.substring(0, 255)
    }).where(eq4(orders.id, orderId));
    await logActivity(
      null,
      "API Provider Dispatch Failed",
      `Failed to dispatch order #${orderId}. Reason: ${errorMsg}`,
      "system"
    );
    return {
      success: false,
      error: errorMsg
    };
  }
}
async function syncProviderOrders(specificOrderIds) {
  try {
    const undispatchedOrders = await db.select({
      id: orders.id
    }).from(orders).where(
      and(
        sql2`(${orders.providerOrderId} IS NULL OR ${orders.providerOrderId} = '')`,
        eq4(orders.status, "pending")
      )
    ).limit(10);
    if (undispatchedOrders.length > 0) {
      console.log(`[AUTO-DISPATCH QUEUE] Found ${undispatchedOrders.length} undispatched orders. Connecting to provider...`);
      for (const unOrd of undispatchedOrders) {
        try {
          await dispatchOrderToProvider(unOrd.id, true);
        } catch (dispatchErr) {
          console.error(`[AUTO-DISPATCH QUEUE ERROR] Order #${unOrd.id}:`, dispatchErr);
        }
      }
    }
    let activeOrdersQuery = db.select({
      id: orders.id,
      providerOrderId: orders.providerOrderId,
      serviceId: orders.serviceId,
      userId: orders.userId,
      charge: orders.charge,
      status: orders.status,
      startCount: orders.startCount,
      remains: orders.remains
    }).from(orders);
    let activeOrders = [];
    if (specificOrderIds && specificOrderIds.length > 0) {
      activeOrders = await activeOrdersQuery.where(
        and(
          inArray(orders.id, specificOrderIds),
          sql2`${orders.providerOrderId} IS NOT NULL AND ${orders.providerOrderId} != '' AND ${orders.providerOrderId} NOT LIKE 'FAILED:%'`
        )
      );
    } else {
      activeOrders = await activeOrdersQuery.where(
        and(
          sql2`${orders.providerOrderId} IS NOT NULL AND ${orders.providerOrderId} != '' AND ${orders.providerOrderId} NOT LIKE 'FAILED:%'`,
          sql2`LOWER(${orders.status}) NOT IN ('completed', 'cancelled', 'refunded')`
        )
      ).limit(50);
    }
    if (activeOrders.length === 0) return { synced: 0 };
    const allProviders = await db.select().from(providers);
    const providerMap = /* @__PURE__ */ new Map();
    allProviders.forEach((p) => {
      if (p.apiUrl && p.apiKey) {
        providerMap.set(p.id, { apiUrl: p.apiUrl.trim(), apiKey: p.apiKey.trim() });
      }
    });
    const defaultProv = allProviders.find((p) => p.apiUrl && p.apiKey);
    let syncedCount = 0;
    for (const ord of activeOrders) {
      if (!ord.providerOrderId) continue;
      let apiUrl = "";
      let apiKey = "";
      let hasCustomProvider = false;
      if (ord.userId) {
        const userResult = await db.select({
          customProviderUrl: users.customProviderUrl,
          customProviderKey: users.customProviderKey
        }).from(users).where(eq4(users.id, ord.userId)).limit(1);
        if (userResult.length > 0 && userResult[0].customProviderUrl && userResult[0].customProviderKey) {
          apiUrl = userResult[0].customProviderUrl.trim();
          apiKey = userResult[0].customProviderKey.trim();
          hasCustomProvider = true;
        }
      }
      if (!hasCustomProvider) {
        const srv = await db.select({ providerId: services.providerId }).from(services).where(eq4(services.id, ord.serviceId)).limit(1);
        if (srv.length > 0 && srv[0].providerId && providerMap.has(srv[0].providerId)) {
          const provCreds = providerMap.get(srv[0].providerId);
          apiUrl = provCreds.apiUrl;
          apiKey = provCreds.apiKey;
        }
        if (!apiUrl && defaultProv) {
          apiUrl = defaultProv.apiUrl.trim();
          apiKey = defaultProv.apiKey.trim();
        }
      }
      if (!apiUrl || !apiKey) continue;
      try {
        const pOrderId = String(ord.providerOrderId).trim();
        const data = await executeSmmApiRequest(
          apiUrl,
          {
            key: apiKey.trim(),
            action: "status",
            order: pOrderId
          },
          2
        );
        if (data && typeof data === "object") {
          let orderData = data;
          if (data[pOrderId] && typeof data[pOrderId] === "object") {
            orderData = data[pOrderId];
          } else if (data.data && typeof data.data === "object") {
            orderData = data.data[pOrderId] || data.data;
          } else if (data.result && typeof data.result === "object") {
            orderData = data.result[pOrderId] || data.result;
          } else if (Array.isArray(data) && data.length > 0) {
            orderData = data[0];
          }
          const statusField = orderData?.status ?? orderData?.order_status ?? orderData?.status_text ?? "";
          const rawStatus = String(statusField || "").toLowerCase().trim();
          let internalStatus = null;
          if (rawStatus === "completed" || rawStatus.includes("complete") || rawStatus.includes("finish") || rawStatus.includes("success") || rawStatus.includes("done")) {
            internalStatus = "completed";
          } else if (rawStatus === "canceled" || rawStatus === "cancelled" || rawStatus.includes("cancel") || rawStatus.includes("reject") || rawStatus.includes("fail")) {
            internalStatus = "cancelled";
          } else if (rawStatus.includes("refund")) {
            internalStatus = "refunded";
          } else if (rawStatus.includes("partial")) {
            internalStatus = "partial";
          } else if (rawStatus.includes("pend") || rawStatus.includes("wait") || rawStatus.includes("queue")) {
            internalStatus = "pending";
          } else if (rawStatus.includes("progress") || rawStatus.includes("process") || rawStatus.includes("active")) {
            internalStatus = "processing";
          }
          if (!internalStatus && orderData.remains !== void 0 && Number(orderData.remains) === 0 && rawStatus !== "pending") {
            internalStatus = "completed";
          }
          if (internalStatus) {
            const startCountRaw = orderData.start_count ?? orderData.startCount;
            const remainsRaw = orderData.remains;
            let startCount = startCountRaw !== void 0 && !isNaN(parseInt(startCountRaw)) ? parseInt(startCountRaw) : ord.startCount || 0;
            let remains = remainsRaw !== void 0 && !isNaN(parseInt(remainsRaw)) ? parseInt(remainsRaw) : ord.remains || 0;
            if (internalStatus === "completed") {
              remains = 0;
            }
            if ((internalStatus === "cancelled" || internalStatus === "refunded") && ord.charge > 0 && ord.userId && ord.status !== "cancelled" && ord.status !== "refunded") {
              const existingRefund = await db.select().from(payments).where(eq4(payments.transactionId, `REFUND-${ord.id}`)).limit(1);
              if (existingRefund.length === 0) {
                const u = await db.select().from(users).where(eq4(users.id, ord.userId)).limit(1);
                if (u.length > 0) {
                  await db.update(users).set({ balance: (u[0].balance || 0) + ord.charge }).where(eq4(users.id, ord.userId));
                  await db.insert(payments).values({
                    userId: ord.userId,
                    amount: ord.charge,
                    paymentMethod: "Refund",
                    transactionId: `REFUND-${ord.id}`,
                    status: "completed"
                  });
                }
              }
            }
            await db.update(orders).set({
              status: internalStatus,
              startCount,
              remains
            }).where(eq4(orders.id, ord.id));
            syncedCount++;
            console.log(`[ORDER SYNC] Order #${ord.id} (Provider #${pOrderId}) status updated to '${internalStatus}' (remains: ${remains})`);
          }
        }
      } catch (err) {
        console.error(`Failed to sync provider order status for order ID ${ord.id}:`, err);
      }
    }
    return { synced: syncedCount };
  } catch (err) {
    console.error("Failed to sync provider orders:", err);
    throw err;
  }
}
var cronState = {
  lastRun: null,
  lastRunTime: 0,
  runCount: 0,
  status: "idle",
  lastSyncedCount: 0,
  error: null,
  intervalMs: 15e3,
  // Check every 15 seconds so completed orders reflect automatically!
  isActive: true
};
var cronTimer = null;
function startOrderSyncCron() {
  if (cronTimer) {
    clearInterval(cronTimer);
  }
  const runSync = async () => {
    if (!cronState.isActive) return;
    if (cronState.status === "running") {
      if (Date.now() - cronState.lastRunTime > 4e4) {
        console.warn("[CRON WATCHDOG] Previous sync timed out after 40s. Resetting status to idle.");
        cronState.status = "idle";
      } else {
        return;
      }
    }
    cronState.status = "running";
    cronState.lastRunTime = Date.now();
    try {
      const result = await syncProviderOrders();
      cronState.lastRun = /* @__PURE__ */ new Date();
      cronState.runCount++;
      cronState.status = "success";
      cronState.lastSyncedCount = result?.synced || 0;
      cronState.error = null;
    } catch (err) {
      console.error("[CRON] Background order sync failed:", err);
      cronState.lastRun = /* @__PURE__ */ new Date();
      cronState.status = "failed";
      cronState.error = err?.message || String(err);
    } finally {
      if (cronState.status !== "failed") {
        cronState.status = "idle";
      }
    }
  };
  cronTimer = setInterval(runSync, cronState.intervalMs);
  setTimeout(() => {
    runSync().catch((err) => console.error("[CRON] Initial background sync error:", err));
  }, 3e3);
}
startOrderSyncCron();
router.get(["/services/public", "/services", "/public/services"], async (req, res) => {
  try {
    const list = await db.select({
      id: services.id,
      name: services.name,
      description: services.description,
      pricePerThousand: services.pricePerThousand,
      minAmount: services.minAmount,
      maxAmount: services.maxAmount,
      status: services.status,
      categoryName: categories.name,
      categoryIcon: categories.icon,
      icon: services.icon
    }).from(services).innerJoin(categories, eq4(services.categoryId, categories.id)).where(eq4(services.status, "active")).orderBy(categories.sortOrder, services.id);
    res.json(list);
  } catch (error) {
    console.error("Error fetching public services:", error);
    res.status(500).json({ error: "Failed to retrieve services." });
  }
});
router.get("/user/profile", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    res.json(req.user);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve profile." });
  }
});
router.post("/user/toggle-role", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    if (!isSuperAdminEmail(req.user.email)) {
      return res.status(403).json({ error: "Forbidden: Only administrators can toggle roles." });
    }
    const newRole = req.user.role === "admin" ? "user" : "admin";
    await db.update(users).set({ role: newRole }).where(eq4(users.id, req.user.id));
    await logActivity(req.user.id, "Toggle Role", `Toggled user role to ${newRole}`, req.ip);
    res.json({ success: true, newRole });
  } catch (error) {
    console.error("Failed to toggle role:", error);
    res.status(500).json({ error: "Failed to toggle role." });
  }
});
router.post("/user/custom-provider", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { customProviderUrl, customProviderKey } = req.body;
    await db.update(users).set({
      customProviderUrl: customProviderUrl || null,
      customProviderKey: customProviderKey || null
    }).where(eq4(users.id, req.user.id));
    await logActivity(
      req.user.id,
      "Update Custom Provider",
      `Updated custom API provider URL to: ${customProviderUrl || "none"}`,
      req.ip
    );
    res.json({
      success: true,
      customProviderUrl: customProviderUrl || null,
      customProviderKey: customProviderKey || null
    });
  } catch (error) {
    console.error("Failed to update custom provider details:", error);
    res.status(500).json({ error: "Failed to update custom provider details." });
  }
});
router.post(["/user/generate-key", "/user/generate-api-key"], requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const newApiKey = crypto.randomBytes(32).toString("hex");
    await db.update(users).set({ apiKey: newApiKey }).where(eq4(users.id, req.user.id));
    await logActivity(req.user.id, "Generate API Key", "Generated a new API key", req.ip);
    try {
      const supabase = getSupabaseServer();
      if (supabase) {
        await supabase.from("users").update({ api_key: newApiKey }).eq("id", req.user.id);
      }
    } catch (sbErr) {
      // Non-blocking fallback
    }
    res.json({ success: true, apiKey: newApiKey });
  } catch (error) {
    console.error("Failed to generate API Key:", error);
    res.status(500).json({ error: "Failed to generate API Key." });
  }
});
router.all(["/v1", "/v2", "/v1/", "/v2/"], async (req, res) => {
  try {
    const key = req.body?.key || req.query?.key;
    const action = req.body?.action || req.query?.action;
    if (!key) {
      return res.status(400).json({ error: "Invalid API key" });
    }
    const userResult = await db.select().from(users).where(eq4(users.apiKey, String(key))).limit(1);
    if (userResult.length === 0) {
      return res.status(401).json({ error: "Invalid API key" });
    }
    const apiUser = userResult[0];
    if (apiUser.status !== "active" && !isSuperAdminEmail(apiUser.email)) {
      return res.status(403).json({ error: "Your account is suspended" });
    }
    if (!action) {
      return res.status(400).json({
        error: "Missing action parameter. Supported actions: balance, services, add, status, refill, refill_status, cancel"
      });
    }
    switch (action) {
      case "balance": {
        return res.json({
          balance: Number(apiUser.balance || 0).toFixed(4),
          currency: "INR"
        });
      }
      case "services": {
        const activeServices = await db.select({
          id: services.id,
          name: services.name,
          description: services.description,
          pricePerThousand: services.pricePerThousand,
          minAmount: services.minAmount,
          maxAmount: services.maxAmount,
          categoryName: categories.name
        }).from(services).innerJoin(categories, eq4(services.categoryId, categories.id)).where(eq4(services.status, "active"));
        const responseServices = activeServices.map((srv) => {
          const rate = srv.pricePerThousand * (apiUser.customRate || 1);
          const isRefillSupported = (srv.description || "").toLowerCase().includes("refill") || srv.name.toLowerCase().includes("refill") || srv.name.toLowerCase().includes("guarantee");
          return {
            service: srv.id.toString(),
            name: srv.name,
            type: "Default",
            category: srv.categoryName,
            rate: rate.toFixed(4),
            min: srv.minAmount.toString(),
            max: srv.maxAmount.toString(),
            refill: isRefillSupported,
            cancel: true,
            description: srv.description || ""
          };
        });
        return res.json(responseServices);
      }
      case "add": {
        const service = req.body?.service || req.query?.service;
        const link = req.body?.link || req.query?.link;
        const quantity = req.body?.quantity || req.query?.quantity;
        if (!service || !link || !quantity) {
          return res.status(400).json({ error: "Missing required parameters: service, link, quantity" });
        }
        const srvId = Number(service);
        const qty = Number(quantity);
        if (isNaN(srvId) || isNaN(qty) || qty <= 0) {
          return res.status(400).json({ error: "Invalid service or quantity parameters" });
        }
        const sResult = await db.select().from(services).where(eq4(services.id, srvId)).limit(1);
        if (sResult.length === 0 || sResult[0].status !== "active") {
          return res.status(400).json({ error: "Service is unavailable" });
        }
        const s = sResult[0];
        if (qty < s.minAmount || qty > s.maxAmount) {
          return res.status(400).json({ error: `Quantity must be between ${s.minAmount} and ${s.maxAmount}` });
        }
        const rate = s.pricePerThousand * (apiUser.customRate || 1);
        const charge = qty / 1e3 * rate;
        if (apiUser.balance < charge) {
          return res.status(400).json({ error: "Insufficient funds" });
        }
        const newBalance = apiUser.balance - charge;
        await db.update(users).set({ balance: newBalance }).where(eq4(users.id, apiUser.id));
        const orderResult = await db.insert(orders).values({
          userId: apiUser.id,
          serviceId: s.id,
          link: String(link),
          quantity: qty,
          charge,
          status: "pending",
          startCount: 0,
          remains: qty
        }).returning();
        const createdOrder = orderResult[0];
        await logActivity(
          apiUser.id,
          "API Place Order",
          `Ordered service ID: ${s.id} via API for charge: \u20B9${charge.toFixed(4)}`,
          req.ip
        );
        dispatchOrderToProvider(createdOrder.id).catch((err) => {
          console.error("[RESELLER API ERROR] Async dispatch failed:", err);
        });
        return res.json({
          order: createdOrder.id.toString()
        });
      }
      case "status": {
        const order = req.body?.order || req.query?.order;
        const multiOrders = req.body?.orders || req.query?.orders;
        if (order) {
          const ordId = Number(order);
          if (isNaN(ordId)) {
            return res.status(400).json({ error: "Invalid order parameter" });
          }
          const oResult = await db.select().from(orders).where(and(eq4(orders.id, ordId), eq4(orders.userId, apiUser.id))).limit(1);
          if (oResult.length === 0) {
            return res.status(404).json({ error: "Order not found" });
          }
          const o = oResult[0];
          return res.json({
            charge: o.charge.toFixed(4),
            start_count: o.startCount.toString(),
            status: o.status === "in_progress" ? "In progress" : o.status.charAt(0).toUpperCase() + o.status.slice(1),
            remains: o.remains.toString(),
            currency: "INR"
          });
        } else if (multiOrders) {
          const ids = String(multiOrders).split(",").map((id) => Number(id.trim())).filter((id) => !isNaN(id));
          if (ids.length === 0) {
            return res.status(400).json({ error: "No valid order IDs provided" });
          }
          const oResults = await db.select().from(orders).where(and(inArray(orders.id, ids), eq4(orders.userId, apiUser.id)));
          const statusMap = {};
          for (const o of oResults) {
            statusMap[o.id.toString()] = {
              charge: o.charge.toFixed(4),
              start_count: o.startCount.toString(),
              status: o.status === "in_progress" ? "In progress" : o.status.charAt(0).toUpperCase() + o.status.slice(1),
              remains: o.remains.toString(),
              currency: "INR"
            };
          }
          for (const id of ids) {
            const idStr = id.toString();
            if (!statusMap[idStr]) {
              statusMap[idStr] = { error: "Order not found" };
            }
          }
          return res.json(statusMap);
        } else {
          return res.status(400).json({ error: "Missing order or orders parameter" });
        }
      }
      case "refill": {
        const order = req.body?.order || req.query?.order;
        if (!order) {
          return res.status(400).json({ error: "Missing order parameter for refill" });
        }
        const ordId = Number(order);
        if (isNaN(ordId)) {
          return res.status(400).json({ error: "Invalid order parameter" });
        }
        const oResult = await db.select().from(orders).where(and(eq4(orders.id, ordId), eq4(orders.userId, apiUser.id))).limit(1);
        if (oResult.length === 0) {
          return res.status(404).json({ error: "Order not found" });
        }
        const o = oResult[0];
        const [newRefill] = await db.insert(refillRequests).values({
          userId: apiUser.id,
          orderId: o.id,
          status: "pending"
        }).returning();
        await db.update(orders).set({ refillStatus: "requested" }).where(eq4(orders.id, o.id));
        await logActivity(
          apiUser.id,
          "API Refill Request",
          `Refill requested for order #${o.id} via API`,
          req.ip
        );
        return res.json({
          refill: newRefill.id.toString()
        });
      }
      case "refill_status": {
        const refillIdParam = req.body?.refill || req.query?.refill;
        const orderIdParam = req.body?.order || req.query?.order;
        if (!refillIdParam && !orderIdParam) {
          return res.status(400).json({ error: "Missing refill or order parameter" });
        }
        let refQuery;
        if (refillIdParam) {
          const rId = Number(refillIdParam);
          if (isNaN(rId)) {
            return res.status(400).json({ error: "Invalid refill parameter" });
          }
          refQuery = and(eq4(refillRequests.id, rId), eq4(refillRequests.userId, apiUser.id));
        } else {
          const oId = Number(orderIdParam);
          if (isNaN(oId)) {
            return res.status(400).json({ error: "Invalid order parameter" });
          }
          refQuery = and(eq4(refillRequests.orderId, oId), eq4(refillRequests.userId, apiUser.id));
        }
        const rResult = await db.select().from(refillRequests).where(refQuery).orderBy(desc3(refillRequests.createdAt)).limit(1);
        if (rResult.length === 0) {
          return res.status(404).json({ error: "Refill request not found" });
        }
        const ref = rResult[0];
        let displayStatus = "Pending";
        if (ref.status === "completed") displayStatus = "Completed";
        else if (ref.status === "rejected") displayStatus = "Rejected";
        else if (ref.status === "processing") displayStatus = "In process";
        return res.json({
          status: displayStatus
        });
      }
      case "cancel": {
        const order = req.body?.order || req.query?.order;
        if (!order) {
          return res.status(400).json({ error: "Missing order parameter for cancel" });
        }
        const ordId = Number(order);
        if (isNaN(ordId)) {
          return res.status(400).json({ error: "Invalid order parameter" });
        }
        const oResult = await db.select().from(orders).where(and(eq4(orders.id, ordId), eq4(orders.userId, apiUser.id))).limit(1);
        if (oResult.length === 0) {
          return res.status(404).json({ error: "Order not found" });
        }
        const o = oResult[0];
        if (o.status === "canceled" || o.status === "completed") {
          return res.status(400).json({ error: `Cannot cancel order with status: ${o.status}` });
        }
        const refundAmount = o.charge;
        await db.update(orders).set({ status: "canceled", remains: 0 }).where(eq4(orders.id, o.id));
        const updatedBalance = apiUser.balance + refundAmount;
        await db.update(users).set({ balance: updatedBalance }).where(eq4(users.id, apiUser.id));
        await logActivity(
          apiUser.id,
          "API Cancel Order",
          `Order #${o.id} canceled via API. Refunded \u20B9${refundAmount.toFixed(4)}`,
          req.ip
        );
        return res.json({
          cancel: o.id.toString()
        });
      }
      default: {
        return res.status(400).json({
          error: `Invalid action parameter '${action}'. Supported actions: balance, services, add, status, refill, refill_status, cancel`
        });
      }
    }
  } catch (error) {
    console.error("Reseller API Error:", error);
    res.status(500).json({ error: "Internal API Server Error" });
  }
});
router.get("/user/announcements", requireAuth, async (req, res) => {
  try {
    const activeAnnouncements = await db.select().from(announcements).where(eq4(announcements.status, "active")).orderBy(desc3(announcements.createdAt));
    res.json(activeAnnouncements);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve announcements." });
  }
});
router.get("/user/categories", requireAuth, async (req, res) => {
  try {
    const activeCategories = await db.select().from(categories).where(eq4(categories.status, "active")).orderBy(categories.sortOrder);
    res.json(activeCategories);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve categories." });
  }
});
router.get("/user/services", requireAuth, async (req, res) => {
  try {
    const activeServices = await db.select({
      id: services.id,
      categoryId: services.categoryId,
      name: services.name,
      description: services.description,
      pricePerThousand: services.pricePerThousand,
      minAmount: services.minAmount,
      maxAmount: services.maxAmount,
      status: services.status,
      icon: services.icon
    }).from(services).where(eq4(services.status, "active")).orderBy(services.id);
    res.json(activeServices);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve services." });
  }
});
router.get("/user/favorites", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const favorites = await db.select({ serviceId: favoriteServices.serviceId }).from(favoriteServices).where(eq4(favoriteServices.userId, req.user.id));
    res.json(favorites.map((f) => f.serviceId));
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve favorite services." });
  }
});
router.post("/user/favorites/toggle", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { serviceId } = req.body;
    if (!serviceId) return res.status(400).json({ error: "Service ID required" });
    const existing = await db.select().from(favoriteServices).where(
      and(
        eq4(favoriteServices.userId, req.user.id),
        eq4(favoriteServices.serviceId, Number(serviceId))
      )
    );
    if (existing.length > 0) {
      await db.delete(favoriteServices).where(
        and(
          eq4(favoriteServices.userId, req.user.id),
          eq4(favoriteServices.serviceId, Number(serviceId))
        )
      );
      res.json({ favorited: false });
    } else {
      await db.insert(favoriteServices).values({
        userId: req.user.id,
        serviceId: Number(serviceId)
      });
      res.json({ favorited: true });
    }
  } catch (error) {
    res.status(500).json({ error: "Failed to toggle favorite service." });
  }
});
router.post("/orders/new", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { serviceId, link, quantity, couponCode } = req.body;
    if (!serviceId || !link || !quantity) {
      return res.status(400).json({ error: "Missing required parameters." });
    }
    const service = await db.select().from(services).where(eq4(services.id, Number(serviceId))).limit(1);
    if (service.length === 0 || service[0].status !== "active") {
      return res.status(400).json({ error: "Service is unavailable." });
    }
    const s = service[0];
    if (quantity < s.minAmount || quantity > s.maxAmount) {
      return res.status(400).json({ error: `Quantity must be between ${s.minAmount} and ${s.maxAmount}.` });
    }
    let charge = quantity / 1e3 * s.pricePerThousand;
    if (couponCode) {
      const coupon = await db.select().from(coupons).where(and(eq4(coupons.code, couponCode), eq4(coupons.status, "active"))).limit(1);
      if (coupon.length > 0) {
        const discount = charge * coupon[0].discountPercent / 100;
        charge -= discount;
        await db.update(coupons).set({ usageCount: sql2`${coupons.usageCount} + 1` }).where(eq4(coupons.id, coupon[0].id));
      }
    }
    if (req.user.balance < charge) {
      return res.status(400).json({ error: "Insufficient funds in your wallet." });
    }
    const newBalance = req.user.balance - charge;
    await db.update(users).set({ balance: newBalance }).where(eq4(users.id, req.user.id));
    const result = await db.insert(orders).values({
      userId: req.user.id,
      serviceId: s.id,
      link,
      quantity,
      charge,
      status: "pending",
      startCount: Math.floor(Math.random() * 5e3),
      // initial simulated count
      remains: quantity
    }).returning();
    const createdOrder = result[0];
    await logActivity(req.user.id, "Place Order", `Ordered service ID: ${s.id} for charge: $${charge.toFixed(4)}`, req.ip);
    let providerInfo = null;
    try {
      const dispatchPromise = dispatchOrderToProvider(createdOrder.id);
      providerInfo = await Promise.race([
        dispatchPromise,
        new Promise((_, reject) => setTimeout(() => reject(new Error("Background dispatching")), 5e3))
      ]);
    } catch (dispatchErr) {
      console.log(`[ASYNC DISPATCH BG] Order #${createdOrder.id} continuing dispatch in background`);
    }
    const latestOrderObj = await db.select().from(orders).where(eq4(orders.id, createdOrder.id)).limit(1);
    const finalOrder = latestOrderObj.length > 0 ? latestOrderObj[0] : createdOrder;
    let responseMessage = "Order placed successfully!";
    if (finalOrder.providerOrderId) {
      if (finalOrder.providerOrderId.startsWith("FAILED:")) {
        const failureReason = finalOrder.providerOrderId.replace("FAILED: ", "");
        responseMessage = `Order #${finalOrder.id} placed! (Provider Note: ${failureReason})`;
      } else {
        responseMessage = `Order #${finalOrder.id} placed & connected to ${providerInfo?.providerName || "API Provider"} (ID: #${finalOrder.providerOrderId})!`;
      }
    } else {
      responseMessage = `Order #${finalOrder.id} placed successfully! Connecting to API provider in background...`;
    }
    res.json({
      success: true,
      message: responseMessage,
      order: finalOrder,
      providerOrderId: finalOrder.providerOrderId,
      providerName: providerInfo?.providerName,
      newBalance
    });
  } catch (error) {
    console.error("New order error:", error);
    res.status(500).json({ error: "Failed to place order." });
  }
});
router.post("/orders/mass", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { massInput } = req.body;
    if (!massInput || typeof massInput !== "string") {
      return res.status(400).json({ error: "Invalid input format." });
    }
    const lines = massInput.split("\n").filter((line) => line.trim() !== "");
    const results = [];
    let totalCharge = 0;
    const ordersToInsert = [];
    for (const line of lines) {
      const parts = line.split("|");
      if (parts.length < 3) {
        results.push({ line, error: "Invalid line format. Use: service_id|quantity|link" });
        continue;
      }
      const serviceId = parseInt(parts[0].trim());
      const quantity = parseInt(parts[1].trim());
      const link = parts[2].trim();
      if (isNaN(serviceId) || isNaN(quantity) || !link) {
        results.push({ line, error: "Invalid parameters." });
        continue;
      }
      const service = await db.select().from(services).where(eq4(services.id, serviceId)).limit(1);
      if (service.length === 0 || service[0].status !== "active") {
        results.push({ line, error: "Service not active or not found." });
        continue;
      }
      const s = service[0];
      if (quantity < s.minAmount || quantity > s.maxAmount) {
        results.push({ line, error: `Quantity must be between ${s.minAmount} and ${s.maxAmount}.` });
        continue;
      }
      const charge = quantity / 1e3 * s.pricePerThousand;
      totalCharge += charge;
      ordersToInsert.push({
        serviceId,
        link,
        quantity,
        charge,
        serviceName: s.name
      });
    }
    if (ordersToInsert.length === 0) {
      return res.status(400).json({ error: "No valid orders found in input.", results });
    }
    if (req.user.balance < totalCharge) {
      return res.status(400).json({ error: `Insufficient wallet balance. Total required: $${totalCharge.toFixed(4)}` });
    }
    const newBalance = req.user.balance - totalCharge;
    await db.update(users).set({ balance: newBalance }).where(eq4(users.id, req.user.id));
    for (const ord of ordersToInsert) {
      const inserted = await db.insert(orders).values({
        userId: req.user.id,
        serviceId: ord.serviceId,
        link: ord.link,
        quantity: ord.quantity,
        charge: ord.charge,
        status: "pending",
        startCount: Math.floor(Math.random() * 5e3),
        remains: ord.quantity
      }).returning();
      dispatchOrderToProvider(inserted[0].id).catch((err) => {
        console.error("[MASS-DISPATCH ERROR] Async dispatch failed:", err);
      });
      results.push({
        line: `${ord.serviceId}|${ord.quantity}|${ord.link}`,
        success: true,
        orderId: inserted[0].id,
        charge: ord.charge
      });
    }
    await logActivity(req.user.id, "Place Mass Orders", `Placed ${ordersToInsert.length} mass orders. Total charge: $${totalCharge.toFixed(4)}`, req.ip);
    res.json({
      success: true,
      results,
      newBalance
    });
  } catch (error) {
    console.error("Mass order error:", error);
    res.status(500).json({ error: "Failed to process mass orders." });
  }
});
router.get("/user/orders", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const userActiveOrders = await db.select({ id: orders.id }).from(orders).where(
      and(
        eq4(orders.userId, req.user.id),
        sql2`${orders.providerOrderId} IS NOT NULL AND ${orders.providerOrderId} != '' AND ${orders.providerOrderId} NOT LIKE 'FAILED:%'`,
        sql2`LOWER(${orders.status}) NOT IN ('completed', 'cancelled', 'refunded')`
      )
    ).limit(20);
    if (userActiveOrders.length > 0) {
      try {
        await Promise.race([
          syncProviderOrders(userActiveOrders.map((o) => o.id)),
          new Promise((resolve) => setTimeout(resolve, 2500))
        ]);
      } catch (syncErr) {
        console.warn("User order fast sync error:", syncErr);
      }
    }
    const userOrders = await db.select({
      id: orders.id,
      link: orders.link,
      quantity: orders.quantity,
      charge: orders.charge,
      status: orders.status,
      startCount: orders.startCount,
      remains: orders.remains,
      refillStatus: orders.refillStatus,
      createdAt: orders.createdAt,
      serviceName: sql2`COALESCE(${services.name}, 'Service #' || ${orders.serviceId})`,
      providerOrderId: orders.providerOrderId
    }).from(orders).leftJoin(services, eq4(orders.serviceId, services.id)).where(eq4(orders.userId, req.user.id)).orderBy(desc3(orders.createdAt));
    const offset = await getOrderIdOffset();
    if (offset > 0) {
      userOrders.forEach((o) => {
        o.id += offset;
      });
    }
    res.json(userOrders);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve orders." });
  }
});
router.post("/user/orders/sync", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const userActiveOrders = await db.select({ id: orders.id }).from(orders).where(
      and(
        eq4(orders.userId, req.user.id),
        sql2`${orders.providerOrderId} IS NOT NULL AND ${orders.providerOrderId} != '' AND ${orders.providerOrderId} NOT LIKE 'FAILED:%'`,
        sql2`LOWER(${orders.status}) NOT IN ('completed', 'cancelled', 'refunded')`
      )
    ).limit(30);
    let synced = 0;
    if (userActiveOrders.length > 0) {
      const result = await syncProviderOrders(userActiveOrders.map((o) => o.id));
      synced = result?.synced || 0;
    }
    const userOrders = await db.select({
      id: orders.id,
      link: orders.link,
      quantity: orders.quantity,
      charge: orders.charge,
      status: orders.status,
      startCount: orders.startCount,
      remains: orders.remains,
      refillStatus: orders.refillStatus,
      createdAt: orders.createdAt,
      serviceName: sql2`COALESCE(${services.name}, 'Service #' || ${orders.serviceId})`,
      providerOrderId: orders.providerOrderId
    }).from(orders).leftJoin(services, eq4(orders.serviceId, services.id)).where(eq4(orders.userId, req.user.id)).orderBy(desc3(orders.createdAt));
    const offset = await getOrderIdOffset();
    if (offset > 0) {
      userOrders.forEach((o) => {
        o.id += offset;
      });
    }
    res.json({ success: true, synced, orders: userOrders });
  } catch (error) {
    console.error("Failed to sync user orders:", error);
    res.status(500).json({ error: "Failed to sync orders." });
  }
});
router.post("/orders/:id/refill", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const offset = await getOrderIdOffset();
    const orderId = parseInt(req.params.id) - offset;
    const orderObj = await db.select().from(orders).where(and(eq4(orders.id, orderId), eq4(orders.userId, req.user.id))).limit(1);
    if (orderObj.length === 0) {
      return res.status(404).json({ error: "Order not found." });
    }
    if (orderObj[0].status !== "completed") {
      return res.status(400).json({ error: "Only completed orders can be refilled." });
    }
    await db.update(orders).set({ refillStatus: "requested" }).where(eq4(orders.id, orderId));
    await db.insert(refillRequests).values({
      userId: req.user.id,
      orderId,
      status: "pending"
    });
    await logActivity(req.user.id, "Request Refill", `Requested refill for order ID: ${orderId}`, req.ip);
    res.json({ success: true, message: "Refill requested successfully." });
  } catch (error) {
    res.status(500).json({ error: "Failed to request refill." });
  }
});
router.get("/user/child-panels", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const userPanels = await db.select().from(childPanels).where(eq4(childPanels.userId, req.user.id)).orderBy(desc3(childPanels.createdAt));
    res.json(userPanels);
  } catch (error) {
    console.error("Failed to retrieve child panels:", error);
    res.status(500).json({ error: "Failed to retrieve child panels." });
  }
});
router.post("/user/child-panels", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { domain, currency, adminUsername, adminPassword, price } = req.body;
    if (!domain || !adminUsername || !adminPassword) {
      return res.status(400).json({ error: "Please fill in all required fields (domain, admin username, admin password)." });
    }
    const panelPrice = Number(price) || 10;
    if (req.user.balance < panelPrice) {
      return res.status(400).json({ error: `Insufficient wallet balance. Total required: $${panelPrice.toFixed(2)}` });
    }
    const newBalance = req.user.balance - panelPrice;
    await db.update(users).set({ balance: newBalance }).where(eq4(users.id, req.user.id));
    const inserted = await db.insert(childPanels).values({
      userId: req.user.id,
      domain,
      currency: currency || "USD",
      adminUsername,
      adminPassword,
      price: panelPrice,
      status: "pending"
    }).returning();
    await logActivity(
      req.user.id,
      "Order Child Panel",
      `Ordered child panel for domain: ${domain} (Price: $${panelPrice.toFixed(2)})`,
      req.ip
    );
    res.json({ success: true, message: "Child panel ordered successfully!", panel: inserted[0] });
  } catch (error) {
    console.error("Failed to order child panel:", error);
    res.status(500).json({ error: "Failed to order child panel." });
  }
});
router.get("/user/refill-requests", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const requests = await db.select({
      id: refillRequests.id,
      orderId: refillRequests.orderId,
      status: refillRequests.status,
      createdAt: refillRequests.createdAt,
      link: orders.link,
      quantity: orders.quantity,
      charge: orders.charge,
      serviceName: services.name
    }).from(refillRequests).innerJoin(orders, eq4(refillRequests.orderId, orders.id)).innerJoin(services, eq4(orders.serviceId, services.id)).where(eq4(refillRequests.userId, req.user.id)).orderBy(desc3(refillRequests.createdAt));
    const offset = await getOrderIdOffset();
    if (offset > 0) {
      requests.forEach((r) => {
        r.orderId += offset;
      });
    }
    res.json(requests);
  } catch (error) {
    console.error("Failed to retrieve refill requests:", error);
    res.status(500).json({ error: "Failed to retrieve refill requests." });
  }
});
router.get("/user/tickets", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const userTickets = await db.select().from(tickets).where(eq4(tickets.userId, req.user.id)).orderBy(desc3(tickets.createdAt));
    res.json(userTickets);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve tickets." });
  }
});
router.post("/tickets/new", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { subject, message } = req.body;
    if (!subject || !message) {
      return res.status(400).json({ error: "Subject and message are required." });
    }
    const newTicket = await db.insert(tickets).values({
      userId: req.user.id,
      subject,
      status: "open"
    }).returning();
    const ticketId = newTicket[0].id;
    await db.insert(ticketMessages).values({
      ticketId,
      senderId: req.user.id,
      message
    });
    await logActivity(req.user.id, "Create Support Ticket", `Created ticket ID: ${ticketId} - ${subject}`, req.ip);
    res.json({ success: true, ticket: newTicket[0] });
  } catch (error) {
    res.status(500).json({ error: "Failed to create support ticket." });
  }
});
router.get("/tickets/:id/messages", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const ticketId = parseInt(req.params.id);
    const ticketObj = await db.select().from(tickets).where(and(eq4(tickets.id, ticketId), or2(eq4(tickets.userId, req.user.id), eq4(sql2`${req.user.role}`, "admin")))).limit(1);
    if (ticketObj.length === 0) {
      return res.status(404).json({ error: "Ticket not found." });
    }
    const messages = await db.select({
      id: ticketMessages.id,
      message: ticketMessages.message,
      createdAt: ticketMessages.createdAt,
      senderName: users.name,
      senderRole: users.role
    }).from(ticketMessages).innerJoin(users, eq4(ticketMessages.senderId, users.id)).where(eq4(ticketMessages.ticketId, ticketId)).orderBy(ticketMessages.id);
    res.json({ ticket: ticketObj[0], messages });
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve ticket messages." });
  }
});
router.post("/tickets/:id/reply", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const ticketId = parseInt(req.params.id);
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: "Message content is empty" });
    const ticketObj = await db.select().from(tickets).where(and(eq4(tickets.id, ticketId), or2(eq4(tickets.userId, req.user.id), eq4(sql2`${req.user.role}`, "admin")))).limit(1);
    if (ticketObj.length === 0) {
      return res.status(404).json({ error: "Ticket not found." });
    }
    await db.insert(ticketMessages).values({
      ticketId,
      senderId: req.user.id,
      message
    });
    const newStatus = req.user.role === "admin" ? "answered" : "open";
    await db.update(tickets).set({ status: newStatus }).where(eq4(tickets.id, ticketId));
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to submit reply." });
  }
});
router.post("/user/add-funds", requireAuth, async (req, res) => {
  return res.status(403).json({
    error: "Direct unverified fund addition is disabled. All deposits must be verified through the official BharatPe UPI Payment Gateway."
  });
});
router.post("/user/deposit/create-order", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { amount, bonusPercent } = req.body;
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt < 10) {
      return res.status(400).json({ error: "Invalid deposit amount. Minimum is \u20B910." });
    }
    const settingsMap = await getSettingsMap();
    const methodIdentifier = "bharatpe_upi";
    const methodDisplayTitle = "BharatPe UPI Gateway";
    const vpa = (settingsMap["bharatpeVpa"] || settingsMap["allUpiVpa"] || "BHARATPE2H0D0Q1Y4T29351@unitype").trim();
    const merchantName = (settingsMap["bharatpeMerchantName"] || settingsMap["allUpiMerchantName"] || "PRIYA").trim();
    const customQrUrl = (settingsMap["bharatpeQrUrl"] || settingsMap["allUpiQrUrl"] || "").trim();
    const instructions = settingsMap["bharatpeInstructions"] || "Scan the BharatPe QR code using any UPI app (GPay, PhonePe, Paytm, BHIM, Cred) and submit the 12-digit UTR bank reference number for instant automated verification.";
    let calculatedBonusPct = 0;
    if (bonusPercent !== void 0 && !isNaN(parseFloat(bonusPercent)) && parseFloat(bonusPercent) > 0) {
      calculatedBonusPct = parseFloat(bonusPercent);
    }
    const randomSuffix = crypto.randomBytes(3).toString("hex").toUpperCase();
    const orderRef = `BPE-${Date.now().toString().slice(-6)}-${randomSuffix}`;
    const bonusAmt = calculatedBonusPct > 0 ? amt * calculatedBonusPct / 100 : 0;
    const finalCredit = amt + bonusAmt;
    const [createdPayment] = await db.insert(payments).values({
      userId: req.user.id,
      amount: finalCredit,
      paymentMethod: methodDisplayTitle,
      transactionId: orderRef,
      status: "pending"
    }).returning();
    const upiPayload = `upi://pay?pa=${encodeURIComponent(vpa)}&pn=${encodeURIComponent(merchantName)}&am=${amt.toFixed(2)}&cu=INR&tn=${encodeURIComponent(orderRef)}`;
    const upiQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=350x350&data=${encodeURIComponent(upiPayload)}`;
    await logActivity(req.user.id, "Deposit Order Initiated", `Created BharatPe deposit order ${orderRef} for \u20B9${amt}`, req.ip);
    res.json({
      success: true,
      orderId: createdPayment.id,
      orderRef,
      amount: amt,
      bonusAmount: bonusAmt,
      bonusPercent: calculatedBonusPct,
      finalCredit,
      methodKey: methodIdentifier,
      paymentMethod: methodDisplayTitle,
      vpa,
      merchantName,
      customQrUrl,
      instructions,
      upiPayload,
      upiQrUrl,
      status: "pending"
    });
  } catch (error) {
    console.error("Create deposit order error:", error);
    res.status(500).json({ error: "Failed to create payment order." });
  }
});
router.post("/user/deposit/submit-utr", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { orderRef, utr, paymentMethod } = req.body;
    const cleanUtr = String(utr || "").trim().replace(/\D/g, "");
    if (cleanUtr.length !== 12) {
      return res.status(400).json({ error: "Invalid UPI Transaction Reference Number (UTR). Must be exactly 12 digits." });
    }
    const isRepeated = /^(\d)\1{11}$/.test(cleanUtr);
    const isSequential = "01234567890123456789".includes(cleanUtr) || "98765432109876543210".includes(cleanUtr);
    if (isRepeated || isSequential) {
      return res.status(400).json({ error: "Fake or dummy UTR number detected. Please enter your real 12-digit UPI bank reference." });
    }
    let targetPayment = null;
    const duplicate = await db.select().from(payments).where(
      or2(
        eq4(payments.transactionId, cleanUtr),
        sql2`${payments.transactionId} LIKE ${"%" + cleanUtr + "%"}`
      )
    ).limit(1);
    if (duplicate.length > 0) {
      if (duplicate[0].status === "completed") {
        return res.status(400).json({ error: "This Transaction Reference ID (UTR) has already been used and credited." });
      }
      targetPayment = duplicate[0];
    }
    if (orderRef && !targetPayment) {
      const existing = await db.select().from(payments).where(and(eq4(payments.transactionId, orderRef), eq4(payments.userId, req.user.id))).limit(1);
      if (existing.length > 0) {
        targetPayment = existing[0];
      }
    }
    const userEnteredAmount = parseFloat(req.body.amount);
    let expectedAmount = !isNaN(userEnteredAmount) && userEnteredAmount > 0 ? userEnteredAmount : targetPayment && targetPayment.amount > 0 ? targetPayment.amount : 10;
    if (!targetPayment) {
      const methodLabel = paymentMethod || "BharatPe UPI QR";
      const [newPending] = await db.insert(payments).values({
        userId: req.user.id,
        amount: expectedAmount,
        paymentMethod: methodLabel,
        transactionId: cleanUtr,
        status: "pending"
      }).returning();
      targetPayment = newPending;
    } else if (targetPayment.status === "completed") {
      return res.status(400).json({ error: "This payment order is already completed and credited." });
    }
    const settingsMap = await getSettingsMap();
    const instantAutoCredit = settingsMap["instantUtrAutoCredit"] === "enabled";
    if (!instantAutoCredit) {
      if (!/^\d{12}$/.test(cleanUtr)) {
        return res.status(400).json({ error: "Invalid UTR: Bank transaction ID must be exactly 12 numeric digits." });
      }
      if (/^(\d)\1{11}$/.test(cleanUtr)) {
        return res.status(400).json({ error: "Invalid UTR: Suspicious sequence or repeated digits detected." });
      }
      if (cleanUtr === "123456789012" || cleanUtr === "012345678901" || cleanUtr === "987654321098" || cleanUtr === "112233445566") {
        return res.status(400).json({ error: "Invalid UTR: Sequential demo numbers are not accepted." });
      }
      const duplicate2 = await db.select().from(payments).where(eq4(payments.transactionId, cleanUtr)).limit(1);
      if (duplicate2.length > 0 && duplicate2[0].id !== targetPayment.id) {
        if (duplicate2[0].status === "completed") {
          return res.status(400).json({ error: "This Transaction Reference ID (UTR) has already been approved and credited." });
        }
        await db.delete(payments).where(eq4(payments.id, duplicate2[0].id));
      }
      await db.update(payments).set({
        status: "pending",
        transactionId: cleanUtr,
        amount: expectedAmount
      }).where(eq4(payments.id, targetPayment.id));
      await logActivity(
        req.user.id,
        "Deposit Queued (Pending Admin Approval)",
        `UTR ${cleanUtr} submitted for \u20B9${expectedAmount}. Waiting for admin approval.`,
        req.ip
      );
      return res.status(200).json({
        success: true,
        status: "pending",
        isPending: true,
        amount: expectedAmount,
        transactionId: cleanUtr,
        message: `\u092A\u0947\u092E\u0947\u0902\u091F \u0930\u093F\u0915\u094D\u0935\u0947\u0938\u094D\u091F (UTR: ${cleanUtr}) \u0938\u092B\u0932\u0924\u093E\u092A\u0942\u0930\u094D\u0935\u0915 \u0926\u0930\u094D\u091C \u0939\u094B \u0917\u0908 \u0939\u0948! \u090F\u0921\u092E\u093F\u0928 \u0926\u094D\u0935\u093E\u0930\u093E \u0935\u0947\u0930\u0940\u092B\u093E\u0908 \u0935 \u0905\u092A\u094D\u0930\u0942\u0935 \u0939\u094B\u0924\u0947 \u0939\u0940 \u20B9${expectedAmount.toFixed(2)} \u0906\u092A\u0915\u0947 \u0935\u0949\u0932\u0947\u091F \u092E\u0947\u0902 \u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u0930 \u0926\u093F\u090F \u091C\u093E\u090F\u0901\u0917\u0947\u0964`
      });
    }
    const verification = await verifyPaymentWithOfficialProvider({
      utr: cleanUtr,
      expectedAmount: expectedAmount > 0 ? expectedAmount : void 0,
      orderRef: orderRef || targetPayment.transactionId,
      paymentMethod: "BharatPe UPI",
      userId: req.user.id,
      userEmail: req.user.email,
      customMerchantId: settingsMap["bharatpeMerchantId"],
      customToken: settingsMap["bharatpeToken"]
    });
    let isInstantApproved = false;
    if (!verification.verified) {
      if (verification.status === "pending") {
        await db.update(payments).set({
          status: "pending",
          transactionId: cleanUtr,
          amount: expectedAmount
        }).where(eq4(payments.id, targetPayment.id));
        await logActivity(
          req.user.id,
          "Deposit Queued (Pending Approval)",
          `UTR ${cleanUtr} submitted for \u20B9${expectedAmount}. Queued for merchant admin approval.`,
          req.ip
        );
        return res.status(200).json({
          success: true,
          status: "pending",
          isPending: true,
          amount: expectedAmount,
          message: `UTR #${cleanUtr} \u0938\u092C\u092E\u093F\u091F \u0939\u094B \u0917\u092F\u093E \u0939\u0948! \u0906\u092A\u0915\u0940 \u092A\u0947\u092E\u0947\u0902\u091F \u0935\u0947\u0930\u093F\u092B\u093F\u0915\u0947\u0936\u0928 \u0915\u0947 \u0932\u093F\u090F \u0926\u0930\u094D\u091C \u0915\u0930 \u0932\u0940 \u0917\u0908 \u0939\u0948\u0964 \u090F\u0921\u092E\u093F\u0928 \u0926\u094D\u0935\u093E\u0930\u093E \u092A\u0941\u0937\u094D\u091F\u093F \u0939\u094B\u0924\u0947 \u0939\u0940 \u20B9${expectedAmount.toFixed(2)} \u0906\u092A\u0915\u0947 \u0935\u0949\u0932\u0947\u091F \u092E\u0947\u0902 \u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u0930 \u0926\u093F\u090F \u091C\u093E\u090F\u0901\u0917\u0947\u0964`
        });
      } else {
        await db.update(payments).set({
          status: "failed"
        }).where(eq4(payments.id, targetPayment.id));
        await logActivity(
          req.user.id,
          "Deposit Verification Failed",
          `BharatPe verification failed for UTR ${cleanUtr}: ${verification.error || "Unverified"}`,
          req.ip
        );
        return res.status(400).json({
          success: false,
          status: "failed",
          error: verification.error || "Payment could not be verified on BharatPe. Please check your payment receipt and try again.",
          missingCredentials: verification.missingCredentials
        });
      }
    }
    const creditAmount = verification.verified && verification.verifiedAmount && verification.verifiedAmount > 0 ? verification.verifiedAmount : expectedAmount > 0 ? expectedAmount : 10;
    if (targetPayment.transactionId !== cleanUtr) {
      const conflictRecord = await db.select().from(payments).where(eq4(payments.transactionId, cleanUtr)).limit(1);
      if (conflictRecord.length > 0 && conflictRecord[0].id !== targetPayment.id) {
        await db.delete(payments).where(eq4(payments.id, conflictRecord[0].id));
      }
    }
    await db.update(payments).set({
      amount: creditAmount,
      transactionId: cleanUtr,
      status: "completed"
    }).where(eq4(payments.id, targetPayment.id));
    const userTarget = await db.select().from(users).where(eq4(users.id, req.user.id)).limit(1);
    const currentBal = userTarget[0]?.balance || 0;
    const newBal = currentBal + creditAmount;
    await db.update(users).set({ balance: newBal }).where(eq4(users.id, req.user.id));
    try {
      await syncPaymentToSupabase({
        userId: req.user.id,
        amount: creditAmount,
        paymentMethod: targetPayment.paymentMethod,
        transactionId: cleanUtr,
        status: "completed"
      });
      await syncUserBalanceToSupabase(req.user.id, newBal);
    } catch (syncErr) {
      console.warn("Background Supabase sync warning:", syncErr);
    }
    await logActivity(
      req.user.id,
      isInstantApproved ? "Instant UTR Deposit Credited" : "Deposit Auto-Verified",
      `Deposit of \u20B9${creditAmount} credited via ${isInstantApproved ? "Instant UPI UTR Settlement" : verification.gateway || "Official Gateway API"} (UTR: ${cleanUtr})`,
      req.ip
    );
    res.json({
      success: true,
      status: "completed",
      orderRef: cleanUtr,
      transactionId: cleanUtr,
      amount: creditAmount,
      newBalance: newBal,
      gateway: isInstantApproved ? "Instant UPI Settlement" : verification.gateway,
      message: `Payment Verified \u2713 \u20B9${creditAmount.toFixed(2)} added successfully to your wallet!`
    });
  } catch (error) {
    console.error("Automated UTR verification error:", error);
    res.status(500).json({ error: error?.message || "Payment verification failed due to server error. Please try again." });
  }
});
router.get("/user/deposit/status/:orderRef", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { orderRef } = req.params;
    if (!orderRef) {
      return res.status(400).json({ error: "Order reference is required." });
    }
    const existing = await db.select().from(payments).where(
      and(
        eq4(payments.userId, req.user.id),
        or2(
          eq4(payments.transactionId, orderRef),
          sql2`${payments.transactionId} LIKE ${"%" + orderRef + "%"}`
        )
      )
    ).orderBy(desc3(payments.createdAt)).limit(1);
    if (existing.length === 0) {
      return res.status(404).json({ error: "Payment order not found." });
    }
    const payment = existing[0];
    const userTarget = await db.select().from(users).where(eq4(users.id, req.user.id)).limit(1);
    const currentBalance = userTarget[0]?.balance || req.user.balance;
    if (payment.status === "completed") {
      return res.json({
        success: true,
        status: "completed",
        amount: payment.amount,
        newBalance: currentBalance,
        message: "Payment Verified \u2713 Funds Added Successfully"
      });
    }
    if (payment.status === "failed") {
      return res.json({
        success: false,
        status: "failed",
        message: "Payment could not be verified. Please check your payment and try again."
      });
    }
    return res.json({
      success: true,
      status: "pending",
      message: "Waiting for payment confirmation..."
    });
  } catch (error) {
    console.error("Check payment status error:", error);
    res.status(500).json({ error: "Failed to query payment status." });
  }
});
router.post("/webhook/payment", async (req, res) => {
  try {
    const webhookSecret = process.env.PAYMENT_WEBHOOK_SECRET || process.env.WEBHOOK_SECRET;
    const providedSecret = req.headers["x-webhook-secret"] || req.query.secret;
    if (webhookSecret && providedSecret !== webhookSecret) {
      return res.status(401).json({ error: "Unauthorized webhook request" });
    }
    const { utr, transactionId, amount, status, orderRef } = req.body;
    const cleanUtr = String(utr || transactionId || "").trim().replace(/\D/g, "");
    const numAmount = parseFloat(amount);
    if (!cleanUtr || isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: "Invalid webhook payload: 12-digit utr and valid positive amount are required." });
    }
    const normalizedStatus = String(status || "").toUpperCase();
    if (normalizedStatus !== "SUCCESS" && normalizedStatus !== "COMPLETED" && normalizedStatus !== "SETTLED") {
      return res.status(200).json({ received: true, message: "Non-success status acknowledged." });
    }
    const pendingList = await db.select().from(payments).where(
      or2(
        eq4(payments.transactionId, cleanUtr),
        orderRef ? eq4(payments.transactionId, orderRef) : sql2`1=0`
      )
    ).limit(1);
    if (pendingList.length > 0) {
      const p = pendingList[0];
      if (p.status === "completed") {
        return res.status(200).json({ received: true, message: "Payment already completed and credited." });
      }
      const creditAmt = numAmount > 0 ? numAmount : p.amount;
      await db.update(payments).set({
        status: "completed",
        amount: creditAmt,
        transactionId: cleanUtr
      }).where(eq4(payments.id, p.id));
      const u = await db.select().from(users).where(eq4(users.id, p.userId)).limit(1);
      if (u.length > 0) {
        const newBal = (u[0].balance || 0) + creditAmt;
        await db.update(users).set({ balance: newBal }).where(eq4(users.id, p.userId));
        await syncUserBalanceToSupabase(p.userId, newBal);
      }
      await logActivity(
        p.userId,
        "Webhook Payment Completed",
        `Credited \u20B9${creditAmt} automatically via authorized merchant webhook (UTR: ${cleanUtr})`,
        req.ip
      );
      return res.status(200).json({ success: true, message: "Payment credited successfully via webhook." });
    }
    return res.status(200).json({ received: true, message: "Transaction acknowledged, pending manual match." });
  } catch (err) {
    console.error("[Payment Webhook Error]:", err);
    res.status(500).json({ error: "Webhook processing error." });
  }
});
router.post("/payment/razorpay/create-order", requireAuth, async (req, res) => {
  return res.status(403).json({ error: "Razorpay is disabled. YouthSMM now exclusively supports BharatPe Payment Gateway." });
});
router.post("/payment/razorpay/verify", requireAuth, async (req, res) => {
  return res.status(403).json({ error: "Razorpay is disabled. YouthSMM now exclusively supports BharatPe Payment Gateway." });
});
router.get("/admin/payments", requireAdmin, async (req, res) => {
  try {
    const list = await db.select({
      id: payments.id,
      userId: payments.userId,
      amount: payments.amount,
      paymentMethod: payments.paymentMethod,
      transactionId: payments.transactionId,
      status: payments.status,
      createdAt: payments.createdAt,
      userEmail: users.email,
      userName: users.name
    }).from(payments).leftJoin(users, eq4(payments.userId, users.id)).orderBy(desc3(payments.createdAt)).limit(200);
    res.json(list);
  } catch (error) {
    console.error("Failed to retrieve admin payments:", error);
    res.status(500).json({ error: "Failed to retrieve payment records." });
  }
});
router.patch("/admin/payments/:id/status", requireAdmin, async (req, res) => {
  try {
    const paymentId = parseInt(req.params.id);
    if (isNaN(paymentId)) return res.status(400).json({ error: "Invalid payment ID" });
    const { status } = req.body;
    const validStatuses = ["pending", "completed", "success", "failed", "cancelled"];
    if (!status || !validStatuses.includes(status.toLowerCase())) {
      return res.status(400).json({ error: "Invalid status. Must be pending, success, failed, or cancelled." });
    }
    const normalizedStatus = status.toLowerCase() === "success" ? "completed" : status.toLowerCase();
    const p = await db.select().from(payments).where(eq4(payments.id, paymentId)).limit(1);
    if (p.length === 0) return res.status(404).json({ error: "Payment record not found" });
    const targetPayment = p[0];
    const prevStatus = targetPayment.status;
    if (normalizedStatus === "completed" && prevStatus !== "completed" && targetPayment.amount > 0) {
      const u = await db.select().from(users).where(eq4(users.id, targetPayment.userId)).limit(1);
      if (u.length > 0) {
        const newBal = (u[0].balance || 0) + targetPayment.amount;
        await db.update(users).set({ balance: newBal }).where(eq4(users.id, targetPayment.userId));
        await syncUserBalanceToSupabase(targetPayment.userId, newBal);
      }
    } else if (prevStatus === "completed" && normalizedStatus !== "completed" && targetPayment.amount > 0) {
      const u = await db.select().from(users).where(eq4(users.id, targetPayment.userId)).limit(1);
      if (u.length > 0) {
        const newBal = Math.max(0, (u[0].balance || 0) - targetPayment.amount);
        await db.update(users).set({ balance: newBal }).where(eq4(users.id, targetPayment.userId));
        await syncUserBalanceToSupabase(targetPayment.userId, newBal);
      }
    }
    await db.update(payments).set({ status: normalizedStatus }).where(eq4(payments.id, paymentId));
    await logActivity(
      req.user?.id || null,
      "Update Payment Status",
      `Updated payment #${paymentId} status from ${prevStatus} to ${normalizedStatus}`,
      req.ip
    );
    res.json({
      success: true,
      message: `Payment #${paymentId} status updated to ${normalizedStatus}.`,
      status: normalizedStatus
    });
  } catch (error) {
    console.error("Failed to update payment status:", error);
    res.status(500).json({ error: "Failed to update payment status." });
  }
});
router.post("/admin/payments/:id/approve", requireAdmin, async (req, res) => {
  try {
    const paymentId = parseInt(req.params.id);
    if (isNaN(paymentId)) return res.status(400).json({ error: "Invalid payment ID" });
    const p = await db.select().from(payments).where(eq4(payments.id, paymentId)).limit(1);
    if (p.length === 0) return res.status(404).json({ error: "Payment record not found" });
    const targetPayment = p[0];
    if (targetPayment.status === "completed") {
      return res.status(400).json({ error: "This payment is already approved and credited." });
    }
    const u = await db.select().from(users).where(eq4(users.id, targetPayment.userId)).limit(1);
    if (u.length === 0) {
      return res.status(404).json({ error: "User associated with this payment not found." });
    }
    const currentBal = u[0].balance || 0;
    const newBal = currentBal + targetPayment.amount;
    await db.update(users).set({ balance: newBal }).where(eq4(users.id, targetPayment.userId));
    await db.update(payments).set({ status: "completed" }).where(eq4(payments.id, paymentId));
    try {
      await syncUserBalanceToSupabase(targetPayment.userId, newBal);
      await syncPaymentToSupabase({
        userId: targetPayment.userId,
        amount: targetPayment.amount,
        paymentMethod: targetPayment.paymentMethod,
        transactionId: targetPayment.transactionId,
        status: "completed"
      });
    } catch (syncErr) {
      console.warn("Supabase sync warning on payment approval:", syncErr);
    }
    await logActivity(
      req.user?.id || null,
      "Admin Approved Payment",
      `Admin approved payment #${paymentId} for \u20B9${targetPayment.amount} (User ID: ${targetPayment.userId}, UTR: ${targetPayment.transactionId}). New balance: \u20B9${newBal.toFixed(2)}`,
      req.ip
    );
    res.json({
      success: true,
      message: `Payment #${paymentId} (\u20B9${targetPayment.amount.toFixed(2)}) approved successfully! User wallet credited.`,
      status: "completed",
      newBalance: newBal
    });
  } catch (error) {
    console.error("Failed to approve payment:", error);
    res.status(500).json({ error: "Failed to approve payment." });
  }
});
router.post("/admin/payments/:id/reject", requireAdmin, async (req, res) => {
  try {
    const paymentId = parseInt(req.params.id);
    if (isNaN(paymentId)) return res.status(400).json({ error: "Invalid payment ID" });
    const p = await db.select().from(payments).where(eq4(payments.id, paymentId)).limit(1);
    if (p.length === 0) return res.status(404).json({ error: "Payment record not found" });
    const targetPayment = p[0];
    const prevStatus = targetPayment.status;
    if (prevStatus === "completed" && targetPayment.amount > 0) {
      const u = await db.select().from(users).where(eq4(users.id, targetPayment.userId)).limit(1);
      if (u.length > 0) {
        const newBal = Math.max(0, (u[0].balance || 0) - targetPayment.amount);
        await db.update(users).set({ balance: newBal }).where(eq4(users.id, targetPayment.userId));
        await syncUserBalanceToSupabase(targetPayment.userId, newBal);
      }
    }
    await db.update(payments).set({ status: "failed" }).where(eq4(payments.id, paymentId));
    await logActivity(
      req.user?.id || null,
      "Admin Rejected Payment",
      `Admin rejected payment #${paymentId} (UTR: ${targetPayment.transactionId})`,
      req.ip
    );
    res.json({
      success: true,
      message: `Payment #${paymentId} marked as failed/rejected.`,
      status: "failed"
    });
  } catch (error) {
    console.error("Failed to reject payment:", error);
    res.status(500).json({ error: "Failed to reject payment." });
  }
});
router.post("/admin/payments/remove-today-payments", requireAdmin, async (req, res) => {
  try {
    const now = /* @__PURE__ */ new Date();
    const istOffsetMs = 5.5 * 60 * 60 * 1e3;
    const istNow = new Date(now.getTime() + istOffsetMs);
    const istStart = new Date(istNow);
    istStart.setUTCHours(0, 0, 0, 0);
    const startOfTodayUtc = new Date(istStart.getTime() - istOffsetMs);
    const endOfTodayUtc = new Date(startOfTodayUtc.getTime() + 24 * 60 * 60 * 1e3);
    const startOfUtcDay = /* @__PURE__ */ new Date();
    startOfUtcDay.setUTCHours(0, 0, 0, 0);
    const effectiveStart = startOfTodayUtc.getTime() < startOfUtcDay.getTime() ? startOfTodayUtc : startOfUtcDay;
    const todaysPayments = await db.select().from(payments).where(and(
      gte(payments.createdAt, effectiveStart),
      lt(payments.createdAt, endOfTodayUtc)
    ));
    if (todaysPayments.length === 0) {
      return res.json({
        success: true,
        removedCount: 0,
        totalDeducted: 0,
        message: "No payments or added funds were found for today. All older payments remain safe and untouched."
      });
    }
    let totalDeducted = 0;
    for (const p of todaysPayments) {
      if (p.status === "completed" && p.amount > 0 && p.paymentMethod !== "Refund") {
        const u = await db.select().from(users).where(eq4(users.id, p.userId)).limit(1);
        if (u.length > 0) {
          const newBal = Math.max(0, (u[0].balance || 0) - p.amount);
          await db.update(users).set({ balance: newBal }).where(eq4(users.id, p.userId));
          totalDeducted += p.amount;
          await syncUserBalanceToSupabase(p.userId, newBal);
        }
      }
      await db.delete(payments).where(eq4(payments.id, p.id));
    }
    await logActivity(
      req.user?.id || null,
      "Remove Today Payments",
      `Removed ${todaysPayments.length} payments created today totaling \u20B9${totalDeducted.toFixed(2)}`,
      req.ip
    );
    res.json({
      success: true,
      removedCount: todaysPayments.length,
      totalDeducted,
      message: `Successfully removed ${todaysPayments.length} payment(s) from today and deducted \u20B9${totalDeducted.toFixed(2)} from user balances. Only today's payments were removed.`
    });
  } catch (error) {
    console.error("Failed to remove today payments:", error);
    res.status(500).json({ error: "Failed to remove today payments." });
  }
});
router.delete("/admin/payments/:id", requireAdmin, async (req, res) => {
  try {
    const paymentId = parseInt(req.params.id);
    if (isNaN(paymentId)) return res.status(400).json({ error: "Invalid payment ID" });
    const p = await db.select().from(payments).where(eq4(payments.id, paymentId)).limit(1);
    if (p.length === 0) return res.status(404).json({ error: "Payment record not found" });
    const targetPayment = p[0];
    let deductedAmount = 0;
    if (targetPayment.status === "completed" && targetPayment.amount > 0 && targetPayment.paymentMethod !== "Refund") {
      const u = await db.select().from(users).where(eq4(users.id, targetPayment.userId)).limit(1);
      if (u.length > 0) {
        const newBal = Math.max(0, (u[0].balance || 0) - targetPayment.amount);
        await db.update(users).set({ balance: newBal }).where(eq4(users.id, targetPayment.userId));
        deductedAmount = targetPayment.amount;
        await syncUserBalanceToSupabase(targetPayment.userId, newBal);
      }
    }
    await db.delete(payments).where(eq4(payments.id, paymentId));
    await logActivity(
      req.user?.id || null,
      "Delete Payment Record",
      `Deleted payment #${paymentId} (${targetPayment.transactionId}) for \u20B9${targetPayment.amount}${deductedAmount > 0 ? ` (Deducted \u20B9${deductedAmount} from user #${targetPayment.userId})` : ""}`,
      req.ip
    );
    res.json({
      success: true,
      message: `Payment #${paymentId} removed successfully.${deductedAmount > 0 ? ` User balance adjusted by -\u20B9${deductedAmount.toFixed(2)}.` : ""}`
    });
  } catch (error) {
    console.error("Failed to delete payment:", error);
    res.status(500).json({ error: "Failed to delete payment." });
  }
});
router.post("/user/add-funds-bharatpe", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { amount, utr, paymentMethod, bonusPercent } = req.body;
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt < 10) {
      return res.status(400).json({ error: "Invalid deposit amount. Minimum is \u20B910." });
    }
    const cleanUtr = String(utr || "").trim().replace(/\D/g, "");
    if (cleanUtr.length !== 12) {
      return res.status(400).json({ error: "Invalid UPI Transaction Reference Number (UTR). Must be exactly 12 digits." });
    }
    const isRepeated = /^(\d)\1{11}$/.test(cleanUtr);
    const isSequential = "01234567890123456789".includes(cleanUtr) || "98765432109876543210".includes(cleanUtr);
    if (isRepeated || isSequential) {
      return res.status(400).json({ error: "Fake/Dummy UTR number detected. Please enter your real UPI bank reference." });
    }
    const duplicate = await db.select().from(payments).where(eq4(payments.transactionId, cleanUtr)).limit(1);
    if (duplicate.length > 0 && duplicate[0].status === "completed") {
      return res.status(400).json({ error: "This Transaction Reference ID (UTR) has already been used and credited." });
    }
    const bonusPct = parseFloat(bonusPercent) || 0;
    const bonusAmt = bonusPct > 0 ? amt * bonusPct / 100 : 0;
    const finalCredit = amt + bonusAmt;
    const methodLabel = paymentMethod || "All UPI Payments";
    const settingsMap = await getSettingsMap();
    const instantAutoCredit = settingsMap["instantUtrAutoCredit"] === "enabled";
    if (!instantAutoCredit) {
      if (duplicate.length > 0) {
        await db.update(payments).set({
          amount: finalCredit,
          paymentMethod: methodLabel,
          transactionId: cleanUtr,
          status: "pending"
        }).where(eq4(payments.id, duplicate[0].id));
      } else {
        await db.insert(payments).values({
          userId: req.user.id,
          amount: finalCredit,
          paymentMethod: methodLabel,
          transactionId: cleanUtr,
          status: "pending"
        });
      }
      await logActivity(
        req.user.id,
        "Deposit Queued (Pending Approval)",
        `UTR ${cleanUtr} submitted for \u20B9${finalCredit}. Queued for admin approval.`,
        req.ip
      );
      return res.status(200).json({
        success: true,
        status: "pending",
        isPending: true,
        amount: finalCredit,
        transactionId: cleanUtr,
        message: `\u092A\u0947\u092E\u0947\u0902\u091F \u0930\u093F\u0915\u094D\u0935\u0947\u0938\u094D\u091F (UTR: ${cleanUtr}) \u0926\u0930\u094D\u091C \u0939\u094B \u0917\u0908 \u0939\u0948! \u090F\u0921\u092E\u093F\u0928 \u0926\u094D\u0935\u093E\u0930\u093E \u0905\u092A\u094D\u0930\u0942\u0935\u0932 \u0915\u0947 \u092C\u093E\u0926 \u20B9${finalCredit.toFixed(2)} \u0906\u092A\u0915\u0947 \u0935\u0949\u0932\u0947\u091F \u092E\u0947\u0902 \u091C\u0941\u0921\u093C \u091C\u093E\u090F\u0901\u0917\u0947\u0964`
      });
    }
    const verification = await verifyPaymentWithOfficialProvider({
      utr: cleanUtr,
      expectedAmount: finalCredit,
      paymentMethod: methodLabel,
      userId: req.user.id,
      userEmail: req.user.email
    });
    if (!verification.verified) {
      return res.status(400).json({
        success: false,
        status: "failed",
        error: verification.error || "Payment could not be verified. Please check your payment and try again.",
        missingCredentials: verification.missingCredentials
      });
    }
    if (duplicate.length > 0) {
      await db.update(payments).set({
        amount: finalCredit,
        paymentMethod: methodLabel,
        status: "completed"
      }).where(eq4(payments.id, duplicate[0].id));
    } else {
      await db.insert(payments).values({
        userId: req.user.id,
        amount: finalCredit,
        paymentMethod: methodLabel,
        transactionId: cleanUtr,
        status: "completed"
      });
    }
    const userTarget = await db.select().from(users).where(eq4(users.id, req.user.id)).limit(1);
    const newBal = (userTarget[0]?.balance || 0) + finalCredit;
    await db.update(users).set({ balance: newBal }).where(eq4(users.id, req.user.id));
    try {
      await syncPaymentToSupabase({
        userId: req.user.id,
        amount: finalCredit,
        paymentMethod: methodLabel,
        transactionId: cleanUtr,
        status: "completed"
      });
      await syncUserBalanceToSupabase(req.user.id, newBal);
    } catch (syncErr) {
      console.warn("Background Supabase sync warning:", syncErr);
    }
    res.json({
      success: true,
      status: "completed",
      message: "Payment Verified \u2713 Funds Added Successfully",
      transactionId: cleanUtr,
      newBalance: newBal
    });
  } catch (error) {
    console.error("Add funds verification error:", error);
    res.status(500).json({ error: error?.message || "Payment verification failed due to server error." });
  }
});
router.get("/user/payments", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const list = await db.select().from(payments).where(eq4(payments.userId, req.user.id)).orderBy(desc3(payments.createdAt));
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve payments." });
  }
});
router.get("/user/affiliate", requireAuth, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    let partner = await db.select().from(affiliates).where(eq4(affiliates.userId, req.user.id)).limit(1);
    if (partner.length === 0) {
      const refCode = "REF-" + Math.floor(Math.random() * 1e4);
      const inserted = await db.insert(affiliates).values({
        userId: req.user.id,
        referralCode: refCode
      }).returning();
      partner = [inserted[0]];
    }
    res.json(partner[0]);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve affiliate details." });
  }
});
router.get("/admin/stats", requireAdmin, async (req, res) => {
  try {
    const totalUsers = await db.select({ count: sql2`count(*)` }).from(users);
    const totalOrders = await db.select({
      count: sql2`count(*)`,
      totalSpent: sql2`COALESCE(sum(${orders.charge}), 0)`,
      activeSpent: sql2`COALESCE(sum(CASE WHEN ${orders.status} NOT IN ('cancelled', 'refunded') THEN ${orders.charge} ELSE 0 END), 0)`
    }).from(orders);
    const totalDeposits = await db.select({
      total: sql2`COALESCE(sum(CASE WHEN ${payments.paymentMethod} != 'Refund' THEN ${payments.amount} ELSE 0 END), 0)`
    }).from(payments).where(eq4(payments.status, "completed"));
    const now = /* @__PURE__ */ new Date();
    const istOffsetMs = 5.5 * 60 * 60 * 1e3;
    const istNow = new Date(now.getTime() + istOffsetMs);
    const istStart = new Date(istNow);
    istStart.setUTCHours(0, 0, 0, 0);
    const startOfTodayUtc = new Date(istStart.getTime() - istOffsetMs);
    const endOfTodayUtc = new Date(startOfTodayUtc.getTime() + 24 * 60 * 60 * 1e3);
    const todayOrders = await db.select({
      count: sql2`count(*)`,
      todayRevenue: sql2`COALESCE(sum(CASE WHEN ${orders.status} NOT IN ('cancelled', 'refunded') THEN ${orders.charge} ELSE 0 END), 0)`
    }).from(orders).where(and(
      gte(orders.createdAt, startOfTodayUtc),
      lt(orders.createdAt, endOfTodayUtc)
    ));
    const todayPayments = await db.select({
      count: sql2`count(*)`,
      todayDeposits: sql2`COALESCE(sum(CASE WHEN ${payments.paymentMethod} != 'Refund' THEN ${payments.amount} ELSE 0 END), 0)`
    }).from(payments).where(and(
      eq4(payments.status, "completed"),
      ne(payments.paymentMethod, "Refund"),
      gte(payments.createdAt, startOfTodayUtc),
      lt(payments.createdAt, endOfTodayUtc)
    ));
    const orderStatuses = await db.select({
      status: orders.status,
      count: sql2`count(*)`
    }).from(orders).groupBy(orders.status);
    const pendingDeposits = await db.select({
      count: sql2`count(*)`,
      totalPendingAmount: sql2`COALESCE(sum(${payments.amount}), 0)`
    }).from(payments).where(eq4(payments.status, "pending"));
    res.json({
      usersCount: Number(totalUsers[0]?.count || 0),
      ordersCount: Number(totalOrders[0]?.count || 0),
      totalRevenue: Number(totalOrders[0]?.totalSpent || 0),
      totalDeposited: Number(totalDeposits[0]?.total || 0),
      todayRevenue: Number(todayOrders[0]?.todayRevenue || 0),
      todayOrdersCount: Number(todayOrders[0]?.count || 0),
      todayDeposited: Number(todayPayments[0]?.todayDeposits || 0),
      todayDepositsCount: Number(todayPayments[0]?.count || 0),
      pendingDepositsCount: Number(pendingDeposits[0]?.count || 0),
      pendingDepositsAmount: Number(pendingDeposits[0]?.totalPendingAmount || 0),
      statusChart: orderStatuses
    });
  } catch (error) {
    console.error("Error fetching admin stats:", error);
    res.status(500).json({ error: "Failed to retrieve admin statistics." });
  }
});
router.get("/admin/users", requireAdmin, async (req, res) => {
  try {
    const list = await db.select().from(users).orderBy(desc3(users.createdAt));
    const userSpents = await db.select({
      userId: orders.userId,
      totalSpent: sql2`COALESCE(SUM(${orders.charge}), 0)`,
      activeSpent: sql2`COALESCE(SUM(CASE WHEN ${orders.status} NOT IN ('cancelled', 'refunded') THEN ${orders.charge} ELSE 0 END), 0)`,
      activeOrdersCount: sql2`COALESCE(SUM(CASE WHEN ${orders.status} NOT IN ('cancelled', 'refunded') THEN 1 ELSE 0 END), 0)`,
      ordersCount: sql2`COUNT(*)`
    }).from(orders).groupBy(orders.userId);
    const spentMap = /* @__PURE__ */ new Map();
    userSpents.forEach((item) => {
      if (item.userId !== null && item.userId !== void 0) {
        spentMap.set(Number(item.userId), {
          totalSpent: Number(item.totalSpent) || 0,
          activeSpent: Number(item.activeSpent) || 0,
          ordersCount: Number(item.ordersCount) || 0,
          activeOrdersCount: Number(item.activeOrdersCount) || 0
        });
      }
    });
    const userDeposits = await db.select({
      userId: payments.userId,
      totalDeposited: sql2`COALESCE(SUM(CASE WHEN ${payments.status} = 'completed' AND ${payments.paymentMethod} != 'Refund' THEN ${payments.amount} ELSE 0 END), 0)`
    }).from(payments).groupBy(payments.userId);
    const depositMap = /* @__PURE__ */ new Map();
    userDeposits.forEach((item) => {
      if (item.userId !== null && item.userId !== void 0) {
        depositMap.set(Number(item.userId), Number(item.totalDeposited) || 0);
      }
    });
    const realUsers = list.filter((u) => !u.email.startsWith("eyj") && u.email !== "undefined");
    const enrichedList = realUsers.map((u) => {
      const stats = spentMap.get(Number(u.id)) || { totalSpent: 0, activeSpent: 0, ordersCount: 0, activeOrdersCount: 0 };
      const totalDeposited = depositMap.get(Number(u.id)) || 0;
      return {
        ...u,
        spent: stats.totalSpent,
        activeSpent: stats.activeSpent,
        saved: Number(u.balance) || 0,
        // Current saved funds in wallet
        totalDeposited,
        ordersCount: stats.ordersCount,
        activeOrdersCount: stats.activeOrdersCount
      };
    });
    res.json(enrichedList);
  } catch (error) {
    console.error("Failed to retrieve users with stats:", error);
    res.status(500).json({ error: "Failed to retrieve users." });
  }
});
router.post("/admin/users/:id/balance", requireAdmin, async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    const { amount, action } = req.body;
    const amt = parseFloat(amount);
    if (isNaN(amt)) return res.status(400).json({ error: "Invalid amount" });
    const targetUser = await db.select().from(users).where(eq4(users.id, userId)).limit(1);
    if (!targetUser.length) {
      return res.status(404).json({ error: "User not found" });
    }
    const currentBalance = targetUser[0].balance || 0;
    let newBalance = currentBalance;
    let fundsAddedAmount = 0;
    if (action === "add") {
      newBalance = currentBalance + amt;
      fundsAddedAmount = amt;
      await db.update(users).set({ balance: newBalance }).where(eq4(users.id, userId));
      await logActivity(req.user?.id || null, "Admin Balance Add", `Added \u20B9${amt.toFixed(2)} to user ID: ${userId} balance (New balance: \u20B9${newBalance.toFixed(2)})`, req.ip);
    } else {
      newBalance = amt;
      if (amt > currentBalance) {
        fundsAddedAmount = amt - currentBalance;
      }
      await db.update(users).set({ balance: amt }).where(eq4(users.id, userId));
      await logActivity(req.user?.id || null, "Admin Balance Update", `Updated user ID: ${userId} balance to \u20B9${amt.toFixed(2)}`, req.ip);
    }
    if (fundsAddedAmount > 0) {
      await db.insert(payments).values({
        userId,
        amount: fundsAddedAmount,
        paymentMethod: "Manual (Admin Credit)",
        transactionId: `ADM-CREDIT-${userId}-${Date.now()}`,
        status: "completed"
      });
      await syncPaymentToSupabase({
        userId,
        amount: fundsAddedAmount,
        paymentMethod: "Manual (Admin Credit)",
        transactionId: `ADM-CREDIT-${userId}-${Date.now()}`,
        status: "completed"
      });
    }
    await syncUserBalanceToSupabase(userId, newBalance);
    const [updatedUser] = await db.select().from(users).where(eq4(users.id, userId)).limit(1);
    res.json({ success: true });
  } catch (error) {
    console.error("Failed to update balance:", error);
    res.status(500).json({ error: "Failed to update balance." });
  }
});
router.post("/admin/users/reset-all-balances", requireAdmin, async (req, res) => {
  try {
    await db.update(users).set({ balance: 0 });
    await logActivity(req.user?.id || null, "Reset All Balances", "Reset all user wallet balances to \u20B90.00", req.ip);
    res.json({ success: true, message: "All user balances have been reset to 0.00 successfully." });
  } catch (error) {
    console.error("Failed to reset balances:", error);
    res.status(500).json({ error: "Failed to reset all balances." });
  }
});
router.post("/admin/users/:id/status", requireAdmin, async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    const { status } = req.body;
    if (!status || !["active", "suspended"].includes(status)) {
      return res.status(400).json({ error: 'Valid status ("active" or "suspended") is required.' });
    }
    const [targetUser] = await db.select().from(users).where(eq4(users.id, userId)).limit(1);
    if (!targetUser) {
      return res.status(404).json({ error: "User not found." });
    }
    if (isSuperAdminEmail(targetUser.email) && status === "suspended") {
      return res.status(400).json({ error: "Cannot suspend the main administrator account." });
    }
    const [updatedUser] = await db.update(users).set({ status }).where(eq4(users.id, userId)).returning();
    await logActivity(
      req.user?.id || null,
      "Admin User Status Update",
      `Admin set user ${targetUser.email} (ID: ${userId}) status to "${status}"`,
      req.ip
    );
    res.json({ success: true, user: updatedUser });
  } catch (error) {
    console.error("Failed to update user status:", error);
    res.status(500).json({ error: "Failed to update user status." });
  }
});
router.post("/admin/users/:id/login-as", requireAdmin, async (req, res) => {
  try {
    const targetUserId = parseInt(req.params.id);
    if (isNaN(targetUserId)) {
      return res.status(400).json({ error: "Invalid user ID provided." });
    }
    const [targetUser] = await db.select().from(users).where(eq4(users.id, targetUserId)).limit(1);
    if (!targetUser) {
      return res.status(404).json({ error: "Target user not found." });
    }
    const clientIp = req.ip || req.headers["x-forwarded-for"] || "127.0.0.1";
    const [updatedUser] = await db.update(users).set({
      lastLoginAt: /* @__PURE__ */ new Date(),
      lastIp: clientIp
    }).where(eq4(users.id, targetUserId)).returning();
    await logActivity(
      req.user?.id || null,
      "Admin Impersonate User",
      `Admin (${req.user?.email || "admin"}) initiated direct user login as '${targetUser.email}' (ID: ${targetUser.id})`,
      clientIp
    );
    const userToken = `local-token-${targetUser.email.toLowerCase().trim()}`;
    res.json({
      success: true,
      token: userToken,
      user: updatedUser,
      message: `Successfully logged in as ${targetUser.email}`
    });
  } catch (error) {
    console.error("Error logging in as user:", error);
    res.status(500).json({ error: error.message || "Failed to login as user." });
  }
});
router.get("/admin/orders", requireAdmin, async (req, res) => {
  try {
    if (req.query.sync === "true") {
      try {
        await Promise.race([
          syncProviderOrders(),
          new Promise((resolve) => setTimeout(resolve, 3e3))
        ]);
      } catch (e) {
        console.warn("Admin orders sync error:", e);
      }
    }
    const allOrders = await db.select({
      id: orders.id,
      link: orders.link,
      quantity: orders.quantity,
      charge: orders.charge,
      status: orders.status,
      startCount: orders.startCount,
      remains: orders.remains,
      refillStatus: orders.refillStatus,
      createdAt: orders.createdAt,
      serviceName: sql2`COALESCE(${services.name}, 'Service #' || ${orders.serviceId})`,
      userEmail: sql2`COALESCE(${users.email}, 'User #' || ${orders.userId})`,
      userName: users.name,
      providerOrderId: orders.providerOrderId,
      providerName: providers.name
    }).from(orders).leftJoin(services, eq4(orders.serviceId, services.id)).leftJoin(users, eq4(orders.userId, users.id)).leftJoin(providers, eq4(services.providerId, providers.id)).orderBy(desc3(orders.createdAt));
    const offset = await getOrderIdOffset();
    if (offset > 0) {
      allOrders.forEach((o) => {
        o.id += offset;
      });
    }
    res.json(allOrders);
  } catch (error) {
    console.error("Failed to retrieve all orders:", error);
    res.status(500).json({ error: "Failed to retrieve orders." });
  }
});
router.get("/admin/users/:id/orders", requireAdmin, async (req, res) => {
  try {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) return res.status(400).json({ error: "Invalid user ID" });
    const userOrders = await db.select({
      id: orders.id,
      link: orders.link,
      quantity: orders.quantity,
      charge: orders.charge,
      status: orders.status,
      startCount: orders.startCount,
      remains: orders.remains,
      refillStatus: orders.refillStatus,
      createdAt: orders.createdAt,
      serviceName: sql2`COALESCE(${services.name}, 'Service #' || ${orders.serviceId})`,
      providerOrderId: orders.providerOrderId,
      providerName: providers.name
    }).from(orders).leftJoin(services, eq4(orders.serviceId, services.id)).leftJoin(providers, eq4(services.providerId, providers.id)).where(eq4(orders.userId, userId)).orderBy(desc3(orders.createdAt));
    const offset = await getOrderIdOffset();
    if (offset > 0) {
      userOrders.forEach((o) => {
        o.id += offset;
      });
    }
    res.json(userOrders);
  } catch (error) {
    console.error("Failed to retrieve user orders:", error);
    res.status(500).json({ error: "Failed to retrieve user orders history." });
  }
});
router.post("/admin/orders/:id/status", requireAdmin, async (req, res) => {
  try {
    const offset = await getOrderIdOffset();
    const orderId = parseInt(req.params.id) - offset;
    const { status } = req.body;
    if (!status) return res.status(400).json({ error: "Status is required" });
    const currentOrder = await db.select().from(orders).where(eq4(orders.id, orderId)).limit(1);
    if (currentOrder.length === 0) {
      return res.status(404).json({ error: "Order not found." });
    }
    const ord = currentOrder[0];
    if ((status === "refunded" || status === "cancelled") && ord.status !== "refunded" && ord.status !== "cancelled") {
      const userToRefund = await db.select().from(users).where(eq4(users.id, ord.userId)).limit(1);
      if (userToRefund.length > 0) {
        const refundedBalance = userToRefund[0].balance + ord.charge;
        await db.update(users).set({ balance: refundedBalance }).where(eq4(users.id, ord.userId));
        await db.insert(payments).values({
          userId: ord.userId,
          amount: ord.charge,
          paymentMethod: "Refund",
          transactionId: "REFUND-" + ord.id,
          status: "completed"
        });
      }
    }
    await db.update(orders).set({ status }).where(eq4(orders.id, orderId));
    await logActivity(req.user?.id || null, "Admin Order Update", `Set order ID: ${orderId} status to ${status}`, req.ip);
    res.json({ success: true });
  } catch (error) {
    console.error("Update order status error:", error);
    res.status(500).json({ error: "Failed to update order status." });
  }
});
router.post("/admin/orders/:id/dispatch", requireAdmin, async (req, res) => {
  try {
    const offset = await getOrderIdOffset();
    const orderId = parseInt(req.params.id) - offset;
    const result = await dispatchOrderToProvider(orderId, true);
    if (result.success) {
      res.json({
        success: true,
        message: `Order #${req.params.id} dispatched to ${result.providerName} successfully! Provider Order ID: ${result.providerOrderId}`,
        providerOrderId: result.providerOrderId
      });
    } else {
      res.status(400).json({
        success: false,
        error: result.error || "Failed to dispatch order to provider."
      });
    }
  } catch (error) {
    console.error("Admin dispatch order error:", error);
    res.status(500).json({ error: error.message || "Failed to dispatch order to provider." });
  }
});
router.get("/admin/child-panels", requireAdmin, async (req, res) => {
  try {
    const list = await db.select({
      id: childPanels.id,
      userId: childPanels.userId,
      domain: childPanels.domain,
      currency: childPanels.currency,
      adminUsername: childPanels.adminUsername,
      adminPassword: childPanels.adminPassword,
      price: childPanels.price,
      status: childPanels.status,
      createdAt: childPanels.createdAt,
      userName: users.name,
      userEmail: users.email
    }).from(childPanels).innerJoin(users, eq4(childPanels.userId, users.id)).orderBy(desc3(childPanels.createdAt));
    res.json(list);
  } catch (error) {
    console.error("Failed to fetch child panels for admin:", error);
    res.status(500).json({ error: "Failed to retrieve child panels." });
  }
});
router.post("/admin/child-panels/:id/status", requireAdmin, async (req, res) => {
  try {
    const panelId = parseInt(req.params.id);
    const { status } = req.body;
    if (!status) return res.status(400).json({ error: "Status is required" });
    await db.update(childPanels).set({ status }).where(eq4(childPanels.id, panelId));
    await logActivity(req.user?.id || null, "Admin Child Panel Update", `Updated child panel ID: ${panelId} status to ${status}`, req.ip);
    res.json({ success: true });
  } catch (error) {
    console.error("Failed to update child panel status:", error);
    res.status(500).json({ error: "Failed to update child panel status." });
  }
});
router.get("/admin/refill-requests", requireAdmin, async (req, res) => {
  try {
    const list = await db.select({
      id: refillRequests.id,
      orderId: refillRequests.orderId,
      status: refillRequests.status,
      createdAt: refillRequests.createdAt,
      userId: refillRequests.userId,
      userName: users.name,
      userEmail: users.email,
      link: orders.link,
      quantity: orders.quantity,
      charge: orders.charge,
      serviceName: services.name
    }).from(refillRequests).innerJoin(orders, eq4(refillRequests.orderId, orders.id)).innerJoin(services, eq4(orders.serviceId, services.id)).innerJoin(users, eq4(refillRequests.userId, users.id)).orderBy(desc3(refillRequests.createdAt));
    const offset = await getOrderIdOffset();
    if (offset > 0) {
      list.forEach((r) => {
        r.orderId += offset;
      });
    }
    res.json(list);
  } catch (error) {
    console.error("Failed to fetch refill requests for admin:", error);
    res.status(500).json({ error: "Failed to retrieve refill requests." });
  }
});
router.post("/admin/refill-requests/:id/status", requireAdmin, async (req, res) => {
  try {
    const requestId = parseInt(req.params.id);
    const { status } = req.body;
    if (!status) return res.status(400).json({ error: "Status is required" });
    const requestObj = await db.select().from(refillRequests).where(eq4(refillRequests.id, requestId)).limit(1);
    if (requestObj.length === 0) {
      return res.status(404).json({ error: "Refill request not found." });
    }
    const reqItem = requestObj[0];
    await db.update(refillRequests).set({ status }).where(eq4(refillRequests.id, requestId));
    let orderRefillStatus = "requested";
    if (status === "completed") orderRefillStatus = "completed";
    if (status === "rejected") orderRefillStatus = "rejected";
    await db.update(orders).set({ refillStatus: orderRefillStatus }).where(eq4(orders.id, reqItem.orderId));
    await logActivity(req.user?.id || null, "Admin Refill Update", `Updated refill request ID: ${requestId} status to ${status}`, req.ip);
    res.json({ success: true });
  } catch (error) {
    console.error("Failed to update refill status:", error);
    res.status(500).json({ error: "Failed to update refill status." });
  }
});
router.get("/admin/coupons", requireAdmin, async (req, res) => {
  try {
    const list = await db.select().from(coupons).orderBy(desc3(coupons.createdAt));
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve coupons." });
  }
});
router.post("/admin/coupons", requireAdmin, async (req, res) => {
  try {
    const { code, discountPercent } = req.body;
    if (!code || !discountPercent) return res.status(400).json({ error: "Missing parameters." });
    await db.insert(coupons).values({
      code: code.toUpperCase(),
      discountPercent: Number(discountPercent),
      status: "active"
    });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to create coupon." });
  }
});
router.post("/admin/announcements", requireAdmin, async (req, res) => {
  try {
    const { title, content, type } = req.body;
    if (!title || !content) return res.status(400).json({ error: "Title and content required." });
    await db.insert(announcements).values({
      title,
      content,
      type: type || "info",
      status: "active"
    });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to create announcement." });
  }
});
router.post("/admin/services", requireAdmin, async (req, res) => {
  try {
    const { categoryId, name, description, pricePerThousand, minAmount, maxAmount, providerId, providerServiceId, icon } = req.body;
    if (!categoryId || !name || !pricePerThousand) {
      return res.status(400).json({ error: "Category ID, Name and Price are required." });
    }
    await db.insert(services).values({
      categoryId: Number(categoryId),
      name,
      description,
      pricePerThousand: parseFloat(pricePerThousand),
      minAmount: Number(minAmount || 10),
      maxAmount: Number(maxAmount || 1e4),
      providerId: providerId ? Number(providerId) : null,
      providerServiceId: providerServiceId ? String(providerServiceId) : null,
      icon: icon || null,
      status: "active"
    });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to create service." });
  }
});
router.get("/admin/categories", requireAdmin, async (req, res) => {
  try {
    const allCategories = await db.select({
      id: categories.id,
      name: categories.name,
      status: categories.status,
      sortOrder: categories.sortOrder,
      icon: categories.icon,
      createdAt: categories.createdAt
    }).from(categories).orderBy(categories.sortOrder, categories.id);
    const servicesList = await db.select({ categoryId: services.categoryId }).from(services);
    const countMap = {};
    for (const s of servicesList) {
      if (s.categoryId) {
        countMap[s.categoryId] = (countMap[s.categoryId] || 0) + 1;
      }
    }
    const result = allCategories.map((c) => ({
      ...c,
      servicesCount: countMap[c.id] || 0
    }));
    res.json(result);
  } catch (error) {
    console.error("Failed to get admin categories:", error);
    res.status(500).json({ error: "Failed to retrieve categories." });
  }
});
router.post("/admin/categories", requireAdmin, async (req, res) => {
  try {
    const { name, icon } = req.body;
    if (!name) return res.status(400).json({ error: "Name is required" });
    await db.insert(categories).values({
      name,
      status: "active",
      sortOrder: 1,
      icon: icon || null
    });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to create category." });
  }
});
router.put("/admin/categories/:id", requireAdmin, async (req, res) => {
  try {
    const catId = parseInt(req.params.id);
    if (isNaN(catId)) return res.status(400).json({ error: "Invalid Category ID" });
    const { name, status, sortOrder, icon } = req.body;
    const updateData = {};
    if (name !== void 0) updateData.name = name;
    if (status !== void 0) updateData.status = status;
    if (sortOrder !== void 0) updateData.sortOrder = typeof sortOrder === "number" ? sortOrder : parseInt(sortOrder) || 0;
    if (icon !== void 0) updateData.icon = icon;
    await db.update(categories).set(updateData).where(eq4(categories.id, catId));
    res.json({ success: true });
  } catch (error) {
    console.error("Failed to update category:", error);
    res.status(500).json({ error: "Failed to update category." });
  }
});
router.get("/admin/tickets", requireAdmin, async (req, res) => {
  try {
    const adminTickets = await db.select({
      id: tickets.id,
      subject: tickets.subject,
      status: tickets.status,
      createdAt: tickets.createdAt,
      userEmail: users.email,
      userName: users.name
    }).from(tickets).innerJoin(users, eq4(tickets.userId, users.id)).orderBy(desc3(tickets.createdAt));
    res.json(adminTickets);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve tickets." });
  }
});
router.get("/admin/logs", requireAdmin, async (req, res) => {
  try {
    const logs = await db.select({
      id: activityLogs.id,
      action: activityLogs.action,
      details: activityLogs.details,
      ipAddress: activityLogs.ipAddress,
      createdAt: activityLogs.createdAt,
      userEmail: users.email
    }).from(activityLogs).leftJoin(users, eq4(activityLogs.userId, users.id)).orderBy(desc3(activityLogs.createdAt)).limit(100);
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve activity logs." });
  }
});
router.get("/admin/providers", requireAdmin, async (req, res) => {
  try {
    const list = await db.select().from(providers).orderBy(providers.id);
    const secureList = list.map((prov) => ({
      ...prov,
      apiKey: prov.apiKey ? `${prov.apiKey.slice(0, 4)}\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022${prov.apiKey.slice(-4)}` : "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
    }));
    res.json(secureList);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve API providers." });
  }
});
router.post("/admin/providers", requireAdmin, async (req, res) => {
  try {
    const { name, apiUrl, apiKey } = req.body;
    if (!name || !apiUrl || !apiKey) {
      return res.status(400).json({ error: "Name, API URL, and API Key are required." });
    }
    const inserted = await db.insert(providers).values({
      name,
      apiUrl,
      apiKey,
      status: "active",
      balance: 0
    }).returning();
    await logActivity(req.user?.id || null, "Create API Provider", `Created provider: ${name} (${apiUrl})`, req.ip);
    res.json({ success: true, provider: inserted[0] });
  } catch (error) {
    console.error("Failed to create SMM provider:", error);
    res.status(500).json({ error: "Failed to create SMM provider." });
  }
});
router.put("/admin/providers/:id", requireAdmin, async (req, res) => {
  try {
    const provId = parseInt(req.params.id);
    const { name, apiUrl, apiKey } = req.body;
    const existing = await db.select().from(providers).where(eq4(providers.id, provId)).limit(1);
    if (existing.length === 0) {
      return res.status(404).json({ error: "Provider not found." });
    }
    const updateFields = {};
    if (name) updateFields.name = name;
    if (apiUrl) updateFields.apiUrl = apiUrl;
    if (apiKey && !apiKey.includes("\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022")) {
      updateFields.apiKey = apiKey;
    }
    await db.update(providers).set(updateFields).where(eq4(providers.id, provId));
    await logActivity(req.user?.id || null, "Update API Provider", `Updated provider ID: ${provId}`, req.ip);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to update SMM provider." });
  }
});
router.delete("/admin/providers/:id", requireAdmin, async (req, res) => {
  try {
    const provId = parseInt(req.params.id);
    await db.update(services).set({ providerId: null, providerServiceId: null }).where(eq4(services.providerId, provId));
    await db.delete(providers).where(eq4(providers.id, provId));
    await logActivity(req.user?.id || null, "Delete API Provider", `Deleted provider ID: ${provId}`, req.ip);
    res.json({ success: true });
  } catch (error) {
    console.error("Delete provider error:", error);
    res.status(500).json({ error: "Failed to delete SMM provider." });
  }
});
router.post("/admin/providers/:id/balance", requireAdmin, async (req, res) => {
  try {
    const provId = parseInt(req.params.id);
    const prov = await db.select().from(providers).where(eq4(providers.id, provId)).limit(1);
    if (prov.length === 0) {
      return res.status(404).json({ error: "Provider not found." });
    }
    const provider = prov[0];
    const params = new URLSearchParams();
    params.append("key", provider.apiKey);
    params.append("action", "balance");
    const response = await fetch(provider.apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: params.toString()
    });
    if (!response.ok) {
      throw new Error(`HTTP Error ${response.status}`);
    }
    const data = await response.json();
    if (data && data.balance !== void 0) {
      const parsedBalance = parseFloat(data.balance);
      await db.update(providers).set({ balance: parsedBalance }).where(eq4(providers.id, provId));
      res.json({ success: true, balance: parsedBalance });
    } else if (data && data.error) {
      res.status(400).json({ error: data.error });
    } else {
      res.status(400).json({ error: "Invalid response from SMM API." });
    }
  } catch (error) {
    console.error("Failed to fetch provider balance:", error);
    res.status(500).json({ error: `Connection failed: ${error.message || error}` });
  }
});
router.get("/admin/providers/:id/services", requireAdmin, async (req, res) => {
  try {
    const provId = parseInt(req.params.id);
    if (!provId || isNaN(provId) || provId <= 0) {
      return res.status(400).json({ error: "Please select a valid SMM Provider." });
    }
    const prov = await db.select().from(providers).where(eq4(providers.id, provId)).limit(1);
    if (prov.length === 0) {
      return res.status(404).json({ error: "Provider not found." });
    }
    const provider = prov[0];
    const params = new URLSearchParams();
    params.append("key", provider.apiKey);
    params.append("action", "services");
    const response = await fetch(provider.apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: params.toString()
    });
    if (!response.ok) {
      throw new Error(`HTTP Error ${response.status}`);
    }
    const data = await response.json();
    if (Array.isArray(data)) {
      res.json(data);
    } else if (data && data.error) {
      res.status(400).json({ error: data.error });
    } else {
      res.status(400).json({ error: "Invalid response or no services returned from SMM API." });
    }
  } catch (error) {
    res.status(500).json({ error: error.message || "Failed to fetch services from SMM API." });
  }
});
router.post("/admin/services/import-bulk", requireAdmin, async (req, res) => {
  try {
    const { services: servicesToImport, providerId, priceMultiplier } = req.body;
    if (!Array.isArray(servicesToImport) || !providerId) {
      return res.status(400).json({ error: "Invalid input data. Expected services array and providerId." });
    }
    const multiplier = parseFloat(priceMultiplier) || 1;
    const existingCategories = await db.select().from(categories);
    const categoryMap = /* @__PURE__ */ new Map();
    existingCategories.forEach((cat) => {
      categoryMap.set(cat.name.toLowerCase().trim(), cat.id);
    });
    const results = [];
    for (const item of servicesToImport) {
      const categoryName = (item.category || "Uncategorized").trim();
      const lowerCatName = categoryName.toLowerCase();
      let catId = categoryMap.get(lowerCatName);
      if (!catId) {
        const [insertedCat] = await db.insert(categories).values({
          name: categoryName,
          status: "active",
          sortOrder: 1
        }).returning();
        catId = insertedCat.id;
        categoryMap.set(lowerCatName, catId);
      }
      const originalRate = parseFloat(item.rate) || 0;
      const finalPrice = originalRate * multiplier;
      const [insertedSrv] = await db.insert(services).values({
        categoryId: catId,
        name: item.name,
        description: item.desc || `SMM Provider Service ID: ${item.service}`,
        pricePerThousand: finalPrice,
        minAmount: Number(item.min || 10),
        maxAmount: Number(item.max || 1e4),
        providerId: Number(providerId),
        providerServiceId: String(item.service),
        status: "active"
      }).returning();
      results.push(insertedSrv);
    }
    res.json({ success: true, count: results.length });
  } catch (error) {
    console.error("Failed bulk-importing provider services:", error);
    res.status(500).json({ error: error.message || "Failed to import services." });
  }
});
router.post("/admin/services/seller-sync", requireAdmin, async (req, res) => {
  try {
    const { providerId, syncScope, profitPercentage, selectedServiceIds } = req.body;
    if (!providerId) {
      return res.status(400).json({ error: "SMM Provider ID is required." });
    }
    const prov = await db.select().from(providers).where(eq4(providers.id, Number(providerId))).limit(1);
    if (prov.length === 0) {
      return res.status(404).json({ error: "SMM Provider not found." });
    }
    const provider = prov[0];
    const params = new URLSearchParams();
    params.append("key", provider.apiKey);
    params.append("action", "services");
    const response = await fetch(provider.apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: params.toString()
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch from SMM API: ${response.statusText}`);
    }
    const remoteServices = await response.json();
    if (!Array.isArray(remoteServices)) {
      return res.status(400).json({ error: "Remote provider did not return a valid services array." });
    }
    const existingServices = await db.select().from(services).where(eq4(services.providerId, provider.id));
    const existingMap = /* @__PURE__ */ new Map();
    existingServices.forEach((s) => {
      if (s.providerServiceId) {
        existingMap.set(String(s.providerServiceId), s);
      }
    });
    const existingCategories = await db.select().from(categories);
    const categoryMap = /* @__PURE__ */ new Map();
    existingCategories.forEach((cat) => {
      categoryMap.set(cat.name.toLowerCase().trim(), cat.id);
    });
    const markup = 1 + (parseFloat(profitPercentage) || 0) / 100;
    let addedCount = 0;
    let updatedCount = 0;
    let skippedCount = 0;
    const selectedSet = selectedServiceIds ? new Set(selectedServiceIds.map(String)) : null;
    for (const remote of remoteServices) {
      const remoteIdStr = String(remote.service);
      if (syncScope === "selected" && selectedSet && !selectedSet.has(remoteIdStr)) {
        skippedCount++;
        continue;
      }
      const existing = existingMap.get(remoteIdStr);
      if (syncScope === "new_only" && existing) {
        skippedCount++;
        continue;
      }
      const originalRate = parseFloat(remote.rate) || 0;
      const finalPrice = originalRate * markup;
      const categoryName = (remote.category || "Uncategorized").trim();
      const lowerCatName = categoryName.toLowerCase();
      let catId = categoryMap.get(lowerCatName);
      if (!catId) {
        const [insertedCat] = await db.insert(categories).values({
          name: categoryName,
          status: "active",
          sortOrder: 1
        }).returning();
        catId = insertedCat.id;
        categoryMap.set(lowerCatName, catId);
      }
      if (existing) {
        if (syncScope === "price_only") {
          await db.update(services).set({
            pricePerThousand: finalPrice,
            minAmount: Number(remote.min || 10),
            maxAmount: Number(remote.max || 1e4)
          }).where(eq4(services.id, existing.id));
        } else {
          await db.update(services).set({
            categoryId: catId,
            name: remote.name,
            description: remote.desc || `SMM Provider Service ID: ${remote.service}`,
            pricePerThousand: finalPrice,
            minAmount: Number(remote.min || 10),
            maxAmount: Number(remote.max || 1e4)
          }).where(eq4(services.id, existing.id));
        }
        updatedCount++;
      } else {
        if (syncScope !== "price_only") {
          await db.insert(services).values({
            categoryId: catId,
            name: remote.name,
            description: remote.desc || `SMM Provider Service ID: ${remote.service}`,
            pricePerThousand: finalPrice,
            minAmount: Number(remote.min || 10),
            maxAmount: Number(remote.max || 1e4),
            providerId: provider.id,
            providerServiceId: remoteIdStr,
            status: "active"
          });
          addedCount++;
        } else {
          skippedCount++;
        }
      }
    }
    await logActivity(req.user?.id || null, "Seller Sync", `Synced SMM Provider ${provider.name}. Added: ${addedCount}, Updated: ${updatedCount}, Skipped: ${skippedCount}`, req.ip);
    res.json({
      success: true,
      addedCount,
      updatedCount,
      skippedCount,
      totalProcessed: addedCount + updatedCount + skippedCount
    });
  } catch (error) {
    console.error("Error in seller-sync API:", error);
    res.status(500).json({ error: error.message || "Internal Server Error during synchronization." });
  }
});
router.post("/admin/orders/sync", requireAdmin, async (req, res) => {
  try {
    const result = await syncProviderOrders();
    res.json({ success: true, ...result });
  } catch (error) {
    res.status(500).json({ error: "Failed to sync provider orders." });
  }
});
router.get("/admin/cron/status", requireAdmin, async (req, res) => {
  try {
    res.json({
      success: true,
      cronState: {
        lastRun: cronState.lastRun,
        runCount: cronState.runCount,
        status: cronState.status,
        lastSyncedCount: cronState.lastSyncedCount,
        error: cronState.error,
        intervalMs: cronState.intervalMs,
        isActive: cronState.isActive
      }
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve cron status." });
  }
});
router.post("/admin/cron/toggle", requireAdmin, async (req, res) => {
  try {
    const { active } = req.body;
    if (typeof active === "boolean") {
      cronState.isActive = active;
      if (active) {
        startOrderSyncCron();
      }
    } else {
      cronState.isActive = !cronState.isActive;
    }
    res.json({ success: true, cronState });
  } catch (error) {
    res.status(500).json({ error: "Failed to toggle cron state." });
  }
});
router.post("/admin/cron/trigger", requireAdmin, async (req, res) => {
  try {
    if (cronState.status === "running") {
      return res.status(400).json({ error: "Cron job is already running in the background." });
    }
    cronState.status = "running";
    console.log("[MANUAL TRIGGER] Manually triggering SMM status sync...");
    const result = await syncProviderOrders();
    cronState.lastRun = /* @__PURE__ */ new Date();
    cronState.runCount++;
    cronState.status = "success";
    cronState.lastSyncedCount = result?.synced || 0;
    cronState.error = null;
    res.json({ success: true, cronState });
  } catch (error) {
    console.error("[MANUAL TRIGGER] Sync failed:", error);
    cronState.lastRun = /* @__PURE__ */ new Date();
    cronState.status = "failed";
    cronState.error = error?.message || String(error);
    res.status(500).json({ error: error?.message || "Manual trigger failed.", cronState });
  }
});
router.get("/admin/cron/settings", requireAdmin, async (req, res) => {
  try {
    const intervalMinutes = (cronState.intervalMs || 15e3) / (60 * 1e3);
    res.json({ success: true, intervalMinutes, cronState });
  } catch (error) {
    res.status(500).json({ error: "Failed to get cron settings." });
  }
});
router.post("/admin/cron/settings", requireAdmin, async (req, res) => {
  try {
    const { intervalMinutes } = req.body;
    const mins = parseFloat(intervalMinutes);
    if (isNaN(mins) || mins < 0.5) {
      return res.status(400).json({ error: "Interval must be at least 0.5 minutes (30 seconds)." });
    }
    cronState.intervalMs = Math.round(mins * 60 * 1e3);
    startOrderSyncCron();
    res.json({ success: true, cronState });
  } catch (error) {
    res.status(500).json({ error: "Failed to update cron interval." });
  }
});
router.get("/admin/services", requireAdmin, async (req, res) => {
  try {
    const list = await db.select({
      id: services.id,
      categoryId: services.categoryId,
      name: services.name,
      description: services.description,
      pricePerThousand: services.pricePerThousand,
      minAmount: services.minAmount,
      maxAmount: services.maxAmount,
      status: services.status,
      providerId: services.providerId,
      providerServiceId: services.providerServiceId,
      icon: services.icon,
      categoryName: categories.name
    }).from(services).innerJoin(categories, eq4(services.categoryId, categories.id)).orderBy(services.id);
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve admin services." });
  }
});
router.put("/admin/services/:id", requireAdmin, async (req, res) => {
  try {
    const srvId = parseInt(req.params.id);
    const { categoryId, name, description, pricePerThousand, minAmount, maxAmount, providerId, providerServiceId, status, icon } = req.body;
    const existing = await db.select().from(services).where(eq4(services.id, srvId)).limit(1);
    if (existing.length === 0) {
      return res.status(404).json({ error: "Service not found." });
    }
    const updateFields = {};
    if (categoryId !== void 0) updateFields.categoryId = Number(categoryId);
    if (name !== void 0) updateFields.name = name;
    if (description !== void 0) updateFields.description = description;
    if (pricePerThousand !== void 0) updateFields.pricePerThousand = parseFloat(pricePerThousand);
    if (minAmount !== void 0) updateFields.minAmount = Number(minAmount);
    if (maxAmount !== void 0) updateFields.maxAmount = Number(maxAmount);
    if (status !== void 0) updateFields.status = status;
    if (icon !== void 0) updateFields.icon = icon || null;
    updateFields.providerId = providerId ? Number(providerId) : null;
    updateFields.providerServiceId = providerServiceId || null;
    await db.update(services).set(updateFields).where(eq4(services.id, srvId));
    await logActivity(req.user?.id || null, "Update Service", `Updated service ID: ${srvId}`, req.ip);
    res.json({ success: true });
  } catch (error) {
    console.error("Failed to update service:", error);
    res.status(500).json({ error: "Failed to update service." });
  }
});
router.delete("/admin/services/:id", requireAdmin, async (req, res) => {
  try {
    const srvId = parseInt(req.params.id);
    const serviceOrders = await db.select({ id: orders.id }).from(orders).where(eq4(orders.serviceId, srvId));
    const orderIds = serviceOrders.map((o) => o.id);
    if (orderIds.length > 0) {
      await db.delete(refillRequests).where(inArray(refillRequests.orderId, orderIds));
      await db.delete(orders).where(inArray(orders.id, orderIds));
    }
    await db.delete(favoriteServices).where(eq4(favoriteServices.serviceId, srvId));
    await db.delete(services).where(eq4(services.id, srvId));
    await logActivity(req.user?.id || null, "Delete Service", `Deleted service ID: ${srvId}`, req.ip);
    res.json({ success: true });
  } catch (error) {
    console.error("Failed to delete service:", error);
    res.status(500).json({ error: "Failed to delete service." });
  }
});
router.post("/admin/services/bulk-delete", requireAdmin, async (req, res) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: "Invalid or empty service IDs array." });
    }
    const srvIds = ids.map((id) => parseInt(id)).filter((id) => !isNaN(id));
    if (srvIds.length === 0) {
      return res.status(400).json({ error: "No valid service IDs provided." });
    }
    const chunkArray = (arr, size) => {
      const chunks = [];
      for (let i = 0; i < arr.length; i += size) {
        chunks.push(arr.slice(i, i + size));
      }
      return chunks;
    };
    const srvChunks = chunkArray(srvIds, 50);
    let totalDeleted = 0;
    for (const chunk of srvChunks) {
      try {
        const serviceOrders = await db.select({ id: orders.id }).from(orders).where(inArray(orders.serviceId, chunk));
        const orderIds = serviceOrders.map((o) => o.id);
        if (orderIds.length > 0) {
          const orderChunks = chunkArray(orderIds, 50);
          for (const oChunk of orderChunks) {
            try {
              await db.delete(refillRequests).where(inArray(refillRequests.orderId, oChunk));
            } catch (_) {
            }
            try {
              await db.delete(orders).where(inArray(orders.id, oChunk));
            } catch (_) {
            }
          }
        }
        try {
          await db.delete(favoriteServices).where(inArray(favoriteServices.serviceId, chunk));
        } catch (_) {
        }
        await db.delete(services).where(inArray(services.id, chunk));
        totalDeleted += chunk.length;
      } catch (chunkErr) {
        console.warn("[BULK SERVICE DELETE CHUNK ERROR]:", chunkErr);
        for (const singleId of chunk) {
          try {
            const sOrders = await db.select({ id: orders.id }).from(orders).where(eq4(orders.serviceId, singleId));
            const oIds = sOrders.map((o) => o.id);
            if (oIds.length > 0) {
              await db.delete(refillRequests).where(inArray(refillRequests.orderId, oIds));
              await db.delete(orders).where(inArray(orders.id, oIds));
            }
            await db.delete(favoriteServices).where(eq4(favoriteServices.serviceId, singleId));
            await db.delete(services).where(eq4(services.id, singleId));
            totalDeleted++;
          } catch (singleErr) {
            console.error(`[SINGLE SERVICE DELETE FAILED] ID: ${singleId}`, singleErr);
          }
        }
      }
    }
    await logActivity(req.user?.id || null, "Bulk Delete Services", `Bulk deleted ${totalDeleted} service IDs: ${srvIds.join(", ")}`, req.ip);
    res.json({ success: true, count: totalDeleted });
  } catch (error) {
    console.error("Failed to bulk delete services:", error);
    res.status(500).json({ error: error?.message || "Failed to bulk delete services." });
  }
});
async function safeDeleteCategories(catIds) {
  if (!catIds || catIds.length === 0) return { deletedCount: 0 };
  const deleteSingleCategory = async (catId) => {
    try {
      const catServices = await db.select({ id: services.id }).from(services).where(eq4(services.categoryId, catId));
      const sIds = catServices.map((s) => s.id);
      for (const sId of sIds) {
        try {
          const ords = await db.select({ id: orders.id }).from(orders).where(eq4(orders.serviceId, sId));
          const oIds = ords.map((o) => o.id);
          for (const oId of oIds) {
            try {
              await db.delete(refillRequests).where(eq4(refillRequests.orderId, oId));
            } catch (_) {
            }
            try {
              await db.delete(orders).where(eq4(orders.id, oId));
            } catch (_) {
            }
          }
        } catch (_) {
        }
        try {
          await db.delete(favoriteServices).where(eq4(favoriteServices.serviceId, sId));
        } catch (_) {
        }
        try {
          await db.delete(services).where(eq4(services.id, sId));
        } catch (_) {
        }
      }
      try {
        await db.delete(services).where(eq4(services.categoryId, catId));
      } catch (_) {
      }
      await db.delete(categories).where(eq4(categories.id, catId));
      return true;
    } catch (err) {
      console.error(`[CATEGORY DELETE ERROR] Category #${catId}:`, err);
      return false;
    }
  };
  const chunkArray = (arr, size) => {
    const chunks = [];
    for (let i = 0; i < arr.length; i += size) {
      chunks.push(arr.slice(i, i + size));
    }
    return chunks;
  };
  const catChunks = chunkArray(catIds, 50);
  let totalDeleted = 0;
  for (const catChunk of catChunks) {
    try {
      const catServices = await db.select({ id: services.id }).from(services).where(inArray(services.categoryId, catChunk));
      const serviceIds = catServices.map((s) => s.id);
      if (serviceIds.length > 0) {
        const serviceChunks = chunkArray(serviceIds, 50);
        for (const sChunk of serviceChunks) {
          try {
            const serviceOrders = await db.select({ id: orders.id }).from(orders).where(inArray(orders.serviceId, sChunk));
            const orderIds = serviceOrders.map((o) => o.id);
            if (orderIds.length > 0) {
              const orderChunks = chunkArray(orderIds, 50);
              for (const oChunk of orderChunks) {
                try {
                  await db.delete(refillRequests).where(inArray(refillRequests.orderId, oChunk));
                } catch (_) {
                }
                try {
                  await db.delete(orders).where(inArray(orders.id, oChunk));
                } catch (_) {
                }
              }
            }
          } catch (_) {
          }
          try {
            await db.delete(favoriteServices).where(inArray(favoriteServices.serviceId, sChunk));
          } catch (_) {
          }
          try {
            await db.delete(services).where(inArray(services.id, sChunk));
          } catch (_) {
          }
        }
      }
      try {
        await db.delete(services).where(inArray(services.categoryId, catChunk));
      } catch (_) {
      }
      await db.delete(categories).where(inArray(categories.id, catChunk));
      totalDeleted += catChunk.length;
    } catch (batchErr) {
      console.warn("[BULK CATEGORY DELETE] Batch chunk failed, falling back to individual category deletion:", batchErr);
      for (const singleId of catChunk) {
        const ok = await deleteSingleCategory(singleId);
        if (ok) totalDeleted++;
      }
    }
  }
  return { deletedCount: totalDeleted };
}
router.post("/admin/categories/bulk-delete", requireAdmin, async (req, res) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: "Invalid or empty category IDs array." });
    }
    const catIds = ids.map((id) => parseInt(id)).filter((id) => !isNaN(id));
    if (catIds.length === 0) {
      return res.status(400).json({ error: "No valid category IDs provided." });
    }
    console.log(`[BULK DELETE CATEGORIES] Admin requested deletion of ${catIds.length} categories: [${catIds.join(", ")}]`);
    const result = await safeDeleteCategories(catIds);
    await logActivity(req.user?.id || null, "Bulk Delete Categories", `Bulk deleted ${result.deletedCount} category IDs: ${catIds.join(", ")}`, req.ip);
    res.json({ success: true, count: result.deletedCount });
  } catch (error) {
    console.error("Failed to bulk delete categories:", error);
    res.status(500).json({ error: error?.message || "Failed to bulk delete categories." });
  }
});
router.delete("/admin/categories/:id", requireAdmin, async (req, res) => {
  try {
    const catId = parseInt(req.params.id);
    if (isNaN(catId)) {
      return res.status(400).json({ error: "Invalid category ID." });
    }
    const result = await safeDeleteCategories([catId]);
    if (result.deletedCount === 0) {
      return res.status(500).json({ error: "Failed to delete category." });
    }
    await logActivity(req.user?.id || null, "Delete Category", `Deleted category ID: ${catId}`, req.ip);
    res.json({ success: true });
  } catch (error) {
    console.error("Failed to delete category:", error);
    res.status(500).json({ error: error?.message || "Failed to delete category." });
  }
});
router.delete("/admin/clear-catalog", requireAdmin, async (req, res) => {
  try {
    await db.delete(refillRequests);
    await db.delete(orders);
    await db.delete(favoriteServices);
    await db.delete(services);
    await db.delete(categories);
    await logActivity(req.user?.id || null, "Clear Catalog", "Purged all categories and services from catalog", req.ip);
    res.json({ success: true });
  } catch (error) {
    console.error("Failed to clear catalog:", error);
    res.status(500).json({ error: "Failed to clear catalog." });
  }
});
router.get(["/public-settings", "/public/settings", "/settings/public"], async (req, res) => {
  try {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    const map = await getSettingsMap();
    const publicMap = {};
    const privateKeys = [
      "stripeSecretKey",
      "paypalSecretKey",
      "phonepeSaltKey",
      "phonepeSaltIndex",
      "razorpayKeySecret",
      "googleClientSecret"
    ];
    for (const [key, val] of Object.entries(map)) {
      if (!privateKeys.includes(key)) {
        publicMap[key] = val;
      }
    }
    res.json(publicMap);
  } catch (error) {
    console.error("Failed to get public settings:", error);
    res.status(500).json({ error: "Failed to retrieve public settings." });
  }
});
router.get("/admin/settings", requireAdmin, async (req, res) => {
  try {
    const map = await getSettingsMap();
    res.json(map);
  } catch (error) {
    console.error("Failed to get admin settings:", error);
    res.status(500).json({ error: "Failed to retrieve settings." });
  }
});
router.post("/admin/settings", requireAdmin, async (req, res) => {
  try {
    const payload = req.body;
    if (payload && typeof payload === "object") {
      const entries = Object.entries(payload);
      for (const [key, val] of entries) {
        const stringVal = String(val);
        const existing = await db.select().from(settings).where(eq4(settings.key, key)).limit(1);
        if (existing.length > 0) {
          await db.update(settings).set({ value: stringVal, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(settings.key, key));
        } else {
          await db.insert(settings).values({ key, value: stringVal });
        }
      }
      cachedSettingsMap = null;
      await logActivity(req.user?.id || null, "Update Settings", `Updated settings keys: ${Object.keys(payload).join(", ")}`, req.ip);
      const newMap = await getSettingsMap(true);
      return res.json({ success: true, settings: newMap });
    }
    res.status(400).json({ error: "Invalid settings payload." });
  } catch (error) {
    console.error("Failed to update settings:", error);
    res.status(500).json({ error: "Failed to update settings." });
  }
});
router.post("/admin/bharatpe/request-otp", requireAdmin, async (req, res) => {
  try {
    const { phone } = req.body;
    const cleanPhone = String(phone || "").replace(/\D/g, "").slice(-10);
    if (!cleanPhone || cleanPhone.length !== 10) {
      return res.status(400).json({ error: "Please enter a valid 10-digit mobile number." });
    }
    const generatedOtp = Math.floor(1e5 + Math.random() * 9e5).toString();
    const otpKey = `bharatpe_otp_${cleanPhone}`;
    const otpRecord = JSON.stringify({
      phone: cleanPhone,
      otp: generatedOtp,
      expiresAt: Date.now() + 10 * 60 * 1e3
      // 10 minutes
    });
    const existing = await db.select().from(settings).where(eq4(settings.key, otpKey)).limit(1);
    if (existing.length > 0) {
      await db.update(settings).set({ value: otpRecord, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(settings.key, otpKey));
    } else {
      await db.insert(settings).values({ key: otpKey, value: otpRecord });
    }
    const smsDispatch = await sendOtpSms({
      phone: cleanPhone,
      otp: generatedOtp,
      senderName: "YouthSMM"
    });
    if (!smsDispatch.success) {
      console.warn(`[BharatPe OTP] SMS dispatch failed for +91 ${cleanPhone}:`, smsDispatch.message);
      return res.status(400).json({
        error: smsDispatch.message || "Failed to dispatch SMS to mobile phone.",
        missingGateway: smsDispatch.provider === "none",
        provider: smsDispatch.provider,
        phone: cleanPhone
      });
    }
    await logActivity(req.user?.id || null, "BharatPe OTP Request", `Requested OTP SMS for phone number: +91 ${cleanPhone} (${smsDispatch.provider})`, req.ip);
    res.json({
      success: true,
      message: smsDispatch.message || `A 6-digit verification code has been sent via SMS to +91 ${cleanPhone}. Please check your phone.`,
      provider: smsDispatch.provider,
      phone: cleanPhone
    });
  } catch (error) {
    console.error("BharatPe OTP Request failed:", error);
    res.status(500).json({ error: "Internal server error." });
  }
});
router.post("/admin/bharatpe/verify-otp", requireAdmin, async (req, res) => {
  try {
    const { phone, otp, merchantName, vpa, qrUrl } = req.body;
    const cleanPhone = String(phone || "").replace(/\D/g, "").slice(-10);
    if (!cleanPhone || !otp) {
      return res.status(400).json({ error: "Phone and OTP are required." });
    }
    const submittedOtp = String(otp).trim();
    if (submittedOtp.length !== 6 || !/^\d{6}$/.test(submittedOtp)) {
      return res.status(400).json({ error: "OTP must be a valid 6-digit numeric code." });
    }
    const otpKey = `bharatpe_otp_${cleanPhone}`;
    const storedRecord = await db.select().from(settings).where(eq4(settings.key, otpKey)).limit(1);
    if (storedRecord.length === 0) {
      return res.status(400).json({
        error: 'No active OTP request found for this phone number. Please click "Send Verification OTP" first.'
      });
    }
    let storedData = null;
    try {
      storedData = JSON.parse(storedRecord[0].value);
    } catch {
      storedData = null;
    }
    if (!storedData || !storedData.otp) {
      return res.status(400).json({
        error: "Invalid OTP session. Please request a new verification OTP."
      });
    }
    if (Date.now() > storedData.expiresAt) {
      await db.delete(settings).where(eq4(settings.key, otpKey));
      return res.status(400).json({
        error: 'Verification OTP has expired. Please click "Resend SMS" to get a new code.'
      });
    }
    if (storedData.otp !== submittedOtp) {
      return res.status(400).json({
        error: "Incorrect OTP! The 6-digit code you entered does not match the verification code sent to your phone. Random or dummy codes are rejected."
      });
    }
    const realMerchantId = (process.env.BHARATPE_MERCHANT_ID || process.env.MERCHANT_ID || process.env.BHARATPE_MID || process.env.MID || "").trim();
    const realToken = (process.env.BHARATPE_TOKEN || process.env.TOKEN || process.env.BHARATPE_API_KEY || process.env.API_KEY || "").trim();
    const finalMerchantName = merchantName?.trim() || process.env.BHARATPE_MERCHANT_NAME || "YouthSMM";
    const finalVpa = vpa?.trim() || process.env.BHARATPE_VPA || "BHARATPE2H0D0Q1Y4T29351@unitype";
    const finalQrUrl = qrUrl?.trim() || process.env.BHARATPE_QR_URL || "https://cdn.phototourl.com/free/2026-08-18-f25c7129-6d72-4b7a-9d01-b64aafa3d060.jpg";
    const updates = {
      bharatpePhone: cleanPhone,
      bharatpeMerchantId: realMerchantId,
      bharatpeToken: realToken,
      bharatpeMerchantName: finalMerchantName,
      bharatpeVpa: finalVpa,
      bharatpeQrUrl: finalQrUrl,
      bharatpeStatus: "linked",
      allUpiMerchantName: finalMerchantName,
      allUpiVpa: finalVpa,
      allUpiQrUrl: finalQrUrl,
      allUpiStatus: "enabled"
    };
    for (const [key, value] of Object.entries(updates)) {
      const existing = await db.select().from(settings).where(eq4(settings.key, key)).limit(1);
      if (existing.length > 0) {
        await db.update(settings).set({ value, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(settings.key, key));
      } else {
        await db.insert(settings).values({ key, value });
      }
    }
    await db.delete(settings).where(eq4(settings.key, otpKey));
    await logActivity(req.user?.id || null, "BharatPe QR Linked", `Linked Real BharatPe Merchant account (${finalMerchantName}) for +91 ${cleanPhone}`, req.ip);
    const newMap = await getSettingsMap();
    res.json({
      success: true,
      message: "Real BharatPe Merchant QR connected and activated successfully!",
      settings: newMap,
      qrUrl: finalQrUrl,
      vpa: finalVpa,
      merchantName: finalMerchantName
    });
  } catch (error) {
    console.error("BharatPe OTP Verify failed:", error);
    res.status(500).json({ error: "Internal server error." });
  }
});
router.post("/admin/bharatpe/unlink", requireAdmin, async (req, res) => {
  try {
    const resets = {
      bharatpePhone: "",
      bharatpeMerchantName: "",
      bharatpeVpa: "",
      bharatpeStatus: "unlinked"
    };
    for (const [key, value] of Object.entries(resets)) {
      const existing = await db.select().from(settings).where(eq4(settings.key, key)).limit(1);
      if (existing.length > 0) {
        await db.update(settings).set({ value, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(settings.key, key));
      } else {
        await db.insert(settings).values({ key, value });
      }
    }
    await logActivity(req.user?.id || null, "BharatPe QR Unlinked", "Unlinked BharatPe Merchant account", req.ip);
    const newMap = await getSettingsMap();
    res.json({
      success: true,
      message: "BharatPe Merchant QR Unlinked successfully!",
      settings: newMap
    });
  } catch (error) {
    console.error("BharatPe Unlink failed:", error);
    res.status(500).json({ error: "Internal server error." });
  }
});
router.post("/bharatpe/lookup/request-otp", async (req, res) => {
  try {
    const { phone } = req.body;
    const cleanPhone = String(phone || "").replace(/\D/g, "").slice(-10);
    if (!cleanPhone || cleanPhone.length !== 10) {
      return res.status(400).json({ error: "Please enter a valid 10-digit mobile number." });
    }
    const generatedOtp = Math.floor(1e5 + Math.random() * 9e5).toString();
    const otpKey = `bharatpe_lookup_otp_${cleanPhone}`;
    const otpRecord = JSON.stringify({
      phone: cleanPhone,
      otp: generatedOtp,
      expiresAt: Date.now() + 10 * 60 * 1e3
    });
    const existing = await db.select().from(settings).where(eq4(settings.key, otpKey)).limit(1);
    if (existing.length > 0) {
      await db.update(settings).set({ value: otpRecord, updatedAt: /* @__PURE__ */ new Date() }).where(eq4(settings.key, otpKey));
    } else {
      await db.insert(settings).values({ key: otpKey, value: otpRecord });
    }
    const smsDispatch = await sendOtpSms({
      phone: cleanPhone,
      otp: generatedOtp,
      senderName: "YouthSMM"
    });
    if (!smsDispatch.success) {
      return res.status(400).json({
        error: smsDispatch.message || "Failed to dispatch SMS to mobile carrier.",
        missingGateway: smsDispatch.provider === "none",
        provider: smsDispatch.provider
      });
    }
    res.json({
      success: true,
      message: `A 6-digit verification code has been dispatched via SMS to +91 ${cleanPhone}.`,
      provider: smsDispatch.provider
    });
  } catch (error) {
    console.error("BharatPe lookup request OTP error:", error);
    res.status(500).json({ error: "Internal server error processing OTP request." });
  }
});
router.post("/bharatpe/lookup/verify-otp", async (req, res) => {
  try {
    const { phone, otp } = req.body;
    const cleanPhone = String(phone || "").replace(/\D/g, "").slice(-10);
    const submittedOtp = String(otp || "").trim();
    if (!cleanPhone || cleanPhone.length !== 10) {
      return res.status(400).json({ error: "Valid 10-digit phone number is required." });
    }
    if (!submittedOtp || submittedOtp.length !== 6 || !/^\d{6}$/.test(submittedOtp)) {
      return res.status(400).json({ error: "Please enter a valid 6-digit numeric OTP code." });
    }
    const otpKey = `bharatpe_lookup_otp_${cleanPhone}`;
    const storedRecord = await db.select().from(settings).where(eq4(settings.key, otpKey)).limit(1);
    if (storedRecord.length === 0) {
      return res.status(400).json({
        error: 'No active OTP request found for this phone number. Please click "Send OTP" first.'
      });
    }
    let storedData = null;
    try {
      storedData = JSON.parse(storedRecord[0].value);
    } catch {
      storedData = null;
    }
    if (!storedData || !storedData.otp) {
      return res.status(400).json({ error: "Invalid or expired OTP session. Please request a new OTP." });
    }
    if (Date.now() > storedData.expiresAt) {
      await db.delete(settings).where(eq4(settings.key, otpKey));
      return res.status(400).json({ error: "OTP has expired. Please request a new OTP." });
    }
    if (storedData.otp !== submittedOtp) {
      return res.status(400).json({ error: "Incorrect OTP code! Please enter the exact 6 digits received on your phone." });
    }
    await db.delete(settings).where(eq4(settings.key, otpKey));
    const settingsMap = await getSettingsMap();
    const merchantId = (process.env.BHARATPE_MERCHANT_ID || settingsMap["bharatpeMerchantId"] || "").trim();
    const token = (process.env.BHARATPE_TOKEN || settingsMap["bharatpeToken"] || "").trim();
    const merchantName = settingsMap["bharatpeMerchantName"] || "PRIYA";
    const vpa = settingsMap["bharatpeVpa"] || "BHARATPE2H0D0Q1Y4T29351@unitype";
    res.json({
      success: true,
      message: "Mobile OTP verified successfully!",
      merchantId: merchantId || "Configured in Vercel / Settings",
      token: token || "Configured in Vercel / Settings",
      merchantName,
      vpa,
      phone: cleanPhone
    });
  } catch (error) {
    console.error("BharatPe lookup verify OTP error:", error);
    res.status(500).json({ error: "Internal server error verifying OTP." });
  }
});
router.get("/blogs", async (req, res) => {
  try {
    const list = await db.select({
      id: blogs.id,
      title: blogs.title,
      slug: blogs.slug,
      content: blogs.content,
      authorId: blogs.authorId,
      status: blogs.status,
      coverImage: blogs.coverImage,
      createdAt: blogs.createdAt,
      updatedAt: blogs.updatedAt,
      authorName: users.name
    }).from(blogs).leftJoin(users, eq4(blogs.authorId, users.id)).where(eq4(blogs.status, "published")).orderBy(desc3(blogs.createdAt));
    res.json(list);
  } catch (error) {
    console.error("Failed to get blogs:", error);
    res.status(500).json({ error: "Failed to retrieve blog posts." });
  }
});
router.get("/blogs/:identifier", async (req, res) => {
  try {
    const { identifier } = req.params;
    const isId = /^\d+$/.test(identifier);
    const condition = isId ? eq4(blogs.id, parseInt(identifier, 10)) : eq4(blogs.slug, identifier);
    const result = await db.select({
      id: blogs.id,
      title: blogs.title,
      slug: blogs.slug,
      content: blogs.content,
      authorId: blogs.authorId,
      status: blogs.status,
      coverImage: blogs.coverImage,
      createdAt: blogs.createdAt,
      updatedAt: blogs.updatedAt,
      authorName: users.name
    }).from(blogs).leftJoin(users, eq4(blogs.authorId, users.id)).where(condition).limit(1);
    if (result.length === 0) {
      return res.status(404).json({ error: "Blog post not found." });
    }
    res.json(result[0]);
  } catch (error) {
    console.error("Failed to get blog:", error);
    res.status(500).json({ error: "Failed to retrieve the blog post." });
  }
});
router.get("/admin/blogs", requireAdmin, async (req, res) => {
  try {
    const list = await db.select({
      id: blogs.id,
      title: blogs.title,
      slug: blogs.slug,
      content: blogs.content,
      authorId: blogs.authorId,
      status: blogs.status,
      coverImage: blogs.coverImage,
      createdAt: blogs.createdAt,
      updatedAt: blogs.updatedAt,
      authorName: users.name
    }).from(blogs).leftJoin(users, eq4(blogs.authorId, users.id)).orderBy(desc3(blogs.createdAt));
    res.json(list);
  } catch (error) {
    console.error("Failed to get admin blogs:", error);
    res.status(500).json({ error: "Failed to retrieve admin blog posts." });
  }
});
router.post("/admin/blogs", requireAdmin, async (req, res) => {
  try {
    const { title, slug, content, status, coverImage } = req.body;
    if (!title || !title.toString().trim()) {
      return res.status(400).json({ error: "Post title is required." });
    }
    if (!content || !content.toString().trim()) {
      return res.status(400).json({ error: "Post content is required." });
    }
    const trimmedTitle = title.toString().trim();
    const rawSlug = slug && slug.toString().trim() ? slug.toString().trim() : trimmedTitle;
    let cleanSlug = rawSlug.toLowerCase().replace(/[^a-z0-9-_]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
    if (!cleanSlug) {
      cleanSlug = `post-${Date.now().toString(36)}`;
    }
    const existing = await db.select().from(blogs).where(eq4(blogs.slug, cleanSlug)).limit(1);
    if (existing.length > 0) {
      cleanSlug = `${cleanSlug}-${Date.now().toString(36)}`;
    }
    let safeAuthorId = null;
    if (req.user?.id && typeof req.user.id === "number") {
      try {
        const userExists = await db.select({ id: users.id }).from(users).where(eq4(users.id, req.user.id)).limit(1);
        if (userExists.length > 0) {
          safeAuthorId = req.user.id;
        }
      } catch (checkErr) {
        console.warn("Author verification fallback:", checkErr);
      }
    }
    const trimmedCover = coverImage && coverImage.toString().trim() ? coverImage.toString().trim() : null;
    const postStatus = status === "draft" ? "draft" : "published";
    const [newBlog] = await db.insert(blogs).values({
      title: trimmedTitle,
      slug: cleanSlug,
      content: content.toString().trim(),
      authorId: safeAuthorId,
      status: postStatus,
      coverImage: trimmedCover,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    }).returning();
    try {
      await logActivity(safeAuthorId, "Create Blog", `Created blog post: "${trimmedTitle}"`, req.ip || null);
    } catch (logErr) {
      console.warn("Blog log activity error:", logErr);
    }
    res.status(201).json(newBlog);
  } catch (error) {
    console.error("Failed to create blog:", error);
    res.status(500).json({ error: error?.message || "Failed to create blog post." });
  }
});
router.put("/admin/blogs/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid blog ID." });
    }
    const { title, slug, content, status, coverImage } = req.body;
    if (!title || !title.toString().trim()) {
      return res.status(400).json({ error: "Post title is required." });
    }
    if (!content || !content.toString().trim()) {
      return res.status(400).json({ error: "Post content is required." });
    }
    const trimmedTitle = title.toString().trim();
    const existingBlog = await db.select().from(blogs).where(eq4(blogs.id, id)).limit(1);
    if (existingBlog.length === 0) {
      return res.status(404).json({ error: "Blog post not found." });
    }
    const rawSlug = slug && slug.toString().trim() ? slug.toString().trim() : trimmedTitle;
    let cleanSlug = rawSlug.toLowerCase().replace(/[^a-z0-9-_]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
    if (!cleanSlug) {
      cleanSlug = `post-${id}`;
    }
    const taken = await db.select().from(blogs).where(and(eq4(blogs.slug, cleanSlug), sql2`${blogs.id} != ${id}`)).limit(1);
    if (taken.length > 0) {
      cleanSlug = `${cleanSlug}-${Date.now().toString(36)}`;
    }
    const trimmedCover = coverImage && coverImage.toString().trim() ? coverImage.toString().trim() : null;
    const postStatus = status === "draft" ? "draft" : "published";
    const [updatedBlog] = await db.update(blogs).set({
      title: trimmedTitle,
      slug: cleanSlug,
      content: content.toString().trim(),
      status: postStatus,
      coverImage: trimmedCover,
      updatedAt: /* @__PURE__ */ new Date()
    }).where(eq4(blogs.id, id)).returning();
    try {
      await logActivity(req.user?.id || null, "Update Blog", `Updated blog post: "${trimmedTitle}"`, req.ip || null);
    } catch (logErr) {
      console.warn("Blog log activity error:", logErr);
    }
    res.json(updatedBlog);
  } catch (error) {
    console.error("Failed to update blog:", error);
    res.status(500).json({ error: error?.message || "Failed to update blog post." });
  }
});
router.delete("/admin/blogs/:id", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const existingBlog = await db.select().from(blogs).where(eq4(blogs.id, id)).limit(1);
    if (existingBlog.length === 0) {
      return res.status(404).json({ error: "Blog post not found." });
    }
    await db.delete(blogs).where(eq4(blogs.id, id));
    await logActivity(req.user?.id || null, "Delete Blog", `Deleted blog post: "${existingBlog[0].title}"`, req.ip);
    res.json({ success: true, message: "Blog post deleted successfully." });
  } catch (error) {
    console.error("Failed to delete blog:", error);
    res.status(500).json({ error: "Failed to delete blog post." });
  }
});
router.post("/ai/chat", async (req, res) => {
  try {
    const { message, history, userId } = req.body;
    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "A message prompt is required." });
    }
    const result = await handleAiChat({
      message,
      history: history || [],
      userId: userId ? Number(userId) : void 0
    });
    res.json(result);
  } catch (error) {
    console.error("AI Chatbot endpoint error:", error);
    res.status(500).json({
      success: false,
      error: error?.message || "Failed to process AI chat request."
    });
  }
});
router.post("/appointments", async (req, res) => {
  try {
    const { name, email, phone, date, timeSlot, time_slot, serviceType, service_type, message, userId } = req.body;
    if (!name || !email || !date) {
      return res.status(400).json({ error: "Name, email, and date are required to book an appointment." });
    }
    const slot = timeSlot || time_slot || "10:00 AM - 11:00 AM";
    const sType = serviceType || service_type || "General Consultation";
    const assignedUserId = req.user?.id || (userId ? Number(userId) : null);
    let supabaseSaved = false;
    let supabaseRecord = null;
    try {
      const supabase = getSupabaseServer();
      const payload = {
        name,
        email: email.trim().toLowerCase(),
        phone: phone || "",
        date,
        time_slot: slot,
        service_type: sType,
        message: message || "",
        status: "pending",
        user_id: assignedUserId ? String(assignedUserId) : null,
        created_at: (/* @__PURE__ */ new Date()).toISOString()
      };
      const { data: inserted, error: sbError } = await supabase.from("appointments").insert([payload]).select();
      if (!sbError && inserted && inserted.length > 0) {
        supabaseSaved = true;
        supabaseRecord = inserted[0];
      } else if (sbError) {
        console.warn("Supabase primary insert warning:", sbError.message);
        const { data: bData, error: bError } = await supabase.from("bookings").insert([payload]).select();
        if (!bError && bData && bData.length > 0) {
          supabaseSaved = true;
          supabaseRecord = bData[0];
        }
      }
    } catch (sbErr) {
      console.warn("Supabase direct connection note:", sbErr?.message || sbErr);
    }
    let localRecord = null;
    try {
      const [insertedLocal] = await db.insert(appointments).values({
        userId: assignedUserId,
        name,
        email: email.trim().toLowerCase(),
        phone: phone || "",
        date,
        timeSlot: slot,
        serviceType: sType,
        message: message || "",
        status: "pending"
      }).returning();
      localRecord = insertedLocal;
    } catch (dbErr) {
      console.warn("Local database appointment insert note:", dbErr);
    }
    const resultAppointment = supabaseRecord || localRecord || {
      id: Date.now(),
      name,
      email,
      phone,
      date,
      timeSlot: slot,
      serviceType: sType,
      message,
      status: "pending",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (assignedUserId) {
      await logActivity(assignedUserId, "Booked Appointment", `Booked appointment for ${date} (${slot})`, req.ip || null);
    }
    res.json({
      success: true,
      message: "Your appointment booking has been successfully confirmed and saved to the Supabase backend.",
      appointment: resultAppointment,
      supabaseSaved
    });
  } catch (error) {
    console.error("Failed to create appointment booking:", error);
    res.status(500).json({ error: error?.message || "Failed to book appointment." });
  }
});
router.get("/appointments", async (req, res) => {
  try {
    const isAdmin = req.user && req.user.role === "admin";
    const currentUserId = req.user ? req.user.id : null;
    const emailQuery = req.query.email ? String(req.query.email).trim().toLowerCase() : null;
    try {
      const supabase = getSupabaseServer();
      let query = supabase.from("appointments").select("*").order("created_at", { ascending: false });
      if (!isAdmin) {
        if (currentUserId) {
          query = query.or(`user_id.eq.${currentUserId},email.eq.${req.user?.email}`);
        } else if (emailQuery) {
          query = query.eq("email", emailQuery);
        }
      }
      const { data: sbAppointments, error } = await query;
      if (!error && sbAppointments && sbAppointments.length > 0) {
        const formatted = sbAppointments.map((a) => ({
          id: a.id,
          userId: a.user_id ? Number(a.user_id) : null,
          name: a.name,
          email: a.email,
          phone: a.phone || "",
          date: a.date,
          timeSlot: a.time_slot || a.timeSlot,
          serviceType: a.service_type || a.serviceType || "General Consultation",
          message: a.message || "",
          status: a.status || "pending",
          createdAt: a.created_at || a.createdAt
        }));
        return res.json({ success: true, appointments: formatted });
      }
    } catch (sbErr) {
      console.warn("Supabase fetch note:", sbErr);
    }
    try {
      let localQuery = db.select().from(appointments).orderBy(desc3(appointments.createdAt));
      if (!isAdmin && currentUserId) {
        const list2 = await db.select().from(appointments).where(or2(eq4(appointments.userId, currentUserId), eq4(appointments.email, req.user.email))).orderBy(desc3(appointments.createdAt));
        return res.json({ success: true, appointments: list2 });
      }
      const list = await localQuery;
      return res.json({ success: true, appointments: list });
    } catch (dbErr) {
      return res.json({ success: true, appointments: [] });
    }
  } catch (error) {
    console.error("Failed to get appointments:", error);
    res.status(500).json({ error: "Failed to retrieve appointments." });
  }
});
router.patch("/appointments/:id/status", async (req, res) => {
  try {
    const appointmentId = req.params.id;
    const { status } = req.body;
    if (!status) {
      return res.status(400).json({ error: "Status is required." });
    }
    try {
      const supabase = getSupabaseServer();
      await supabase.from("appointments").update({ status }).eq("id", appointmentId);
    } catch (sbErr) {
      console.warn("Supabase status update note:", sbErr);
    }
    try {
      const numId = Number(appointmentId);
      if (!isNaN(numId)) {
        await db.update(appointments).set({ status }).where(eq4(appointments.id, numId));
      }
    } catch (dbErr) {
      console.warn("Local database status update note:", dbErr);
    }
    res.json({ success: true, message: `Appointment status updated to ${status}.` });
  } catch (error) {
    console.error("Failed to update appointment status:", error);
    res.status(500).json({ error: "Failed to update appointment status." });
  }
});
router.delete("/appointments/:id", requireAdmin, async (req, res) => {
  try {
    const appointmentId = req.params.id;
    try {
      const supabase = getSupabaseServer();
      await supabase.from("appointments").delete().eq("id", appointmentId);
    } catch (sbErr) {
      console.warn("Supabase delete note:", sbErr);
    }
    try {
      const numId = Number(appointmentId);
      if (!isNaN(numId)) {
        await db.delete(appointments).where(eq4(appointments.id, numId));
      }
    } catch (dbErr) {
      console.warn("Local DB delete note:", dbErr);
    }
    res.json({ success: true, message: "Appointment deleted successfully." });
  } catch (error) {
    console.error("Failed to delete appointment:", error);
    res.status(500).json({ error: "Failed to delete appointment." });
  }
});
var api_default = router;

// src/server/vercel.ts
dotenv.config();
var app = express();
app.use(cors({
  origin: true,
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
  allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With", "Accept"]
}));
app.use(cookieParser());
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: true, limit: "20mb" }));
app.get("/api/health", (req, res) => {
  res.setHeader("Content-Type", "application/json");
  res.json({ status: "ok", time: /* @__PURE__ */ new Date() });
});
app.use("/api", api_default);
app.use("/", (req, res, next) => {
  if (req.path.startsWith("/api")) {
    return next();
  }
  next();
}, api_default);
app.all("/api/*", (req, res) => {
  res.status(404).json({ error: `API route ${req.method} ${req.path} not found.` });
});
app.use((err, req, res, next) => {
  console.error("[Vercel Serverless Error]", err);
  res.status(err.status || 500).json({ error: err.message || "Internal Server Error" });
});
var vercel_default = app;
export {
  vercel_default as default
};
